import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<!-- SIDEBAR -->
    <aside>
        <div class="user-profile-section">
            <div class="avatar-container">
                <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150&h=150" alt="User Avatar">
                <div class="avatar-overlay">
                    <i class="fas fa-camera"></i>
                </div>
            </div>
            <h3 class="user-name">Jonathan Miller</h3>
            <span class="user-role">Premium Partner</span>
            <span class="status-badge">Active</span>
        </div>

        <nav class="nav-menu">
            <a href="#" class="nav-item active"><i class="fas fa-th-large"></i> Dashboard</a>
            <a href="#" class="nav-item"><i class="fas fa-user"></i> Profile</a>
            <a href="#" class="nav-item"><i class="fas fa-file-invoice-dollar"></i> Leads</a>
            <a href="#" class="nav-item"><i class="fas fa-hand-holding-usd"></i> Commissions</a>
            <a href="#" class="nav-item"><i class="fas fa-folder-open"></i> Documents</a>
            <a href="#" class="nav-item"><i class="fas fa-cog"></i> Settings</a>
            <a href="#" class="nav-item"><i class="fas fa-shield-alt"></i> Security</a>
            <a href="#" class="nav-item"><i class="fas fa-comment-alt"></i> Messages</a>
            <a href="#" class="nav-item"><i class="fas fa-graduation-cap"></i> Resources</a>
            <a href="#" class="nav-item"><i class="fas fa-question-circle"></i> Help & Support</a>
        </nav>
    </aside>

    <!-- MAIN CONTENT -->
    <main>
        <header>
            <div class="welcome-text">
                <h1>Welcome back, Jonathan</h1>
                <p>Here's what's happening with your portfolio today.</p>
            </div>
            <div class="header-actions">
                <div class="search-bar">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search leads, docs...">
                </div>
                <div class="notification-bell">
                    <i class="fas fa-bell"></i>
                    <div class="notification-dot"></div>
                </div>
                <button class="btn btn-primary">
                    <i class="fas fa-plus"></i> Submit New Lead
                </button>
            </div>
        </header>

        <div class="dashboard-grid">
            <!-- QUICK ACTIONS -->
            <div class="card quick-action-card">
                <div class="icon-circle navy-icon"><i class="fas fa-paper-plane"></i></div>
                <h4>Submit Lead</h4>
                <p style="font-size: 0.85rem; color: var(--text-muted); margin-top: 8px;">Start a new funding request for a client.</p>
            </div>

            <div class="card quick-action-card">
                <div class="icon-circle green-icon"><i class="fas fa-file-upload"></i></div>
                <h4>Upload Docs</h4>
                <p style="font-size: 0.85rem; color: var(--text-muted); margin-top: 8px;">Drag and drop financial statements here.</p>
            </div>

            <div class="card quick-action-card">
                <div class="icon-circle orange-icon"><i class="fas fa-headset"></i></div>
                <h4>Support</h4>
                <p style="font-size: 0.85rem; color: var(--text-muted); margin-top: 8px;">Chat with your dedicated account manager.</p>
            </div>

            <!-- STATUS OVERVIEW (For Partner Style) -->
            <div class="card two-thirds">
                <div class="card-title">
                    Active Leads Overview
                    <a href="#" style="font-size: 0.8rem; color: var(--brand-navy-light); text-decoration: none;">View All</a>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>Client Name</th>
                            <th>Product</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Apex Logistics LLC</td>
                            <td>Working Capital</td>
                            <td>\$125,000</td>
                            <td><span class="status-pill pill-funded">Funded</span></td>
                            <td><button class="btn btn-outline" style="padding: 5px 10px;">Details</button></td>
                        </tr>
                        <tr>
                            <td>Green Valley Retail</td>
                            <td>SBA Loan</td>
                            <td>\$450,000</td>
                            <td><span class="status-pill pill-review">Under Review</span></td>
                            <td><button class="btn btn-outline" style="padding: 5px 10px;">Details</button></td>
                        </tr>
                        <tr>
                            <td>Blue Wave Tech</td>
                            <td>Equipment Fin.</td>
                            <td>\$68,000</td>
                            <td><span class="status-pill pill-draft">Draft</span></td>
                            <td><button class="btn btn-outline" style="padding: 5px 10px;">Details</button></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- COMMISSIONS STATS -->
            <div class="card one-third">
                <div class="card-title">Earnings</div>
                <div style="margin-top: 20px;">
                    <span style="font-size: 0.85rem; color: var(--text-muted);">This Month</span>
                    <h2 style="font-size: 2rem; color: var(--brand-navy);">\$12,450.00</h2>
                    <div class="progress-container">
                        <div class="progress-bar" style="width: 75%;"></div>
                    </div>
                    <p style="font-size: 0.75rem; color: var(--text-muted);">75% of your monthly goal</p>
                </div>
                <div style="margin-top: 24px; display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                    <div style="background: var(--bg-light); padding: 12px; border-radius: 8px;">
                        <span style="font-size: 0.75rem; color: var(--text-muted);">Pending</span>
                        <div style="font-weight: 700; color: var(--warning-orange);">\$3,200</div>
                    </div>
                    <div style="background: var(--bg-light); padding: 12px; border-radius: 8px;">
                        <span style="font-size: 0.75rem; color: var(--text-muted);">Lifetime</span>
                        <div style="font-weight: 700; color: var(--success-green);">\$142.8k</div>
                    </div>
                </div>
                <button class="btn btn-primary" style="width: 100%; margin-top: 20px; justify-content: center;">Request Payout</button>
            </div>

            <!-- RECENT ACTIVITY -->
            <div class="card one-third">
                <div class="card-title">Recent Activity</div>
                <div class="timeline">
                    <div class="timeline-item">
                        <div class="timeline-content">
                            <h4>Commission Paid</h4>
                            <p>Deal #8842 funded successfully. +\$1,200 credited.</p>
                            <small style="color: var(--text-muted);">2 hours ago</small>
                        </div>
                    </div>
                    <div class="timeline-item">
                        <div class="timeline-content">
                            <h4>Document Approved</h4>
                            <p>Tax returns for "Apex Logistics" verified.</p>
                            <small style="color: var(--text-muted);">Yesterday, 4:15 PM</small>
                        </div>
                    </div>
                    <div class="timeline-item">
                        <div class="timeline-content">
                            <h4>New Message</h4>
                            <p>From Underwriter: "Need clarify on Q3 P&L."</p>
                            <small style="color: var(--text-muted);">Oct 24, 10:30 AM</small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- DOCUMENTS SUMMARY -->
            <div class="card two-thirds">
                <div class="card-title">
                    Missing Documents
                    <span style="background: var(--danger-red); color: white; padding: 2px 8px; border-radius: 10px; font-size: 0.7rem;">3 Action Items</span>
                </div>
                <div style="display: flex; flex-direction: column; gap: 12px; margin-top: 10px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 12px; border: 1px dashed var(--warning-orange); border-radius: 8px; background: rgba(245, 158, 11, 0.02);">
                        <div style="display: flex; align-items: center; gap: 12px;">
                            <i class="fas fa-file-pdf" style="color: #ef4444; font-size: 1.5rem;"></i>
                            <div>
                                <h5 style="font-size: 0.9rem;">2023 Corporate Tax Returns</h5>
                                <p style="font-size: 0.75rem; color: var(--text-muted);">Required for Green Valley Retail</p>
                            </div>
                        </div>
                        <button class="btn btn-outline" style="padding: 6px 12px; font-size: 0.8rem;">Upload</button>
                    </div>
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 12px; border: 1px dashed var(--border-color); border-radius: 8px;">
                        <div style="display: flex; align-items: center; gap: 12px;">
                            <i class="fas fa-file-invoice" style="color: var(--brand-navy); font-size: 1.5rem;"></i>
                            <div>
                                <h5 style="font-size: 0.9rem;">Voided Check / Bank Letter</h5>
                                <p style="font-size: 0.75rem; color: var(--text-muted);">Required for payout setup</p>
                            </div>
                        </div>
                        <button class="btn btn-outline" style="padding: 6px 12px; font-size: 0.8rem;">Upload</button>
                    </div>
                </div>
            </div>

        </div>
    </main>

    <!-- MOBILE OVERLAY -->
    <script>
        // Simple script to handle navigation "active" states
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', function(e) {
                document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
                this.classList.add('active');
            });
        });
    </script>
      ` }} />
    </main>
  );
}
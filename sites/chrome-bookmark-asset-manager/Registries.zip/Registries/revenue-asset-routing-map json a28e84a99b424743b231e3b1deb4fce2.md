# revenue-asset-routing-map.json

Description: First-pass revenue asset routing map — 23 entries routing existing assets into fast public value, lead capture, integrations, service offers, and micro-venture opportunities, with launch queues and quick-win fixes.
Suggested Fields: asset_id, asset_name, asset_type, asset_family, audience, problem_solved, revenue_angle, free_value_path, lead_capture_path, paid_offer_path, launch_readiness, fastest_next_action
Last Updated: July 3, 2026 8:37 PM

<aside>
🎯

First-pass revenue asset routing map. 23 entries routing existing assets into fast public value, lead capture, integrations, service offers, and micro-venture opportunities, plus launch queues and quick-win fixes.

</aside>

## revenue-asset-routing-map.json

[revenue-asset-routing-map.json](revenue-asset-routing-map%20json/27b688a2-db1e-4eee-b690-5f96b9aa4676.json)

revenue-asset-routing-map.json

<aside>
✅

The attached file is the source of truth for this entry.

</aside>

### 🧱 Suggested Fields

```json
{
  "asset_id": "",
  "asset_name": "",
  "asset_type": "",
  "asset_family": "",
  "audience": "",
  "problem_solved": "",
  "revenue_angle": "",
  "free_value_path": "",
  "lead_capture_path": "",
  "paid_offer_path": "",
  "launch_readiness": "",
  "fastest_next_action": ""
}
```
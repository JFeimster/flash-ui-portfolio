# funnel-routes.registry.json

Description: Valuable once you map tool → offer → form → CRM/follow-up.
Last Updated: June 9, 2026 4:16 AM
# fundability-checklist.registry.json

Description: The Fundability Foundation items vendors verify before approval — feeds a readiness widget/scorecard. Pairs with funding-scorecard.registry.json.
Suggested Fields: item_id, requirement, category, why_it_matters, required_for_tier
File: fundability-checklist.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
🎯

The Fundability Foundation checklist. Mismatched/missing items trigger instant denials, so this is the gate before applying anywhere.

</aside>

## Completed Registry — fundability-checklist.registry.json

```json
[
  { "item_id": "registered-entity", "requirement": "Registered business entity (LLC or corporation) with the Secretary of State", "category": "Entity", "why_it_matters": "Establishes a legal entity separate from the owner; required before any business credit.", "required_for_tier": 1 },
  { "item_id": "ein", "requirement": "EIN issued by the IRS", "category": "Identity", "why_it_matters": "The business tax ID used in place of an SSN for EIN-only credit.", "required_for_tier": 1 },
  { "item_id": "business-phone-411", "requirement": "Business phone number listed with 411 under the business name", "category": "Listings", "why_it_matters": "Vendors and lenders verify a listed business line; missing listing is a red flag.", "required_for_tier": 1 },
  { "item_id": "business-address", "requirement": "Professional business address (no PO box or home address)", "category": "Identity", "why_it_matters": "Home/PO box addresses trigger denials; address must match all records.", "required_for_tier": 1 },
  { "item_id": "domain-email", "requirement": "Business domain and professional email (e.g. info@yourbusiness.com)", "category": "Web Presence", "why_it_matters": "Free email domains look unestablished; matching domain reinforces legitimacy.", "required_for_tier": 1 },
  { "item_id": "business-bank-account", "requirement": "Business bank account in the exact entity name", "category": "Banking", "why_it_matters": "Seasoned account with healthy balances is required for higher tiers and bank financing.", "required_for_tier": 1 },
  { "item_id": "duns-number", "requirement": "D-U-N-S number from Dun & Bradstreet", "category": "Identity", "why_it_matters": "Required to build a D&B file and Paydex score; free to obtain.", "required_for_tier": 1 },
  { "item_id": "naics-code", "requirement": "NAICS code that is not in a high-risk bucket", "category": "Classification", "why_it_matters": "High-risk industry codes (gambling, some finance) auto-flag applications.", "required_for_tier": 4 },
  { "item_id": "website", "requirement": "Live, professional business website", "category": "Web Presence", "why_it_matters": "Underwriters check for a real web presence consistent with the listing.", "required_for_tier": 1 },
  { "item_id": "listing-consistency", "requirement": "Consistent name/address/phone across 411, D&B, and Secretary of State", "category": "Listings", "why_it_matters": "Mismatched or missing data across sources is the leading cause of denials.", "required_for_tier": 1 }
]
```

## Drafting & Schema Details

### 🧱 Suggested Fields

```json
{
  "item_id": "",
  "requirement": "",
  "category": "",
  "why_it_matters": "",
  "required_for_tier": 1
}
```

### 📌 Example entry

```json
{
  "item_id": "duns-number",
  "requirement": "D-U-N-S number from Dun & Bradstreet",
  "category": "Identity",
  "why_it_matters": "Vendors verify it; missing or mismatched data triggers instant denials.",
  "required_for_tier": 1
}
```

### 

```jsx

```
# funding-providers.registry.json

Description: Lenders/partners with financing products, eligibility, terms, routing, and affiliate config — the layer the matching engine scores against. 33 active partners: 31 from the Funding Partners Database (affiliate URLs, commission rates, contacts populated) plus Blue Bridge Financial and National Business Capital added from the product catalog (affiliate/contact details pending).
Suggested Fields: id, slug, name, providerCategory, fundingModels, productFamilyIds, financingProducts, geographicCoverage, industryAppetite, restrictedIndustries, businessStageFit, typicalBorrowerProfile, eligibility, underwriting, terms, requirements, routing, affiliate, source
Last Updated: June 26, 2026 8:53 AM

<aside>
🏦

Funding providers with underwriting style, routing weight, and affiliate config — the layer the matching engine scores against.

</aside>

## Entries (33)

Built from all **active** partners in the Funding Partners Database, plus 2 providers added from the product catalog to back products that had no provider record. Each entry carries financing products, eligibility (min FICO / revenue / time-in-business), PG type, affiliate URL, commission rate, contact, and the `productFamilyIds` it serves. Highlights:

- **Bank Breezy** — working-capital, business-line-access · 500 FICO / $3k mo / 3 mo · up to $2M · 2-8%
- **David Allen Capital** — working-capital, business-line-access · 500 FICO / $3k mo / 3 mo · $10k–$2m · 2-8%
- **GoKapital** — working-capital, line, term, equipment, SBA, real-estate · 600 FICO / $3k mo / 6 mo · up to $5M
- **The Finance Factory** — working-capital, line, term, SBA, equipment · 600 FICO / $10k mo / 3 mo · up to $5M
- **Visio Lending / Gator Lending / New Silver** — real-estate-capital (DSCR, bridge, fix & flip, construction)
- **8fig / Payability / Onramp / SellersFi** — marketplace-capital (e-commerce seller funding)

<aside>
✅

Expanded from 1 to **31 providers**, all pulled from the Funding Partners Database with affiliate URLs, commission rates, contacts, eligibility, and family mappings populated. A few CRM affiliate links were non-URL placeholders (e.g. "Apply HERE" / portal-only) — those are flagged in each entry's `source.notes` for reconfirmation. `verificationStatus: verified`.

</aside>

<aside>
➕

**+2 added (now 33)** to back products that had no provider record: **Blue Bridge Financial** (equipment-finance) and **National Business Capital** (structured-growth-loans). Eligibility and terms come from the product catalog; affiliate URL, commission, and contact are not yet verified and are flagged in each entry's `needsReview`. `verificationStatus: imported_from_portfolio_report`.

</aside>

## Registry file

[funding-providers.registry.json](funding-providers%20registry%20json/funding-providers.registry.json)

funding-providers.registry.json
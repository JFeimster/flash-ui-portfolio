# product-ideas.registry.json

Description: Catalog of product/tool ideas (20 base ideas expanded into 944 variants) with brand fit, delivery stack, monetization path, and weighted opportunity scores.
Suggested Fields: id, name, rank, base_idea, variant, category, target_audience, niche, best_brand_fit, primary_offer_type, delivery_stack, promise, example_angle, build_difficulty, est_build_time_days, monetization_path, fit, speed, monetization, leverage, complexity_penalty, weighted_score, next_step_prompt
File: product-ideas.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
💡

**Purpose:** Catalog of product/tool ideas (20 base ideas expanded into 944 variants) with brand fit, delivery stack, monetization path, and weighted opportunity scores.

**Source:** CSV Import · **Visibility:** Internal · **Status:** Idea · **Priority:** Medium

</aside>

## Completed Registry — product-ideas.registry.json

[product-ideas.registry.json](product-ideas.registry.json)

product-ideas.registry.json

<aside>
✅

The attached completed JSON file is the primary source of truth. The sections below are secondary drafting/schema notes and compact previews.

</aside>

## Drafting & Schema Details

### Registry JSON

```json
{
  "id": "product-ideas",
  "name": "product-ideas.registry.json",
  "description": "Catalog of product/tool ideas (20 base ideas expanded into variants) with brand fit, delivery stack, monetization path, and weighted opportunity scores.",
  "source": "CSV Import",
  "visibility": "Internal",
  "fields": {
    "id": "", "name": "", "rank": "", "base_idea": "", "variant": "", "category": "", "target_audience": "", "niche": "", "best_brand_fit": "", "primary_offer_type": "", "delivery_stack": "", "promise": "", "example_angle": "", "build_difficulty": "", "est_build_time_days": "", "monetization_path": "", "fit": "", "speed": "", "monetization": "", "leverage": "", "complexity_penalty": "", "weighted_score": "", "next_step_prompt": ""
  },
  "entries": [
    {
      "id": "idea-0001",
      "name": "Subscription Health Monitor — Managed",
      "rank": 1,
      "base_idea": "Subscription Health Monitor",
      "variant": "Managed",
      "category": "Revenue Dashboard",
      "target_audience": "gig workers",
      "best_brand_fit": "Moonshine Capital",
      "primary_offer_type": "Recurring",
      "delivery_stack": "Stripe + Sheets + Gmail",
      "weighted_score": 8.85
    },
    {
      "id": "idea-0002",
      "name": "Subscription Health Monitor — DFY",
      "rank": 2,
      "base_idea": "Subscription Health Monitor",
      "variant": "DFY",
      "category": "Revenue Dashboard",
      "target_audience": "gig workers",
      "best_brand_fit": "Moonshine Capital",
      "primary_offer_type": "High-ticket",
      "weighted_score": 8.85
    },
    {
      "id": "idea-0005",
      "name": "Subscription Health Monitor — Managed",
      "rank": 5,
      "base_idea": "Subscription Health Monitor",
      "variant": "Managed",
      "category": "Revenue Dashboard",
      "target_audience": "eCommerce sellers",
      "best_brand_fit": "Moonshine Capital",
      "weighted_score": 8.85
    }
  ],
  "_note": "Showing 3 of 944 entries. The complete 944-entry registry is in the attached product-ideas.registry.json file."
}
```

### Example entries

- **Subscription Health Monitor — Managed** (Revenue Dashboard, Moonshine Capital) — weighted score 8.85.
- **Subscription Health Monitor — DFY** (Revenue Dashboard, Moonshine Capital) — high-ticket variant.
- 944 total scored variants spanning 20 base ideas across audiences, niches, and offer types.

The complete 944-variant idea matrix is attached in the **File** property above.
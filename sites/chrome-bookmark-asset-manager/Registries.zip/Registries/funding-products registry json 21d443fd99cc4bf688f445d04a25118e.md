# funding-products.registry.json

Description: Taxonomy of funding product types across the stack: partner financing options plus applicant-requested product types.
Suggested Fields: id, product_name, group
File: funding-products.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
🏷️

**Single responsibility** — The canonical list of funding product / financing types used across the funding stack (45 types: partner financing options + applicant-requested products).

</aside>

## Completed Registry — funding-products.registry.json

[funding-products.registry.json](funding-products.registry.json)

funding-products.registry.json

<aside>
✅

The attached completed JSON file is the primary source of truth. The sections below are secondary drafting/schema notes and compact previews.

</aside>

## Drafting & Schema Details

### Suggested fields

- `id` — kebab-case slug
- `product_name` — product / financing type name
- `group` — where the product type is defined (partner financing option vs applicant-requested)

### Registry JSON

```json
{
  "id": "funding-products",
  "name": "funding-products",
  "description": "Taxonomy of funding product types: partner financing options plus applicant-requested product types.",
  "source": "Manual",
  "visibility": "Internal",
  "fields": {
    "id": "kebab-case slug",
    "product_name": "Product / financing type name",
    "group": "Where the product type is defined"
  },
  "entries": [
    { "id": "term-loan", "product_name": "Term Loan", "group": "Financing Option (Partner Database)" },
    { "id": "merchant-cash-advance-mca", "product_name": "Merchant Cash Advance (MCA)", "group": "Financing Option (Partner Database)" },
    { "id": "financing-consulting", "product_name": "Financing Consulting", "group": "Applicant-Requested Product Type (Intake CRM)" }
  ]
}
```

### Example entries

- **Term Loan**, **Line of Credit**, **SBA 7(a)**, **Equipment Financing** — partner financing options.
- **Financing Consulting**, **Business Credit**, **Debt Consolidation** — applicant-requested product types.
- Overlapping types (e.g. **Working Capital**, **MCA**) are tagged as both.
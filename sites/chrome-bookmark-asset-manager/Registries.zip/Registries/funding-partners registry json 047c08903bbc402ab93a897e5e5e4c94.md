# funding-partners.registry.json

Description: Catalog of lending and affiliate funding partners (lenders, marketplaces, embedded-finance platforms) with products, qualification minimums, affiliate status, commission, and apply links.
Suggested Fields: id, partner_name, financing_options, funding_range, target_industries, requirements, min_credit_score, min_time_in_business_months, min_monthly_revenue, pg_type, affiliate_status, affiliate_commission_rate, affiliate_url, apply_url, category, directory, geography, product_notes, use_case, domain_url, description
File: funding-partners.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
🤝

**Single responsibility** — One row per funding/affiliate partner: who they are, what they fund, who qualifies, and how to refer/apply. Sourced from the Funding Partners Database (54 partners).

</aside>

## Completed Registry — funding-partners.registry.json

[funding-partners.registry.json](funding-partners.registry.json)

funding-partners.registry.json

<aside>
✅

The attached completed JSON file is the primary source of truth. The sections below are secondary drafting/schema notes and compact previews.

</aside>

## Drafting & Schema Details

### Suggested fields

- `id` — kebab-case slug of partner name
- `partner_name` — affiliate / lender name
- `financing_options` — funding products offered (array)
- `funding_range` — funding amount or range
- `target_industries` — industries served (array)
- `requirements` — qualification requirements
- `min_credit_score` / `min_time_in_business_months` / `min_monthly_revenue` — numeric minimums
- `pg_type` — personal guarantee type (None / Soft PG / Full PG)
- `affiliate_status` — Prospecting / Pending / Active
- `affiliate_commission_rate`, `affiliate_url`, `apply_url`
- `category`, `directory`, `geography`, `use_case` — tags & eligibility
- `product_notes`, `domain_url`, `description`

### Registry JSON

```json
{
  "id": "funding-partners",
  "name": "funding-partners",
  "description": "Catalog of lending and affiliate funding partners with products, qualification minimums, affiliate status, commission, and apply links.",
  "source": "CSV Import",
  "visibility": "Internal",
  "fields": {
    "id": "kebab-case slug of partner name",
    "partner_name": "Affiliate / lender name",
    "financing_options": "Funding products offered (array)",
    "funding_range": "Funding amount or range (text)",
    "requirements": "Qualification requirements (text)",
    "affiliate_status": "Prospecting / Pending / Active",
    "apply_url": "Application URL"
  },
  "entries": [
    {
      "id": "7-figures-funding",
      "partner_name": "7 Figures Funding",
      "financing_options": ["Term Loan", "Line of Credit", "Revenue-Based Financing (RBF)", "Merchant Cash Advance (MCA)"],
      "requirements": "680+ credit score, U.S. citizen, no recent bankruptcies",
      "affiliate_status": "Active",
      "pg_type": "Soft PG"
    },
    {
      "id": "david-allen-capital",
      "partner_name": "David Allen Capital",
      "funding_range": "$10k - $2M",
      "financing_options": ["Revenue-Based Financing (RBF)", "Merchant Cash Advance (MCA)", "Line of Credit"],
      "pg_type": "Soft PG",
      "affiliate_status": "Active"
    }
  ]
}
```

### Example entries

- **David Allen Capital** — $10k–$2M, RBF / MCA / LOC, Soft PG, Active affiliate.
- **GoKapital** — up to $5M, 8 financing types, Active.
- **Bank Breezy** — up to $2M, Construction / HVAC focus, Active.

*TODO: link individual partners to the Registries “Linked Sources / Tools” relation once partner page URLs are mapped.*
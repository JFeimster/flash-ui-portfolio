# vercel-projects.registry.json

Description: Live inventory of deployed Vercel projects with deployment URL, connected GitHub repo, and last-edit recency.
Suggested Fields: id, name, project_slug, vercel_dashboard, deployment_domain, public_url, github_repo, last_edit, main_deployment, description
File: vercel-projects.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
▲

**Purpose:** Live inventory of deployed Vercel projects with deployment URL, connected GitHub repo, and last-edit recency.

**Source:** CSV Import · **Visibility:** Internal · **Status:** Built · **Priority:** High

</aside>

## Completed Registry — vercel-projects.registry.json

[vercel-projects.registry.json](vercel-projects.registry.json)

vercel-projects.registry.json

<aside>
✅

The attached completed JSON file is the primary source of truth. The sections below are secondary drafting/schema notes and compact previews.

</aside>

## Drafting & Schema Details

### Registry JSON

```json
{
  "id": "vercel-projects",
  "name": "vercel-projects.registry.json",
  "description": "Live inventory of deployed Vercel projects with deployment URL, connected GitHub repo, and last-edit recency.",
  "source": "CSV Import",
  "visibility": "Internal",
  "fields": {
    "id": "", "name": "", "project_slug": "", "vercel_dashboard": "", "deployment_domain": "", "public_url": "", "github_repo": "", "last_edit": "", "main_deployment": "", "description": ""
  },
  "entries": [
    {
      "id": "onboarding",
      "name": "Onboarding",
      "project_slug": "Onboarding",
      "public_url": "https://onboarding-kappa-gules.vercel.app/",
      "github_repo": "JFeimster/Onboarding",
      "last_edit": "2025-12-30T00:00:00",
      "description": "The definitive 30-day launchpad for elite funding partners to build their agency."
    },
    {
      "id": "staged-funding",
      "name": "staged-funding",
      "project_slug": "staged-funding",
      "public_url": "https://staged-funding.vercel.app/",
      "github_repo": "JFeimster/staged-funding",
      "last_edit": "12h ago",
      "description": null
    },
    {
      "id": "estimator",
      "name": "estimator",
      "project_slug": "estimator",
      "public_url": "https://estimator-lyart.vercel.app/",
      "github_repo": "JFeimster/estimator",
      "last_edit": "13h ago",
      "description": null
    }
  ],
  "_note": "Showing 3 of 99 entries. The complete 99-entry registry is in the attached vercel-projects.registry.json file."
}
```

### Example entries

- **Onboarding** — [onboarding-kappa-gules.vercel.app](http://onboarding-kappa-gules.vercel.app), repo JFeimster/Onboarding.
- **staged-funding** — [staged-funding.vercel.app](http://staged-funding.vercel.app), repo JFeimster/staged-funding.
- **estimator** — [estimator-lyart.vercel.app](http://estimator-lyart.vercel.app), repo JFeimster/estimator.

TODO: some rows carry relative last-edit values (e.g. "12h ago") rather than absolute dates, exactly as exported. The complete 99-project inventory is attached in the **File** property above.
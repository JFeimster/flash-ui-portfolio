# affiliate-offers.registry.json

Description: Provider / internal offer routing — not public app data.
Suggested Fields: offer_id, provider, payout, requirements, geo, status, internal_notes
Last Updated: June 9, 2026 3:34 AM

<aside>
🎯

This is where provider / internal offer routing belongs — not public app data.

</aside>

### 🧱 Suggested Fields

```json
{
  "offer_id": "",
  "provider": "",
  "payout": "",
  "requirements": "",
  "geo": "",
  "status": "",
  "internal_notes": ""
}
```
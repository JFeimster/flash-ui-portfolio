# distilledfunding-subdomain-prompts.registry.json

Description: Registry of subdomain-specific Flash UI prompts for Distilled Funding/Moonshine funnels, tools, booking flows, education hubs, comparison engines, blogs, and client portals.
Suggested Fields: id, name, subdomain, asset_type, purpose, target_audience, visual_style, core_sections, primary_cta, prompt, source_file
File: distilledfunding-subdomain-prompts.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
🗂️

**Purpose:** Registry of subdomain-specific Flash UI prompts for Distilled Funding/Moonshine funnels, tools, booking flows, education hubs, comparison engines, blogs, and client portals.

</aside>

## Registry summary

- **Registry:** `distilledfunding-subdomain-prompts.registry.json`
- **Source:** Manual
- **Visibility:** Internal
- **Entries:** 10
- **Suggested fields:** id, name, subdomain, asset_type, purpose, target_audience, visual_style, core_sections, primary_cta, prompt, source_file

## Example entries

- **Partner Landing Page (Conversion-Focused)** — Design a high-conversion "Partner Recruitment Landing Page" for [partners.distilledfunding.com](http://partners.distilledfunding.com) (Moonshine Capital partner network).
- **Partner Application Funnel (Multi-Step)** — Design a "Multi-Step Partner Application Funnel" for [partners.distilledfunding.com](http://partners.distilledfunding.com).
- **Quick Application Funnel (High-Speed Conversion)** — Design a "Quick Application Funnel" for [qa.distilledfunding.com](http://qa.distilledfunding.com) (quick apply subdomain) focused on speed and simplicity.

## Full registry JSON

```json
{
  "id": "distilledfunding-subdomain-prompts",
  "name": "distilledfunding-subdomain-prompts.registry.json",
  "description": "Registry of subdomain-specific Flash UI prompts for Distilled Funding/Moonshine funnels, tools, booking flows, education hubs, comparison engines, blogs, and client portals.",
  "source": "Manual",
  "visibility": "Internal",
  "fields": {
    "id": "kebab-case unique id",
    "name": "prompt name",
    "subdomain": "target subdomain",
    "asset_type": "asset type",
    "purpose": "prompt purpose",
    "target_audience": "audience",
    "visual_style": "visual style instructions",
    "core_sections": "major page sections",
    "primary_cta": "primary CTA",
    "prompt": "full prompt",
    "source_file": "source file name"
  },
  "entries": [
    {
      "id": "partner-landing-page-conversion-focused",
      "name": "Partner Landing Page (Conversion-Focused)",
      "category": "subdomain_specific",
      "asset_type": "Calculator",
      "audience": "TODO",
      "purpose": "Design a high-conversion \"Partner Recruitment Landing Page\" for partners.distilledfunding.com (Moonshine Capital partner network).",
      "visual_style": "Opportunity-Driven, Professional, Aspirational. Navy Blue (#1e40af), Success Green (#10b981), Gold Highlights (#f59e0b), Clean White (#ffffff). Modern sans-serif, motivational imagery, earnings-focused design. BRAND CONTEXT: This is the primary recruitment funnel for Moonshine Capital's ISO/MLM netw",
      "core_sections": [
        "VISUAL STYLE",
        "BRAND CONTEXT",
        "LAYOUT STRUCTURE",
        "HERO SECTION",
        "INCOME COMPARISON SECTION",
        "REQUIREMENTS SECTION",
        "APPLICATION PREVIEW",
        "TRUST SIGNALS FOOTER",
        "FINAL CTA SECTION",
        "DESIGN REQUIREMENTS",
        "CONVERSION OPTIMIZATIONS",
        "TECHNICAL REQUIREMENTS"
      ],
      "primary_cta": "Start Your Application",
      "prompt": "Design a high-conversion \"Partner Recruitment Landing Page\" for partners.distilledfunding.com (Moonshine Capital partner network).\n    \n    VISUAL STYLE: Opportunity-Driven, Professional, Aspirational. Navy Blue (#1e40af), Success Green (#10b981), Gold Highlights (#f59e0b), Clean White (#ffffff). Modern sans-serif, motivational imagery, earnings-focused design.\n    \n    BRAND CONTEXT: This is the primary recruitment funnel for Moonshine Capital's ISO/MLM network. Goal: convert visitors into partner applications with minimal friction.\n    \n    LAYOUT STRUCTURE:\n    \n    HERO SECTION:\n    - H1: \"Build Your Funding Business. Earn Daily Commissions.\"\n    - Subheadline: \"Join 500+ independent agents earning $500-$5K per deal with zero upfront costs\"\n    - Video Background: Looping b-roll of successful agents, professional settings\n    - Primary CTA: \"Start Your Application\" (glowing green button)\n    - Secondary CTA: \"Watch 2-Min Explainer Video\" (video modal)\n    - Trust Strip: \"Zero Fees | Daily Payouts | Full Training Included\"\n    \n    INCOME POTENTIAL CALCULATOR (Interactive Widget):\n    - Title: \"Calculate Your Earning Potential\"\n    - Slider Input: \"Deals per month\" (1-50)\n    - Slider Input: \"Average deal size\" ($10K - $500K)\n    - Real-time output: \"Monthly Commission: $X,XXX\" + \"Annual: $XX,XXX\"\n    - CTA below calculator: \"Get Started for Free\"\n    \n    3-TIER PARTNERSHIP MODEL (Card Grid):\n    Card 1: \"Affiliate Partner\"\n    - Commission: 10-15%\n    - Time Commitment: Part-time (5-10 hrs/week)\n    - Best For: Side hustle, passive income seekers\n    - What You Do: Share referral links\n    - CTA: \"Become Affiliate\"\n    \n    Card 2: \"Independent Agent (ISO)\"\n    - Commission: 20-40%\n    - Time Commitment: Full-time or serious part-time\n    - Best For: Sales professionals, entrepreneurs\n    - What You Do: Source clients, guide applications\n    - CTA: \"Apply as Agent\" (featured/recommended)\n    \n    Card 3: \"Agency Builder\"\n    - Commission: Your deals + 5-10% team override\n    - Time Commitment: Full-time business\n    - Best For: Team builders, MLM veterans\n    - What You Do: Build and train your own agency\n    - CTA: \"Build Agency\"\n    \n    HOW IT WORKS (4-Step Visual):\n    Step 1: Apply (2-min application)\n    Step 2: Get Approved (24-48 hour review)\n    Step 3: Complete Training (Free online modules)\n    Step 4: Start Earning (Submit first deal, get paid)\n    Visual: Arrow or timeline connecting steps\n    \n    INCOME COMPARISON SECTION:\n    Title: \"Compare Your Earning Potential\"\n    Visual Bar Chart comparing:\n    - Traditional Job: $50K/year\n    - Other MLMs: $30K-$80K/year (variable)\n    - Moonshine Partner: $60K-$250K/year (unlimited)\n    CTA: \"I Want Unlimited Earning Potential\"\n    \n    SUCCESS STORIES (Testimonial Carousel):\n    - 3-5 video testimonials from real partners\n    - Each featuring: Photo, name, location, monthly earnings\n    - Pull quotes: \"I quit my 9-5 after 6 months\"\n    - CTA: \"Read More Success Stories\"\n    \n    REQUIREMENTS SECTION:\n    Title: \"Do You Qualify?\"\n    ✅ What We're Looking For:\n    - Age 18+ (21+ in some states)\n    - Willingness to learn\n    - Basic tech skills\n    - Hustle mentality\n    - Legal to work in US/Canada\n    \n    ❌ Disqualifiers:\n    - Expecting instant riches without work\n    - Unwilling to follow proven system\n    - No network or prospecting skills\n    - Looking for guaranteed salary\n    \n    FAQ ACCORDION (10 Questions):\n    1. How much can I really earn?\n    2. Are there any upfront costs?\n    3. How long does approval take?\n    4. Do I need experience in finance?\n    5. Is this MLM or a pyramid scheme?\n    6. How do I find clients?\n    7. What training do you provide?\n    8. How fast do I get paid?\n    9. Can I do this part-time?\n    10. What's the difference between affiliate and agent?\n    \n    APPLICATION PREVIEW:\n    Title: \"Your Application Takes 2 Minutes\"\n    Preview of application form fields:\n    - Full name\n    - Email\n    - Phone\n    - Current occupation\n    - Why you want to join\n    - Preferred partnership tier\n    CTA: \"Start Application Now\"\n    \n    TRUST SIGNALS FOOTER:\n    - \"500+ Active Partners\"\n    - \"$2M+ in Commissions Paid\"\n    - \"BBB Accredited Business\"\n    - Partner testimonial quotes\n    - Logos of funding partners (David Allen Capital, etc.)\n    \n    FINAL CTA SECTION:\n    Headline: \"Your Financial Freedom Starts Today\"\n    Subheadline: \"Join hundreds who quit their 9-5 and now earn on their terms\"\n    Primary CTA: \"Apply Now (Free)\"\n    Secondary CTA: \"Schedule Call with Recruiter\"\n    Urgency: \"Only X spots available this month\" (if truthful)\n    \n    DESIGN REQUIREMENTS:\n    - Mobile-first responsive design\n    - Fast loading (under 2 seconds)\n    - Sticky header with CTA button\n    - Exit-intent popup offering free guide or video\n    - Chat widget for immediate questions\n    - Multiple CTAs (every 1.5 screen scrolls)\n    - A/B testing setup for headlines and CTAs\n    - Analytics tracking on all buttons\n    \n    CONVERSION OPTIMIZATIONS:\n    - Above-the-fold CTA (no scrolling required)\n    - Social proof throughout\n    - Scarcity elements (limited spots)\n    - Risk reversal (zero cost to join)\n    - Clear value proposition\n    - Simple application process\n    \n    TECHNICAL REQUIREMENTS:\n    - Form submission triggers webhook to CRM\n    - Email automation for application confirmation\n    - SMS option for instant follow-up\n    - Calendly integration for recruiter calls\n    - Video hosting optimized (Vimeo/YouTube)\n    - SSL certificate and security badges\n    \n    SEO/META:\n    - Title: \"Become a Funding Partner | Earn Daily Commissions | Moonshine Capital\"\n    - Meta Description: \"Join Moonshine Capital's partner network. Earn $500-$5K per deal with zero upfront costs. Free training, daily payouts, unlimited earning potential. Apply now.\"\n    - OG Image: Earnings calculator or success story graphic\n    \n    OUTPUT FORMAT: Next.js app deployed to Vercel with form handling via API routes.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md",
      "subdomain": "partners.distilledfunding.com",
      "target_audience": "TODO"
    },
    {
      "id": "partner-application-funnel-multi-step",
      "name": "Partner Application Funnel (Multi-Step)",
      "category": "subdomain_specific",
      "asset_type": "Funnel",
      "audience": "TODO",
      "purpose": "Design a \"Multi-Step Partner Application Funnel\" for partners.distilledfunding.com.",
      "visual_style": "Clean, Progress-Focused, Motivational. White background, Purple accents (#8b5cf6), Progress indicators, Minimal distractions. BRAND CONTEXT: This is the application flow after someone clicks \"Apply Now\" from the landing page. Goal: maximize completion rate while qualifying serious applicants. LAYOUT",
      "core_sections": [
        "VISUAL STYLE",
        "BRAND CONTEXT",
        "LAYOUT STRUCTURE",
        "STEP 1",
        "STEP 2",
        "STEP 3",
        "STEP 4",
        "STEP 5",
        "CONFIRMATION PAGE",
        "ABANDONED APPLICATION RECOVERY",
        "DESIGN REQUIREMENTS",
        "PSYCHOLOGICAL TRIGGERS"
      ],
      "primary_cta": "Continue",
      "prompt": "Design a \"Multi-Step Partner Application Funnel\" for partners.distilledfunding.com.\n    \n    VISUAL STYLE: Clean, Progress-Focused, Motivational. White background, Purple accents (#8b5cf6), Progress indicators, Minimal distractions.\n    \n    BRAND CONTEXT: This is the application flow after someone clicks \"Apply Now\" from the landing page. Goal: maximize completion rate while qualifying serious applicants.\n    \n    LAYOUT STRUCTURE:\n    \n    PROGRESS INDICATOR (Top, Sticky):\n    - Visual progress bar showing: Step 1 of 5 (20% complete)\n    - Step labels: Info → Experience → Goals → Agreement → Submit\n    - Completed steps show checkmark\n    - Current step highlighted in purple\n    \n    STEP 1: BASIC INFORMATION\n    Title: \"Let's Get to Know You\"\n    Fields:\n    - First Name\n    - Last Name\n    - Email Address\n    - Phone Number (with SMS opt-in checkbox)\n    - Current Location (City, State)\n    - Date of Birth (age verification)\n    Validation: Real-time field validation\n    CTA: \"Continue\" button\n    Secondary: \"Save and finish later\" link\n    Auto-save: Form data saved in localStorage\n    \n    STEP 2: BACKGROUND & EXPERIENCE\n    Title: \"Tell Us About Your Background\"\n    Fields:\n    - Current Occupation/Employment Status (dropdown)\n    - Years of Sales/Business Experience (dropdown: 0-1, 1-3, 3-5, 5-10, 10+)\n    - Industry Experience (checkboxes: Finance, Real Estate, Insurance, MLM, Sales, Other)\n    - Have you worked as an ISO/broker before? (Yes/No radio)\n    - Do you have an existing network of business owners? (Yes/No/Building One)\n    Previous/Continue buttons\n    \n    STEP 3: PARTNERSHIP GOALS\n    Title: \"What Are You Looking For?\"\n    Questions:\n    - Which partnership tier interests you? (Radio: Affiliate, Agent, Agency Builder)\n    - Time commitment? (Radio: Part-time 5-10 hrs, Part-time 10-20 hrs, Full-time 40+ hrs)\n    - Income goal in first 12 months? (Dropdown: $10K-$25K, $25K-$50K, $50K-$100K, $100K+)\n    - When can you start? (Radio: Immediately, Within 2 weeks, Within 30 days, Just exploring)\n    - How did you hear about us? (Dropdown: Google, Social Media, Referral, Event, Other)\n    Previous/Continue buttons\n    \n    STEP 4: AGREEMENT & DISCLOSURES\n    Title: \"Review and Agree\"\n    Content:\n    - Scrollable terms and conditions (plain language summary at top)\n    - Key points highlighted:\n      * Independent contractor status\n      * Commission structure\n      * Compliance requirements\n      * Non-compete clause (if applicable)\n    Checkboxes:\n    - ☐ I have read and agree to the Partner Agreement\n    - ☐ I understand this is a commission-based opportunity\n    - ☐ I authorize background and credit check (if applicable)\n    - ☐ I agree to receive communications via email and SMS\n    E-signature field (type full name)\n    Previous/Continue buttons\n    \n    STEP 5: REVIEW & SUBMIT\n    Title: \"Almost Done! Review Your Application\"\n    Display: Summary of all information entered (editable)\n    - Personal Info (with Edit button)\n    - Background (with Edit button)\n    - Goals (with Edit button)\n    - Agreement Status (checkmarks)\n    Final CTA: \"Submit My Application\" (large, prominent button)\n    Confirmation message: \"You'll hear from us within 24-48 hours\"\n    Secondary action: \"Download Partner Guide While You Wait\" (lead magnet)\n    \n    CONFIRMATION PAGE:\n    Headline: \"Application Submitted! Here's What Happens Next\"\n    Timeline visualization:\n    - ✅ Application received (now)\n    - ⏳ Review by recruitment team (24-48 hours)\n    - ⏳ Approval notification via email\n    - ⏳ Onboarding invitation\n    Next steps:\n    - Check email for confirmation\n    - Join private Facebook group (link)\n    - Watch \"What to Expect\" video\n    - Download partner resources\n    CTA: \"Schedule Onboarding Call\" (Calendly embed)\n    \n    ABANDONED APPLICATION RECOVERY:\n    - Email sent if user leaves before completing (with magic link to resume)\n    - Exit-intent popup: \"Save your progress? We'll email you a link to finish later\"\n    - SMS follow-up (if phone provided): \"Complete your application in 2 minutes: [link]\"\n    \n    DESIGN REQUIREMENTS:\n    - Single field focus (one question per screen on mobile)\n    - Large, touch-friendly inputs\n    - Real-time validation feedback\n    - Progress saved automatically\n    - Back button always available\n    - Mobile-optimized keyboard types\n    - Loading states on submit\n    - Success animation on submission\n    \n    PSYCHOLOGICAL TRIGGERS:\n    - Progress indication (creates completion motivation)\n    - Social proof: \"500+ partners applied this month\"\n    - Deadline scarcity (if truthful): \"Applications reviewed weekly\"\n    - Risk reversal: \"No commitment until you're approved\"\n    \n    TECHNICAL REQUIREMENTS:\n    - Form state management (React Hook Form or similar)\n    - Auto-save to localStorage or database\n    - Multi-step validation logic\n    - Conditional fields based on previous answers\n    - CRM integration (HubSpot/Salesforce webhook)\n    - Email automation trigger on submit\n    - SMS automation (Twilio)\n    - Analytics tracking per step (completion rate, drop-off points)\n    \n    MOBILE OPTIMIZATIONS:\n    - One question per screen on mobile\n    - Swipe gestures for next/previous\n    - Sticky CTA button at bottom\n    - Minimal text input (use dropdowns/radio when possible)\n    - Native date pickers and phone number formatters\n    \n    A/B TESTING OPPORTUNITIES:\n    - Test different progress indicators (bar vs. steps)\n    - Test single-page vs. multi-step\n    - Test CTA button copy (\"Continue\" vs. \"Next Step\")\n    - Test with/without e-signature requirement\n    \n    OUTPUT FORMAT: React/Next.js components with Formik or React Hook Form, deployed to Vercel with API integration.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md",
      "subdomain": "partners.distilledfunding.com",
      "target_audience": "TODO"
    },
    {
      "id": "quick-application-funnel-high-speed-conversion",
      "name": "Quick Application Funnel (High-Speed Conversion)",
      "category": "subdomain_specific",
      "asset_type": "Funnel",
      "audience": "TODO",
      "purpose": "Design a \"Quick Application Funnel\" for qa.distilledfunding.com (quick apply subdomain) focused on speed and simplicity.",
      "visual_style": "Streamlined, Urgent, Conversion-Optimized. Minimal design, Large CTAs, Trust Blue (#3b82f6), Success Green (#10b981), Clean White. BRAND CONTEXT: This is the fast-track application flow for businesses that need funding NOW. Every element should reduce friction and accelerate decision-making. LAYOUT ",
      "core_sections": [
        "VISUAL STYLE",
        "BRAND CONTEXT",
        "LAYOUT STRUCTURE",
        "EMBEDDED APPLICATION FORM",
        "INSTANT RESULTS PAGE",
        "DESIGN REQUIREMENTS",
        "CONVERSION OPTIMIZATIONS",
        "TECHNICAL REQUIREMENTS",
        "ABANDONED APPLICATION RECOVERY",
        "OUTPUT FORMAT"
      ],
      "primary_cta": "Apply Now",
      "prompt": "Design a \"Quick Application Funnel\" for qa.distilledfunding.com (quick apply subdomain) focused on speed and simplicity.\n    \n    VISUAL STYLE: Streamlined, Urgent, Conversion-Optimized. Minimal design, Large CTAs, Trust Blue (#3b82f6), Success Green (#10b981), Clean White.\n    \n    BRAND CONTEXT: This is the fast-track application flow for businesses that need funding NOW. Every element should reduce friction and accelerate decision-making.\n    \n    LAYOUT STRUCTURE:\n    \n    LANDING PAGE (Single Focus):\n    Hero:\n    - H1: \"Get Funded in 24 Hours. Apply in 90 Seconds.\"\n    - Countdown timer: \"Apply today for same-day approval\"\n    - Trust badges: \"No Credit Impact | Secure Application | 10,000+ Funded\"\n    - Large embedded form (see below)\n    - No navigation header (no escape routes)\n    - Mobile-first design\n    \n    EMBEDDED APPLICATION FORM:\n    Title: \"See What You Qualify For\"\n    Progress: \"3 Quick Questions\"\n    \n    Question 1: \"How much funding do you need?\"\n    - Large buttons: $10K | $25K | $50K | $100K | $250K | Custom\n    - Slider alternative for custom amount\n    \n    Question 2: \"How long have you been in business?\"\n    - Buttons: Less than 6 months | 6-12 months | 1-2 years | 2+ years\n    \n    Question 3: \"What's your monthly revenue?\"\n    - Buttons: $5K-$10K | $10K-$25K | $25K-$50K | $50K-$100K | $100K+\n    \n    Then: Contact Information Reveal\n    Fields:\n    - Business Name\n    - Your Name\n    - Email\n    - Phone Number\n    - \"Send My Funding Options\" button (large, green)\n    \n    Micro-interactions: Each question slides in smoothly, previous answers shown at top\n    \n    INSTANT RESULTS PAGE:\n    Headline: \"Great News! You Pre-Qualify for Up to $XX,XXX\"\n    Subheadline: \"Here are your best funding options based on your profile\"\n    \n    Recommended Products (3 Cards):\n    Card 1: [Product Name]\n    - Amount: $XX,XXX available\n    - Speed: Funded in 24-48 hours\n    - Payment: [structure]\n    - CTA: \"Apply Now\" (leads to full app)\n    \n    Card 2: [Alternative Product]\n    - Similar structure\n    - CTA: \"Learn More\"\n    \n    Card 3: [Third Option]\n    - Similar structure\n    - CTA: \"Compare All Options\"\n    \n    Alternative Path:\n    \"Prefer to speak with a specialist?\"\n    - CTA: \"Schedule Free Consultation\" (Calendly embed)\n    \n    Next Steps Section:\n    \"What Happens Next?\"\n    1. Complete full application (5 more minutes)\n    2. Speak with funding specialist (15-min call)\n    3. Receive approval (same day or next day)\n    4. Get funded (24-48 hours)\n    \n    Email Capture Success:\n    - Automatic email sent with results summary\n    - PDF download option: \"Your Funding Options Report\"\n    - Follow-up sequence triggered\n    \n    DESIGN REQUIREMENTS:\n    - Single-column layout (no distractions)\n    - Large, thumb-friendly buttons\n    - Instant feedback on selections\n    - No page reloads (smooth transitions)\n    - Sticky CTA button on scroll\n    - Exit-intent popup (offer phone consultation)\n    - Trust signals throughout\n    \n    CONVERSION OPTIMIZATIONS:\n    - Pre-fill fields if user came from ad with UTM parameters\n    - Social proof: \"John in Miami just got approved for $45K\"\n    - Urgency: \"Only X same-day slots left today\"\n    - Risk reversal: \"No obligation, no credit impact\"\n    - Progress indicators: \"Step 1 of 3\"\n    \n    TECHNICAL REQUIREMENTS:\n    - Form submission triggers instant email\n    - CRM integration (create lead record)\n    - SMS automation (instant text with next steps)\n    - Calendly integration for booking\n    - Analytics: track completion rate by question\n    - A/B testing framework\n    - Mobile-optimized (60%+ of traffic)\n    \n    ABANDONED APPLICATION RECOVERY:\n    - Exit-intent: \"Wait! Get your results in 30 seconds\"\n    - Email follow-up if email captured but form incomplete\n    - Retargeting pixel for ads\n    \n    ALTERNATIVE BOOKING VERSION (book.distilledfunding.com):\n    If this subdomain focuses more on consultation booking:\n    - Hero: \"Book Your Free Funding Consultation\"\n    - Calendly embed as primary CTA\n    - Qualification questions to route to right specialist\n    - Confirmation page with prep instructions\n    \n    OUTPUT FORMAT: Single-page React app or Next.js page deployed to Vercel with API integration for lead capture.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md",
      "subdomain": "qa.distilledfunding.com",
      "target_audience": "TODO"
    },
    {
      "id": "calendly-style-booking-interface",
      "name": "Calendly-Style Booking Interface",
      "category": "subdomain_specific",
      "asset_type": "Prompt Template",
      "audience": "TODO",
      "purpose": "Design a \"Consultation Booking Interface\" for book.distilledfunding.com styled like Calendly but branded for Moonshine Capital.",
      "visual_style": "Clean, Calendar-Focused, Professional. White background, Brand Navy (#1e40af), Calendar Blue (#3b82f6), Minimal chrome. BRAND CONTEXT: This is where prospects book consultation calls with funding specialists. Should feel modern, trustworthy, and effortless. LAYOUT STRUCTURE: LEFT SIDEBAR (Fixed): Mo",
      "core_sections": [
        "VISUAL STYLE",
        "BRAND CONTEXT",
        "LAYOUT STRUCTURE",
        "MAIN CONTENT AREA",
        "STEP 1",
        "STEP 2",
        "STEP 3",
        "MOBILE OPTIMIZATIONS",
        "ADDITIONAL FEATURES",
        "INTEGRATION REQUIREMENTS",
        "NO-SHOW PREVENTION",
        "BOOKING PAGE VARIATIONS"
      ],
      "primary_cta": "Prepare for Your Call - Download Funding Checklist",
      "prompt": "Design a \"Consultation Booking Interface\" for book.distilledfunding.com styled like Calendly but branded for Moonshine Capital.\n    \n    VISUAL STYLE: Clean, Calendar-Focused, Professional. White background, Brand Navy (#1e40af), Calendar Blue (#3b82f6), Minimal chrome.\n    \n    BRAND CONTEXT: This is where prospects book consultation calls with funding specialists. Should feel modern, trustworthy, and effortless.\n    \n    LAYOUT STRUCTURE:\n    \n    LEFT SIDEBAR (Fixed):\n    Moonshine Capital Logo\n    Meeting Details Card:\n    - Specialist photo and name\n    - Meeting title: \"Funding Consultation\"\n    - Duration: 15 minutes\n    - Format: Phone or Zoom (user choice)\n    - Description: \"Discuss your funding needs and get personalized recommendations\"\n    Trust elements:\n    - \"No sales pressure\"\n    - \"100% confidential\"\n    - Calendar icon: \"We'll send calendar invite\"\n    \n    MAIN CONTENT AREA:\n    \n    STEP 1: SELECT DATE & TIME\n    Calendar widget:\n    - Current month displayed\n    - Available dates highlighted in blue\n    - Unavailable dates grayed out\n    - Time zone selector at top\n    Available time slots (right side):\n    - List of available times for selected date\n    - Slots in 15-30 minute increments\n    - \"Morning\" | \"Afternoon\" | \"Evening\" filter tabs\n    - Each slot clickable button\n    - Shows specialist's local time\n    Selected slot highlighted\n    \n    STEP 2: ENTER DETAILS\n    Form fields:\n    - Full Name *\n    - Business Name *\n    - Email Address *\n    - Phone Number *\n    - Preferred contact method: (Radio: Phone | Zoom)\n    - How much funding do you need? (Dropdown)\n    - What will you use funding for? (Dropdown)\n    - Additional notes (Optional textarea)\n    Reschedule/Cancel policy shown below form\n    \n    STEP 3: CONFIRMATION\n    Success message: \"Your consultation is booked!\"\n    Confirmation details card:\n    - Date and time\n    - Specialist name and photo\n    - Meeting link (if Zoom) or phone number\n    - \"Add to Calendar\" buttons (Google, Apple, Outlook)\n    - \"Reschedule\" or \"Cancel\" links\n    Next steps:\n    - \"Check your email for confirmation\"\n    - \"We'll send a reminder 1 hour before\"\n    - \"Need to reschedule? Use the link in your email\"\n    CTA: \"Prepare for Your Call - Download Funding Checklist\"\n    \n    MOBILE OPTIMIZATIONS:\n    - Calendar collapsible on mobile\n    - Time slots in scrollable list\n    - Sticky \"Continue\" button\n    - One-tap phone number input\n    - Native date pickers\n    \n    ADDITIONAL FEATURES:\n    - Multiple specialist selection (if applicable)\n    - Group meeting option\n    - Buffer time between bookings\n    - Blackout dates for holidays\n    - Automatic time zone detection\n    - SMS confirmation and reminders\n    - Email confirmation with calendar file\n    \n    INTEGRATION REQUIREMENTS:\n    - Calendly API integration (if using Calendly backend)\n    - Or custom booking system with:\n      * Google Calendar sync\n      * Zoom API integration\n      * Twilio for SMS\n      * Email automation (SendGrid/Mailgun)\n    - CRM integration (log booking event)\n    - Payment integration (if paid consultations)\n    \n    NO-SHOW PREVENTION:\n    - SMS reminder 24 hours before\n    - SMS reminder 1 hour before\n    - Email reminders\n    - Penalty for no-shows (if applicable): lose booking privileges\n    - Reschedule option up to 2 hours before\n    \n    BOOKING PAGE VARIATIONS:\n    Different booking types:\n    - Quick consultation (15 min, free)\n    - Deep dive (30 min, qualifier questions required)\n    - Paid advisory (60 min, payment required upfront)\n    Route to different specialists based on:\n    - Funding amount requested\n    - Business type\n    - Urgency level\n    \n    OUTPUT FORMAT: React booking interface integrated with Calendly API or custom booking backend, deployed to Vercel.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md",
      "subdomain": "book.distilledfunding.com",
      "target_audience": "TODO"
    },
    {
      "id": "funding-tools-dashboard-resource-hub",
      "name": "Funding Tools Dashboard (Resource Hub)",
      "category": "subdomain_specific",
      "asset_type": "Calculator",
      "audience": "TODO",
      "purpose": "Design a \"Funding Tools & Calculators Hub\" for tools.distilledfunding.com - a resource center with interactive financial tools.",
      "visual_style": "Tool-Focused, Data-Driven, Accessible. Clean White (#ffffff), Data Blue (#3b82f6), Chart Green (#10b981), Dark Text (#1f2937). Modern, functional design prioritizing usability. BRAND CONTEXT: This subdomain houses all free tools and calculators that generate leads while providing genuine value. Each",
      "core_sections": [
        "VISUAL STYLE",
        "BRAND CONTEXT",
        "LAYOUT STRUCTURE",
        "HEADER",
        "HERO SECTION",
        "INDIVIDUAL TOOLS TO BUILD",
        "LEAD CAPTURE STRATEGY",
        "DESIGN REQUIREMENTS",
        "TECHNICAL STACK",
        "SEO OPTIMIZATION",
        "ANALYTICS",
        "OUTPUT FORMAT"
      ],
      "primary_cta": "Explore All Tools",
      "prompt": "Design a \"Funding Tools & Calculators Hub\" for tools.distilledfunding.com - a resource center with interactive financial tools.\n    \n    VISUAL STYLE: Tool-Focused, Data-Driven, Accessible. Clean White (#ffffff), Data Blue (#3b82f6), Chart Green (#10b981), Dark Text (#1f2937). Modern, functional design prioritizing usability.\n    \n    BRAND CONTEXT: This subdomain houses all free tools and calculators that generate leads while providing genuine value. Each tool should capture email for full results.\n    \n    LAYOUT STRUCTURE:\n    \n    HEADER:\n    - Moonshine Capital logo (links to main site)\n    - Navigation: Home | Tools | Guides | Blog | Contact\n    - Search bar: \"Find a tool or calculator...\"\n    - User account icon (if logged in) or \"Sign In\" link\n    \n    HERO SECTION:\n    - H1: \"Free Business Funding Tools & Calculators\"\n    - Subheadline: \"Make smarter financing decisions with data-driven insights\"\n    - Featured Tool Spotlight: Rotating carousel of 3-4 top tools\n    - CTA: \"Explore All Tools\"\n    \n    TOOLS GRID (Main Content):\n    Category Navigation (Sidebar or Top Tabs):\n    - All Tools\n    - Calculators\n    - Comparison Tools\n    - Credit & Qualification\n    - Planning & Analysis\n    - Forms & Templates\n    \n    Tool Cards (Responsive Grid):\n    Each card shows:\n    - Tool icon/illustration\n    - Tool name\n    - Brief description (1-2 sentences)\n    - \"Time to complete\" badge\n    - \"Used by X businesses\" social proof\n    - \"Launch Tool\" button\n    - Optional: \"Save\" or \"Favorite\" heart icon\n    \n    INDIVIDUAL TOOLS TO BUILD:\n    \n    1. FUNDING ELIGIBILITY CALCULATOR\n    Input:\n    - Monthly revenue (slider $0-$500K)\n    - Time in business (dropdown)\n    - Credit score range (buttons: Excellent, Good, Fair, Poor)\n    - Industry (dropdown)\n    Output:\n    - Estimated funding amount range\n    - Product recommendations\n    - Approval likelihood percentage\n    - \"Get Pre-Qualified\" CTA\n    \n    2. PAYMENT CALCULATOR\n    Input:\n    - Loan amount\n    - Interest rate or factor rate\n    - Term length\n    - Payment frequency (daily, weekly, monthly)\n    Output:\n    - Payment amount\n    - Total repayment amount\n    - Total interest/fees\n    - Amortization table (toggle view)\n    - \"Apply for This Amount\" CTA\n    \n    3. REVENUE-BASED FINANCING CALCULATOR\n    Input:\n    - Loan amount\n    - Repayment percentage (of daily sales)\n    - Average daily revenue\n    - Estimated term (calculated automatically based on inputs)\n    Output:\n    - Daily payment amount\n    - Payoff timeline\n    - Scenario modeling: \"What if revenue increases/decreases?\"\n    - Visual graph of repayment over time\n    \n    4. BREAKEVEN ANALYSIS TOOL\n    Input:\n    - Fixed costs (monthly)\n    - Variable costs (per unit)\n    - Price per unit\n    - Funding amount considering\n    Output:\n    - Breakeven point (units and revenue)\n    - How funding affects breakeven\n    - Profitability timeline\n    - Visual chart\n    \n    5. ROI CALCULATOR FOR BUSINESS LOANS\n    Input:\n    - Funding amount\n    - Intended use (dropdown: inventory, marketing, equipment, etc.)\n    - Expected revenue increase\n    - Loan cost (interest/fees)\n    Output:\n    - Expected ROI percentage\n    - Payback period\n    - Net profit after loan repayment\n    - \"Is this loan worth it?\" verdict\n    \n    6. CREDIT SCORE SIMULATOR\n    Input:\n    - Current credit score\n    - Recent late payments\n    - Credit utilization\n    - Time in business\n    - Planned actions (checkboxes: pay down debt, increase limits, etc.)\n    Output:\n    - Projected credit score (30, 60, 90 days)\n    - Recommendations for improvement\n    - \"Credit building roadmap\" download\n    \n    7. BUSINESS CREDIT BUILDER ROADMAP\n    Input:\n    - Business age\n    - Current credit status\n    - Goals (funding amount target)\n    Output:\n    - Personalized 90-day action plan\n    - Tasks with timeline\n    - Progress tracking (if user creates account)\n    - Vendor recommendations\n    \n    8. FUNDING PRODUCT COMPARISON TOOL\n    Input:\n    - Select 2-3 products to compare\n    Output:\n    - Side-by-side feature matrix\n    - Pros/cons list\n    - \"Best for\" recommendations\n    - \"Apply\" buttons for each\n    \n    9. CASH FLOW FORECAST TOOL\n    Input:\n    - Monthly revenue (past 6 months)\n    - Monthly expenses\n    - Seasonal factors\n    - Growth rate\n    Output:\n    - 12-month cash flow projection\n    - Funding gap identification\n    - Recommended funding amount\n    - Visual chart\n    \n    10. DEBT CONSOLIDATION CALCULATOR\n    Input:\n    - List of current debts (amount, rate, payment)\n    - Proposed consolidation loan terms\n    Output:\n    - Monthly payment comparison\n    - Total interest savings\n    - Payoff timeline comparison\n    - \"Should you consolidate?\" verdict\n    \n    TOOL FEATURES (Standard Across All):\n    - Real-time calculation (no page reload)\n    - Save results (requires email or account)\n    - Export to PDF\n    - Share results link\n    - Email results to yourself\n    - Comparison mode (compare scenarios)\n    - Mobile-optimized sliders and inputs\n    - Tooltips explaining terms\n    - \"Talk to specialist\" CTA with results\n    \n    LEAD CAPTURE STRATEGY:\n    - Light touch: Let users play with tools freely\n    - Gate full results: \"Enter email to see complete analysis\"\n    - Progressive disclosure: Basic results free, detailed insights require email\n    - Account creation: Save results, track progress over time\n    - Upgrade path: \"Schedule consultation for personalized analysis\"\n    \n    DESIGN REQUIREMENTS:\n    - Fast, responsive interactions (under 100ms)\n    - Clear visual feedback\n    - Accessible (WCAG 2.1 AA)\n    - Mobile-first design\n    - Print-friendly results pages\n    - Shareable results (unique URLs)\n    \n    TECHNICAL STACK:\n    - Frontend: React or Next.js\n    - Charts: Recharts or Chart.js\n    - Forms: React Hook Form\n    - Animations: Framer Motion\n    - Backend: Next.js API routes\n    - Database: Store user calculations (if account feature)\n    - Email: SendGrid or Mailgun for results delivery\n    \n    SEO OPTIMIZATION:\n    - Each tool gets its own page: /tools/payment-calculator\n    - Rich snippets (schema.org/SoftwareApplication)\n    - Meta descriptions for each tool\n    - Internal linking between related tools\n    - Blog posts linking to tools\n    \n    ANALYTICS:\n    - Track tool usage (which tools most popular)\n    - Completion rate (how many finish calculation)\n    - Email capture rate\n    - Conversion to application rate\n    - Time spent per tool\n    \n    MONETIZATION (Future):\n    - Affiliate links to recommended products\n    - Sponsored product placements\n    - Premium tools for paid members\n    - White-label licensing to other platforms\n    \n    RESOURCE SECTION (Bottom of Dashboard):\n    - \"How to Use These Tools\" guide\n    - Video tutorials for each tool\n    - Glossary of financing terms\n    - Blog posts related to each tool category\n    - Link to full funding guides\n    \n    OUTPUT FORMAT: Next.js app with individual tool pages, deployed to Vercel with API for email capture and results storage.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md",
      "subdomain": "tools.distilledfunding.com",
      "target_audience": "TODO"
    },
    {
      "id": "interactive-funding-quiz-lead-gen",
      "name": "Interactive Funding Quiz (Lead Gen)",
      "category": "subdomain_specific",
      "asset_type": "Quiz",
      "audience": "TODO",
      "purpose": "Design an \"Interactive Funding Quiz\" for tools.distilledfunding.com/quiz that diagnoses the best funding option while capturing lead information.",
      "visual_style": "Engaging, Quiz-Like, Friendly. Purple gradients (#8b5cf6 to #6366f1), White background, Playful illustrations, Progress gamification. BRAND CONTEXT: This is a fun, interactive way to educate prospects while qualifying them and capturing contact info. Think BuzzFeed meets financial assessment. LAYOUT",
      "core_sections": [
        "VISUAL STYLE",
        "BRAND CONTEXT",
        "LAYOUT STRUCTURE",
        "QUIZ LANDING PAGE",
        "QUIZ INTERFACE",
        "QUESTION 1",
        "QUESTION 2",
        "QUESTION 3",
        "QUESTION 4",
        "QUESTION 5",
        "QUESTION 6",
        "QUESTION 7"
      ],
      "primary_cta": "Start Quiz",
      "prompt": "Design an \"Interactive Funding Quiz\" for tools.distilledfunding.com/quiz that diagnoses the best funding option while capturing lead information.\n    \n    VISUAL STYLE: Engaging, Quiz-Like, Friendly. Purple gradients (#8b5cf6 to #6366f1), White background, Playful illustrations, Progress gamification.\n    \n    BRAND CONTEXT: This is a fun, interactive way to educate prospects while qualifying them and capturing contact info. Think BuzzFeed meets financial assessment.\n    \n    LAYOUT STRUCTURE:\n    \n    QUIZ LANDING PAGE:\n    Headline: \"Find Your Perfect Funding Match in 60 Seconds\"\n    Subheadline: \"Answer 7 quick questions and we'll recommend your best financing options\"\n    Hero illustration: Friendly character at crossroads with money signs\n    Trust elements: \"10,000+ businesses funded\" | \"2-minute quiz\" | \"100% free\"\n    CTA: \"Start Quiz\" (large, colorful button)\n    Optional: Email capture before quiz (\"Get results via email\")\n    \n    QUIZ INTERFACE:\n    \n    Progress Bar (Top):\n    - Visual progress: Question 3 of 7 (43% complete)\n    - Motivational text: \"You're almost there!\"\n    - Back button (allow going back to change answers)\n    \n    Question Format:\n    Each question on its own screen (mobile-friendly)\n    Question number and total shown\n    Large, visual answer buttons (icons + text)\n    \"Skip\" option (tracked for later follow-up)\n    \n    QUESTION 1: \"How much funding do you need?\"\n    Buttons with icons:\n    - 💵 Less than $10K\n    - 💰 $10K - $50K\n    - 💸 $50K - $250K\n    - 🏦 $250K - $1M\n    - 🚀 More than $1M\n    \n    QUESTION 2: \"How quickly do you need the money?\"\n    Buttons:\n    - ⚡ Today or tomorrow (emergency)\n    - 📅 This week\n    - 📆 This month\n    - 🗓️ I'm just planning ahead\n    \n    QUESTION 3: \"How long have you been in business?\"\n    Buttons:\n    - 🐣 Just starting (0-3 months)\n    - 🌱 Early stage (3-12 months)\n    - 🌿 Growing (1-2 years)\n    - 🌳 Established (2+ years)\n    \n    QUESTION 4: \"What's your monthly revenue?\"\n    Buttons:\n    - $0 - $5K\n    - $5K - $10K\n    - $10K - $50K\n    - $50K - $100K\n    - $100K+\n    \n    QUESTION 5: \"How's your credit?\"\n    Buttons with friendly labels:\n    - 😊 Excellent (720+)\n    - 🙂 Good (650-719)\n    - 😐 Fair (580-649)\n    - 😕 Needs work (below 580)\n    - 🤷 Not sure\n    \n    QUESTION 6: \"What will you use the funding for?\"\n    Checkboxes (multi-select):\n    - Working capital / Cash flow\n    - Inventory purchase\n    - Equipment / Vehicles\n    - Marketing / Advertising\n    - Expansion / New location\n    - Debt consolidation\n    - Other\n    \n    QUESTION 7: \"What's most important to you?\"\n    Radio buttons:\n    - Lowest interest rate\n    - Fastest approval\n    - Highest approval odds\n    - No collateral required\n    - Flexible repayment\n    - Building business credit\n    \n    CONTACT INFORMATION PAGE:\n    Headline: \"Almost done! Where should we send your results?\"\n    Fields:\n    - Business Name\n    - Your Name\n    - Email Address\n    - Phone Number (optional but encouraged: \"Get your results faster via text\")\n    Privacy note: \"We'll never share your information\"\n    CTA: \"Get My Results\" button\n    \n    RESULTS PAGE:\n    \n    Headline: \"Based on Your Answers, Here Are Your Best Options:\"\n    \n    Personalized message: \"Great news, [Name]! Businesses like yours typically qualify for [amount range] in funding.\"\n    \n    Recommended Products (Ranked):\n    #1 Best Match: [Product Name]\n    - Why it's a match: [Personalized explanation based on quiz answers]\n    - Amount: $XX,XXX - $XX,XXX\n    - Approval time: X days\n    - Key features: [Bullet points]\n    - Match percentage: 95% match (gamification element)\n    - CTA: \"Apply Now\" or \"Learn More\"\n    \n    #2 Alternative Option: [Product Name]\n    - Similar structure, 80% match\n    - CTA: \"Compare Options\"\n    \n    #3 Backup Plan: [Product Name]\n    - 65% match\n    - CTA: \"View Details\"\n    \n    Not Recommended:\n    - [Product type] is not ideal because [reason based on answers]\n    - But if interested: \"Explore Anyway\" link\n    \n    NEXT STEPS SECTION:\n    \"What Should You Do Next?\"\n    Path 1: ✅ \"I'm ready to apply\"\n    - CTA: \"Start Application\"\n    \n    Path 2: 💬 \"I have questions first\"\n    - CTA: \"Chat with Specialist\"\n    \n    Path 3: 📚 \"I want to learn more\"\n    - CTA: \"Download Funding Guide\"\n    \n    RESULTS ACTIONS:\n    - Download results as PDF\n    - Email results to yourself\n    - Share quiz on social media\n    - Retake quiz\n    - Schedule consultation\n    \n    FOLLOW-UP AUTOMATION:\n    - Immediate email with results\n    - Follow-up email in 24 hours: \"Did you get a chance to review your funding options?\"\n    - Follow-up in 3 days: \"Case study of similar business\"\n    - Follow-up in 7 days: \"Still looking for funding? Let's talk.\"\n    \n    DESIGN REQUIREMENTS:\n    - One question per screen (mobile-friendly)\n    - Smooth transitions between questions\n    - Confetti animation on completion\n    - Visual progress indicators\n    - Shareable results page (unique URL)\n    - Mobile-optimized buttons (large, thumb-friendly)\n    - Playful illustrations throughout\n    - Accessibility considerations (keyboard navigation)\n    \n    GAMIFICATION ELEMENTS:\n    - Progress bar with encouraging messages\n    - \"X% match\" scoring for recommendations\n    - Badges or achievements (optional)\n    - Social sharing: \"I just found my perfect funding match!\"\n    \n    TECHNICAL REQUIREMENTS:\n    - Logic engine to map answers to product recommendations\n    - Email delivery of results\n    - CRM integration (create lead with quiz answers)\n    - Analytics: track drop-off by question\n    - A/B testing for question order and wording\n    - Retargeting pixel for incomplete quizzes\n    \n    VARIATIONS:\n    - Industry-specific quiz: \"E-commerce Funding Quiz\"\n    - Stage-specific: \"Startup Funding Quiz\"\n    - Goal-specific: \"Growth Capital Quiz\"\n    \n    OUTPUT FORMAT: React quiz app with state management, deployed to tools.distilledfunding.com/quiz.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md",
      "subdomain": "tools.distilledfunding.com",
      "target_audience": "TODO"
    },
    {
      "id": "learn-distilledfunding-com-education-platform",
      "name": "learn.distilledfunding.com - Education Platform",
      "category": "additional_subdomain",
      "asset_type": "Quiz",
      "audience": "TODO",
      "purpose": "Design a \"Funding Education Platform\" for learn.distilledfunding.com - comprehensive resource library with courses, guides, and certifications.",
      "visual_style": "Educational, Structured, Professional. Navy blue, Academic feel, Course cards, Progress tracking. CONTENT STRUCTURE: - Funding Fundamentals (Free Course) - Credit Building Bootcamp (Free Course) - Partner Certification Program (For affiliates) - Industry-Specific Guides (E-commerce, SaaS, Retail, et",
      "core_sections": [
        "VISUAL STYLE",
        "CONTENT STRUCTURE",
        "FEATURES",
        "OUTPUT FORMAT"
      ],
      "primary_cta": "TODO",
      "prompt": "Design a \"Funding Education Platform\" for learn.distilledfunding.com - comprehensive resource library with courses, guides, and certifications.\n    \n    VISUAL STYLE: Educational, Structured, Professional. Navy blue, Academic feel, Course cards, Progress tracking.\n    \n    CONTENT STRUCTURE:\n    - Funding Fundamentals (Free Course)\n    - Credit Building Bootcamp (Free Course)\n    - Partner Certification Program (For affiliates)\n    - Industry-Specific Guides (E-commerce, SaaS, Retail, etc.)\n    - Video Library\n    - Webinar Recordings\n    - Templates & Checklists (Downloadable)\n    - Glossary of Financing Terms\n    \n    FEATURES:\n    - User accounts with progress tracking\n    - Quizzes and assessments\n    - Certificates upon completion\n    - Community forum or discussion boards\n    - Live webinar schedule\n    - Email course drip campaigns\n    \n    OUTPUT FORMAT: Learning Management System (LMS) - Consider Teachable integration or custom Next.js + MDX for content.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md",
      "subdomain": "learn.distilledfunding.com",
      "target_audience": "TODO"
    },
    {
      "id": "compare-distilledfunding-com-product-comparison-engine",
      "name": "compare.distilledfunding.com - Product Comparison Engine",
      "category": "additional_subdomain",
      "asset_type": "Prompt Template",
      "audience": "TODO",
      "purpose": "Design a \"Funding Product Comparison Engine\" for compare.distilledfunding.com - dedicated to helping users compare all funding options side-by-side.",
      "visual_style": "Data-Driven, Clean Tables, Filterable, Sortable. Blue and green accents, Clear typography, Comparison charts. FEATURES: - Filterable comparison table (80+ funding products) - Search by: Product type, amount, speed, credit requirement, industry - Sort by: Rate, approval time, funding amount, populari",
      "core_sections": [
        "VISUAL STYLE",
        "FEATURES",
        "COMPARISON CATEGORIES",
        "OUTPUT FORMAT"
      ],
      "primary_cta": "TODO",
      "prompt": "Design a \"Funding Product Comparison Engine\" for compare.distilledfunding.com - dedicated to helping users compare all funding options side-by-side.\n    \n    VISUAL STYLE: Data-Driven, Clean Tables, Filterable, Sortable. Blue and green accents, Clear typography, Comparison charts.\n    \n    FEATURES:\n    - Filterable comparison table (80+ funding products)\n    - Search by: Product type, amount, speed, credit requirement, industry\n    - Sort by: Rate, approval time, funding amount, popularity\n    - \"Add to compare\" checkbox (up to 4 products)\n    - Side-by-side comparison view\n    - Pros/cons lists\n    - User reviews and ratings\n    - \"Best for\" recommendations\n    - Real-time rates (if available via API)\n    - \"Apply now\" links for each product\n    \n    COMPARISON CATEGORIES:\n    - Business Loans\n    - Lines of Credit\n    - Revenue-Based Financing\n    - Invoice Factoring\n    - Equipment Financing\n    - Merchant Cash Advances\n    - SBA Loans\n    - Business Credit Cards\n    - Microloans\n    - Grants\n    \n    OUTPUT FORMAT: Next.js app with filterable data tables, comparison logic, deployed to Vercel.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md",
      "subdomain": "compare.distilledfunding.com",
      "target_audience": "TODO"
    },
    {
      "id": "blog-distilledfunding-com-content-hub",
      "name": "blog.distilledfunding.com - Content Hub",
      "category": "additional_subdomain",
      "asset_type": "Hub",
      "audience": "TODO",
      "purpose": "Design a \"Funding Blog & Content Hub\" for blog.distilledfunding.com - SEO-optimized content library driving organic traffic.",
      "visual_style": "Editorial, Readable, Content-Focused. Clean typography, Featured images, Category organization. CONTENT CATEGORIES: - Funding Guides (How-tos, Comparisons) - Industry Insights (E-commerce, SaaS, Retail, etc.) - Success Stories (Case studies) - Partner Spotlights - Credit & Finance Tips - Company New",
      "core_sections": [
        "VISUAL STYLE",
        "CONTENT CATEGORIES",
        "BLOG FEATURES",
        "SEO OPTIMIZATION",
        "OUTPUT FORMAT"
      ],
      "primary_cta": "TODO",
      "prompt": "Design a \"Funding Blog & Content Hub\" for blog.distilledfunding.com - SEO-optimized content library driving organic traffic.\n    \n    VISUAL STYLE: Editorial, Readable, Content-Focused. Clean typography, Featured images, Category organization.\n    \n    CONTENT CATEGORIES:\n    - Funding Guides (How-tos, Comparisons)\n    - Industry Insights (E-commerce, SaaS, Retail, etc.)\n    - Success Stories (Case studies)\n    - Partner Spotlights\n    - Credit & Finance Tips\n    - Company News\n    - Market Trends\n    \n    BLOG FEATURES:\n    - Category and tag filtering\n    - Author pages (for thought leadership)\n    - Related posts\n    - Social sharing buttons\n    - Email subscription opt-in\n    - Comments (Disqus or native)\n    - Search functionality\n    - Newsletter signup\n    - Lead magnets within posts (downloadable guides)\n    \n    SEO OPTIMIZATION:\n    - Pillar page strategy (detailed above)\n    - Internal linking structure\n    - Schema markup for articles\n    - Social media optimization\n    - Fast loading times\n    - Mobile-responsive\n    \n    OUTPUT FORMAT: Next.js blog with MDX for content management, or headless CMS integration (Contentful, Sanity), deployed to Vercel.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md",
      "subdomain": "blog.distilledfunding.com",
      "target_audience": "TODO"
    },
    {
      "id": "app-distilledfunding-com-client-portal",
      "name": "app.distilledfunding.com - Client Portal",
      "category": "additional_subdomain",
      "asset_type": "Calculator",
      "audience": "TODO",
      "purpose": "Design a \"Client Portal Application\" for app.distilledfunding.com - secure dashboard for active clients to manage their funding.",
      "visual_style": "Application Dashboard, Secure, Professional. Dark mode option, Data visualizations, Clean UI. FEATURES: For Clients: - Application status tracking - Document upload - Payment history - Loan balance and payoff calculator - Communication with rep - Request additional funding - Statements and invoices ",
      "core_sections": [
        "VISUAL STYLE",
        "FEATURES",
        "TECHNICAL REQUIREMENTS",
        "OUTPUT FORMAT"
      ],
      "primary_cta": "TODO",
      "prompt": "Design a \"Client Portal Application\" for app.distilledfunding.com - secure dashboard for active clients to manage their funding.\n    \n    VISUAL STYLE: Application Dashboard, Secure, Professional. Dark mode option, Data visualizations, Clean UI.\n    \n    FEATURES:\n    For Clients:\n    - Application status tracking\n    - Document upload\n    - Payment history\n    - Loan balance and payoff calculator\n    - Communication with rep\n    - Request additional funding\n    - Statements and invoices\n    - Payment scheduling\n    - Refinancing options\n    \n    For Partners:\n    - Lead management dashboard\n    - Commission tracking\n    - Application submission\n    - Training modules\n    - Marketing resources\n    - Payout requests\n    - Team management (for agency builders)\n    - Performance analytics\n    \n    TECHNICAL REQUIREMENTS:\n    - Secure authentication (Auth0 or similar)\n    - Role-based access control\n    - Encrypted data storage\n    - Plaid integration for bank connections\n    - DocuSign integration for e-signatures\n    - Notification system (email + SMS)\n    - Real-time updates\n    - Mobile app potential (React Native)\n    \n    OUTPUT FORMAT: Full-stack Next.js application with database (PostgreSQL/MongoDB), authentication, and API integrations.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md",
      "subdomain": "app.distilledfunding.com",
      "target_audience": "TODO"
    }
  ]
}
```
# output-artifacts.registry.json

Description: Tracks what each tool generates: PDF, scorecard, script, checklist, quote, dashboard.
Last Updated: June 9, 2026 4:16 AM
# site-builder-gpts.registry.json

Description: Catalogs GPTs used to generate, scaffold, design, personalize, or deploy websites, landing pages, static pages, widgets, agent launch sites, profile pages, and Vercel-ready web assets.
Suggested Fields: id, name, slug, gpt_url, chatgpt_gpt_id, ownership, builder_type, primary_job, best_used_for, not_best_for, asset_type, page_type, site_type, build_format, runtime_stack, embed_type, style_presets, integrations, required_inputs, optional_inputs, outputs, prompt_templates, example_outputs, source_examples, business_model, audience_type, conversion_goal, cta_type, deployment_target, handoff_target, related_brand, related_project, routing_tags, status, visibility, notes
Last Updated: July 3, 2026 9:12 PM

## Purpose

This registry is the routing layer for site-builder GPTs. Use it to decide which builder to use based on output format, asset type, style preset, integrations, and handoff target.

## Registry property mapping

- Source: Manual
- Visibility: Internal
- Status: Planned
- Priority: High
- Deployed / Hosted At: TODO
- Linked Sources / Tools: TODO

## Source notes

- Items 1–7 were user-provided as owned CustomGPTs.
- Public ChatGPT pages for the owned GPTs expose limited logged-out metadata only, so unsupported fields are marked TODO.
- External GPT metadata was added only where public web results supported it.

## Example entries

```json
[
  {
    "id": "flash-ui-prompt-architect",
    "name": "Flash-UI Prompt Architect",
    "ownership": "Owned",
    "builder_type": "Prompt Builder",
    "build_format": ["Prompt Only", "Static HTML", "Embeddable Widget", "TODO"],
    "style_presets": ["Neo Brutalist", "Luxe Bento", "Luxury Agency", "Cyberpunk Fintech", "Brutalist Fintech"],
    "integrations": ["Vercel", "GitHub", "Tally", "Notion", "OpenAI Actions", "TODO"],
    "handoff_target": ["GitHub Repo", "Vercel Project", "Custom GPT Knowledge", "Prompt Only"]
  },
  {
    "id": "vercel-launch-smith",
    "name": "Vercel Launch Smith",
    "ownership": "Owned",
    "builder_type": "Deployment Helper",
    "build_format": ["Static HTML", "Next.js App Router", "Embeddable Widget", "JSON Config", "TODO"],
    "integrations": ["Vercel", "GitHub", "OpenAI Actions", "Tally", "Supabase", "TODO"],
    "deployment_target": ["Vercel"],
    "handoff_target": ["GitHub Repo", "Vercel Project"]
  },
  {
    "id": "designergpt",
    "name": "DesignerGPT",
    "ownership": "External",
    "builder_type": "UI Generator",
    "build_format": ["Hosted Page", "Static HTML", "TODO"],
    "integrations": ["DALL·E", "Replit"],
    "deployment_target": ["Replit", "ChatGPT", "TODO"],
    "handoff_target": ["Replit", "Prompt Only", "TODO"]
  }
]
```

## Full registry JSON

The complete `site-builder-gpts.registry.json` file was generated separately as the downloadable source file for this registry. Upload it to the File property when attaching local files is available.
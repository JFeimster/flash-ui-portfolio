# digital-products.registry.json

Description: Catalog of digital products and offers with type, format, funnel role, status, brand fit, persona, price, billing, shop category, and build target.
Suggested Fields: id, product_name, catalog_type, offer_format, funnel_role, status, brand_fit, primary_persona, price, billing_type, shop_category, build_target, description
File: digital-products.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
🛒

**Single responsibility:** Track the digital product/offer catalog (format, funnel role, price, build target) so the shop and offer ladder stay organized. Source: Digital Products database (60 captured rows).

</aside>

## Completed Registry — digital-products.registry.json

[digital-products.registry.json](digital-products.registry.json)

digital-products.registry.json

<aside>
✅

The attached completed JSON file is the primary source of truth. The sections below are secondary drafting/schema notes and compact previews.

</aside>

## Drafting & Schema Details

### Suggested fields

- `id`, `product_name`, `catalog_type`, `offer_format`, `funnel_role`, `status`
- `brand_fit`, `primary_persona`, `price`, `billing_type`
- `shop_category`, `build_target`, `description`

### Registry JSON

```json
{
  "id": "digital-products",
  "name": "Digital Products",
  "source": "CSV Import",
  "visibility": "Internal",
  "fields": {
    "id": "kebab-case unique id",
    "product_name": "product name",
    "catalog_type": "catalog type",
    "offer_format": "offer format",
    "funnel_role": "funnel role",
    "status": "status",
    "brand_fit": "brand fit",
    "primary_persona": "primary persona",
    "price": "price",
    "billing_type": "billing type",
    "shop_category": "shop category",
    "build_target": "build target",
    "description": "description"
  },
  "entries": [
    {
      "id": "ai-funding-coach-membership",
      "product_name": "AI Funding Coach Membership",
      "catalog_type": "Membership",
      "offer_format": "Subscription",
      "funnel_role": "Premium Recurring",
      "price": 349,
      "billing_type": "Monthly",
      "build_target": "Hybrid"
    }
  ]
}
```

### Example entries

- **AI Funding Coach Membership** — $349/mo premium recurring coaching.
- **Capital Stack Planner** — $79 planning template (Retention).
- **Embed Tools Into Wix and Notion** — $59 implementation guide (Front-End).

*Complete data (60 entries) is in the attached `digital-products.registry.json`.*
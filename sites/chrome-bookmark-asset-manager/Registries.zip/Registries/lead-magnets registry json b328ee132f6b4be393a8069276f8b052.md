# lead-magnets.registry.json

Description: Lead-magnet catalog (Fundability Scorecard, Daily Cash Flow Impact Report, etc.) mapped to source tools and personas.
Suggested Fields: lead_magnet_slug, name, format, source_tools, persona, funnel_stage, delivery_method, requires_email
Last Updated: June 9, 2026 3:35 AM

<aside>
🎯

Catalog of lead magnets / output artifacts produced by tools (Funding Quote PDF, Fundability Scorecard, Daily Cash Flow Impact Report, Good Business Certificate, Second-Chance Funding Match PDF, Fast Funding Alternatives Checklist, Weekly Payroll Liquidity Plan).

</aside>

### 🧱 Suggested Fields

```json
{
  "lead_magnet_slug": "",
  "name": "",
  "format": "",
  "source_tools": [],
  "persona": "",
  "funnel_stage": "",
  "delivery_method": "",
  "requires_email": false
}
```

### 📌 Example entry

```json
{
  "lead_magnet_slug": "fundability-scorecard",
  "name": "Fundability Scorecard",
  "format": "scorecard",
  "source_tools": ["the-blue-collar-banker-lead-qualifier"],
  "persona": "Funding Agents",
  "funnel_stage": "lead-capture",
  "delivery_method": "onscreen-summary",
  "requires_email": true
}
```
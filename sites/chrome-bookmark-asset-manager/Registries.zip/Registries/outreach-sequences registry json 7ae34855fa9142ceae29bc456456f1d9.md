# outreach-sequences.registry.json

Description: Automated applicant outreach sequences used by the Applicant Intake CRM with triggers, step cadences, and exit conditions.
Suggested Fields: id, sequence_name, trigger, steps, cadence, exit_condition
File: outreach-sequences.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
📨

**Single responsibility** — The applicant-facing outreach sequences (intro, docs follow-up, Plaid connection, nurture, re-engagement) with their cadences and exit conditions. Kept separate from the offer-launch `offer-sequencing` registry.

</aside>

## Completed Registry — outreach-sequences.registry.json

[outreach-sequences.registry.json](outreach-sequences.registry.json)

outreach-sequences.registry.json

<aside>
✅

The attached completed JSON file is the primary source of truth. The sections below are secondary drafting/schema notes and compact previews.

</aside>

## Drafting & Schema Details

### Suggested fields

- `id` — kebab-case slug
- `sequence_name` — sequence name
- `trigger` — what starts the sequence
- `steps` — ordered steps (array)
- `cadence` — timing between steps
- `exit_condition` — what ends the sequence

### Registry JSON

```json
{
  "id": "outreach-sequences",
  "name": "outreach-sequences",
  "source": "Manual",
  "visibility": "Internal",
  "fields": {
    "id": "kebab-case slug",
    "sequence_name": "Sequence name",
    "trigger": "What starts the sequence",
    "steps": "Ordered steps (array)",
    "cadence": "Timing between steps",
    "exit_condition": "What ends the sequence"
  },
  "entries": [
    { "id": "new-lead-intro", "sequence_name": "New Lead Intro", "trigger": "New applicant lead", "steps": ["Step 1 (day 0)", "Step 2 (+1 day)", "Step 3 (+3 days)", "Step 4 (+7 days)"], "exit_condition": "Applicant responds / advances stage" },
    { "id": "docs-follow-up", "sequence_name": "Docs Follow-up", "trigger": "Docs Requested stage", "steps": ["Step 1 (immediate)", "Step 2 (+2 days)", "Step 3 (+5 days)", "Step 4 (+10 days)"], "exit_condition": "All required documents received" }
  ]
}
```

### Example entries

- **New Lead Intro** — days 0/1/3/7.
- **Docs Follow-up** — days 0/2/5/10.
- **Plaid Connection**, **Nurture Drip** (30d), **Re-engagement** (7d).
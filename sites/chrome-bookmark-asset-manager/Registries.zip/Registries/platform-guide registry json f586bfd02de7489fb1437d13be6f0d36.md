# platform-guide.registry.json

Description: Reference rules for which platform to use per offer type across Vercel, Stripe, Wix, WordPress, HubSpot, Notion, and GitHub.
Suggested Fields: id, name, platform, primary_use, use_when, avoid_when, best_offer_types, notes
File: platform-guide.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
🧭

**Purpose:** Reference rules for which platform to use per offer type across Vercel, Stripe, Wix, WordPress, HubSpot, Notion, and GitHub.

**Source:** CSV Import · **Visibility:** Internal · **Status:** Built · **Priority:** Medium

</aside>

## Completed Registry — platform-guide.registry.json

[platform-guide.registry.json](platform-guide.registry.json)

platform-guide.registry.json

<aside>
✅

The attached completed JSON file is the primary source of truth. The sections below are secondary drafting/schema notes and compact previews.

</aside>

## Drafting & Schema Details

### Registry JSON

```json
{
  "id": "platform-guide",
  "name": "platform-guide.registry.json",
  "description": "Reference rules for which platform to use per offer type across Vercel, Stripe, Wix, WordPress, HubSpot, Notion, and GitHub.",
  "source": "CSV Import",
  "visibility": "Internal",
  "fields": {
    "id": "", "name": "", "platform": "", "primary_use": "", "use_when": "", "avoid_when": "", "best_offer_types": "", "notes": ""
  },
  "entries": [
    {
      "id": "vercel",
      "name": "Vercel",
      "platform": "Vercel",
      "primary_use": "Fast high-design landing pages, funnels, widgets, calculators, mini-apps",
      "use_when": "You need sizzling UX, embeds, quizzes, custom logic, or rapid GPT-driven launch",
      "avoid_when": "You only need native commerce/community tools that Wix already handles well",
      "best_offer_types": "Assessments, calculators, tool-led funnels, flagship sales pages"
    },
    {
      "id": "stripe",
      "name": "Stripe",
      "platform": "Stripe",
      "primary_use": "Checkout, subscriptions, invoices, payment links, embeddable buy flows",
      "use_when": "You need the fastest path to collecting money or want embeds/hosted checkout",
      "best_offer_types": "Tripwires, digital products, subscriptions, premium invoices"
    },
    {
      "id": "wix",
      "name": "Wix",
      "platform": "Wix",
      "primary_use": "Native stores, bookings, pricing plans, members area, services, groups",
      "use_when": "You are using Stores, Bookings, Services, Pricing Plans, Groups, or Members Area",
      "avoid_when": "You need a highly custom sales page or funnel and Wix fights the design",
      "best_offer_types": "Memberships, events, service directories, partner hubs"
    }
  ],
  "_note": "Showing 3 of 7 entries (also: WordPress, HubSpot, Notion, GitHub). The complete 7-entry registry is in the attached platform-guide.registry.json file."
}
```

### Example entries

- **Vercel** — Fast high-design funnels, tools, calculators; default for speed + quality.
- **Stripe** — Checkout, subscriptions, payment links; fastest path to collecting money.
- **Wix** — Native stores, bookings, memberships; use as commerce/community shell.

All 7 platforms (incl. WordPress, HubSpot, Notion, GitHub) are in the attached **File** property above.
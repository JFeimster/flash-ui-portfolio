# integrations.registry.json

Description: n8n/webhook/endpoint map referenced by key, not secrets. endpoint_ref/auth_ref hold env-var KEY names only.
Suggested Fields: id, name, type, endpoint_ref, auth_ref, used_by, status, schemaVersion, superseded, supersededBy, updatedAt
Last Updated: June 18, 2026 12:35 PM

<aside>
🎯

The integration/endpoint map: n8n flows, webhooks, and APIs the network depends on. ⚠️ `endpoint_ref` and `auth_ref` store env-var KEY names only — never raw URLs with tokens or secrets.

</aside>

### 🧱 Suggested Fields

```json
{
  "id": "",
  "name": "",
  "type": "",
  "endpoint_ref": "",
  "auth_ref": "",
  "used_by": [],
  "status": "active",
  "schemaVersion": "1.0.0",
  "superseded": false,
  "supersededBy": null,
  "updatedAt": ""
}
```

### 📌 Example entry

```json
[
  { "id": "n8n-lead-router", "name": "n8n Lead Router", "type": "webhook", "endpoint_ref": "N8N_LEAD_WEBHOOK_URL", "auth_ref": "N8N_API_KEY", "used_by": ["funding-directory.registry.json", "cta-routing.registry.json"], "status": "active", "schemaVersion": "1.0.0", "superseded": false, "supersededBy": null, "updatedAt": "2026-06-18" }
]
```
# public-funding-directory.registry.json

Description: White-labeled public directory — no provider names, no affiliate links, no commission rates, no direct-to-provider leakage.
Suggested Fields: name, slug, public_category, persona, description, best_for, requirements_summary, funding_range_summary, speed_summary, cta_label, cta_url, related_tools, collection, featured
Last Updated: June 9, 2026 3:35 AM

<aside>
🎯

The public-facing, white-labeled directory. **No provider names, no affiliate links, no commission rates, no direct-to-provider leakage** — those live in the private registries.

</aside>

### 🧱 Suggested Fields

```json
{
  "name": "",
  "slug": "",
  "public_category": "",
  "persona": [],
  "description": "",
  "best_for": [],
  "requirements_summary": "",
  "funding_range_summary": "",
  "speed_summary": "",
  "cta_label": "",
  "cta_url": "",
  "related_tools": [],
  "collection": "",
  "featured": false
}
```

### 📌 Example entry

```json
{
  "name": "Fast Working Capital Review",
  "slug": "fast-working-capital-review",
  "public_category": "Business Funding",
  "persona": ["Small Business Owner", "Service Business", "Local Operator"],
  "description": "Review possible working capital paths based on revenue, time in business, and cash-flow profile",
  "cta_label": "Check Funding Fit",
  "cta_url": "/tools/funding-pathfinder/",
  "collection": "cashgap",
  "featured": true
}
```
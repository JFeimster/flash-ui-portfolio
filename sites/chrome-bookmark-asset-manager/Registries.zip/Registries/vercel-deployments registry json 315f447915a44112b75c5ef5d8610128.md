# vercel-deployments.registry.json

Description: Inventory of 157 live Vercel deployments (the hands + storefronts) with live URLs, repos, and last deploy.
Suggested Fields: name, slug, live_url, repo, last_deploy, status, duplicate
File: vercel-deployments.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
▲

**157 live Vercel apps** — the “hands + storefront” layer: tools, widgets, funnels, and portals with live URLs.

</aside>

## Summary

- **Total projects:** 157 (all marked `status: live`)
- **Exact-name duplicates:** 0
- **Near-duplicate families to reconcile:** `FundStack-AI`/`fund-stack-ai`, `saasfly`/`saasfly-ai`, `bizcredit-os`/`BizCreditOS`, `bio-1`/`bio-2`
- **Role in stacks:** tool + host-site layer

## Full registry file

[vercel-deployments.registry.json](vercel-deployments.registry.json)

vercel-deployments.registry.json
# offer-sequencing.registry.json

Description: Build-order sequencing plan for the 20 offers with priority tier, owner, dependencies, required assets, AI path, and launch status.
Suggested Fields: id, name, build_order, brand_lane, priority_tier, owner, dependencies, required_assets, est_build_time, ai_assisted_path, primary_build_surface, checkout_monetization, crm_ops_wiring, launch_status, recommended_first_action, risk_bottleneck, notes
File: offer-sequencing.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
🗓️

**Purpose:** Build-order sequencing plan for the 20 offers with priority tier, owner, dependencies, required assets, AI path, and launch status.

**Source:** CSV Import · **Visibility:** Internal · **Status:** In Progress · **Priority:** High

</aside>

## Completed Registry — offer-sequencing.registry.json

[offer-sequencing.registry.json](offer-sequencing.registry.json)

offer-sequencing.registry.json

<aside>
✅

The attached completed JSON file is the primary source of truth. The sections below are secondary drafting/schema notes and compact previews.

</aside>

## Drafting & Schema Details

### Registry JSON

```json
{
  "id": "offer-sequencing",
  "name": "offer-sequencing.registry.json",
  "description": "Build-order sequencing plan for the 20 offers with priority tier, owner, dependencies, required assets, AI path, and launch status.",
  "source": "CSV Import",
  "visibility": "Internal",
  "fields": {
    "id": "", "name": "", "build_order": "", "brand_lane": "", "priority_tier": "", "owner": "", "dependencies": "", "required_assets": "", "est_build_time": "", "ai_assisted_path": "", "primary_build_surface": "", "checkout_monetization": "", "crm_ops_wiring": "", "launch_status": "", "recommended_first_action": "", "risk_bottleneck": "", "notes": ""
  },
  "entries": [
    {
      "id": "creator-toolkit-vault",
      "name": "Creator Toolkit Vault",
      "build_order": 1,
      "brand_lane": "Full-Time Hustler",
      "priority_tier": "Quick Win",
      "owner": "Jason + AI",
      "est_build_time": "0.5-1 day",
      "primary_build_surface": "Stripe + Notion",
      "launch_status": "Ready to Build",
      "recommended_first_action": "Package the starter toolkit and publish a Stripe payment link"
    },
    {
      "id": "magnet-forge",
      "name": "Magnet Forge",
      "build_order": 2,
      "brand_lane": "Moonshine Capital",
      "priority_tier": "Quick Win",
      "est_build_time": "0.5-1 day",
      "primary_build_surface": "Vercel or Stripe-hosted page",
      "launch_status": "Ready to Build"
    },
    {
      "id": "capital-readiness-brief",
      "name": "Capital Readiness Brief",
      "build_order": 3,
      "brand_lane": "Moonshine Capital",
      "priority_tier": "Quick Win",
      "est_build_time": "1-2 days",
      "primary_build_surface": "Vercel",
      "launch_status": "Ready to Spec"
    }
  ],
  "_note": "Showing 3 of 20 entries. The complete 20-entry registry is in the attached offer-sequencing.registry.json file."
}
```

### Example entries

- **1. Creator Toolkit Vault** (FTH, Quick Win) — Ready to Build, Stripe + Notion, ~0.5–1 day.
- **2. Magnet Forge** (Moonshine, Quick Win) — Ready to Build, Vercel/Stripe page.
- **3. Capital Readiness Brief** (Moonshine, Quick Win) — Ready to Spec, Vercel, ~1–2 days.

The complete 20-offer sequencing plan is attached in the **File** property above.
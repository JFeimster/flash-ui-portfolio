# flash-ui-template-patterns.registry.json

Description: Registry of reusable Flash UI template patterns, including dashboards, calculators, portals, knowledge bases, directories, SaaS consoles, fintech infrastructure UIs, and landing page layouts.
Suggested Fields: id, name, description, asset_type, industry, visual_style, layout_pattern, prompt, source_file, overlap_notes
File: flash-ui-template-patterns.registry.json
Last Updated: June 30, 2026 7:06 PM

<aside>
🗂️

**Purpose:** Registry of reusable Flash UI template patterns, including dashboards, calculators, portals, knowledge bases, directories, SaaS consoles, fintech infrastructure UIs, and landing page layouts.

</aside>

## Registry summary

- **Registry:** `flash-ui-template-patterns.registry.json`
- **Source:** Manual
- **Visibility:** Internal
- **Entries:** 107
- **Suggested fields:** id, name, description, asset_type, industry, visual_style, layout_pattern, prompt, source_file, overlap_notes

## Example entries

- **Payroll Panic' Survival Dashboard** — Emergency cash-flow visualizer for contractors (ROK).
- **Stockout Death Spiral' Estimator** — Loss calculator for Amazon sellers (8fig).
- **Amazon 'Phantom Cash' Audit** — Visualizes trapped 'DD+7' funds (Payability).

## Full registry JSON

```json
{
  "id": "flash-ui-template-patterns",
  "name": "flash-ui-template-patterns.registry.json",
  "description": "Registry of reusable Flash UI template patterns, including dashboards, calculators, portals, knowledge bases, directories, SaaS consoles, fintech infrastructure UIs, and landing page layouts.",
  "source": "Manual",
  "visibility": "Internal",
  "fields": {
    "id": "kebab-case unique id",
    "name": "template name",
    "description": "source description",
    "asset_type": "template asset type",
    "industry": "industry or vertical",
    "visual_style": "visual direction",
    "layout_pattern": "layout details",
    "prompt": "full prompt",
    "source_file": "source file name",
    "overlap_notes": "duplicate/overlap notes"
  },
  "entries": [
    {
      "id": "payroll-panic-survival-dashboard",
      "name": "Payroll Panic' Survival Dashboard",
      "description": "Emergency cash-flow visualizer for contractors (ROK).",
      "asset_type": "Dashboard",
      "industry": "construction",
      "visual_style": "Crisis Management, High-Contrast, \"Red Alert\" aesthetics. Matte Black background, Warning Red, Safety Yellow, Solvency Green. Mono-spaced numbers",
      "layout_pattern": "Countdown timer (\"Time Until Payroll\"), Visual bar chart gap (Cash vs Burden), Invoice Selector, Solvency Simulator toggle, CTA \"Bridge the Gap\"",
      "prompt": "Design a high-stakes \"Payroll Panic\" Survival Dashboard for construction contractors. VISUAL STYLE: Crisis Management, High-Contrast, \"Red Alert\" aesthetics. Matte Black background, Warning Red, Safety Yellow, Solvency Green. Mono-spaced numbers. LAYOUT: Countdown timer (\"Time Until Payroll\"), Visual bar chart gap (Cash vs Burden), Invoice Selector, Solvency Simulator toggle, CTA \"Bridge the Gap\".",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "stockout-death-spiral-estimator",
      "name": "Stockout Death Spiral' Estimator",
      "description": "Loss calculator for Amazon sellers (8fig).",
      "asset_type": "Calculator",
      "industry": "ecommerce",
      "visual_style": "Data-Forensics, Analytical, Serious. Deep Navy, Loss Red, Ghost Grey",
      "layout_pattern": "Header \"Inventory Health: CRITICAL\", Simulation graph (Funded vs Stockout), Damage Report grid, Capital Injection slider, CTA \"Secure Inventory\"",
      "prompt": "Design a \"Stockout Death Spiral\" Estimator for high-volume Amazon sellers. VISUAL STYLE: Data-Forensics, Analytical, Serious. Deep Navy, Loss Red, Ghost Grey. LAYOUT: Header \"Inventory Health: CRITICAL\", Simulation graph (Funded vs Stockout), Damage Report grid, Capital Injection slider, CTA \"Secure Inventory\".",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "amazon-phantom-cash-audit",
      "name": "Amazon 'Phantom Cash' Audit",
      "description": "Visualizes trapped 'DD+7' funds (Payability).",
      "asset_type": "Prompt Template",
      "industry": "ecommerce",
      "visual_style": "FinTech, Revealing, \"Hidden Truth\". Amazon Dark Blue, \"Locked\" Grey, \"Liquid\" Gold",
      "layout_pattern": "Receipt-style Ledger, Deferred Transactions breakdown with padlock icon, Interest Lost ticker, Unlock Animation toggle, Result CTA \"Withdraw to Bank\"",
      "prompt": "Design an \"Amazon Phantom Cash\" Audit tool. VISUAL STYLE: FinTech, Revealing, \"Hidden Truth\". Amazon Dark Blue, \"Locked\" Grey, \"Liquid\" Gold. LAYOUT: Receipt-style Ledger, Deferred Transactions breakdown with padlock icon, Interest Lost ticker, Unlock Animation toggle, Result CTA \"Withdraw to Bank\".",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "spot-market-breakeven-cockpit",
      "name": "Spot Market' Breakeven Cockpit",
      "description": "Profitability calculator for truckers (ROK).",
      "asset_type": "Calculator",
      "industry": "trucking",
      "visual_style": "Industrial, Automotive, HUD. Dashboard Amber, Night-Mode Black, Chrome",
      "layout_pattern": "Rate Gauge, Cost Inputs (Fuel, Insurance), Dynamic Breakeven Line, Profit Zone highlight, Emergency Button",
      "prompt": "Design a \"Spot Market Breakeven Cockpit\" for independent truckers. VISUAL STYLE: Industrial, Automotive, HUD. Dashboard Amber, Night-Mode Black, Chrome. LAYOUT: Rate Gauge, Cost Inputs (Fuel, Insurance), Dynamic Breakeven Line, Profit Zone highlight, Emergency Button.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "tiktok-shop-viral-curse-manager",
      "name": "TikTok Shop 'Viral Curse' Manager",
      "description": "Inventory vs. Velocity tracker to prevent suspension.",
      "asset_type": "Dashboard",
      "industry": "general",
      "visual_style": "Social Commerce, Fast-Paced, Gen-Z Tech. Neon Pink, Cyan, Black",
      "layout_pattern": "Viral Spike line chart, Inventory Depletion bar, Suspension Risk badge, Bridge funding visualization, Instant Fix button",
      "prompt": "Design a \"TikTok Shop Viral Curse\" Manager dashboard. VISUAL STYLE: Social Commerce, Fast-Paced, Gen-Z Tech. Neon Pink, Cyan, Black. LAYOUT: Viral Spike line chart, Inventory Depletion bar, Suspension Risk badge, Bridge funding visualization, Instant Fix button.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "logistics-repair-vs-replace-roi",
      "name": "Logistics 'Repair vs Replace' ROI",
      "description": "Decision engine for blown truck engines.",
      "asset_type": "Prompt Template",
      "industry": "trucking",
      "visual_style": "Heavy Machinery, Blueprint, Calculated. Caterpillar Yellow, Steel, Blueprint Blue",
      "layout_pattern": "Asset details, Scenario A (Repair) vs Scenario B (Replace) comparison, Verdict stamp, Funding button",
      "prompt": "Design a \"Repair vs Replace\" ROI decision engine for heavy equipment. VISUAL STYLE: Heavy Machinery, Blueprint, Calculated. Caterpillar Yellow, Steel, Blueprint Blue. LAYOUT: Asset details, Scenario A (Repair) vs Scenario B (Replace) comparison, Verdict stamp, Funding button.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "net-90-opportunity-cost-calc",
      "name": "Net-90' Opportunity Cost Calc",
      "description": "Shows cost of waiting for payment vs. factoring.",
      "asset_type": "Calculator",
      "industry": "banking",
      "visual_style": "Investment Banking, Clean, High-Value. White, ROI Green, \"Lost\" Red",
      "layout_pattern": "Invoice details, Timeline of waiting, Missed Opportunities metrics, Factoring Math comparison, CTA \"Buy Your Cash Flow Back\"",
      "prompt": "Design a \"Net-90 Opportunity Cost\" Calculator. VISUAL STYLE: Investment Banking, Clean, High-Value. White, ROI Green, \"Lost\" Red. LAYOUT: Invoice details, Timeline of waiting, Missed Opportunities metrics, Factoring Math comparison, CTA \"Buy Your Cash Flow Back\".",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "gig-economy-survival-wallet",
      "name": "Gig Economy 'Survival' Wallet",
      "description": "Instant 'Back on Road' funding for Uber/Lyft drivers.",
      "asset_type": "Prompt Template",
      "industry": "general",
      "visual_style": "Fast, High-Contrast, Dark Mode. Asphalt Black, Neon Green, Alert Amber",
      "layout_pattern": "Status Header, Main Speedometer Gauge (Fundable Amount), Emergency Buttons (Tires, Tow), Recent Earnings list, One-Tap Fund slider",
      "prompt": "Design a mobile-first \"Gig Economy Survival Wallet\" for independent drivers. VISUAL STYLE: Fast, High-Contrast, Dark Mode. Asphalt Black, Neon Green, Alert Amber. LAYOUT: Status Header, Main Speedometer Gauge (Fundable Amount), Emergency Buttons (Tires, Tow), Recent Earnings list, One-Tap Fund slider.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "contractor-supply-house-checkout",
      "name": "Contractor 'Supply House' Checkout",
      "description": "Material financing app for Electricians/Plumbers.",
      "asset_type": "Prompt Template",
      "industry": "construction",
      "visual_style": "Industrial, Utilitarian, Trustworthy. Safety Orange, Steel Gray, Blueprint Blue",
      "layout_pattern": "Job Selector, Invoice Scanner, Visual Gap breakdown, Fund/Pay toggle, Repayment Terms selector",
      "prompt": "Design a \"Supply House Checkout\" tablet interface for Trade Contractors. VISUAL STYLE: Industrial, Utilitarian, Trustworthy. Safety Orange, Steel Gray, Blueprint Blue. LAYOUT: Job Selector, Invoice Scanner, Visual Gap breakdown, Fund/Pay toggle, Repayment Terms selector.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "real-estate-wholesaler-deal-room",
      "name": "Real Estate 'Wholesaler' Deal Room",
      "description": "Instant Proof-of-Funds generator for flippers.",
      "asset_type": "Dashboard",
      "industry": "real_estate",
      "visual_style": "Deal-driven, Premium. Deep Gold, Navy Blue, White",
      "layout_pattern": "Property Card (Distressed vs ARV), Closing Date Countdown, Proof of Funds Widget, Hard Money Quote sidebar, Action button \"Fund This Flip\"",
      "prompt": "Design a \"Real Estate Wholesaler Deal Room\" dashboard. VISUAL STYLE: Deal-driven, Premium. Deep Gold, Navy Blue, White. LAYOUT: Property Card (Distressed vs ARV), Closing Date Countdown, Proof of Funds Widget, Hard Money Quote sidebar, Action button \"Fund This Flip\".",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "amazon-reserve-unlocker",
      "name": "Amazon 'Reserve Unlocker",
      "description": "Dashboard to free up trapped 'DD+7' cash.",
      "asset_type": "Dashboard",
      "industry": "ecommerce",
      "visual_style": "Analytical, Data-Dense. Amazon Dark Blue, \"Locked\" Grey vs \"Unlocked\" Bright Green",
      "layout_pattern": "Progress bar trap (Available vs Deferred), Unlock animation, Velocity Metric chart, Fee Nullifier comparison, CTA \"Advance to Bank\"",
      "prompt": "Design an \"Amazon Reserve Unlocker\" dashboard for FBA Sellers. VISUAL STYLE: Analytical, Data-Dense. Amazon Dark Blue, \"Locked\" Grey vs \"Unlocked\" Bright Green. LAYOUT: Progress bar trap (Available vs Deferred), Unlock animation, Velocity Metric chart, Fee Nullifier comparison, CTA \"Advance to Bank\".",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "startup-credit-stacker-console",
      "name": "Startup 'Credit Stacker' Console",
      "description": "0% interest business credit optimizer for startups.",
      "asset_type": "Console",
      "industry": "startup",
      "visual_style": "Fintech, Sleek, Gamified. Cyber Purple, Holographic Gradients",
      "layout_pattern": "Personal FICO anchor, Vertical Stack of cards, Interest Saver display, Utilization Monitor, Runway Simulator slider",
      "prompt": "Design a \"Startup Credit Stacker\" console. VISUAL STYLE: Fintech, Sleek, Gamified. Cyber Purple, Holographic Gradients. LAYOUT: Personal FICO anchor, Vertical Stack of cards, Interest Saver display, Utilization Monitor, Runway Simulator slider.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "logistics-repair-finance-hub",
      "name": "Logistics 'Repair Finance' Hub",
      "description": "Emergency engine repair funding for truckers.",
      "asset_type": "Calculator",
      "industry": "trucking",
      "visual_style": "Heavy Duty, Mechanic Shop, Urgent. Grease Black, Chrome, Stop-Sign Red",
      "layout_pattern": "Truck Profile, Repair Quote, Revenue Loss Calculator, Asset-Backed Loan solution, Direct Pay button",
      "prompt": "Design a \"Fleet Rescue\" repair finance interface. VISUAL STYLE: Heavy Duty, Mechanic Shop, Urgent. Grease Black, Chrome, Stop-Sign Red. LAYOUT: Truck Profile, Repair Quote, Revenue Loss Calculator, Asset-Backed Loan solution, Direct Pay button.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "supply-chain-flow-planner",
      "name": "Supply Chain 'Flow' Planner",
      "description": "Logistics-aligned funding for private label sellers.",
      "asset_type": "Prompt Template",
      "industry": "ecommerce",
      "visual_style": "Logistics, Global Trade. Ocean Blue, Container Red, Map Beige",
      "layout_pattern": "Horizontal Gantt Chart, Cash Milestones, Funding Injection drops, Inventory Value tracker, Change Request button",
      "prompt": "Design a \"Supply Chain Flow\" funding planner. VISUAL STYLE: Logistics, Global Trade. Ocean Blue, Container Red, Map Beige. LAYOUT: Horizontal Gantt Chart, Cash Milestones, Funding Injection drops, Inventory Value tracker, Change Request button.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "e-com-ad-arbitrage-command",
      "name": "E-Com 'Ad Arbitrage' Command",
      "description": "Funding Q4 ad spend based on ROAS.",
      "asset_type": "Calculator",
      "industry": "general",
      "visual_style": "High-Frequency Trading, Aggressive. Chart Green, Panic Red, Dark Mode",
      "layout_pattern": "Live ROAS ticker, Budget Constraint, Arbitrage Calculator, Funding Lever slider, Performance Pay toggle",
      "prompt": "Design an \"E-Com Ad Arbitrage\" command center. VISUAL STYLE: High-Frequency Trading, Aggressive. Chart Green, Panic Red, Dark Mode. LAYOUT: Live ROAS ticker, Budget Constraint, Arbitrage Calculator, Funding Lever slider, Performance Pay toggle.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "cpa-tax-rescue-portal",
      "name": "CPA 'Tax Rescue' Portal",
      "description": "IRS tax bill financing for business owners.",
      "asset_type": "Portal",
      "industry": "tax",
      "visual_style": "Professional, Calming. Paper White, Slate Blue, Green accents",
      "layout_pattern": "Client Profile, Liability Total, Rescue Advance option, Plan Comparison (IRS vs Rescue), Direct Settlement screen",
      "prompt": "Design a \"CPA Tax Rescue\" portal. VISUAL STYLE: Professional, Calming. Paper White, Slate Blue, Green accents. LAYOUT: Client Profile, Liability Total, Rescue Advance option, Plan Comparison (IRS vs Rescue), Direct Settlement screen.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "unbankable-credit-incubator",
      "name": "Unbankable' Credit Incubator",
      "description": "Gamified business credit builder for rejected leads.",
      "asset_type": "Dashboard",
      "industry": "banking",
      "visual_style": "Educational, Gamified. Level-up Gold, Progress Blue",
      "layout_pattern": "Fundability Score gauge, Roadmap path (steps to unlock), Action Items, Prize (Unlock Credit Line)",
      "prompt": "Design a \"Credit Incubator\" dashboard. VISUAL STYLE: Educational, Gamified. Level-up Gold, Progress Blue. LAYOUT: Fundability Score gauge, Roadmap path (steps to unlock), Action Items, Prize (Unlock Credit Line).",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "ai-contract-sentinel",
      "name": "AI Contract Sentinel",
      "description": "B2B Legal SaaS for automated NDA/MSA review.",
      "asset_type": "Prompt Template",
      "industry": "legal",
      "visual_style": "Authoritative, Trustworthy. Deep Navy Blue, Paper White, Red Flag accents",
      "layout_pattern": "Split Screen (Doc Viewer vs AI Panel), Analysis Cards, Sidebar Nav, Breadcrumbs Header",
      "prompt": "Design a workspace for \"AI Contract Sentinel\". VISUAL STYLE: Authoritative, Trustworthy. Deep Navy Blue, Paper White, Red Flag accents. LAYOUT: Split Screen (Doc Viewer vs AI Panel), Analysis Cards, Sidebar Nav, Breadcrumbs Header.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "construction-bid-commander",
      "name": "Construction Bid Commander",
      "description": "Estimating tool for GCs to process blueprints.",
      "asset_type": "Dashboard",
      "industry": "construction",
      "visual_style": "Industrial, Utilitarian. Technical Blue, Concrete Gray, Safety Orange",
      "layout_pattern": "Project Header, Material Takeoff data table, Blueprint Viewer placeholder, Sticky Estimator Widget",
      "prompt": "Design a rugged \"Construction Bid Commander\" dashboard. VISUAL STYLE: Industrial, Utilitarian. Technical Blue, Concrete Gray, Safety Orange. LAYOUT: Project Header, Material Takeoff data table, Blueprint Viewer placeholder, Sticky Estimator Widget.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "dtc-creative-ops",
      "name": "DTC Creative Ops",
      "description": "Ad performance dashboard for e-com agencies.",
      "asset_type": "Dashboard",
      "industry": "general",
      "visual_style": "High-energy, Media-rich, Dark Mode. Black, Neon Green, Hot Pink",
      "layout_pattern": "Metric Ticker, Creative Grid (masonry), Card Details overlay, Sidebar Filters, Leaderboard podium",
      "prompt": "Design a \"DTC Creative Ops\" dashboard. VISUAL STYLE: High-energy, Media-rich, Dark Mode. Black, Neon Green, Hot Pink. LAYOUT: Metric Ticker, Creative Grid (masonry), Card Details overlay, Sidebar Filters, Leaderboard podium.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "medi-cal-intake-flow",
      "name": "Medi-Cal Intake Flow",
      "description": "Patient onboarding for private practices.",
      "asset_type": "Prompt Template",
      "industry": "general",
      "visual_style": "Clinical, Calming. Soft Teal, White, Light Gray",
      "layout_pattern": "Patient Queue sidebar, Main Form wizard, Quick Actions buttons, Privacy Shield toggle",
      "prompt": "Design a \"Medi-Cal Intake\" tablet interface. VISUAL STYLE: Clinical, Calming. Soft Teal, White, Light Gray. LAYOUT: Patient Queue sidebar, Main Form wizard, Quick Actions buttons, Privacy Shield toggle.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "supply-chain-sentinel",
      "name": "Supply Chain Sentinel",
      "description": "Inventory prediction for logistics managers.",
      "asset_type": "Dashboard",
      "industry": "logistics",
      "visual_style": "Global, Data-driven. Midnight Blue, Map colors",
      "layout_pattern": "Global Map View, Alerts Panel overlay, Inventory Gauges, Timeline Gantt chart",
      "prompt": "Design a \"Supply Chain Sentinel\" logistics dashboard. VISUAL STYLE: Global, Data-driven. Midnight Blue, Map colors. LAYOUT: Global Map View, Alerts Panel overlay, Inventory Gauges, Timeline Gantt chart.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "api-developer-portal",
      "name": "API Developer Portal",
      "description": "Documentation and key management for B2B APIs.",
      "asset_type": "Portal",
      "industry": "tax",
      "visual_style": "Technical, Developer-centric. Dark Mode, Syntax colors",
      "layout_pattern": "Split View (Nav/Content/Code), API Key Manager, Code Playground, Status Dot",
      "prompt": "Design a \"B2B Developer Portal\". VISUAL STYLE: Technical, Developer-centric. Dark Mode, Syntax colors. LAYOUT: Split View (Nav/Content/Code), API Key Manager, Code Playground, Status Dot.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "luxury-editorial-bento",
      "name": "Luxury Editorial Bento",
      "description": "High-end Acquisition Financing content hub.",
      "asset_type": "Hub",
      "industry": "general",
      "visual_style": "CSS Grid \"Bento\", High-end Editorial. Deep charcoal/black, gold accents",
      "layout_pattern": "TODO",
      "prompt": "Design a \"Luxury Editorial Bento\" grid layout. VISUAL STYLE: CSS Grid \"Bento\", High-end Editorial. Deep charcoal/black, gold accents. CONTENT: 15 specific articles regarding business acquisitions, loans, and financing strategies.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "saas-dashboard-dark",
      "name": "SaaS Dashboard Dark",
      "description": "Modern analytics dashboard with glassmorphism.",
      "asset_type": "Dashboard",
      "industry": "general",
      "visual_style": "TODO",
      "layout_pattern": "TODO",
      "prompt": "Create a high-fidelity SaaS analytics dashboard in dark mode. Modular grid layout. Sidebar nav, MRR chart, Metric cards (Active Users, Churn, LTV), Activity feed table. Glassmorphism effects, neon accents.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "bold-motion-studio",
      "name": "Bold Motion Studio",
      "description": "Kinetic, editorial portfolio for creative shops.",
      "asset_type": "Prompt Template",
      "industry": "general",
      "visual_style": "High-impact, Kinetic typography. Deep black, Electric Blue/Neon Green",
      "layout_pattern": "TODO",
      "prompt": "Design a \"Bold Motion Studio\" portfolio. VISUAL STYLE: High-impact, Kinetic typography. Deep black, Electric Blue/Neon Green. MOVES: Marquee Hero, Parallax Posters, Case Study Reel, Hover Morph cards, Fluid Footer.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "saas-enterprise-console",
      "name": "SaaS Enterprise Console",
      "description": "Structured, high-density dashboard for complex B2B tools.",
      "asset_type": "Dashboard",
      "industry": "general",
      "visual_style": "Serious, Efficient. Light mode, subtle grays, blue actions",
      "layout_pattern": "Left Rail nav, Data Table (multi-select), KPI Tiles, Activity Log, Docs Integration",
      "prompt": "Create an \"Enterprise SaaS Console\". VISUAL STYLE: Serious, Efficient. Light mode, subtle grays, blue actions. LAYOUT: Left Rail nav, Data Table (multi-select), KPI Tiles, Activity Log, Docs Integration.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "modern-knowledge-base",
      "name": "Modern Knowledge Base",
      "description": "Structured docs hub for wikis and resources.",
      "asset_type": "Hub",
      "industry": "general",
      "visual_style": "Calm, Structured. Monospace/Sans-serif mix",
      "layout_pattern": "Search-First Hero, Sidebar Nav tree, Main Content with TOC, Code Blocks, Community Links",
      "prompt": "Design a \"Modern Knowledge Base\". VISUAL STYLE: Calm, Structured. Monospace/Sans-serif mix. LAYOUT: Search-First Hero, Sidebar Nav tree, Main Content with TOC, Code Blocks, Community Links.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "cinematic-dark-luxe",
      "name": "Cinematic Dark Luxe",
      "description": "Premium consulting/coaching offer landing page.",
      "asset_type": "Landing Page",
      "industry": "general",
      "visual_style": "Elite, Exclusive. Deep black, charcoal, gold spotlight",
      "layout_pattern": "TODO",
      "prompt": "Design a \"Cinematic Dark Luxe\" landing page. VISUAL STYLE: Elite, Exclusive. Deep black, charcoal, gold spotlight. SECTIONS: Trailer Hero, Authority Stack logos, Spotlight Testimonials, Process Timeline, Micro-CTA.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "e-commerce-catalog",
      "name": "E-commerce Catalog",
      "description": "Sleek retail grid with checkout focus.",
      "asset_type": "Prompt Template",
      "industry": "general",
      "visual_style": "Minimalist, Product-forward. White, Gray, Black",
      "layout_pattern": "Promotional Hero, Filter Sidebar, Responsive Product Grid, Wishlist icons, Sticky Checkout bar",
      "prompt": "Design a \"Modern E-commerce Catalog\". VISUAL STYLE: Minimalist, Product-forward. White, Gray, Black. LAYOUT: Promotional Hero, Filter Sidebar, Responsive Product Grid, Wishlist icons, Sticky Checkout bar.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "performance-marketing-machine",
      "name": "Performance Marketing Machine",
      "description": "High-conversion lead gen site for agencies.",
      "asset_type": "Landing Page",
      "industry": "general",
      "visual_style": "Conversion-first, High Energy. White with \"Power Color\" (Orange)",
      "layout_pattern": "TODO",
      "prompt": "Design a \"Performance Marketing\" landing page. VISUAL STYLE: Conversion-first, High Energy. White with \"Power Color\" (Orange). MOVES: ROI Hero, Metrics Grid, Before/After comparison, Sticky CTA, Lead Capture form.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "authority-consulting",
      "name": "Authority Consulting",
      "description": "Trust-building site for personal brand experts.",
      "asset_type": "Prompt Template",
      "industry": "general",
      "visual_style": "Professional, Trusted Advisor. Serif/Sans mix",
      "layout_pattern": "TODO",
      "prompt": "Design an \"Authority Consulting\" page. VISUAL STYLE: Professional, Trusted Advisor. Serif/Sans mix. SECTIONS: Credibility Hero, Framework visualization, Case Study deck, Service Packages, Booking Widget.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "creator-media-grid",
      "name": "Creator Media Grid",
      "description": "Thumbnail-forward hub for YouTubers and Podcasters.",
      "asset_type": "Hub",
      "industry": "general",
      "visual_style": "Dynamic, Thumbnail-friendly. Dark mode",
      "layout_pattern": "Featured Drop hero, Category Filters, Video Grid, Clips Carousel, Newsletter Opt-in",
      "prompt": "Design a \"Creator Media Grid\". VISUAL STYLE: Dynamic, Thumbnail-friendly. Dark mode. LAYOUT: Featured Drop hero, Category Filters, Video Grid, Clips Carousel, Newsletter Opt-in.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "brand-story-editorial",
      "name": "Brand Story Editorial",
      "description": "Magazine-style narrative for luxury brands.",
      "asset_type": "Prompt Template",
      "industry": "general",
      "visual_style": "Magazine-style, High-fashion. Asymmetrical, white space",
      "layout_pattern": "TODO",
      "prompt": "Design a \"Brand Story Editorial\" page. VISUAL STYLE: Magazine-style, High-fashion. Asymmetrical, white space. MOVES: Chaptered Scroll, Pull Quotes, Values Manifesto, Curated Image Modules, Soft Fade Reveals.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "modern-saas-landing",
      "name": "Modern SaaS Landing",
      "description": "Clean, high-conversion landing page for software.",
      "asset_type": "Landing Page",
      "industry": "general",
      "visual_style": "Trustworthy, Scalable. Crisp white, slate, primary blue",
      "layout_pattern": "TODO",
      "prompt": "Create a high-fidelity \"Modern SaaS Landing Page\". VISUAL STYLE: Trustworthy, Scalable. Crisp white, slate, primary blue. SECTIONS: Hero with 3D mockup, Social Proof, Zig-zag Features, Bento Grid, Pricing cards, Footer.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "ai-tool-directory",
      "name": "AI Tool Directory",
      "description": "Dark-mode catalog for AI tools with search and tags.",
      "asset_type": "Directory",
      "industry": "general",
      "visual_style": "Deep midnight blue, Glowing gradients, Glassmorphism",
      "layout_pattern": "Sticky Header, Search Hero with tags, Featured Tool, Responsive Grid, Sidebar/Filter",
      "prompt": "Design a sleek, dark-mode \"AI Tool Directory\". VISUAL STYLE: Deep midnight blue, Glowing gradients, Glassmorphism. LAYOUT: Sticky Header, Search Hero with tags, Featured Tool, Responsive Grid, Sidebar/Filter.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "creative-agency",
      "name": "Creative Agency",
      "description": "Bold, motion-heavy site for a creative studio.",
      "asset_type": "Prompt Template",
      "industry": "general",
      "visual_style": "Stark Black & White. Massive kinetic typography",
      "layout_pattern": "Video Hero, Project List with hover preview, Accordion Services, Team Marquee, Huge Footer",
      "prompt": "Design a bold \"Creative Agency\" portfolio site. VISUAL STYLE: Stark Black & White. Massive kinetic typography. LAYOUT: Video Hero, Project List with hover preview, Accordion Services, Team Marquee, Huge Footer.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "neo-brutalist-portfolio",
      "name": "Neo-Brutalist Portfolio",
      "description": "Bold, high-contrast, raw aesthetic.",
      "asset_type": "Prompt Template",
      "industry": "general",
      "visual_style": "TODO",
      "layout_pattern": "TODO",
      "prompt": "Design a Neo-Brutalist personal portfolio. High-contrast black and white with one bold accent. Features: Large heavy typography, thick borders, hard shadows, marquee text, raw grid.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "minimalist-newsletter",
      "name": "Minimalist Newsletter",
      "description": "Reader-focused layout for a weekly digest.",
      "asset_type": "Hub",
      "industry": "general",
      "visual_style": "Warm off-white, Dark charcoal, Forest green. Serif headings",
      "layout_pattern": "Centered Header, Hero with email input, Latest Issue card, Archive list, Topic cloud, Footer",
      "prompt": "Design a \"Minimalist Newsletter\" content hub. VISUAL STYLE: Warm off-white, Dark charcoal, Forest green. Serif headings. LAYOUT: Centered Header, Hero with email input, Latest Issue card, Archive list, Topic cloud, Footer.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "streetwear-drop-page",
      "name": "Streetwear Drop Page",
      "description": "High-hype product launch with marquee and parallax.",
      "asset_type": "Prompt Template",
      "industry": "general",
      "visual_style": "TODO",
      "layout_pattern": "Split screen hero (3D product vs sticky details), Infinite marquee, Countdown timer, Full-width Cart button, Lookbook grid, Accordions",
      "prompt": "Design a high-hype streetwear product drop page. Stark black and white, aggressive typography. LAYOUT: Split screen hero (3D product vs sticky details), Infinite marquee, Countdown timer, Full-width Cart button, Lookbook grid, Accordions.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "tech-conference",
      "name": "Tech Conference",
      "description": "Vibrant event page with schedule and speakers.",
      "asset_type": "Landing Page",
      "industry": "general",
      "visual_style": "\"Electric\" theme, Neon yellow/pink on dark. Brutalist geometry",
      "layout_pattern": "TODO",
      "prompt": "Design a vibrant \"Tech Conference 2025\" landing page. VISUAL STYLE: \"Electric\" theme, Neon yellow/pink on dark. Brutalist geometry. SECTIONS: Massive Date Hero, Speaker Grid, Vertical Schedule, Retro Ticket Pricing, Monochrome Sponsors.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "lead-magnet-funnel",
      "name": "Lead Magnet Funnel",
      "description": "Direct response page for a webinar or guide.",
      "asset_type": "Funnel",
      "industry": "general",
      "visual_style": "Clean white, Strong Action Color. Single column, no exit links",
      "layout_pattern": "TODO",
      "prompt": "Design a high-converting \"Lead Magnet\" funnel page. VISUAL STYLE: Clean white, Strong Action Color. Single column, no exit links. CONTENT: Eyebrow, Benefit Headline, VSL Placeholder, Bullet list, Form, Testimonials.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "community-hub",
      "name": "Community Hub",
      "description": "Resource directory and forum landing.",
      "asset_type": "Directory",
      "industry": "general",
      "visual_style": "Soft purple/lavender, Welcoming",
      "layout_pattern": "TODO",
      "prompt": "Design a \"Community Hub\" landing page. VISUAL STYLE: Soft purple/lavender, Welcoming. SECTIONS: Hero with avatars, Stats counters, Resource Grid, Event List, Masonry Testimonials.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "cyberpunk-system-hud",
      "name": "Cyberpunk System HUD",
      "description": "Sci-fi data interface with neon accents.",
      "asset_type": "Console",
      "industry": "general",
      "visual_style": "TODO",
      "layout_pattern": "Central data viz, Console log, System Health bars, Hex button arrays, Target reticle cursor. Monospace fonts",
      "prompt": "Create a futuristic 'Cyberpunk HUD' interface. Transparent dark backgrounds, neon cyan/magenta, glitch text. LAYOUT: Central data viz, Console log, System Health bars, Hex button arrays, Target reticle cursor. Monospace fonts.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "zen-productivity",
      "name": "Zen Productivity",
      "description": "Calm, soft, nature-inspired task manager.",
      "asset_type": "Dashboard",
      "industry": "general",
      "visual_style": "Soft pastel earth tones, Rounded corners",
      "layout_pattern": "Masonry grid",
      "prompt": "Design a 'Zen Productivity' dashboard. VISUAL STYLE: Soft pastel earth tones, Rounded corners. LAYOUT: Masonry grid. COMPONENTS: Focus Mode timer, Fading To-Do list, Daily Quote, Organic gradient background.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "franchise-owner-cfo",
      "name": "Franchise Owner CFO",
      "description": "Multi-unit P&L dashboard for franchisees.",
      "asset_type": "Calculator",
      "industry": "general",
      "visual_style": "Corporate, Trustworthy. Navy Blue, Gold accents, Clean White",
      "layout_pattern": "Location Selector dropdown, Consolidated P&L table, Unit Comparison chart, Royalty Calculator, Performance Alerts panel",
      "prompt": "Design a \"Franchise Owner CFO\" dashboard. VISUAL STYLE: Corporate, Trustworthy. Navy Blue, Gold accents, Clean White. LAYOUT: Location Selector dropdown, Consolidated P&L table, Unit Comparison chart, Royalty Calculator, Performance Alerts panel.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "restaurant-shift-command",
      "name": "Restaurant Shift Command",
      "description": "Real-time POS and labor tracker for restaurant managers.",
      "asset_type": "Command",
      "industry": "restaurant",
      "visual_style": "Fast-paced, Kitchen-ready. Fire Red, Fresh Green, Charcoal",
      "layout_pattern": "Live Sales ticker, Table Status grid, Labor Cost gauge, Inventory Alerts, Clock-out Queue",
      "prompt": "Design a \"Restaurant Shift Command\" interface. VISUAL STYLE: Fast-paced, Kitchen-ready. Fire Red, Fresh Green, Charcoal. LAYOUT: Live Sales ticker, Table Status grid, Labor Cost gauge, Inventory Alerts, Clock-out Queue.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "subscription-churn-defender",
      "name": "Subscription Churn Defender",
      "description": "Retention dashboard for SaaS subscription businesses.",
      "asset_type": "Dashboard",
      "industry": "general",
      "visual_style": "Urgent, Data-driven. Warning Orange, Safe Green, Dark Mode",
      "layout_pattern": "Churn Risk Score, At-Risk Customer list, Win-back Campaign cards, Retention Playbook sidebar, Monthly Cohort chart",
      "prompt": "Design a \"Subscription Churn Defender\" dashboard. VISUAL STYLE: Urgent, Data-driven. Warning Orange, Safe Green, Dark Mode. LAYOUT: Churn Risk Score, At-Risk Customer list, Win-back Campaign cards, Retention Playbook sidebar, Monthly Cohort chart.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "solar-proposal-builder",
      "name": "Solar Proposal Builder",
      "description": "Interactive quote generator for solar installers.",
      "asset_type": "Calculator",
      "industry": "general",
      "visual_style": "Clean Energy, Modern. Sky Blue, Sun Yellow, White",
      "layout_pattern": "Address Input, Roof Visualizer placeholder, Energy Savings calculator, Panel Configuration, Financing Options tabs, Generate Proposal CTA",
      "prompt": "Design a \"Solar Proposal Builder\" interface. VISUAL STYLE: Clean Energy, Modern. Sky Blue, Sun Yellow, White. LAYOUT: Address Input, Roof Visualizer placeholder, Energy Savings calculator, Panel Configuration, Financing Options tabs, Generate Proposal CTA.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "auto-shop-workflow",
      "name": "Auto Shop Workflow",
      "description": "Job tracker for automotive repair shops.",
      "asset_type": "Dashboard",
      "industry": "auto_services",
      "visual_style": "Garage-ready, Rugged. Tool Gray, Safety Orange, Oil Black",
      "layout_pattern": "Bay Status board, Job Queue kanban, Parts Lookup, Customer Approval checklist, Invoice Preview",
      "prompt": "Design an \"Auto Shop Workflow\" dashboard. VISUAL STYLE: Garage-ready, Rugged. Tool Gray, Safety Orange, Oil Black. LAYOUT: Bay Status board, Job Queue kanban, Parts Lookup, Customer Approval checklist, Invoice Preview.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "law-firm-case-pipeline",
      "name": "Law Firm Case Pipeline",
      "description": "Matter management dashboard for solo attorneys.",
      "asset_type": "Dashboard",
      "industry": "legal",
      "visual_style": "Professional, Serious. Deep Burgundy, Cream, Slate Gray",
      "layout_pattern": "Case Status kanban, Client Directory, Document Vault, Billing Tracker, Court Date calendar",
      "prompt": "Design a \"Law Firm Case Pipeline\" interface. VISUAL STYLE: Professional, Serious. Deep Burgundy, Cream, Slate Gray. LAYOUT: Case Status kanban, Client Directory, Document Vault, Billing Tracker, Court Date calendar.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "gym-member-portal",
      "name": "Gym Member Portal",
      "description": "Client dashboard for fitness studios and trainers.",
      "asset_type": "Dashboard",
      "industry": "fitness",
      "visual_style": "Energetic, Motivational. Electric Blue, Lime Green, Dark Mode",
      "layout_pattern": "Workout Calendar, Progress Photos grid, Personal Records table, Class Booking, Trainer Chat widget",
      "prompt": "Design a \"Gym Member Portal\". VISUAL STYLE: Energetic, Motivational. Electric Blue, Lime Green, Dark Mode. LAYOUT: Workout Calendar, Progress Photos grid, Personal Records table, Class Booking, Trainer Chat widget.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "real-estate-deal-analyzer",
      "name": "Real Estate Deal Analyzer",
      "description": "Property ROI calculator for investors and flippers.",
      "asset_type": "Calculator",
      "industry": "real_estate",
      "visual_style": "Investment-focused, Professional. Forest Green, Gold, Neutral Gray",
      "layout_pattern": "Property Address input, Purchase Price vs ARV comparison, Rehab Budget breakdown, Cash Flow projections, Deal Score gauge",
      "prompt": "Design a \"Real Estate Deal Analyzer\". VISUAL STYLE: Investment-focused, Professional. Forest Green, Gold, Neutral Gray. LAYOUT: Property Address input, Purchase Price vs ARV comparison, Rehab Budget breakdown, Cash Flow projections, Deal Score gauge.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "event-planner-hub",
      "name": "Event Planner Hub",
      "description": "Timeline and vendor coordinator for event planners.",
      "asset_type": "Dashboard",
      "industry": "general",
      "visual_style": "Elegant, Organized. Rose Gold, Blush Pink, Charcoal",
      "layout_pattern": "Event Timeline Gantt, Vendor Contact cards, Budget Tracker, Guest List manager, Mood Board grid",
      "prompt": "Design an \"Event Planner Hub\" dashboard. VISUAL STYLE: Elegant, Organized. Rose Gold, Blush Pink, Charcoal. LAYOUT: Event Timeline Gantt, Vendor Contact cards, Budget Tracker, Guest List manager, Mood Board grid.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "nonprofit-grant-tracker",
      "name": "Nonprofit Grant Tracker",
      "description": "Fundraising pipeline for nonprofit organizations.",
      "asset_type": "Dashboard",
      "industry": "nonprofit",
      "visual_style": "Mission-driven, Hopeful. Ocean Blue, Earth Green, Warm White",
      "layout_pattern": "Grant Pipeline kanban, Funding Goal thermometer, Donor CRM table, Reporting Calendar, Impact Metrics dashboard",
      "prompt": "Design a \"Nonprofit Grant Tracker\" interface. VISUAL STYLE: Mission-driven, Hopeful. Ocean Blue, Earth Green, Warm White. LAYOUT: Grant Pipeline kanban, Funding Goal thermometer, Donor CRM table, Reporting Calendar, Impact Metrics dashboard.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "fintech-infrastructure-builder",
      "name": "Fintech Infrastructure Builder",
      "description": "Modular embedded banking platform configurator.",
      "asset_type": "Prompt Template",
      "industry": "fintech",
      "visual_style": "Technical, Modular. Deep Purple, Electric Blue, White",
      "layout_pattern": "Drag-and-drop component library (Accounts, Cards, Payments, KYC), API endpoint preview, Compliance checklist, Sandbox environment toggle, Integration documentation panel",
      "prompt": "Design a \"Fintech Infrastructure Builder\" interface. VISUAL STYLE: Technical, Modular. Deep Purple, Electric Blue, White. LAYOUT: Drag-and-drop component library (Accounts, Cards, Payments, KYC), API endpoint preview, Compliance checklist, Sandbox environment toggle, Integration documentation panel.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "neobank-control-center",
      "name": "Neobank Control Center",
      "description": "Multi-tenant banking operations dashboard.",
      "asset_type": "Dashboard",
      "industry": "banking",
      "visual_style": "Institutional, Secure. Navy Blue, Trust Green, Clean White",
      "layout_pattern": "Customer segment filters, Account activity stream, Transaction monitoring grid, Fraud alert panel, Regulatory reporting calendar, Balance sheet summary",
      "prompt": "Create a \"Neobank Control Center\" admin interface. VISUAL STYLE: Institutional, Secure. Navy Blue, Trust Green, Clean White. LAYOUT: Customer segment filters, Account activity stream, Transaction monitoring grid, Fraud alert panel, Regulatory reporting calendar, Balance sheet summary.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "payment-flow-designer",
      "name": "Payment Flow Designer",
      "description": "Visual money movement orchestration tool.",
      "asset_type": "Calculator",
      "industry": "general",
      "visual_style": "Flow-based, Technical. Slate Gray, Payment Green, Error Red",
      "layout_pattern": "Drag-and-drop flow builder, Payment method nodes (ACH, Wire, Card, Crypto), Routing logic editor, Fee calculator sidebar, Test transaction simulator",
      "prompt": "Design a \"Payment Flow Designer\" canvas interface. VISUAL STYLE: Flow-based, Technical. Slate Gray, Payment Green, Error Red. LAYOUT: Drag-and-drop flow builder, Payment method nodes (ACH, Wire, Card, Crypto), Routing logic editor, Fee calculator sidebar, Test transaction simulator.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "embedded-lending-console",
      "name": "Embedded Lending Console",
      "description": "White-label loan origination system for platforms.",
      "asset_type": "Dashboard",
      "industry": "fintech",
      "visual_style": "Fintech Modern, Professional. Teal, Charcoal, White",
      "layout_pattern": "Application pipeline kanban, Underwriting scorecard, Document verification queue, Offer configurator, Servicing dashboard, Portfolio health metrics",
      "prompt": "Create an \"Embedded Lending Console\" for marketplace platforms. VISUAL STYLE: Fintech Modern, Professional. Teal, Charcoal, White. LAYOUT: Application pipeline kanban, Underwriting scorecard, Document verification queue, Offer configurator, Servicing dashboard, Portfolio health metrics.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "card-program-manager",
      "name": "Card Program Manager",
      "description": "Branded card issuance and control platform.",
      "asset_type": "Directory",
      "industry": "general",
      "visual_style": "Premium, Card-focused. Gradient backgrounds, Metallic accents",
      "layout_pattern": "Card design studio, Spend control rules builder, Real-time authorization log, Cardholder directory, Virtual card generator, Transaction categorization engine",
      "prompt": "Design a \"Card Program Manager\" interface. VISUAL STYLE: Premium, Card-focused. Gradient backgrounds, Metallic accents. LAYOUT: Card design studio, Spend control rules builder, Real-time authorization log, Cardholder directory, Virtual card generator, Transaction categorization engine.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "treasury-as-a-service-hub",
      "name": "Treasury-as-a-Service Hub",
      "description": "Corporate cash management for embedded finance.",
      "asset_type": "Directory",
      "industry": "banking",
      "visual_style": "Corporate Finance, Serious. Deep Blue, Gold, Neutral Gray",
      "layout_pattern": "Multi-account aggregator, Yield optimization recommendations, Sweep automation rules, Liquidity forecasting chart, Compliance vault, Bank partnership directory",
      "prompt": "Create a \"Treasury-as-a-Service Hub\" for B2B platforms. VISUAL STYLE: Corporate Finance, Serious. Deep Blue, Gold, Neutral Gray. LAYOUT: Multi-account aggregator, Yield optimization recommendations, Sweep automation rules, Liquidity forecasting chart, Compliance vault, Bank partnership directory.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "kyc-aml-command-center",
      "name": "KYC/AML Command Center",
      "description": "Identity verification and compliance monitoring.",
      "asset_type": "Dashboard",
      "industry": "fintech",
      "visual_style": "Regulatory, Alert-focused. Steel Blue, Warning Amber, Risk Red",
      "layout_pattern": "Verification queue, Risk scoring dashboard, Document review workstation, Sanctions screening results, Case management system, Audit trail explorer",
      "prompt": "Design a \"KYC/AML Command Center\" for fintech compliance teams. VISUAL STYLE: Regulatory, Alert-focused. Steel Blue, Warning Amber, Risk Red. LAYOUT: Verification queue, Risk scoring dashboard, Document review workstation, Sanctions screening results, Case management system, Audit trail explorer.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "crypto-rails-dashboard",
      "name": "Crypto Rails Dashboard",
      "description": "Digital asset payment infrastructure monitor.",
      "asset_type": "Dashboard",
      "industry": "general",
      "visual_style": "Blockchain-inspired, Technical. Dark Mode, Neon Green, Crypto Orange",
      "layout_pattern": "Blockchain network status, Wallet balance aggregator, Transaction mempool viewer, Gas fee optimizer, Conversion rate ticker, Settlement reconciliation panel",
      "prompt": "Create a \"Crypto Rails Dashboard\" for embedded crypto payments. VISUAL STYLE: Blockchain-inspired, Technical. Dark Mode, Neon Green, Crypto Orange. LAYOUT: Blockchain network status, Wallet balance aggregator, Transaction mempool viewer, Gas fee optimizer, Conversion rate ticker, Settlement reconciliation panel.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "open-banking-connector",
      "name": "Open Banking Connector",
      "description": "PSD2/Open Banking API aggregation platform.",
      "asset_type": "Dashboard",
      "industry": "banking",
      "visual_style": "API-first, Developer-friendly. Clean White, API Blue, Success Green",
      "layout_pattern": "Bank connection library, Authentication flow tester, Data mapping editor, Webhook configuration, Rate limit monitor, Connection health dashboard",
      "prompt": "Design an \"Open Banking Connector\" developer console. VISUAL STYLE: API-first, Developer-friendly. Clean White, API Blue, Success Green. LAYOUT: Bank connection library, Authentication flow tester, Data mapping editor, Webhook configuration, Rate limit monitor, Connection health dashboard.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "subscription-billing-engine",
      "name": "Subscription Billing Engine",
      "description": "Recurring payment and revenue management system.",
      "asset_type": "Prompt Template",
      "industry": "general",
      "visual_style": "SaaS Modern, Metric-focused. Purple, Green, Dark Mode",
      "layout_pattern": "MRR/ARR chart, Subscription lifecycle pipeline, Payment method updater, Dunning campaign manager, Revenue recognition calendar, Churn analysis grid",
      "prompt": "Create a \"Subscription Billing Engine\" admin interface. VISUAL STYLE: SaaS Modern, Metric-focused. Purple, Green, Dark Mode. LAYOUT: MRR/ARR chart, Subscription lifecycle pipeline, Payment method updater, Dunning campaign manager, Revenue recognition calendar, Churn analysis grid.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "banking-as-a-service-marketplace",
      "name": "Banking-as-a-Service Marketplace",
      "description": "BaaS provider comparison and integration hub.",
      "asset_type": "Hub",
      "industry": "banking",
      "visual_style": "Comparison-focused, Professional. Sky Blue, Neutral Grays",
      "layout_pattern": "Provider comparison table (features, pricing, compliance), Integration difficulty score, Time-to-market estimator, Case study library, API documentation links, Partner RFP generator",
      "prompt": "Design a \"Banking-as-a-Service Marketplace\" platform. VISUAL STYLE: Comparison-focused, Professional. Sky Blue, Neutral Grays. LAYOUT: Provider comparison table (features, pricing, compliance), Integration difficulty score, Time-to-market estimator, Case study library, API documentation links, Partner RFP generator.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "instant-payout-network",
      "name": "Instant Payout Network",
      "description": "Gig economy earnings disbursement platform.",
      "asset_type": "Calculator",
      "industry": "tax",
      "visual_style": "Fast, Accessible. Bright Green, White, Friendly",
      "layout_pattern": "Earnings accumulator, Instant cash-out button, Fee transparency calculator, Payment method selector (card, ACH, digital wallet), Earnings history timeline, Tax document vault",
      "prompt": "Create an \"Instant Payout Network\" for platform workers. VISUAL STYLE: Fast, Accessible. Bright Green, White, Friendly. LAYOUT: Earnings accumulator, Instant cash-out button, Fee transparency calculator, Payment method selector (card, ACH, digital wallet), Earnings history timeline, Tax document vault.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "smb-financial-os",
      "name": "SMB Financial OS",
      "description": "All-in-one financial command center for small businesses.",
      "asset_type": "Calculator",
      "industry": "tax",
      "visual_style": "Unified, Approachable. Warm Blue, Success Green, Clean White",
      "layout_pattern": "Cash position summary, Incoming/outgoing payments stream, Invoice generator, Expense categorization, Tax savings calculator, Financial health score",
      "prompt": "Design an \"SMB Financial OS\" combining banking, payments, and accounting. VISUAL STYLE: Unified, Approachable. Warm Blue, Success Green, Clean White. LAYOUT: Cash position summary, Incoming/outgoing payments stream, Invoice generator, Expense categorization, Tax savings calculator, Financial health score.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "vertical-saas-banking-kit",
      "name": "Vertical SaaS Banking Kit",
      "description": "Embeddable banking widgets for vertical software.",
      "asset_type": "Prompt Template",
      "industry": "banking",
      "visual_style": "Modular, White-label ready. Neutral with accent color customization",
      "layout_pattern": "TODO",
      "prompt": "Create a \"Vertical SaaS Banking Kit\" component library. VISUAL STYLE: Modular, White-label ready. Neutral with accent color customization. COMPONENTS: Account balance widget, Payment button, Transfer modal, Transaction history table, Spend analytics chart, Settings panel. Include light/dark mode toggle.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "decentralized-finance-defi-bridge",
      "name": "Decentralized Finance (DeFi) Bridge",
      "description": "Traditional finance to DeFi protocol connector.",
      "asset_type": "Prompt Template",
      "industry": "general",
      "visual_style": "Futuristic, Trustworthy. Deep Purple, Cyber Blue, White",
      "layout_pattern": "Fiat on-ramp, Protocol selector (Lending, Yield, DEX), Wallet connector, Transaction preview with gas estimates, Portfolio tracker, Educational tooltips",
      "prompt": "Design a \"DeFi Bridge\" interface connecting fiat to decentralized protocols. VISUAL STYLE: Futuristic, Trustworthy. Deep Purple, Cyber Blue, White. LAYOUT: Fiat on-ramp, Protocol selector (Lending, Yield, DEX), Wallet connector, Transaction preview with gas estimates, Portfolio tracker, Educational tooltips.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "regulatory-compliance-autopilot",
      "name": "Regulatory Compliance Autopilot",
      "description": "Automated compliance monitoring and reporting.",
      "asset_type": "Template",
      "industry": "fintech",
      "visual_style": "Systematic, Authoritative. Government Blue, Compliance Green, Alert Red",
      "layout_pattern": "Jurisdiction selector, Regulation changelog feed, License tracker, Automated report generator, Policy template library, Examiner communication log",
      "prompt": "Create a \"Regulatory Compliance Autopilot\" for fintech platforms. VISUAL STYLE: Systematic, Authoritative. Government Blue, Compliance Green, Alert Red. LAYOUT: Jurisdiction selector, Regulation changelog feed, License tracker, Automated report generator, Policy template library, Examiner communication log.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "ai-underwriting-studio",
      "name": "AI Underwriting Studio",
      "description": "Machine learning credit decisioning workbench.",
      "asset_type": "Dashboard",
      "industry": "general",
      "visual_style": "Data Science, Analytical. Dark Mode, ML Blue, Model Green",
      "layout_pattern": "Model performance dashboard, Feature importance visualizer, Decision boundary explorer, A/B test configurator, Bias detection panel, Model deployment pipeline",
      "prompt": "Design an \"AI Underwriting Studio\" for embedded lenders. VISUAL STYLE: Data Science, Analytical. Dark Mode, ML Blue, Model Green. LAYOUT: Model performance dashboard, Feature importance visualizer, Decision boundary explorer, A/B test configurator, Bias detection panel, Model deployment pipeline.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "payroll-linked-lending-portal",
      "name": "Payroll-Linked Lending Portal",
      "description": "Earned wage access and payroll deduction loans.",
      "asset_type": "Calculator",
      "industry": "general",
      "visual_style": "Employee-friendly, Transparent. Soft Blue, Paycheck Green, White",
      "layout_pattern": "Pay cycle timeline, Available advance calculator, Repayment schedule visualizer, Financial education modules, Employer integration status, Transaction history",
      "prompt": "Create a \"Payroll-Linked Lending Portal\" for employee financial wellness. VISUAL STYLE: Employee-friendly, Transparent. Soft Blue, Paycheck Green, White. LAYOUT: Pay cycle timeline, Available advance calculator, Repayment schedule visualizer, Financial education modules, Employer integration status, Transaction history.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "invoice-financing-exchange",
      "name": "Invoice Financing Exchange",
      "description": "B2B invoice factoring marketplace.",
      "asset_type": "Calculator",
      "industry": "general",
      "visual_style": "B2B Professional, Transactional. Navy, Currency Green, Gray",
      "layout_pattern": "Invoice upload, AI valuation engine, Investor bid board, Acceptance workflow, Funded invoice tracker, Customer credit scoring, Early payment calculator",
      "prompt": "Design an \"Invoice Financing Exchange\" for SMB cash flow. VISUAL STYLE: B2B Professional, Transactional. Navy, Currency Green, Gray. LAYOUT: Invoice upload, AI valuation engine, Investor bid board, Acceptance workflow, Funded invoice tracker, Customer credit scoring, Early payment calculator.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "expense-management-suite",
      "name": "Expense Management Suite",
      "description": "Corporate card and expense tracking platform.",
      "asset_type": "Workflow",
      "industry": "general",
      "visual_style": "Corporate Modern, Organized. Slate, Expense Blue, Receipt Gray",
      "layout_pattern": "Virtual card issuer, Receipt capture (OCR), Expense categorization, Policy violation flags, Approval workflow, Accounting integration sync, Spend analytics by department",
      "prompt": "Create an \"Expense Management Suite\" with embedded cards. VISUAL STYLE: Corporate Modern, Organized. Slate, Expense Blue, Receipt Gray. LAYOUT: Virtual card issuer, Receipt capture (OCR), Expense categorization, Policy violation flags, Approval workflow, Accounting integration sync, Spend analytics by department.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "digital-banking-command-center",
      "name": "Digital Banking Command Center",
      "description": "Multi-product financial services orchestration platform.",
      "asset_type": "Dashboard",
      "industry": "fintech",
      "visual_style": "Enterprise Banking, Professional. Navy Blue, Trust Green, Clean White",
      "layout_pattern": "Product suite navigator (Checking, Savings, Credit, Loans), Customer lifecycle pipeline, Cross-sell opportunity engine, Regulatory compliance dashboard, Partner integration status, Real-time transaction monitoring grid",
      "prompt": "Design a \"Digital Banking Command Center\" for neobanks and fintechs. VISUAL STYLE: Enterprise Banking, Professional. Navy Blue, Trust Green, Clean White. LAYOUT: Product suite navigator (Checking, Savings, Credit, Loans), Customer lifecycle pipeline, Cross-sell opportunity engine, Regulatory compliance dashboard, Partner integration status, Real-time transaction monitoring grid.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "niche-landing-page-factory-vertical-template-generator",
      "name": "Niche Landing Page Factory: Vertical Template Generator",
      "description": "Automated system for generating niche-specific landing pages across verticals with consistent structure.",
      "asset_type": "Landing Page",
      "industry": "auto_services",
      "visual_style": "Systematic, Template-driven, Modular. Navy, Template Blue, Generation Green, White. Clean sans-serif",
      "layout_pattern": "Vertical selector dropdown, Keyword input field, Template preview panel, Hero section generator, Option cards builder (3-6 cards), Requirements/Approval factors module, Decision tree configurator (Apply/Prep/Talk), FAQ generator (industry-specific), Proof elements organizer, CTA placement optimizer,",
      "prompt": "Design a \"Niche Landing Page Factory\" automation system. VISUAL STYLE: Systematic, Template-driven, Modular. Navy, Template Blue, Generation Green, White. Clean sans-serif. LAYOUT: Vertical selector dropdown, Keyword input field, Template preview panel, Hero section generator, Option cards builder (3-6 cards), Requirements/Approval factors module, Decision tree configurator (Apply/Prep/Talk), FAQ generator (industry-specific), Proof elements organizer, CTA placement optimizer, SEO meta generator, Unique content blocks (3 use cases + industry denial reasons), Export options (HTML/Next.js/Wix/Notion).",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "landing-page-wireframe-builder-description-visual-wireframe-generator-with-drag-and-drop-components-for-rapid-page-design-prompt-create-a-landing-page-wireframe-builder-for-funding-vertical-pages-visual-style-design-system-structured-wireframe-gray-component-blue-active-green-border-black-layout-component-library-sidebar-hero-cards-trees-forms-proof-faq-canvas-workspace-with-grid-section-templates-above-fold-mid-page-bottom-device-preview-toggle-desktop-tablet-mobile-copy-placeholder-generator-cta-button-variants-spacing-and-padding-controls-export-to-code-button-save-as-template-option-79-vertical-content-automation-engine",
      "name": "Landing Page Wireframe Builder\n~~Description: Visual wireframe generator with drag-and-drop components for rapid page design.\nPrompt: Create a \"Landing Page Wireframe Builder\" for funding vertical pages. VISUAL STYLE: Design System, Structured. Wireframe Gray, Component Blue, Active Green, Border Black. LAYOUT: Component library sidebar (Hero, Cards, Trees, Forms, Proof, FAQ), Canvas workspace with grid, Section templates (Above fold, Mid-page, Bottom), Device preview toggle (Desktop/Tablet/Mobile), Copy placeholder generator, CTA button variants, Spacing and padding controls, Export to code button, Save as template option.~~\n79. Vertical Content Automation Engine",
      "description": "AI-powered content generator for creating unique, SEO-optimized vertical pages at scale.",
      "asset_type": "Landing Page",
      "industry": "auto_services",
      "visual_style": "AI-Powered, Intelligent. Deep Purple, Generation Gold, Content Green, Data Gray",
      "layout_pattern": "Vertical/industry input, Keyword research integration, Unique content modules (3 use cases auto-generated, Industry-specific denial reasons, Approval factors by vertical), FAQ generator (10 questions per niche), Meta description creator, Long-tail question identifier, Internal linking suggester, Dup",
      "prompt": "Design a \"Vertical Content Automation Engine\" for funding niches. VISUAL STYLE: AI-Powered, Intelligent. Deep Purple, Generation Gold, Content Green, Data Gray. LAYOUT: Vertical/industry input, Keyword research integration, Unique content modules (3 use cases auto-generated, Industry-specific denial reasons, Approval factors by vertical), FAQ generator (10 questions per niche), Meta description creator, Long-tail question identifier, Internal linking suggester, Duplicate content checker, Batch generation queue, Content calendar integration.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "microsite-deployment-automation",
      "name": "Microsite Deployment Automation",
      "description": "One-click deployment system for generating and publishing vertical-specific microsites.",
      "asset_type": "Calculator",
      "industry": "auto_services",
      "visual_style": "DevOps, Streamlined. Terminal Black, Deploy Green, Domain Blue, Status Orange",
      "layout_pattern": "Microsite template selector, Vertical configuration panel, Domain/subdomain manager, Content injection interface (pulls from Notion database), Widget embedder (pre-qual forms, calculators), Analytics setup automation, SEO configuration panel, Deployment pipeline visualization, Status dashboard (live",
      "prompt": "Create a \"Microsite Deployment Automation\" platform for funding verticals. VISUAL STYLE: DevOps, Streamlined. Terminal Black, Deploy Green, Domain Blue, Status Orange. LAYOUT: Microsite template selector, Vertical configuration panel, Domain/subdomain manager, Content injection interface (pulls from Notion database), Widget embedder (pre-qual forms, calculators), Analytics setup automation, SEO configuration panel, Deployment pipeline visualization, Status dashboard (live/staging/draft), Rollback controls, A/B testing framework.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "notion-to-website-pipeline",
      "name": "Notion-to-Website Pipeline",
      "description": "Automated system that converts Notion database entries into live landing pages.",
      "asset_type": "Dashboard",
      "industry": "auto_services",
      "visual_style": "Integration-focused, Seamless. Notion White, Pipeline Blue, Sync Green, API Gray",
      "layout_pattern": "Notion database connector, Row-to-page mapper (each row = one niche page), Field mapping interface (Title → H1, Description → Hero copy, etc.), Template assignment rules, Trigger configuration (manual/automatic sync), Preview before publish, Webhook integration options, Change detection system, Bulk",
      "prompt": "Design a \"Notion-to-Website Pipeline\" for funding page generation. VISUAL STYLE: Integration-focused, Seamless. Notion White, Pipeline Blue, Sync Green, API Gray. LAYOUT: Notion database connector, Row-to-page mapper (each row = one niche page), Field mapping interface (Title → H1, Description → Hero copy, etc.), Template assignment rules, Trigger configuration (manual/automatic sync), Preview before publish, Webhook integration options, Change detection system, Bulk update controls, Publishing queue dashboard.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "seo-keyword-matrix-generator",
      "name": "SEO Keyword Matrix Generator",
      "description": "Keyword research and mapping tool for creating vertical-specific landing page strategies.",
      "asset_type": "Landing Page",
      "industry": "general",
      "visual_style": "Data Analytics, Strategic. Search Blue, Keyword Gold, Opportunity Green, Competition Red",
      "layout_pattern": "Vertical/industry input, Primary keyword identifier, Secondary keyword cluster (7-10 keywords grouped by intent: Learn/Compare/Buy), Long-tail question finder (5-10 per vertical), Search volume estimator, Competition analysis, Content gap identifier, Keyword-to-page mapper, Internal linking opportun",
      "prompt": "Create an \"SEO Keyword Matrix Generator\" for funding niches. VISUAL STYLE: Data Analytics, Strategic. Search Blue, Keyword Gold, Opportunity Green, Competition Red. LAYOUT: Vertical/industry input, Primary keyword identifier, Secondary keyword cluster (7-10 keywords grouped by intent: Learn/Compare/Buy), Long-tail question finder (5-10 per vertical), Search volume estimator, Competition analysis, Content gap identifier, Keyword-to-page mapper, Internal linking opportunities, Priority scoring matrix.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "dynamic-component-library",
      "name": "Dynamic Component Library",
      "description": "Reusable, customizable component system for rapid landing page assembly.",
      "asset_type": "Landing Page",
      "industry": "general",
      "visual_style": "Component System, Modular. Library Gray, Component Blue, Active Green, Border Black",
      "layout_pattern": "Hero variants (5-7 styles), Option card templates (2-column, 3-column, grid), Decision tree builders (visual flow diagrams), Form embeds (Tally, Typeform, custom), Social proof modules (testimonials, logos, stats), FAQ accordion styles, CTA button variants (primary, secondary, sticky), Comparison ta",
      "prompt": "Design a \"Dynamic Component Library\" for funding landing pages. VISUAL STYLE: Component System, Modular. Library Gray, Component Blue, Active Green, Border Black. LAYOUT: Hero variants (5-7 styles), Option card templates (2-column, 3-column, grid), Decision tree builders (visual flow diagrams), Form embeds (Tally, Typeform, custom), Social proof modules (testimonials, logos, stats), FAQ accordion styles, CTA button variants (primary, secondary, sticky), Comparison table templates, Requirements checklist layouts, Trust badge collections, Mobile-responsive previews.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "vertical-performance-dashboard",
      "name": "Vertical Performance Dashboard",
      "description": "Analytics and optimization platform for tracking landing page performance across verticals.",
      "asset_type": "Calculator",
      "industry": "general",
      "visual_style": "Analytics, Data-Driven. Dashboard Dark, Metric Green, Alert Orange, Chart Blue",
      "layout_pattern": "Vertical comparison view, Key metrics by page (Traffic, Conversions, Bounce Rate, Time on Page), Conversion funnel visualization, Heat map integration, A/B test results, SEO ranking tracker, Top performing verticals highlighter, Underperforming page alerts, Optimization recommendations, ROI calculat",
      "prompt": "Create a \"Vertical Performance Dashboard\" for niche landing pages. VISUAL STYLE: Analytics, Data-Driven. Dashboard Dark, Metric Green, Alert Orange, Chart Blue. LAYOUT: Vertical comparison view, Key metrics by page (Traffic, Conversions, Bounce Rate, Time on Page), Conversion funnel visualization, Heat map integration, A/B test results, SEO ranking tracker, Top performing verticals highlighter, Underperforming page alerts, Optimization recommendations, ROI calculator by vertical, Export and reporting tools.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "batch-page-generator",
      "name": "Batch Page Generator",
      "description": "Bulk creation tool for generating multiple vertical landing pages simultaneously.",
      "asset_type": "Landing Page",
      "industry": "general",
      "visual_style": "Production-scale, Efficient. Batch Black, Queue Blue, Complete Green, Processing Orange",
      "layout_pattern": "CSV/spreadsheet importer, Vertical list with configurations, Template selector (apply to all or individual), Unique content requirements (use cases, FAQs, denial reasons per vertical), Validation checker, Preview gallery (thumbnails of all pages), Quality assurance checklist, Bulk publish controls, ",
      "prompt": "Design a \"Batch Page Generator\" for funding vertical expansion. VISUAL STYLE: Production-scale, Efficient. Batch Black, Queue Blue, Complete Green, Processing Orange. LAYOUT: CSV/spreadsheet importer, Vertical list with configurations, Template selector (apply to all or individual), Unique content requirements (use cases, FAQs, denial reasons per vertical), Validation checker, Preview gallery (thumbnails of all pages), Quality assurance checklist, Bulk publish controls, Error handling and retry, Progress tracker, Post-generation tasks (sitemap update, internal linking, analytics setup).",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "widget-integration-studio",
      "name": "Widget Integration Studio",
      "description": "Central hub for embedding and managing interactive widgets across landing pages.",
      "asset_type": "Calculator",
      "industry": "general",
      "visual_style": "Integration Platform, Unified. Widget Purple, Embed Blue, Active Green, Container Gray",
      "layout_pattern": "Widget library (Pre-qual forms, Calculators, Chatbots, Booking calendars, Live chat), Embed code generator, Configuration panel (styling, behavior, triggers), Placement optimizer (above fold, mid-page, exit intent), Multi-page deployment, Performance tracking per widget, A/B testing interface, Mobil",
      "prompt": "Create a \"Widget Integration Studio\" for funding page enhancements. VISUAL STYLE: Integration Platform, Unified. Widget Purple, Embed Blue, Active Green, Container Gray. LAYOUT: Widget library (Pre-qual forms, Calculators, Chatbots, Booking calendars, Live chat), Embed code generator, Configuration panel (styling, behavior, triggers), Placement optimizer (above fold, mid-page, exit intent), Multi-page deployment, Performance tracking per widget, A/B testing interface, Mobile responsiveness checker, Widget analytics dashboard, Version control and rollback.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "landing-page-a-b-testing-framework",
      "name": "Landing Page A/B Testing Framework",
      "description": "Integrated testing platform for optimizing vertical landing page performance.",
      "asset_type": "Calculator",
      "industry": "auto_services",
      "visual_style": "Testing Lab, Scientific. Test Blue, Control Gray, Winner Green, Challenger Orange",
      "layout_pattern": "Test creation wizard, Element selector (headline, CTA, hero image, form placement), Variant builder (up to 5 versions), Traffic allocation controls, Statistical significance calculator, Real-time results dashboard, Winning variant auto-promotion, Test history archive, Insights and recommendations, S",
      "prompt": "Design a \"Landing Page A/B Testing Framework\" for conversion optimization. VISUAL STYLE: Testing Lab, Scientific. Test Blue, Control Gray, Winner Green, Challenger Orange. LAYOUT: Test creation wizard, Element selector (headline, CTA, hero image, form placement), Variant builder (up to 5 versions), Traffic allocation controls, Statistical significance calculator, Real-time results dashboard, Winning variant auto-promotion, Test history archive, Insights and recommendations, Segment performance analysis (by traffic source, device, time).",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "compliance-and-legal-module-generator",
      "name": "Compliance & Legal Module Generator",
      "description": "Automated system for adding required compliance elements to funding landing pages.",
      "asset_type": "Calculator",
      "industry": "legal",
      "visual_style": "Regulatory, Professional. Legal Navy, Compliance Blue, Required Red, Approved Green",
      "layout_pattern": "Jurisdiction selector, Required disclosures library, Auto-generated disclaimers (customizable by vertical), Terms and conditions templates, Privacy policy builder, TCPA compliance checker, State-specific requirements, Lender license display, APR calculator and disclosure, Footer compliance module, A",
      "prompt": "Create a \"Compliance & Legal Module Generator\" for regulated funding pages. VISUAL STYLE: Regulatory, Professional. Legal Navy, Compliance Blue, Required Red, Approved Green. LAYOUT: Jurisdiction selector, Required disclosures library, Auto-generated disclaimers (customizable by vertical), Terms and conditions templates, Privacy policy builder, TCPA compliance checker, State-specific requirements, Lender license display, APR calculator and disclosure, Footer compliance module, Audit trail and version history.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "venture-studio-dashboard",
      "name": "Venture Studio Dashboard",
      "description": "Central command center for managing multiple portfolio ventures simultaneously.",
      "asset_type": "Dashboard",
      "industry": "general",
      "visual_style": "Strategic, Executive. Deep Navy (#1e293b), Venture Blue (#3b82f6), Growth Green (#10b981), Alert Amber (#f59e0b), Clean White. Modern sans-serif, data-dense but scannable",
      "layout_pattern": "Portfolio overview grid (venture cards with key metrics), Stage pipeline view (Ideation → Validation → Launch → Scale → Exit), Resource allocation tracker, Capital deployment monitor, Founder/operator directory, Shared service utilization, Cross-portfolio synergies identifier, Monthly burn rate by v",
      "prompt": "Design a \"Venture Studio Dashboard\" for Juliet Foxtrot Ventures portfolio management. VISUAL STYLE: Strategic, Executive. Deep Navy (#1e293b), Venture Blue (#3b82f6), Growth Green (#10b981), Alert Amber (#f59e0b), Clean White. Modern sans-serif, data-dense but scannable. LAYOUT: Portfolio overview grid (venture cards with key metrics), Stage pipeline view (Ideation → Validation → Launch → Scale → Exit), Resource allocation tracker, Capital deployment monitor, Founder/operator directory, Shared service utilization, Cross-portfolio synergies identifier, Monthly burn rate by venture, Revenue dashboard (aggregate + individual), Team capacity planner, Investment committee notes, Exit opportunity tracker.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "self-funded-search-pipeline",
      "name": "Self-Funded Search Pipeline",
      "description": "Deal flow management system for identifying and evaluating acquisition targets.",
      "asset_type": "Calculator",
      "industry": "ecommerce",
      "visual_style": "Deal-focused, Analytical. Search Navy (#0f172a), Target Blue (#2563eb), Qualified Green (#059669), Pass Red (#dc2626)",
      "layout_pattern": "Target company database, Industry filter (SaaS, Media, E-commerce, Agencies), Revenue/EBITDA range selectors, Geographic heat map, Seller motivation tracker, Initial outreach status, Financial snapshot uploader, Quality of Earnings checklist, LOI generator, Due diligence tracker (Legal, Financial, O",
      "prompt": "Create a \"Self-Funded Search Pipeline\" for micro-PE deal sourcing. VISUAL STYLE: Deal-focused, Analytical. Search Navy (#0f172a), Target Blue (#2563eb), Qualified Green (#059669), Pass Red (#dc2626). LAYOUT: Target company database, Industry filter (SaaS, Media, E-commerce, Agencies), Revenue/EBITDA range selectors, Geographic heat map, Seller motivation tracker, Initial outreach status, Financial snapshot uploader, Quality of Earnings checklist, LOI generator, Due diligence tracker (Legal, Financial, Operational, Technical), Valuation calculator (3-5x EBITDA range), Deal structure optimizer (cash, earnout, seller note), Integration playbook library.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "micro-pe-deal-analyzer",
      "name": "Micro-PE Deal Analyzer",
      "description": "Financial modeling and valuation tool for small business acquisitions.",
      "asset_type": "Calculator",
      "industry": "general",
      "visual_style": "Financial, Professional. Spreadsheet Gray, Analysis Blue, Profitable Green, Risk Red",
      "layout_pattern": "Company profile input, Historical financials uploader (3 years), Revenue quality assessment, Customer concentration analysis, Churn rate calculator, Normalized EBITDA adjuster (add-backs), Valuation multiples comparator (industry benchmarks), Debt capacity calculator, Return scenarios (Base/Bull/Bea",
      "prompt": "Design a \"Micro-PE Deal Analyzer\" for sub-$5M acquisitions. VISUAL STYLE: Financial, Professional. Spreadsheet Gray, Analysis Blue, Profitable Green, Risk Red. LAYOUT: Company profile input, Historical financials uploader (3 years), Revenue quality assessment, Customer concentration analysis, Churn rate calculator, Normalized EBITDA adjuster (add-backs), Valuation multiples comparator (industry benchmarks), Debt capacity calculator, Return scenarios (Base/Bull/Bear), Cash-on-cash return projections, IRR calculator, Synergy value estimator, Risk scoring matrix, Investment committee memo generator.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "holding-company-portfolio-tracker",
      "name": "Holding Company Portfolio Tracker",
      "description": "Consolidated performance monitoring across multiple acquired businesses.",
      "asset_type": "Prompt Template",
      "industry": "tax",
      "visual_style": "Corporate, Multi-entity. Holding Navy (#1e3a8a), Portfolio Purple (#7c3aed), Performance indicators (Green/Red)",
      "layout_pattern": "Company roster with ownership stakes, Consolidated P&L rollup, Cash flow waterfall (OpCo → HoldCo), Cross-company comparison metrics, Industry performance benchmarking, Management team scorecards, Capital allocation recommendations, Dividend/distribution tracker, Shared services cost allocation, Tax",
      "prompt": "Create a \"Holding Company Portfolio Tracker\" for JFV operating companies. VISUAL STYLE: Corporate, Multi-entity. Holding Navy (#1e3a8a), Portfolio Purple (#7c3aed), Performance indicators (Green/Red). LAYOUT: Company roster with ownership stakes, Consolidated P&L rollup, Cash flow waterfall (OpCo → HoldCo), Cross-company comparison metrics, Industry performance benchmarking, Management team scorecards, Capital allocation recommendations, Dividend/distribution tracker, Shared services cost allocation, Tax optimization opportunities, Strategic initiative status, M&A pipeline for bolt-ons.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "venture-ideation-lab",
      "name": "Venture Ideation Lab",
      "description": "Structured brainstorming and validation workspace for new venture concepts.",
      "asset_type": "Calculator",
      "industry": "general",
      "visual_style": "Creative, Exploratory. Idea Purple (#a855f7), Validation Blue (#3b82f6), Launch Green (#22c55e), Kill Red (#ef4444)",
      "layout_pattern": "Idea submission form (Problem, Solution, Market, Why Now), Opportunity canvas, TAM/SAM/SOM calculator, Competitor landscape mapper, Unit economics estimator, MVP scope definer, Resource requirement calculator, Founder-market fit evaluator, Risk assessment matrix, Go/No-Go decision tree, Validation e",
      "prompt": "Design a \"Venture Ideation Lab\" for venture studio concept development. VISUAL STYLE: Creative, Exploratory. Idea Purple (#a855f7), Validation Blue (#3b82f6), Launch Green (#22c55e), Kill Red (#ef4444). LAYOUT: Idea submission form (Problem, Solution, Market, Why Now), Opportunity canvas, TAM/SAM/SOM calculator, Competitor landscape mapper, Unit economics estimator, MVP scope definer, Resource requirement calculator, Founder-market fit evaluator, Risk assessment matrix, Go/No-Go decision tree, Validation experiment tracker, Pivot log, Idea graveyard (learnings archive).",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "bootstrapped-growth-calculator",
      "name": "Bootstrapped Growth Calculator",
      "description": "Financial planning tool for ventures scaling without external funding.",
      "asset_type": "Calculator",
      "industry": "general",
      "visual_style": "Sustainable, Realistic. Bootstrap Blue (#0ea5e9), Profitable Green (#16a34a), Burn Orange (#f97316)",
      "layout_pattern": "Current MRR/ARR input, Growth rate scenarios (Conservative/Moderate/Aggressive), CAC/LTV ratio tracker, Payback period calculator, Runway estimator (months of cash), Founder compensation planner, Reinvestment rate optimizer, Profit distribution schedule, Cash reserve requirements, Revenue milestone ",
      "prompt": "Create a \"Bootstrapped Growth Calculator\" for self-funded venture growth. VISUAL STYLE: Sustainable, Realistic. Bootstrap Blue (#0ea5e9), Profitable Green (#16a34a), Burn Orange (#f97316). LAYOUT: Current MRR/ARR input, Growth rate scenarios (Conservative/Moderate/Aggressive), CAC/LTV ratio tracker, Payback period calculator, Runway estimator (months of cash), Founder compensation planner, Reinvestment rate optimizer, Profit distribution schedule, Cash reserve requirements, Revenue milestone projections, Team scaling timeline, Breakeven analysis, Path to profitability visualizer.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "no-code-tech-stack-builder",
      "name": "No-Code Tech Stack Builder",
      "description": "Tool recommender and integration planner for no-code/low-code ventures.",
      "asset_type": "Template",
      "industry": "general",
      "visual_style": "Modern, Modular. Stack Purple (#9333ea), Integration Blue (#3b82f6), Cost Green (#10b981)",
      "layout_pattern": "Venture type selector (SaaS, Marketplace, Media, E-commerce), Functional requirements checklist, Tool recommendations by category (Frontend: Webflow/Framer, Backend: Airtable/Notion, Payments: Stripe, Auth: Clerk, etc.), Integration compatibility matrix, Cost estimator by stage, Alternative comparis",
      "prompt": "Design a \"No-Code Tech Stack Builder\" for rapid venture deployment. VISUAL STYLE: Modern, Modular. Stack Purple (#9333ea), Integration Blue (#3b82f6), Cost Green (#10b981). LAYOUT: Venture type selector (SaaS, Marketplace, Media, E-commerce), Functional requirements checklist, Tool recommendations by category (Frontend: Webflow/Framer, Backend: Airtable/Notion, Payments: Stripe, Auth: Clerk, etc.), Integration compatibility matrix, Cost estimator by stage, Alternative comparisons, Setup difficulty ratings, Scalability limitations, Migration path to code (when needed), Template marketplace, Community resources.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "acquisition-integration-playbook",
      "name": "Acquisition Integration Playbook",
      "description": "Post-acquisition checklist and timeline for operational integration.",
      "asset_type": "Dashboard",
      "industry": "legal",
      "visual_style": "Operational, Systematic. Integration Navy (#1e40af), Milestone Blue (#3b82f6), Complete Green (#059669)",
      "layout_pattern": "Day 1 checklist (Legal, Banking, Access), First 100 days timeline, Team retention strategy, Customer communication plan, System integration roadmap, Brand transition decisions, Financial reporting alignment, Operational audit findings, Quick win identifier, Culture assessment, Key person dependencie",
      "prompt": "Create an \"Acquisition Integration Playbook\" for newly acquired companies. VISUAL STYLE: Operational, Systematic. Integration Navy (#1e40af), Milestone Blue (#3b82f6), Complete Green (#059669). LAYOUT: Day 1 checklist (Legal, Banking, Access), First 100 days timeline, Team retention strategy, Customer communication plan, System integration roadmap, Brand transition decisions, Financial reporting alignment, Operational audit findings, Quick win identifier, Culture assessment, Key person dependencies, Synergy realization tracker, Integration risk monitor, Success metrics dashboard.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "venture-studio-resources-hub",
      "name": "Venture Studio Resources Hub",
      "description": "Shared services and resource allocation platform for portfolio companies.",
      "asset_type": "Directory",
      "industry": "construction",
      "visual_style": "Service-oriented, Accessible. Studio Purple (#8b5cf6), Service Blue (#3b82f6), Available Green (#10b981)",
      "layout_pattern": "Service catalog (Finance, Legal, Marketing, Design, Tech, HR), Resource booking calendar, Expert directory (advisors, consultants, specialists), Template library (Legal docs, Marketing assets, Financial models), Vendor relationships (pre-negotiated rates), Talent pool (contractors, part-time operato",
      "prompt": "Design a \"Venture Studio Resources Hub\" for portfolio support services. VISUAL STYLE: Service-oriented, Accessible. Studio Purple (#8b5cf6), Service Blue (#3b82f6), Available Green (#10b981). LAYOUT: Service catalog (Finance, Legal, Marketing, Design, Tech, HR), Resource booking calendar, Expert directory (advisors, consultants, specialists), Template library (Legal docs, Marketing assets, Financial models), Vendor relationships (pre-negotiated rates), Talent pool (contractors, part-time operators), Knowledge base, Office hours scheduler, Cross-portfolio introductions, Portfolio company directory, Slack/community access, Event calendar (workshops, networking).",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "founder-matching-engine",
      "name": "Founder Matching Engine",
      "description": "AI-powered system for matching venture ideas with ideal founding teams.",
      "asset_type": "Calculator",
      "industry": "general",
      "visual_style": "People-first, Collaborative. Match Purple (#a855f7), Founder Blue (#3b82f6), Team Green (#10b981)",
      "layout_pattern": "Founder profile builder (Skills, Experience, Interests, Availability), Venture opportunity listings, Skills gap identifier, Complementary founder finder, Team composition optimizer (Tech/Business/Design), Culture fit assessments, Previous collaboration tracker, Reference checker, Equity split calcul",
      "prompt": "Create a \"Founder Matching Engine\" for venture studio team formation. VISUAL STYLE: People-first, Collaborative. Match Purple (#a855f7), Founder Blue (#3b82f6), Team Green (#10b981). LAYOUT: Founder profile builder (Skills, Experience, Interests, Availability), Venture opportunity listings, Skills gap identifier, Complementary founder finder, Team composition optimizer (Tech/Business/Design), Culture fit assessments, Previous collaboration tracker, Reference checker, Equity split calculator, Vesting schedule generator, Founder agreement templates, Team formation timeline.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "ai-driven-market-opportunity-scanner",
      "name": "AI-Driven Market Opportunity Scanner",
      "description": "Automated system for identifying emerging market opportunities using AI.",
      "asset_type": "Dashboard",
      "industry": "auto_services",
      "visual_style": "Intelligence, Future-focused. AI Purple (#7c3aed), Insight Blue (#2563eb), Opportunity Gold (#f59e0b)",
      "layout_pattern": "Trend monitoring dashboard (Google Trends, social signals), Pain point aggregator (Reddit, forums, reviews), Technology enabler tracker (new APIs, platforms), Regulatory change monitor, Demographic shift identifier, Market size estimator, Competition density analyzer, Timing score (Why Now?), Opport",
      "prompt": "Design an \"AI-Driven Market Opportunity Scanner\" for venture discovery. VISUAL STYLE: Intelligence, Future-focused. AI Purple (#7c3aed), Insight Blue (#2563eb), Opportunity Gold (#f59e0b). LAYOUT: Trend monitoring dashboard (Google Trends, social signals), Pain point aggregator (Reddit, forums, reviews), Technology enabler tracker (new APIs, platforms), Regulatory change monitor, Demographic shift identifier, Market size estimator, Competition density analyzer, Timing score (Why Now?), Opportunity briefing generator, Validation experiment suggester, Prioritization framework.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "exit-strategy-planner",
      "name": "Exit Strategy Planner",
      "description": "Long-term value creation and exit planning tool for portfolio ventures.",
      "asset_type": "Prompt Template",
      "industry": "tax",
      "visual_style": "Strategic, Forward-looking. Exit Navy (#1e3a8a), Value Gold (#f59e0b), Target Green (#059669)",
      "layout_pattern": "Venture maturity assessor, Exit option evaluator (Strategic sale, Financial buyer, Management buyout, Recapitalization, IPO, Dividend recap), Valuation enhancement opportunities, Buyer persona profiles, Market timing indicators, Financial preparation checklist, Data room builder, Management presenta",
      "prompt": "Create an \"Exit Strategy Planner\" for venture liquidity events. VISUAL STYLE: Strategic, Forward-looking. Exit Navy (#1e3a8a), Value Gold (#f59e0b), Target Green (#059669). LAYOUT: Venture maturity assessor, Exit option evaluator (Strategic sale, Financial buyer, Management buyout, Recapitalization, IPO, Dividend recap), Valuation enhancement opportunities, Buyer persona profiles, Market timing indicators, Financial preparation checklist, Data room builder, Management presentation creator, Deal structure optimizer, Tax efficiency planner, Post-exit founder transition, Success metrics tracker.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "micro-saas-validation-framework",
      "name": "Micro-SaaS Validation Framework",
      "description": "Rapid testing methodology for validating SaaS concepts before full build.",
      "asset_type": "Landing Page",
      "industry": "general",
      "visual_style": "Lean, Experiment-driven. Validation Purple (#9333ea), Test Blue (#3b82f6), Proven Green (#10b981), Pivot Orange (#f97316)",
      "layout_pattern": "Problem hypothesis statement, Target customer definition, Landing page builder (pre-launch), Waitlist signup tracker, Customer interview scheduler, Smoke test metrics (signup rate, email opens), Pricing sensitivity tester, Feature prioritization (Must/Should/Could/Won't), MVP scope definition, Time-",
      "prompt": "Design a \"Micro-SaaS Validation Framework\" for lean SaaS validation. VISUAL STYLE: Lean, Experiment-driven. Validation Purple (#9333ea), Test Blue (#3b82f6), Proven Green (#10b981), Pivot Orange (#f97316). LAYOUT: Problem hypothesis statement, Target customer definition, Landing page builder (pre-launch), Waitlist signup tracker, Customer interview scheduler, Smoke test metrics (signup rate, email opens), Pricing sensitivity tester, Feature prioritization (Must/Should/Could/Won't), MVP scope definition, Time-to-value estimator, Competitor response tracker, Go/No-Go criteria, Pivot decision tree.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "bootstrapped-marketing-playbook",
      "name": "Bootstrapped Marketing Playbook",
      "description": "Cost-effective growth tactics library for self-funded ventures.",
      "asset_type": "Template",
      "industry": "general",
      "visual_style": "Tactical, ROI-focused. Growth Green (#10b981), Channel Blue (#3b82f6), Cost-effective Purple (#a855f7)",
      "layout_pattern": "Channel effectiveness matrix (Organic Social, SEO, Content, Community, Partnerships, Cold Outreach), Cost per acquisition benchmarks, Time investment estimator, Founder-led marketing tactics, Content calendar templates, SEO keyword opportunity finder, Distribution channel optimizer, Viral loop desig",
      "prompt": "Create a \"Bootstrapped Marketing Playbook\" for capital-efficient growth. VISUAL STYLE: Tactical, ROI-focused. Growth Green (#10b981), Channel Blue (#3b82f6), Cost-effective Purple (#a855f7). LAYOUT: Channel effectiveness matrix (Organic Social, SEO, Content, Community, Partnerships, Cold Outreach), Cost per acquisition benchmarks, Time investment estimator, Founder-led marketing tactics, Content calendar templates, SEO keyword opportunity finder, Distribution channel optimizer, Viral loop designer, Referral program builder, Community building tactics, Partnership pitch templates, Growth experiment tracker.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "operating-metrics-dashboard",
      "name": "Operating Metrics Dashboard",
      "description": "Key performance indicator tracker across all portfolio ventures.",
      "asset_type": "Dashboard",
      "industry": "general",
      "visual_style": "Data-centric, Executive. Metric Navy (#0f172a), KPI Blue (#3b82f6), Target Green (#059669), Alert Red (#dc2626)",
      "layout_pattern": "Company selector dropdown, North Star metric by venture, Growth metrics (MRR, ARR, user growth, GMV), Efficiency metrics (CAC, LTV, payback period, burn multiple), Engagement metrics (DAU/MAU, retention cohorts, churn), Financial health (runway, cash position, margins), Team metrics (headcount, prod",
      "prompt": "Design an \"Operating Metrics Dashboard\" for portfolio-wide KPI monitoring. VISUAL STYLE: Data-centric, Executive. Metric Navy (#0f172a), KPI Blue (#3b82f6), Target Green (#059669), Alert Red (#dc2626). LAYOUT: Company selector dropdown, North Star metric by venture, Growth metrics (MRR, ARR, user growth, GMV), Efficiency metrics (CAC, LTV, payback period, burn multiple), Engagement metrics (DAU/MAU, retention cohorts, churn), Financial health (runway, cash position, margins), Team metrics (headcount, productivity), Customer health scores, Benchmark comparisons (industry, stage), Trend analysis, Anomaly detector, Board-ready reports.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "venture-studio-crm",
      "name": "Venture Studio CRM",
      "description": "Relationship management system for founders, advisors, LPs, and operators.",
      "asset_type": "Prompt Template",
      "industry": "auto_services",
      "visual_style": "Relationship-focused, Network-oriented. Network Purple (#8b5cf6), Connection Blue (#3b82f6), Active Green (#10b981)",
      "layout_pattern": "Contact database (Founders, Advisors, Investors, Operators, Service providers), Interaction timeline, Expertise tagging, Availability tracker, Introduction request system, Warm intro path finder, Follow-up reminders, Event attendance tracker, Portfolio company connections, LP reporting automation, A",
      "prompt": "Create a \"Venture Studio CRM\" for ecosystem relationship management. VISUAL STYLE: Relationship-focused, Network-oriented. Network Purple (#8b5cf6), Connection Blue (#3b82f6), Active Green (#10b981). LAYOUT: Contact database (Founders, Advisors, Investors, Operators, Service providers), Interaction timeline, Expertise tagging, Availability tracker, Introduction request system, Warm intro path finder, Follow-up reminders, Event attendance tracker, Portfolio company connections, LP reporting automation, Advisor engagement metrics, Community activity feed, Referral source attribution.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "acquisition-letter-campaign-generator",
      "name": "Acquisition Letter Campaign Generator",
      "description": "Automated outreach system for proactive deal sourcing.",
      "asset_type": "Template",
      "industry": "auto_services",
      "visual_style": "Outreach-focused, Professional. Outreach Navy (#1e40af), Letter Blue (#3b82f6), Response Green (#10b981)",
      "layout_pattern": "Target company list importer, Letter template library (Initial contact, Follow-up, LOI), Personalization token system, Company research auto-fill, Sending schedule planner, Email tracking (opens, clicks, replies), Response categorization (Interested/Not Now/Not Interested), Follow-up sequence automa",
      "prompt": "Design an \"Acquisition Letter Campaign Generator\" for systematic buyer outreach. VISUAL STYLE: Outreach-focused, Professional. Outreach Navy (#1e40af), Letter Blue (#3b82f6), Response Green (#10b981). LAYOUT: Target company list importer, Letter template library (Initial contact, Follow-up, LOI), Personalization token system, Company research auto-fill, Sending schedule planner, Email tracking (opens, clicks, replies), Response categorization (Interested/Not Now/Not Interested), Follow-up sequence automator, CRM integration, Call script generator, Meeting scheduler, Pipeline conversion tracker.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "portfolio-company-launch-checklist",
      "name": "Portfolio Company Launch Checklist",
      "description": "Comprehensive go-to-market checklist for new venture launches.",
      "asset_type": "Prompt Template",
      "industry": "legal",
      "visual_style": "Systematic, Milestone-driven. Launch Purple (#9333ea), Ready Blue (#3b82f6), Live Green (#10b981)",
      "layout_pattern": "Pre-launch sections (Legal entity, Banking, Insurance, Contracts, IP, Brand, Website, Product, Pricing, Analytics), Marketing launch plan, PR strategy, Community seeding, Launch event planner, Customer support setup, Payment processing, Security audit, Performance testing, Backup systems, Monitoring",
      "prompt": "Create a \"Portfolio Company Launch Checklist\" for venture go-live preparation. VISUAL STYLE: Systematic, Milestone-driven. Launch Purple (#9333ea), Ready Blue (#3b82f6), Live Green (#10b981). LAYOUT: Pre-launch sections (Legal entity, Banking, Insurance, Contracts, IP, Brand, Website, Product, Pricing, Analytics), Marketing launch plan, PR strategy, Community seeding, Launch event planner, Customer support setup, Payment processing, Security audit, Performance testing, Backup systems, Monitoring alerts, Post-launch metrics, First 30 days goals, Iteration plan.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "holding-company-tax-optimizer",
      "name": "Holding Company Tax Optimizer",
      "description": "Multi-entity tax planning and optimization tool.",
      "asset_type": "Portal",
      "industry": "tax",
      "visual_style": "Financial, Compliance-focused. Tax Navy (#1e3a8a), Structure Blue (#3b82f6), Savings Green (#059669)",
      "layout_pattern": "Entity structure visualizer, Income allocation planner, State tax comparisons, Transfer pricing guidelines, IP holding strategies, Management fee structuring, Interest deduction optimizer, NOL utilization tracker, Quarterly tax estimator, Audit risk assessor, Compliance calendar, CPA collaboration p",
      "prompt": "Design a \"Holding Company Tax Optimizer\" for corporate structure efficiency. VISUAL STYLE: Financial, Compliance-focused. Tax Navy (#1e3a8a), Structure Blue (#3b82f6), Savings Green (#059669). LAYOUT: Entity structure visualizer, Income allocation planner, State tax comparisons, Transfer pricing guidelines, IP holding strategies, Management fee structuring, Interest deduction optimizer, NOL utilization tracker, Quarterly tax estimator, Audit risk assessor, Compliance calendar, CPA collaboration portal, Tax strategy library, Scenario modeler.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "venture-studio-knowledge-base",
      "name": "Venture Studio Knowledge Base",
      "description": "Centralized documentation and lessons learned repository.",
      "asset_type": "Template",
      "industry": "general",
      "visual_style": "Educational, Searchable. Knowledge Purple (#7c3aed), Document Blue (#3b82f6), Updated Green (#10b981)",
      "layout_pattern": "Searchable documentation, Playbook library (Launch, Growth, Exit), Post-mortem archive (successes and failures), Best practices by function, Vendor recommendations, Template repository, Video tutorials, Founder interviews, Industry research, Competitive intelligence, Tool evaluations, Process docume",
      "prompt": "Create a \"Venture Studio Knowledge Base\" for institutional knowledge capture. VISUAL STYLE: Educational, Searchable. Knowledge Purple (#7c3aed), Document Blue (#3b82f6), Updated Green (#10b981). LAYOUT: Searchable documentation, Playbook library (Launch, Growth, Exit), Post-mortem archive (successes and failures), Best practices by function, Vendor recommendations, Template repository, Video tutorials, Founder interviews, Industry research, Competitive intelligence, Tool evaluations, Process documentation, Change log, Contribution system.",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    }
  ]
}
```
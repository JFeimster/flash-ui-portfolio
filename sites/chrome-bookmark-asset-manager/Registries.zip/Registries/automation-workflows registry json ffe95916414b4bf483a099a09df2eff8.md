# automation-workflows.registry.json

Description: For n8n/Zapier/CRM workflows. This would pair nicely with automation-tools.registry.json.
Suggested Fields: as
Last Updated: June 9, 2026 4:27 AM
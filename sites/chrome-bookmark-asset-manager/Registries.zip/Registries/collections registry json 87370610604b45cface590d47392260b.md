# collections.registry.json

Description: Mirrors and extends data/collections.json with internal strategy notes.
Suggested Fields: collection_id, name, slug, members, strategy_notes, public
Last Updated: June 9, 2026 3:34 AM

<aside>
🎯

Should mirror and extend `data/collections.json`, but with internal strategy notes attached.

</aside>

### 🧱 Suggested Fields

```json
{
  "collection_id": "",
  "name": "",
  "slug": "",
  "members": [],
  "strategy_notes": "",
  "public": false
}
```
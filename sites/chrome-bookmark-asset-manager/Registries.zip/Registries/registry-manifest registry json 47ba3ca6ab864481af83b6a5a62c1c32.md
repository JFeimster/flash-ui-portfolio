# registry-manifest.registry.json

Description: Keystone index of every *.registry.json — file, schemaVersion, owner, visibility, deploy target, status, record count, last-validated, and superseded/supersededBy. The single source of truth that makes CI validation possible.
Suggested Fields: id, file, schemaVersion, owner, visibility, deploy_target, status, record_count, last_validated, superseded, supersededBy, updatedAt
Last Updated: June 26, 2026 12:43 AM

<aside>
🎯

The single source of truth for the entire registry system. One record per `*.registry.json` file. `registry_importer.py` / a CI step reads this to know what to validate, where to deploy, and which files are superseded. ⚠️ The `superseded` flags below (provider-routing duplicates → `internal-provider-rules`) are best-guess consolidation candidates — confirm before any cleanup.

</aside>

### 🧱 Suggested Fields

```json
{
  "id": "",
  "file": "",
  "schemaVersion": "1.0.0",
  "owner": "",
  "visibility": "internal",
  "deploy_target": "",
  "status": "idea",
  "record_count": 0,
  "last_validated": null,
  "superseded": false,
  "supersededBy": null,
  "updatedAt": ""
}
```

### 📄 registry-manifest.registry.json

```json
[
  { "id": "funding-product-families", "file": "funding-product-families.registry.json", "visibility": "internal", "status": "built", "record_count": 9, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "funding-products", "file": "funding-products.registry.json", "visibility": "public", "status": "built", "record_count": 59, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "funding-routing-rules", "file": "funding-routing-rules.registry.json", "visibility": "internal", "status": "built", "record_count": 11, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "funding-scorecard", "file": "funding-scorecard.registry.json", "visibility": "internal", "status": "built", "record_count": 1, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "funding-tools", "file": "funding-tools.registry.json", "visibility": "public", "status": "built", "record_count": 10, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "funding-directory", "file": "funding-directory.registry.json", "visibility": "internal", "status": "built", "record_count": 1, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "funding-lead-fields", "file": "funding-lead-fields.registry.json", "visibility": "internal", "status": "built", "record_count": 19, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "funding-documents", "file": "funding-documents.registry.json", "visibility": "internal", "status": "built", "record_count": 20, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "funding-compliance-copy", "file": "funding-compliance-copy.registry.json", "visibility": "public", "status": "built", "record_count": 8, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "internal-provider-rules", "file": "internal-provider-rules.registry.json", "visibility": "private", "status": "built", "record_count": 97, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "credit-vendors", "file": "credit-vendors.registry.json", "visibility": "internal", "status": "built", "record_count": 43, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "credit-tiers", "file": "credit-tiers.registry.json", "visibility": "internal", "status": "built", "record_count": 4, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "credit-bureaus", "file": "credit-bureaus.registry.json", "visibility": "internal", "status": "built", "record_count": 5, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "account-types", "file": "account-types.registry.json", "visibility": "internal", "status": "built", "record_count": 9, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "fundability-checklist", "file": "fundability-checklist.registry.json", "visibility": "internal", "status": "built", "record_count": 10, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "credit-building-stages", "file": "credit-building-stages.registry.json", "visibility": "internal", "status": "built", "record_count": 6, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "bank-financing", "file": "bank-financing.registry.json", "visibility": "internal", "status": "built", "record_count": 4, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "registry-manifest", "file": "registry-manifest.registry.json", "visibility": "internal", "status": "in_progress", "record_count": 0, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "url-map", "file": "url-map.registry.json", "visibility": "public", "status": "planned", "record_count": 0, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "tracking-events", "file": "tracking-events.registry.json", "visibility": "internal", "status": "planned", "record_count": 0, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "geo-eligibility", "file": "geo-eligibility.registry.json", "visibility": "internal", "status": "planned", "record_count": 0, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "integrations", "file": "integrations.registry.json", "visibility": "private", "status": "planned", "record_count": 0, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "actions", "file": "actions.registry.json", "visibility": "private", "status": "in_progress", "record_count": 14, "superseded": false, "supersededBy": null, "schemaVersion": "1.1.0", "updatedAt": "2026-06-25" },
  { "id": "pricing-plans", "file": "pricing-plans.registry.json", "visibility": "public", "status": "planned", "record_count": 0, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "faqs", "file": "faqs.registry.json", "visibility": "public", "status": "planned", "record_count": 0, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "testimonials", "file": "testimonials.registry.json", "visibility": "public", "status": "planned", "record_count": 0, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "public-funding-directory", "file": "public-funding-directory.registry.json", "visibility": "public", "status": "built", "record_count": null, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "affiliate-partners", "file": "affiliate-partners.registry.json", "visibility": "private", "status": "built", "record_count": null, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "provider-routing", "file": "provider-routing.registry.json", "visibility": "internal", "status": "idea", "record_count": null, "superseded": true, "supersededBy": "internal-provider-rules.registry.json", "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "funding-provider-rules", "file": "funding-provider-rules.registry.json", "visibility": "internal", "status": "idea", "record_count": null, "superseded": true, "supersededBy": "internal-provider-rules.registry.json", "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "moonshine-offers", "file": "moonshine-offers.registry.json", "visibility": "internal", "status": "idea", "record_count": null, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "affiliate-offers", "file": "affiliate-offers.registry.json", "visibility": "internal", "status": "idea", "record_count": null, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "embed-targets", "file": "embed-targets.registry.json", "visibility": "internal", "status": "idea", "record_count": null, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "tool-artifacts", "file": "tool-artifacts.registry.json", "visibility": "internal", "status": "idea", "record_count": null, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "content-assets", "file": "content-assets.registry.json", "visibility": "internal", "status": "idea", "record_count": null, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "cta-routing", "file": "cta-routing.registry.json", "visibility": "internal", "status": "idea", "record_count": null, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "automation-workflows", "file": "automation-workflows.registry.json", "visibility": "internal", "status": "idea", "record_count": null, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "seo-metadata", "file": "seo-metadata.registry.json", "visibility": "public", "status": "idea", "record_count": null, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "monetization", "file": "monetization.registry.json", "visibility": "internal", "status": "idea", "record_count": null, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "personas", "file": "personas.registry.json", "visibility": "internal", "status": "idea", "record_count": null, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "lead-magnets", "file": "lead-magnets.registry.json", "visibility": "public", "status": "idea", "record_count": null, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "funnel-routes", "file": "funnel-routes.registry.json", "visibility": "public", "status": "idea", "record_count": null, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" },
  { "id": "compliance-rules", "file": "compliance-rules.registry.json", "visibility": "internal", "status": "idea", "record_count": null, "superseded": false, "supersededBy": null, "schemaVersion": "1.0.0", "updatedAt": "2026-06-18" }
]
```
# jfventures-config.zip

Description: JFVentures site config bundle — brands, funnels, directories, and per-page JSON configs (capital, credit, partners, AI, and tools sections) for the JFVentures hub.
Suggested Fields: brand, funnel, directory, page, slug, config
Last Updated: July 3, 2026 8:38 PM

<aside>
🎯

JFVentures site config bundle. Contains brands, funnels, directories, and per-page JSON configs (capital, credit, partners, AI, and tools sections) for the JFVentures hub.

</aside>

## [jfventures-config.zip](http://jfventures-config.zip)

[[jfventures-config.zip](http://jfventures-config.zip)](jfventures-config%20zip/f44962be-784c-4be2-a4b1-fc3acfa9d617.zip)

[jfventures-config.zip](http://jfventures-config.zip)

<aside>
✅

The attached file is the source of truth for this entry.

</aside>

### 🧱 Suggested Fields

```json
{
  "brand": "",
  "funnel": "",
  "directory": "",
  "page": "",
  "slug": "",
  "config": {}
}
```
# app-ideas.registry.json

Description: Idea registry of Next.js/Vercel app and tool concepts for funding, fintech, AI agents, analytics, and engineering-as-marketing, including AcquiStack AI modules.
Suggested Fields: id, name, category, description, target_user, stack, deploy_target, monetization, integration_notes
File: app-ideas.registry.json
Last Updated: June 18, 2026 8:55 PM

<aside>
🧱

**Single responsibility:** Capture app/tool build ideas (category, stack, deploy target, monetization) so each can be scoped into a Next.js + Vercel build.

</aside>

## Completed Registry — app-ideas.registry.json

[app-ideas.registry.json](app-ideas.registry.json)

app-ideas.registry.json

<aside>
✅

The attached completed JSON file is the primary source of truth. The sections below are secondary drafting/schema notes and compact previews.

</aside>

## Drafting & Schema Details

### Suggested fields

- `id` — kebab-case unique id
- `name` — app / tool idea name
- `category` — category group
- `description` — what it does
- `target_user` — primary target user
- `stack` — suggested stack
- `deploy_target` — deploy target
- `monetization` — monetization angle (TODO where not captured)
- `integration_notes` — integration notes

### Registry JSON

```json
{
  "id": "app-ideas",
  "name": "App Ideas",
  "source": "AI Generated",
  "visibility": "Internal",
  "fields": {
    "id": "kebab-case unique id",
    "name": "app / tool idea name",
    "category": "category group",
    "description": "what it does",
    "target_user": "primary target user",
    "stack": "suggested stack",
    "deploy_target": "deploy target",
    "monetization": "monetization angle",
    "integration_notes": "integration notes"
  },
  "entries": [
    {
      "id": "ai-cfo-insights-app",
      "name": "AI CFO Insights App",
      "category": "AI Tools",
      "description": "Connects financial data and surfaces cash, growth, and credit insights.",
      "target_user": "Founders",
      "stack": "Next.js + Supabase + OpenAI",
      "deploy_target": "Vercel",
      "monetization": "Subscription",
      "integration_notes": "Plaid/Finta, Stripe"
    }
  ]
}
```

### Example entries

- **Funding Pre-Qualification Wizard** — multi-step prequal routing to funding products.
- **AI CFO Insights App** — financial insights subscription on Next.js + Supabase + OpenAI.
- **Funding Marketplace** (AcquiStack) — matches businesses with funding products; marketplace commissions.

*Complete data (26 entries) is in the attached `app-ideas.registry.json`.*
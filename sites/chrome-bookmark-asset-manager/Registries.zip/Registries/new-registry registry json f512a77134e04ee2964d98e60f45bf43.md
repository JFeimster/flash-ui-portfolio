# new-registry.registry.json

Last Updated: June 9, 2026 3:36 AM

<aside>
🎯

What is this registry for? Describe its single responsibility in one or two sentences.

</aside>

### 🧱 Suggested Fields

```json
{
  "id": "",
  "name": "",
  "": ""
}
```

*Tip: run the Draft JSON schema AI block to generate this from the Description + Suggested Fields.*

### 📌 Example entries

```json
[]
```

*Tip: run the Generate example entries AI block to fill realistic records.*

### 🔗 Connections

- **Deployed / Hosted At:** where this registry lives (repo path, URL).
- **Linked Sources / Tools:** relate to the Funding Partners Database / affiliated tools.
# funding-tools.registry.json

Description: 125 engineering-as-marketing funding tools/calculators with concept-vs-live status. Only 6 are verified live; the rest are a build backlog.
Suggested Fields: name, slug, brand, persona, problem, core_logic, output_artifact, asset_type, partner_channel, status_raw, live_url, build_state, duplicate
Last Updated: June 26, 2026 12:43 AM

<aside>
🧮

**125 funding tool concepts** — mostly a **build backlog**, not live assets. Each carries a `build_state` flag so ideas aren't confused with deployments.

</aside>

## Summary

- **Total tools:** 125
- **Verified live:** 6 (e.g., trucker-repair-tracker)
- **Concept / Missing Asset:** 119
- **Role in stacks:** widget backlog — prioritize the 6 live, then build high-fit concepts into existing host sites

## Full registry file

[funding-tools.registry.json](funding-tools%20registry%20json/funding-tools.registry.json)

funding-tools.registry.json
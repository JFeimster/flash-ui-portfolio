# cta-routing.registry.json

Description: Controls where users go after using a tool; protects affiliate routing and avoids random CTA chaos.
Suggested Fields: rule_id, tool_id, persona, outcome, cta_label, cta_url, fallback_url, priority
Last Updated: June 9, 2026 3:34 AM

<aside>
🎯

Controls where users go after using a tool. Protects affiliate routing and avoids random CTA chaos.

</aside>

### 🧱 Suggested Fields

```json
{
  "rule_id": "",
  "tool_id": "",
  "persona": "",
  "outcome": "",
  "cta_label": "",
  "cta_url": "",
  "fallback_url": "",
  "priority": 0
}
```
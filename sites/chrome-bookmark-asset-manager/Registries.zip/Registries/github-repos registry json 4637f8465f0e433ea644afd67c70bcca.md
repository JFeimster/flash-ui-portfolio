# github-repos.registry.json

Description: Inventory of 186 GitHub repos (128 public + 58 private) — the deployable source behind the sites and tools.
Suggested Fields: name, slug, visibility, description, github_url, duplicate
File: github-repos.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
🐙

**186 repos** (128 public + 58 private) — the source-of-truth code behind your deployed assets.

</aside>

## Summary

- **Public:** 128 · **Private:** 58
- **Exact-name duplicates:** 0
- **Role in stacks:** source layer (what's forkable / deployable)

## Full registry file

[github-repos.registry.json](github-repos.registry.json)

github-repos.registry.json
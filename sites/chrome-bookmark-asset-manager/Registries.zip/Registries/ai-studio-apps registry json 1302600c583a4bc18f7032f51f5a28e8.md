# ai-studio-apps.registry.json

Description: Inventory of 44 Google AI Studio apps (Gemini-built tools, dashboards, and sites) with URLs and last-modified.
Suggested Fields: name, slug, url, description, last_modified, duplicate
Last Updated: June 26, 2026 12:43 AM

<aside>
✨

**44 Google AI Studio apps** — Gemini-built tools, dashboards, and site prototypes that complement the Vercel + GPT layers.

</aside>

## Summary

- **Total apps:** 44
- **Duplicates flagged:** 3 (repeated `Flash UI` / `Juliet Foxtrot Ventures` entries)
- **Role in stacks:** alternative tool/prototype layer

## Full registry file

[ai-studio-apps.registry.json](ai-studio-apps%20registry%20json/ai-studio-apps.registry.json)

ai-studio-apps.registry.json
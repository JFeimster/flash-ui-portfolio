# moonshine_control_files.zip

Description: Bundle of 9 brand/vertical *.control.json files (moonshine, ecom-sellers, real-estate, dac-team, ecom, funding, tools, banking, credit) plus manifest.json for the Moonshine / Funding OS.
Suggested Fields: label, path, filename, contentSources, notion, repos, sites, templates
Last Updated: July 3, 2026 8:32 PM

<aside>
🎯

Bundle of 9 brand/vertical control.json files (moonshine, ecom-sellers, real-estate, dac-team, ecom, funding, tools, banking, credit) plus manifest.json for the Moonshine / Funding OS.

</aside>

## moonshine_control_[files.zip](http://files.zip)

[moonshine_control_[files.zip](http://files.zip)](moonshine_control_files%20zip/a9ea2c7f-9b1a-404c-95d4-45cf523b6de0.zip)

moonshine_control_[files.zip](http://files.zip)

<aside>
✅

The attached file is the source of truth for this entry.

</aside>

### 🧱 Suggested Fields

```json
{
  "label": "",
  "path": "",
  "filename": "",
  "contentSources": {
    "notion": [],
    "repos": [],
    "sites": [],
    "templates": []
  }
}
```
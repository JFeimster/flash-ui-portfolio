# funding-pipeline-leads.registry.json

Description: Borrower lead records from the Funding Pipeline (CRM - Funding Review Requests). Includes inbound applicants and BankBreezy submission artifacts. Contains contact PII.
Suggested Fields: id, name, email, phone, company, account_type, lowest_monthly_revenue, revenue_band, funding_lane, lead_status, priority, source, close_reason, follow_up_date, created, notes
File: funding-pipeline-leads.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
📇

**Single responsibility** — One row per lead in the Funding Pipeline (65 records). ⚠️ Contains contact PII (email, phone) — Internal visibility. Note: many rows are email/notification artifacts (e.g. “BankBreezy Submission Started for…”, “Client File Closed”) and are exported as-is.

</aside>

## Completed Registry — funding-pipeline-leads.registry.json

[funding-pipeline-leads.registry.json](funding-pipeline-leads.registry.json)

funding-pipeline-leads.registry.json

<aside>
✅

The attached completed JSON file is the primary source of truth. The sections below are secondary drafting/schema notes and compact previews.

</aside>

## Drafting & Schema Details

### Suggested fields

- `id` — kebab-case slug or `lead-NN`
- `name`, `email`, `phone`, `company`, `account_type`
- `lowest_monthly_revenue`, `revenue_band`, `funding_lane`
- `lead_status`, `priority`, `source`, `close_reason`, `follow_up_date`, `created`, `notes`

### Registry JSON

```json
{
  "id": "funding-pipeline-leads",
  "name": "funding-pipeline-leads",
  "source": "CSV Import",
  "visibility": "Internal",
  "fields": {
    "id": "kebab-case slug or lead-NN",
    "name": "Lead name / record title",
    "company": "Company",
    "account_type": "personal or business",
    "lowest_monthly_revenue": "Lowest monthly revenue USD (number)",
    "funding_lane": "Routed funding lane",
    "lead_status": "Lead status"
  },
  "entries": [
    { "id": "david-allison", "name": "David Allison", "company": "Custom Made Music", "account_type": "personal", "lowest_monthly_revenue": 3000, "funding_lane": "Giggle Instant Approval", "lead_status": "Needs Applicant Action" },
    { "id": "horace-taffe", "name": "Horace Taffe", "company": "Unity Bar & Grill", "account_type": "business", "lowest_monthly_revenue": 7000, "lead_status": "New" }
  ]
}
```

### Example entries

- **David Allison** — Giggle Instant Approval, Needs Applicant Action, $3,000.
- **Anthony Sanders** — Sanders Outside LLC, $27,000.
- **Horace Taffe** — Unity Bar & Grill, business, $7,000.
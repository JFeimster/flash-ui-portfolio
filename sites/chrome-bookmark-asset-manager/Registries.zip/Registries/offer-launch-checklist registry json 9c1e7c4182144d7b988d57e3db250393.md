# offer-launch-checklist.registry.json

Description: Launch-readiness checklist for the 20 offers tracking copy, checkout, CRM, delivery, demo, QA and launched status with current blockers.
Suggested Fields: id, name, build_order, brand_lane, owner, copy_done, checkout_live, crm_wired, delivery_assets_ready, demo_example_ready, qa_complete, launched, current_blocker, next_action, notes
File: offer-launch-checklist.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
✅

**Purpose:** Launch-readiness checklist for the 20 offers tracking copy, checkout, CRM, delivery, demo, QA and launched status with current blockers.

**Source:** CSV Import · **Visibility:** Internal · **Status:** In Progress · **Priority:** High

</aside>

## Completed Registry — offer-launch-checklist.registry.json

[offer-launch-checklist.registry.json](offer-launch-checklist.registry.json)

offer-launch-checklist.registry.json

<aside>
✅

The attached completed JSON file is the primary source of truth. The sections below are secondary drafting/schema notes and compact previews.

</aside>

## Drafting & Schema Details

### Registry JSON

```json
{
  "id": "offer-launch-checklist",
  "name": "offer-launch-checklist.registry.json",
  "description": "Launch-readiness checklist for the 20 offers tracking copy, checkout, CRM, delivery, demo, QA and launched status with current blockers.",
  "source": "CSV Import",
  "visibility": "Internal",
  "fields": {
    "id": "", "name": "", "build_order": "", "brand_lane": "", "owner": "", "copy_done": "", "checkout_live": "", "crm_wired": "", "delivery_assets_ready": "", "demo_example_ready": "", "qa_complete": "", "launched": "", "current_blocker": "", "next_action": "", "notes": ""
  },
  "entries": [
    {
      "id": "creator-toolkit-vault",
      "name": "Creator Toolkit Vault",
      "build_order": 1,
      "brand_lane": "Full-Time Hustler",
      "copy_done": false,
      "checkout_live": false,
      "crm_wired": false,
      "launched": false,
      "current_blocker": "Final bundle contents not locked",
      "next_action": "Package starter toolkit and define version 1 scope"
    },
    {
      "id": "magnet-forge",
      "name": "Magnet Forge",
      "build_order": 2,
      "brand_lane": "Moonshine Capital",
      "copy_done": false,
      "launched": false,
      "current_blocker": "Need final angle and CTA",
      "next_action": "Turn NotebookLM source into first downloadable lead magnet"
    },
    {
      "id": "capital-readiness-brief",
      "name": "Capital Readiness Brief",
      "build_order": 3,
      "brand_lane": "Moonshine Capital",
      "copy_done": false,
      "launched": false,
      "current_blocker": "Scoring logic not finalized",
      "next_action": "Draft score bands and result-page CTAs"
    }
  ],
  "_note": "Showing 3 of 20 entries. All launch flags currently false (nothing launched yet). The complete 20-entry registry is in the attached offer-launch-checklist.registry.json file."
}
```

### Example entries

- **1. Creator Toolkit Vault** — Not launched. Blocker: final bundle contents not locked.
- **2. Magnet Forge** — Not launched. Blocker: need final angle and CTA.
- **3. Capital Readiness Brief** — Not launched. Blocker: scoring logic not finalized.

All 20 offers currently have every readiness flag set to false. The complete checklist is attached in the **File** property above.
# funding-pages.registry.json

Description: Page registry driving the /funding hub + 6 lane pages on http://moonshine-capital-portal.vercel.app. References product-families, products, providers, tools, and forms registries by id (no data crammed in).
Suggested Fields: id, name, version, visibility, source, lastUpdated, site, references, pages[{id, slug, route, parent, template, status, nav, seo, hero, pageIntent, audiences, sections, dataRefs, filters, compliance}]
Last Updated: June 26, 2026 6:37 AM

<aside>
📄

Drives funding pages on [moonshine-capital-portal.vercel.app](http://moonshine-capital-portal.vercel.app). This is a **page registry** — it controls routes, nav, SEO, hero, and sections, and **references** the product/tool/form registries by id rather than duplicating their data.

</aside>

## Pages (7)

| Route | Template | Product family | Status |
| --- | --- | --- | --- |
| /funding | funding-hub | all 7 families | draft |
| /funding/working-capital | funding-lane | working-capital | draft |
| /funding/business-line-of-credit | funding-lane | business-line-access | draft |
| /funding/startup-funding | funding-lane | startup-credit-leverage | draft |
| /funding/equipment-financing | funding-lane | equipment-finance | draft |
| /funding/real-estate-capital | funding-lane | real-estate-capital | draft |
| /funding/ecommerce-seller-funding | funding-lane | marketplace-capital | draft |

## How it's wired

- **Hub** (`/funding`) uses your exact provided shape: lane grid, qualification bands, tool grid, and the `mDEJB5` form embed.
- **Each lane page** mirrors the hub pattern with: a `product-grid` filtered to that family, a qualification-band table, a `tool-grid` filtered by lane tags, a "related lanes" grid, and the application form embed.
- **CTAs** reuse your two Tally forms — quote (`mDEJB5`) + funding-for-any-reason (`w4R2Ad`).
- **Featured GPTs**: `funding-pathfinder`, `get-my-funding-offer`.
- **Compliance** block (disclaimer + forbidden claims) is applied to every page.

<aside>
🔗

**References** (kept as separate registries, per your architecture): `funding/funding-product-families.registry.json` · `funding/funding-products.registry.json` · `funding/funding-providers.registry.json` · `embeds/tool-registry.json` · `forms/applications.json`.

</aside>

<aside>
⚠️

All 7 pages are `status: draft` / `reviewStatus: needs_review`. SEO copy and hero lines are drafted starting points — no lender terms, rates, or approval claims were invented.

</aside>

## Registry file

[funding-pages.registry.json](funding-pages%20registry%20json/funding-pages.registry.json)

funding-pages.registry.json
# url-map.registry.json

Description: Canonical slugs/routes so cta-routing and funnel-routes can't collide or 404. One record per route with redirects and the owning registry.
Suggested Fields: id, slug, canonical_url, redirects, owner_registry, status, schemaVersion, superseded, supersededBy, updatedAt
Last Updated: June 18, 2026 12:35 PM

<aside>
🎯

Canonical URL/slug map for the whole network. Prevents `cta-routing` and `funnel-routes` from colliding or 404-ing. Every public link should resolve through a record here.

</aside>

### 🧱 Suggested Fields

```json
{
  "id": "",
  "slug": "",
  "canonical_url": "",
  "redirects": [],
  "owner_registry": "",
  "status": "active",
  "schemaVersion": "1.0.0",
  "superseded": false,
  "supersededBy": null,
  "updatedAt": ""
}
```

### 📌 Example entries

```json
[
  { "id": "home", "slug": "/", "canonical_url": "https://example.com/", "redirects": ["/home"], "owner_registry": "funnel-routes.registry.json", "status": "active", "schemaVersion": "1.0.0", "superseded": false, "supersededBy": null, "updatedAt": "2026-06-18" },
  { "id": "apply", "slug": "/apply", "canonical_url": "https://example.com/apply", "redirects": ["/get-funded", "/start"], "owner_registry": "cta-routing.registry.json", "status": "active", "schemaVersion": "1.0.0", "superseded": false, "supersededBy": null, "updatedAt": "2026-06-18" }
]
```
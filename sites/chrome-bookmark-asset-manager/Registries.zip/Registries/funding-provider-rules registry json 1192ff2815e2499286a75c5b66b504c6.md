# funding-provider-rules.registry.json

Description: Private underwriting/routing rules. This is the “don’t let borrowers see behind the curtain” file.
Last Updated: June 9, 2026 4:23 AM
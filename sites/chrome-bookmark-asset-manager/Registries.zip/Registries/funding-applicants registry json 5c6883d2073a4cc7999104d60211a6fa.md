# funding-applicants.registry.json

Description: Applicant records from the Applicant Intake CRM (borrower funding applicants). Currently a single seed/sample record. Contains contact PII.
Suggested Fields: id, applicant_name, business_name, contact_email, phone, industry, monthly_revenue, time_in_business_months, credit_score, funding_need, desired_product_type, stage, source, use_of_funds, geography, notes
File: funding-applicants.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
🧑‍💼

**Single responsibility** — One row per borrower applicant in the Applicant Intake CRM. ⚠️ Contains contact PII (email, phone, credit) — Internal visibility. Currently only a single seed/sample record exists (the CRM is newly set up).

</aside>

## Completed Registry — funding-applicants.registry.json

[funding-applicants.registry.json](funding-applicants.registry.json)

funding-applicants.registry.json

<aside>
✅

The attached completed JSON file is the primary source of truth. The sections below are secondary drafting/schema notes and compact previews.

</aside>

## Drafting & Schema Details

### Suggested fields

- `id` — kebab-case slug
- `applicant_name`, `business_name`, `contact_email`, `phone`
- `industry`, `monthly_revenue`, `time_in_business_months`, `credit_score`, `funding_need`
- `desired_product_type` (array), `stage`, `source`, `use_of_funds`, `geography`, `notes`

### Registry JSON

```json
{
  "id": "funding-applicants",
  "name": "funding-applicants",
  "source": "CSV Import",
  "visibility": "Internal",
  "fields": {
    "id": "kebab-case slug",
    "applicant_name": "Full name",
    "business_name": "Business name",
    "monthly_revenue": "Monthly revenue USD (number)",
    "credit_score": "Credit score (number)",
    "stage": "Pipeline stage"
  },
  "entries": [
    {
      "id": "sample-applicant",
      "applicant_name": "Sample Applicant",
      "business_name": "Acme Brands LLC",
      "industry": "E-commerce Businesses",
      "monthly_revenue": 120000,
      "time_in_business_months": 18,
      "credit_score": 680,
      "funding_need": 500000,
      "stage": "Qualifying"
    }
  ]
}
```

### Example entries

- **Sample Applicant / Acme Brands LLC** — E-commerce, $120k/mo, 18 mo, 680 credit, $500k need, Qualifying *(seed/sample row only)*.

*TODO: real applicant records will populate as the Intake CRM is used.*
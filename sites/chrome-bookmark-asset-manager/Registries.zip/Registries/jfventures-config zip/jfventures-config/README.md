# JF Ventures Config Package

This package is designed for a config-driven Next.js build.

## Structure

```txt
/config
  jfventures.json              # parent ecosystem config
  /pages
    home.json
    capital.json
    capital.business-funding.json
    ...
  /brands
    moonshine-capital.json
    privateer-partner-network.json
    operator-ai-lab.json
    full-time-hustler.json
  /funnels
    funding-partners.json
    business-funding.json
    ai-agents.json
    credit-builder.json
  /directories
    funding-partners.json
    software-tools.json
```

## Suggested Next.js routes

```txt
/                         -> pages/home.json
/[slug]                   -> pages/{slug}.json
/[section]/[slug]         -> pages/{section}.{slug}.json
/api/lead                 -> beta placeholder; later send to Supabase/Neon/Notion/Sheets
```

## Beta data approach

Use static JSON for all content and localStorage for lightweight quiz/pathway state.

Suggested localStorage keys:

```txt
jfventures.pathway
jfventures.utm
jfventures.outboundClicks
jfventures.leads.{section}.{slug}
```

## Later data layer

When ready, add:

- Supabase or Neon for leads, users, partner profiles, and portal data
- Upstash for rate limiting, outbound click counters, queues, and lightweight events
- Notion or Google Sheets as an operator console / CRM mirror
- Tinybird later for event analytics if partner click reporting becomes serious

# seo-metadata.registry.json

Description: Lets you scale tool pages, landing pages, and collection pages without rewriting metadata manually.
Last Updated: June 18, 2026 7:50 PM
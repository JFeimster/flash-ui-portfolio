# brokerflow-ai-repo.zip

Description: BrokerFlow AI repo bundle — the no-auth Lender Match Review action pack (action definition, JSON schema, Vercel API, n8n/Zapier/Make workflows, guardrails, alert/task templates, SOP, and testing/env docs).
Suggested Fields: path, action, schema_file, api_endpoint, workflow, guardrails, template, sop, testing_doc, status
Last Updated: July 3, 2026 8:31 PM

<aside>
🎯

BrokerFlow AI repo bundle. Contains the no-auth Lender Match Review action pack: action definition, JSON schema, Vercel API, n8n/Zapier/Make workflows, guardrails, alert/task templates, SOP, and testing/env docs.

</aside>

## [brokerflow-ai-repo.zip](http://brokerflow-ai-repo.zip)

[[brokerflow-ai-repo.zip](http://brokerflow-ai-repo.zip)](brokerflow-ai-repo%20zip/49e72347-6961-4e59-a73f-e0f2f6adf77d.zip)

[brokerflow-ai-repo.zip](http://brokerflow-ai-repo.zip)

<aside>
✅

The attached file is the source of truth for this entry.

</aside>

### 🧱 Suggested Fields

```json
{
  "path": "",
  "action": "",
  "schema_file": "",
  "api_endpoint": "",
  "workflow": "",
  "guardrails": "",
  "template": "",
  "sop": "",
  "testing_doc": "",
  "status": ""
}
```
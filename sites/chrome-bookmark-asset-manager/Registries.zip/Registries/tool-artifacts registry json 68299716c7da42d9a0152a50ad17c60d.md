# tool-artifacts.registry.json

Description: Tool production board — tracks which tools have landing pages, embeds, configs, READMEs, assets, exports, and status.
Suggested Fields: tool_id, name, landing_page, embed_url, config_path, readme, assets, exports, status
Last Updated: June 9, 2026 4:28 AM

<aside>
🎯

The tool production board. Tracks which tools have landing pages, embeds, configs, READMEs, assets, exports, and current status.

</aside>

### 🧱 Suggested Fields

```json
{
  "tool_id": "",
  "name": "",
  "landing_page": "",
  "embed_url": "",
  "config_path": "",
  "readme": "",
  "assets": [],
  "exports": [],
  "status": ""
}
```
# moonshine-flash-ui-site-prompts.registry.json

Description: Registry of Moonshine Capital Flash UI prompts for full site experiences, marketing website variants, partner tools, account portals, community hubs, onboarding flows, and specialized funding tools.
Suggested Fields: id, name, category, asset_type, audience, purpose, visual_style, core_sections, primary_cta, prompt, source_file
File: moonshine-flash-ui-site-prompts.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
🗂️

**Purpose:** Registry of Moonshine Capital Flash UI prompts for full site experiences, marketing website variants, partner tools, account portals, community hubs, onboarding flows, and specialized funding tools.

</aside>

## Registry summary

- **Registry:** `moonshine-flash-ui-site-prompts.registry.json`
- **Source:** Manual
- **Visibility:** Internal
- **Entries:** 15
- **Suggested fields:** id, name, category, asset_type, audience, purpose, visual_style, core_sections, primary_cta, prompt, source_file

## Example entries

- **Cinematic Dark Luxe Marketing Site** — Design a "Cinematic Dark Luxe" marketing website for Moonshine Capital, a premium alternative financing marketplace.
- **Editorial Bento Grid Marketing Site** — Design an "Editorial Bento Grid" marketing website for Moonshine Capital.
- **Neo-Brutalist Marketing Site** — Design a "Neo-Brutalist" marketing website for Moonshine Capital.

## Full registry JSON

```json
{
  "id": "moonshine-flash-ui-site-prompts",
  "name": "moonshine-flash-ui-site-prompts.registry.json",
  "description": "Registry of Moonshine Capital Flash UI prompts for full site experiences, marketing website variants, partner tools, account portals, community hubs, onboarding flows, and specialized funding tools.",
  "source": "Manual",
  "visibility": "Internal",
  "fields": {
    "id": "kebab-case unique id",
    "name": "prompt name",
    "category": "source category",
    "asset_type": "asset type",
    "audience": "audience",
    "purpose": "purpose",
    "visual_style": "visual style",
    "core_sections": "major sections",
    "primary_cta": "primary CTA",
    "prompt": "full prompt",
    "source_file": "source file name"
  },
  "entries": [
    {
      "id": "cinematic-dark-luxe-marketing-site",
      "name": "Cinematic Dark Luxe Marketing Site",
      "category": "marketing_website_variant",
      "asset_type": "Calculator",
      "audience": "TODO",
      "purpose": "Design a \"Cinematic Dark Luxe\" marketing website for Moonshine Capital, a premium alternative financing marketplace.",
      "visual_style": "Elite, Cinematic, Luxury. Deep black (#0a0a0a), charcoal (#1a1a1a), gold spotlight (#d4af37), platinum accents (#e5e4e2). Dramatic lighting, film grain texture overlay, ultra-wide aspect ratios. LAYOUT STRUCTURE: HERO SECTION: - Full-viewport cinematic video background (abstract liquid gold, money f",
      "core_sections": [
        "VISUAL STYLE",
        "LAYOUT STRUCTURE",
        "HERO SECTION",
        "VALUE PROPOSITION SECTION",
        "SOCIAL PROOF CINEMATIC",
        "PRODUCT SHOWCASE",
        "PARTNER CTA SECTION",
        "FOOTER",
        "DESIGN REQUIREMENTS"
      ],
      "primary_cta": "Get Funded",
      "prompt": "Design a \"Cinematic Dark Luxe\" marketing website for Moonshine Capital, a premium alternative financing marketplace.\n    \n    VISUAL STYLE: Elite, Cinematic, Luxury. Deep black (#0a0a0a), charcoal (#1a1a1a), gold spotlight (#d4af37), platinum accents (#e5e4e2). Dramatic lighting, film grain texture overlay, ultra-wide aspect ratios.\n    \n    LAYOUT STRUCTURE:\n    \n    HERO SECTION:\n    - Full-viewport cinematic video background (abstract liquid gold, money flowing)\n    - Dramatic headline: \"Capital Meets Vision\" with gold gradient\n    - Floating subheadline: \"Alternative Financing for Ambitious Entrepreneurs\"\n    - Dual CTA: \"Get Funded\" (gold button) + \"Become a Partner\" (ghost button)\n    - Scroll indicator with smooth animation\n    \n    VALUE PROPOSITION SECTION:\n    - Split screen: left shows pain points (traditional banking rejection), right shows solution (instant funding)\n    - Animated counter showcasing: \"$500M+ Funded | 10,000+ Businesses | 80+ Funding Partners\"\n    - Luxury card grid highlighting 6 core services with hover reveals\n    \n    SOCIAL PROOF CINEMATIC:\n    - Dark testimonial carousel with client video clips\n    - Brand trust strip: partner logos with gold separators\n    - \"Success Stories\" reel with before/after revenue metrics\n    \n    PRODUCT SHOWCASE:\n    - Horizontal scroll gallery of funding products\n    - Each product card: cinematic image, dramatic copy, instant quote CTA\n    - Categories: Business Capital, Revenue-Based, Asset-Backed, Non-Dilutive Growth, Startup, E-commerce, SaaS, Business Credit\n    \n    PARTNER CTA SECTION:\n    - Dramatic full-width banner: \"Build Your Funding Empire\"\n    - Income potential calculator with gold highlights\n    - Three-tier partner program showcase with luxury card design\n    \n    FOOTER:\n    - Premium dark footer with gold accents\n    - Multi-column: Products, Partners, Resources, Company, Legal\n    - Social proof metrics integrated\n    - Newsletter signup with gold submit button\n    \n    DESIGN REQUIREMENTS:\n    - Smooth parallax scrolling throughout\n    - Cinematic transitions between sections\n    - Premium micro-interactions on all interactive elements\n    - Gold particle effects on hover\n    - High-contrast typography (serif headlines, sans body)\n    - Mobile-first responsive with maintained luxury feel",
      "source_file": "Flash UI Prompts for Moonshine Capital Sites & Tools 🎨.md"
    },
    {
      "id": "editorial-bento-grid-marketing-site",
      "name": "Editorial Bento Grid Marketing Site",
      "category": "marketing_website_variant",
      "asset_type": "Calculator",
      "audience": "TODO",
      "purpose": "Design an \"Editorial Bento Grid\" marketing website for Moonshine Capital.",
      "visual_style": "Magazine-quality, Editorial, Modular. White (#ffffff), soft gray (#f5f5f5), accent blue (#2563eb), rich black (#1a1a1a). CSS Grid masonry layout, asymmetrical blocks, generous white space. LAYOUT STRUCTURE: HERO BENTO GRID: - Asymmetrical CSS Grid (6 columns × 4 rows) - Large headline block (spans 4",
      "core_sections": [
        "VISUAL STYLE",
        "LAYOUT STRUCTURE",
        "HERO BENTO GRID",
        "SERVICES BENTO SECTION",
        "EDITORIAL CONTENT BLOCKS",
        "HOW IT WORKS BENTO",
        "PARTNER OPPORTUNITY SECTION",
        "PROOF SECTION",
        "FOOTER BENTO",
        "DESIGN REQUIREMENTS"
      ],
      "primary_cta": "TODO",
      "prompt": "Design an \"Editorial Bento Grid\" marketing website for Moonshine Capital.\n    \n    VISUAL STYLE: Magazine-quality, Editorial, Modular. White (#ffffff), soft gray (#f5f5f5), accent blue (#2563eb), rich black (#1a1a1a). CSS Grid masonry layout, asymmetrical blocks, generous white space.\n    \n    LAYOUT STRUCTURE:\n    \n    HERO BENTO GRID:\n    - Asymmetrical CSS Grid (6 columns × 4 rows)\n    - Large headline block (spans 4 columns): \"Alternative Financing, Redefined\"\n    - Stats block (2×2): Animated funding metrics\n    - CTA block (2×1): \"Explore Funding Options\" button\n    - Image block (2×2): High-quality business imagery\n    - Testimonial snippet block (2×1)\n    - Partner logos block (6×1)\n    \n    SERVICES BENTO SECTION:\n    - 8 service cards in bento grid layout (varying sizes)\n    - Each card: Icon, title, description, \"Learn More\" link\n    - Hover effect: card expands slightly, reveals more detail\n    - Categories represented: Business Capital, Revenue-Based, Asset-Backed, Non-Dilutive, Startup, E-commerce, SaaS, Credit Building\n    \n    EDITORIAL CONTENT BLOCKS:\n    - Large feature article block: \"The Future of Alternative Financing\"\n    - Smaller blog post teasers in 3-column grid\n    - Pull quotes in colored blocks breaking up content\n    - Statistics callouts in accent color blocks\n    - Video embed block showcasing platform\n    \n    HOW IT WORKS BENTO:\n    - Visual step-by-step in modular blocks\n    - Alternating block sizes creating visual rhythm\n    - Illustrations in some blocks, copy in others\n    - CTA block at end: \"Start Your Application\"\n    \n    PARTNER OPPORTUNITY SECTION:\n    - Split bento: left side shows partner benefits, right shows income calculator\n    - Tiered program blocks stacked vertically\n    - Success story blocks interspersed\n    - Large \"Join Network\" CTA block\n    \n    PROOF SECTION:\n    - Client testimonial blocks (varying sizes)\n    - Company logo blocks\n    - Trust badges and certifications\n    - Case study preview blocks linking to full stories\n    \n    FOOTER BENTO:\n    - Multi-block footer with clear visual hierarchy\n    - Newsletter signup block (prominent)\n    - Quick links blocks (organized by category)\n    - Contact info block with social icons\n    - Legal/compliance block\n    \n    DESIGN REQUIREMENTS:\n    - Fully responsive bento grid (reflows on mobile)\n    - Smooth hover states on all blocks\n    - Consistent 8px spacing system\n    - Typography hierarchy: Large display serif, medium sans headlines, body sans\n    - Subtle shadows and borders defining blocks\n    - High-quality imagery throughout",
      "source_file": "Flash UI Prompts for Moonshine Capital Sites & Tools 🎨.md"
    },
    {
      "id": "neo-brutalist-marketing-site",
      "name": "Neo-Brutalist Marketing Site",
      "category": "marketing_website_variant",
      "asset_type": "Calculator",
      "audience": "TODO",
      "purpose": "Design a \"Neo-Brutalist\" marketing website for Moonshine Capital.",
      "visual_style": "Raw, Bold, Unapologetic. Stark black (#000000), pure white (#ffffff), electric accent (#00ff00 or #ff00ff). Thick borders (4-8px), hard shadows, monospace typography, no gradients, maximum contrast. LAYOUT STRUCTURE: HERO SECTION: - Brutal full-screen block with thick black border - Headline in mass",
      "core_sections": [
        "VISUAL STYLE",
        "LAYOUT STRUCTURE",
        "HERO SECTION",
        "VALUE BLOCKS",
        "STATS BAR",
        "PRODUCT GRID",
        "HOW IT WORKS",
        "PARTNER CTA SECTION",
        "TESTIMONIALS",
        "FOOTER",
        "DESIGN REQUIREMENTS"
      ],
      "primary_cta": "TODO",
      "prompt": "Design a \"Neo-Brutalist\" marketing website for Moonshine Capital.\n    \n    VISUAL STYLE: Raw, Bold, Unapologetic. Stark black (#000000), pure white (#ffffff), electric accent (#00ff00 or #ff00ff). Thick borders (4-8px), hard shadows, monospace typography, no gradients, maximum contrast.\n    \n    LAYOUT STRUCTURE:\n    \n    HERO SECTION:\n    - Brutal full-screen block with thick black border\n    - Headline in massive monospace caps: \"GET FUNDED. NOW.\"\n    - Subheadline in smaller monospace: \"Alternative financing for businesses banks reject\"\n    - Two huge rectangular buttons: \"APPLY\" (black bg, white text) and \"PARTNER\" (white bg, black text)\n    - Hard drop shadow on all elements (10px offset, no blur)\n    \n    VALUE BLOCKS:\n    - Grid of 6 rectangular blocks (3×2 on desktop)\n    - Each block: thick border, hard shadow, single color background\n    - Rotated headline text (90 degrees)\n    - Hover: block shifts position aggressively\n    - Services: BUSINESS CAPITAL | REVENUE-BASED | ASSET-BACKED | NON-DILUTIVE | STARTUP | ECOMMERCE\n    \n    STATS BAR:\n    - Full-width horizontal bar with thick top/bottom borders\n    - Stats in huge monospace numbers with labels\n    - \"$500M+ FUNDED // 10K+ BUSINESSES // 80+ PARTNERS\"\n    - Scrolling marquee effect\n    \n    PRODUCT GRID:\n    - Brutalist card grid (no rounded corners)\n    - Each card: product name in caps, price range, thick border, offset shadow\n    - Cards stack slightly offset creating depth\n    - Click reveals modal with full product details\n    - Modal: full-screen takeover, escape-key close\n    \n    HOW IT WORKS:\n    - Numbered list in huge monospace (1. 2. 3. 4.)\n    - Each step in separate bordered block\n    - Connecting lines between blocks (thick, straight)\n    - Final block: \"START\" button\n    \n    PARTNER CTA SECTION:\n    - Aggressive full-width banner\n    - \"BUILD YOUR EMPIRE\" in massive caps\n    - Income calculator in brutalist form design\n    - Submit button: oversized, hard shadow, hover shift\n    \n    TESTIMONIALS:\n    - Stacked quote blocks with thick borders\n    - Monospace quotes, attribution in caps\n    - Random rotation angles (-3deg, 2deg, -1deg)\n    - Hover: straightens and enlarges\n    \n    FOOTER:\n    - Full-width black block with white text\n    - Multi-column links (thick vertical separators)\n    - Social icons: simple black squares with white logos\n    - Copyright in monospace caps\n    \n    DESIGN REQUIREMENTS:\n    - Zero border radius anywhere\n    - All shadows: hard-edged, no blur, 8-12px offset\n    - Typography: Monospace for all text\n    - Hover states: aggressive position shifts or color inversions\n    - No smooth transitions (instant state changes or very fast)\n    - High contrast accessibility maintained\n    - Mobile: stacked blocks maintain brutalist aesthetic",
      "source_file": "Flash UI Prompts for Moonshine Capital Sites & Tools 🎨.md"
    },
    {
      "id": "ai-directory-marketplace-site",
      "name": "AI Directory / Marketplace Site",
      "category": "marketing_website_variant",
      "asset_type": "Directory",
      "audience": "TODO",
      "purpose": "Design an \"AI Directory / Marketplace\" website for Moonshine Capital funding products.",
      "visual_style": "Tech-forward, Clean, Data-driven. Light mode base (#fafafa), card white (#ffffff), primary purple (#7c3aed), secondary blue (#3b82f6). Modern sans-serif, plenty of filtering UI, search-first design. LAYOUT STRUCTURE: HEADER: - Sticky header with Moonshine Capital logo - Large search bar (center): \"S",
      "core_sections": [
        "VISUAL STYLE",
        "LAYOUT STRUCTURE",
        "HEADER",
        "HERO SEARCH SECTION",
        "PRODUCT DETAIL MODAL",
        "COMPARISON TOOL",
        "PARTNER SPOTLIGHT SECTION",
        "RESOURCES SECTION",
        "FOOTER",
        "DESIGN REQUIREMENTS"
      ],
      "primary_cta": "TODO",
      "prompt": "Design an \"AI Directory / Marketplace\" website for Moonshine Capital funding products.\n    \n    VISUAL STYLE: Tech-forward, Clean, Data-driven. Light mode base (#fafafa), card white (#ffffff), primary purple (#7c3aed), secondary blue (#3b82f6). Modern sans-serif, plenty of filtering UI, search-first design.\n    \n    LAYOUT STRUCTURE:\n    \n    HEADER:\n    - Sticky header with Moonshine Capital logo\n    - Large search bar (center): \"Search 80+ funding products...\"\n    - Filter toggles: Business Type | Funding Amount | Speed | Credit Score\n    - User account icon (top right)\n    \n    HERO SEARCH SECTION:\n    - Prominent search hero: \"Find Your Perfect Funding Match\"\n    - Smart search with autocomplete suggestions\n    - Popular searches: \"SaaS Funding\", \"Bad Credit\", \"Next-Day Cash\"\n    - Category quick-filters below search\n    \n    FILTER SIDEBAR (Left):\n    - Collapsible filter panel\n    - Categories: Product Type, Amount Range, Time to Fund, Credit Requirements, Industry\n    - Checkbox filters with result counts\n    - \"Apply Filters\" and \"Clear All\" buttons\n    \n    PRODUCT GRID (Main):\n    - Responsive card grid (3 columns desktop, 1 mobile)\n    - Each product card:\n      - Provider logo and rating (5 stars)\n      - Product name and tagline\n      - Key specs: Amount range, Time to fund, Min credit score\n      - Features list (checkmarks)\n      - \"Learn More\" and \"Apply Now\" buttons\n      - \"Save\" heart icon\n    - Sorting options: Relevance, Speed, Amount, Rating\n    \n    PRODUCT DETAIL MODAL:\n    - Overlay modal when \"Learn More\" clicked\n    - Full product information\n    - Detailed eligibility requirements\n    - Application process breakdown\n    - Reviews and testimonials\n    - Direct \"Apply Now\" CTA\n    \n    COMPARISON TOOL:\n    - Sticky bottom bar: \"Compare Products\"\n    - Select up to 3 products for side-by-side comparison\n    - Comparison view: detailed feature matrix\n    - Clear winner highlighting\n    \n    PARTNER SPOTLIGHT SECTION:\n    - Featured funding partners (carousel)\n    - Partner benefits and specializations\n    - \"View All Partners\" link to full directory\n    \n    RESOURCES SECTION:\n    - Educational content cards\n    - \"How to Choose Funding\", \"Application Tips\", \"Credit Building\"\n    - Blog posts and guides\n    - Video tutorials\n    \n    FOOTER:\n    - Comprehensive footer\n    - Product categories\n    - Partner programs\n    - Resources and support\n    - Legal and compliance\n    \n    DESIGN REQUIREMENTS:\n    - Fast, responsive filtering (instant results)\n    - Skeleton loaders during data fetch\n    - Accessibility-first design\n    - Mobile-optimized touch targets\n    - Breadcrumb navigation\n    - Pagination or infinite scroll\n    - Save/bookmark functionality (requires account)\n    - Share product links",
      "source_file": "Flash UI Prompts for Moonshine Capital Sites & Tools 🎨.md"
    },
    {
      "id": "partner-dashboard-dark-mode",
      "name": "Partner Dashboard (Dark Mode)",
      "category": "partner_affiliate_tools",
      "asset_type": "Dashboard",
      "audience": "TODO",
      "purpose": "Design a \"Partner Dashboard\" for Moonshine Capital affiliate network.",
      "visual_style": "Professional, Data-rich, Dark Mode. Dark navy (#0f172a), slate (#1e293b), card dark (#1e293b), accent gold (#fbbf24), success green (#10b981), white text (#f8fafc). LAYOUT STRUCTURE: SIDEBAR NAVIGATION (Left): - Moonshine Capital logo at top - User profile section with avatar and name - Navigation i",
      "core_sections": [
        "VISUAL STYLE",
        "LAYOUT STRUCTURE",
        "DASHBOARD OVERVIEW",
        "PERFORMANCE CHART",
        "LEADS PIPELINE TABLE",
        "COMMISSION BREAKDOWN",
        "QUICK ACTIONS PANEL",
        "RECENT ACTIVITY FEED",
        "LEADERBOARD WIDGET",
        "DESIGN REQUIREMENTS"
      ],
      "primary_cta": "TODO",
      "prompt": "Design a \"Partner Dashboard\" for Moonshine Capital affiliate network.\n    \n    VISUAL STYLE: Professional, Data-rich, Dark Mode. Dark navy (#0f172a), slate (#1e293b), card dark (#1e293b), accent gold (#fbbf24), success green (#10b981), white text (#f8fafc).\n    \n    LAYOUT STRUCTURE:\n    \n    SIDEBAR NAVIGATION (Left):\n    - Moonshine Capital logo at top\n    - User profile section with avatar and name\n    - Navigation items with icons:\n      - Dashboard (home icon)\n      - Leads (users icon)\n      - Commissions (dollar icon)\n      - Reports (chart icon)\n      - Marketing (megaphone icon)\n      - Training (book icon)\n      - Support (help icon)\n      - Settings (gear icon)\n    - Collapse/expand toggle\n    \n    HEADER (Top):\n    - Welcome message: \"Welcome back, [Name]\"\n    - Quick actions: \"New Lead\" button, \"Resources\" dropdown\n    - Notifications bell (with count badge)\n    - Profile dropdown\n    \n    DASHBOARD OVERVIEW:\n    - Key metrics row (4 cards):\n      - Total Commissions (this month)\n      - Active Leads (in pipeline)\n      - Funded Deals (this month)\n      - Conversion Rate (percentage)\n    - Each card: Large number, trend indicator (up/down arrow), comparison to last month\n    \n    PERFORMANCE CHART:\n    - Line chart: Commission earned over time (last 6 months)\n    - Toggle: Monthly / Weekly / Daily view\n    - Hover tooltips showing exact values\n    \n    LEADS PIPELINE TABLE:\n    - Recent leads with status\n    - Columns: Client Name, Business Type, Amount Requested, Status, Date Submitted, Actions\n    - Status badges: New (blue), Contacted (yellow), Submitted (orange), Funded (green)\n    - Action buttons: View Details, Add Note, Mark Funded\n    - Pagination controls\n    \n    COMMISSION BREAKDOWN:\n    - Pie chart showing commission by product type\n    - Business Capital, Revenue-Based, Asset-Backed, etc.\n    - Clickable segments for detailed breakdown\n    \n    QUICK ACTIONS PANEL:\n    - Card with buttons:\n      - Submit New Lead\n      - Generate Affiliate Link\n      - Download Marketing Materials\n      - Request Payout\n      - Schedule Training\n    \n    RECENT ACTIVITY FEED:\n    - Timeline of recent actions\n    - Lead submissions, funded deals, commission payments\n    - Timestamps and details\n    - \"View All Activity\" link\n    \n    LEADERBOARD WIDGET:\n    - Top 10 partners this month\n    - Rank, Name, Deals Funded, Commissions Earned\n    - \"See Full Leaderboard\" link\n    \n    DESIGN REQUIREMENTS:\n    - Fully responsive (sidebar collapses to hamburger on mobile)\n    - Real-time data updates\n    - Interactive charts and graphs\n    - Export functionality (CSV, PDF)\n    - Dark mode optimized for reduced eye strain\n    - Loading states and skeleton screens\n    - Error handling and empty states",
      "source_file": "Flash UI Prompts for Moonshine Capital Sites & Tools 🎨.md"
    },
    {
      "id": "affiliate-tracking-and-link-generator",
      "name": "Affiliate Tracking & Link Generator",
      "category": "partner_affiliate_tools",
      "asset_type": "Dashboard",
      "audience": "TODO",
      "purpose": "Design an \"Affiliate Tracking & Link Generator\" tool for Moonshine Capital partners.",
      "visual_style": "Clean, Functional, Modern. Light base (#f9fafb), white cards (#ffffff), primary blue (#3b82f6), success green (#10b981), chart colors (multi). LAYOUT STRUCTURE: HEADER SECTION: - Page title: \"Affiliate Link Generator & Tracker\" - Breadcrumb: Dashboard › Marketing › Link Generator - Quick stats bar: ",
      "core_sections": [
        "VISUAL STYLE",
        "LAYOUT STRUCTURE",
        "HEADER SECTION",
        "LINK GENERATOR PANEL",
        "LINK LIBRARY",
        "PERFORMANCE ANALYTICS",
        "CONVERSION FUNNEL",
        "TOP PERFORMING LINKS",
        "CAMPAIGN MANAGER",
        "SHARING TOOLS",
        "PAYOUT TRACKER",
        "DESIGN REQUIREMENTS"
      ],
      "primary_cta": "TODO",
      "prompt": "Design an \"Affiliate Tracking & Link Generator\" tool for Moonshine Capital partners.\n    \n    VISUAL STYLE: Clean, Functional, Modern. Light base (#f9fafb), white cards (#ffffff), primary blue (#3b82f6), success green (#10b981), chart colors (multi).\n    \n    LAYOUT STRUCTURE:\n    \n    HEADER SECTION:\n    - Page title: \"Affiliate Link Generator & Tracker\"\n    - Breadcrumb: Dashboard › Marketing › Link Generator\n    - Quick stats bar: Total Clicks, Conversions, Earnings (this month)\n    \n    LINK GENERATOR PANEL:\n    - Form to create new affiliate link:\n      - Destination URL dropdown (funding products, landing pages, resources)\n      - Campaign Name input\n      - UTM Parameters (auto-generated, editable): Source, Medium, Campaign, Content\n      - Custom slug (optional)\n    - \"Generate Link\" button\n    - Output: Shortened affiliate URL with copy button\n    - QR code generator toggle\n    \n    LINK LIBRARY:\n    - Table of all generated links\n    - Columns: Link Name, Short URL, Destination, Created Date, Clicks, Conversions, Revenue\n    - Search and filter: by campaign, date range, performance\n    - Bulk actions: Archive, Delete, Export\n    - Sort by: Most Clicks, Highest Converting, Newest\n    \n    PERFORMANCE ANALYTICS:\n    - Line chart: Clicks and conversions over time\n    - Date range selector: Last 7 days, 30 days, 90 days, Custom\n    - Breakdown by:\n      - Traffic source (social, email, website, paid)\n      - Device type (desktop, mobile, tablet)\n      - Geographic location (map visualization)\n    \n    CONVERSION FUNNEL:\n    - Visual funnel showing:\n      - Link Clicks\n      - Landing Page Views\n      - Applications Started\n      - Applications Submitted\n      - Funded Deals\n    - Conversion rates at each stage\n    - Identify drop-off points\n    \n    TOP PERFORMING LINKS:\n    - Card carousel showing top 5 links\n    - Each card: Link name, clicks, conversion rate, revenue\n    - Quick copy button\n    - \"View Details\" link\n    \n    CAMPAIGN MANAGER:\n    - Organize links into campaigns\n    - Campaign overview cards: Name, Total Links, Total Clicks, Total Revenue\n    - Create, edit, archive campaigns\n    - Campaign-level reporting\n    \n    SHARING TOOLS:\n    - Social media share buttons with auto-populated messaging\n    - Email template generator with affiliate link embedded\n    - Embeddable widgets for websites\n    \n    PAYOUT TRACKER:\n    - Commission earned from each link\n    - Pending payouts vs. paid out\n    - Payment history table\n    - Request payout button (if threshold met)\n    \n    DESIGN REQUIREMENTS:\n    - Real-time click tracking (updates without refresh)\n    - Copy-to-clipboard functionality\n    - Export reports (PDF, CSV, Excel)\n    - Mobile-responsive tables (horizontal scroll or card view)\n    - Tooltips explaining metrics\n    - Color-coded performance indicators\n    - Empty states with helpful guidance",
      "source_file": "Flash UI Prompts for Moonshine Capital Sites & Tools 🎨.md"
    },
    {
      "id": "finops-and-management-dashboard",
      "name": "FinOps & Management Dashboard",
      "category": "partner_affiliate_tools",
      "asset_type": "Dashboard",
      "audience": "TODO",
      "purpose": "Design a \"FinOps & Management Dashboard\" for Moonshine Capital operations team.",
      "visual_style": "Enterprise, Data-dense, Professional. Light mode (#ffffff), subtle gray (#f3f4f6), primary navy (#1e40af), alert red (#ef4444), success green (#10b981). LAYOUT STRUCTURE: EXECUTIVE SUMMARY (Top): - Key business metrics in large cards (5 across): - Total Funding Volume (this month, YTD) - Application",
      "core_sections": [
        "VISUAL STYLE",
        "LAYOUT STRUCTURE",
        "FINANCIAL OVERVIEW",
        "FUNDING PIPELINE",
        "PARTNER PERFORMANCE TABLE",
        "PRODUCT PERFORMANCE",
        "OPERATIONAL METRICS",
        "PARTNER PAYOUTS",
        "COMPLIANCE & RISK",
        "ACTIVITY LOG",
        "REPORTS SECTION",
        "ADMIN TOOLS"
      ],
      "primary_cta": "TODO",
      "prompt": "Design a \"FinOps & Management Dashboard\" for Moonshine Capital operations team.\n    \n    VISUAL STYLE: Enterprise, Data-dense, Professional. Light mode (#ffffff), subtle gray (#f3f4f6), primary navy (#1e40af), alert red (#ef4444), success green (#10b981).\n    \n    LAYOUT STRUCTURE:\n    \n    EXECUTIVE SUMMARY (Top):\n    - Key business metrics in large cards (5 across):\n      - Total Funding Volume (this month, YTD)\n      - Applications Processed\n      - Approval Rate (%)\n      - Average Deal Size\n      - Active Partners\n    - Each card: primary metric, trend indicator, comparison period\n    \n    FINANCIAL OVERVIEW:\n    - Revenue chart (bar/line combo)\n      - Total revenue by month (bars)\n      - Target line overlay\n      - Toggle: Revenue, Commissions Paid, Net Profit\n    - Key financial metrics below chart:\n      - Gross Revenue, Commission Expense, Net Revenue, Profit Margin\n    \n    FUNDING PIPELINE:\n    - Kanban board or funnel view\n    - Stages: Applied, Under Review, Approved, Funded, Declined\n    - Deal cards with key info: Business Name, Amount, Product Type, Days in Stage\n    - Drag-and-drop to move deals\n    - Filter by: Partner, Product, Date Range, Amount\n    \n    PARTNER PERFORMANCE TABLE:\n    - Sortable table of all partners\n    - Columns: Partner Name, Deals Submitted, Funded Deals, Conversion Rate, Total Revenue, Commission Paid, Tier/Status\n    - Search and advanced filters\n    - Export to Excel/CSV\n    - Row actions: View Profile, Message, Adjust Commission\n    \n    PRODUCT PERFORMANCE:\n    - Table or card view showing each funding product\n    - Metrics: Applications, Approvals, Funding Volume, Avg Time to Close, Partner Adoption\n    - Compare products side-by-side\n    - Identify underperforming products\n    \n    OPERATIONAL METRICS:\n    - Grid of operational KPIs:\n      - Avg Time to Approval\n      - Avg Time to Funding\n      - Application Abandonment Rate\n      - Support Tickets Resolved\n      - System Uptime\n    - Real-time updates\n    \n    PARTNER PAYOUTS:\n    - Upcoming payouts (by date)\n    - Filter: Pending, Scheduled, Completed\n    - Bulk approve payouts\n    - Individual payout details\n    - Generate payout reports\n    \n    COMPLIANCE & RISK:\n    - Alerts panel showing:\n      - High-risk applications\n      - Compliance issues\n      - Fraud alerts\n      - Audit requirements\n    - Priority levels: Critical, High, Medium, Low\n    - Acknowledge and resolve workflows\n    \n    ACTIVITY LOG:\n    - Real-time feed of system activity\n    - Filterable by: User, Action Type, Date/Time\n    - Events: New Applications, Funded Deals, Partner Signups, Payout Requests\n    - Audit trail for compliance\n    \n    REPORTS SECTION:\n    - Pre-built report templates:\n      - Monthly Executive Summary\n      - Partner Performance Report\n      - Product Analysis Report\n      - Financial Statements\n    - Custom report builder\n    - Schedule automated reports (email delivery)\n    \n    ADMIN TOOLS:\n    - User management (add/edit partners, staff)\n    - Product catalog management (add/edit funding products)\n    - Commission structure editor\n    - System settings and configurations\n    \n    DESIGN REQUIREMENTS:\n    - Role-based access control (different views for different users)\n    - Real-time data synchronization\n    - Responsive tables (collapsible columns on mobile)\n    - Export functionality throughout\n    - Advanced filtering and search\n    - Bulk actions where applicable\n    - Loading states and error handling\n    - Audit logging on all administrative actions",
      "source_file": "Flash UI Prompts for Moonshine Capital Sites & Tools 🎨.md"
    },
    {
      "id": "funding-marketplace-directory",
      "name": "Funding Marketplace Directory",
      "category": "community_engagement_tools",
      "asset_type": "Directory",
      "audience": "TODO",
      "purpose": "Design a \"Funding Marketplace Directory\" for Moonshine Capital.",
      "visual_style": "Clean, Accessible, Trust-building. White background (#ffffff), light gray (#f5f5f5), brand blue (#2563eb), trust green (#10b981), clear hierarchy. LAYOUT STRUCTURE: HERO SECTION: - Large headline: \"Find Your Funding Match\" - Subheadline: \"80+ funding partners, 1 simple search\" - Prominent search bar",
      "core_sections": [
        "VISUAL STYLE",
        "LAYOUT STRUCTURE",
        "HERO SECTION",
        "CATEGORY GRID",
        "POPULAR PRODUCTS",
        "FILTER & SORT",
        "COMPARISON TOOL",
        "PARTNER SPOTLIGHT",
        "EDUCATIONAL CONTENT",
        "TRUST SIGNALS",
        "FOOTER",
        "DESIGN REQUIREMENTS"
      ],
      "primary_cta": "TODO",
      "prompt": "Design a \"Funding Marketplace Directory\" for Moonshine Capital.\n    \n    VISUAL STYLE: Clean, Accessible, Trust-building. White background (#ffffff), light gray (#f5f5f5), brand blue (#2563eb), trust green (#10b981), clear hierarchy.\n    \n    LAYOUT STRUCTURE:\n    \n    HERO SECTION:\n    - Large headline: \"Find Your Funding Match\"\n    - Subheadline: \"80+ funding partners, 1 simple search\"\n    - Prominent search bar with smart suggestions\n    - Category pills: Business Capital, Revenue-Based, Asset-Backed, Startup, E-commerce, SaaS, Credit Building, View All\n    \n    FEATURED PRODUCTS (Carousel):\n    - Rotating carousel of 5-6 featured funding products\n    - Each slide: Product image, name, key benefits, \"Learn More\" button\n    - Auto-advance with pause on hover\n    - Navigation dots\n    \n    CATEGORY GRID:\n    - 8 category cards in responsive grid\n    - Each card: Icon, category name, number of products, \"Browse\" button\n    - Hover effect: slight elevation, color shift\n    \n    POPULAR PRODUCTS:\n    - Grid of most-viewed or best-converting products\n    - Each product card:\n      - Provider logo\n      - Product name and tagline\n      - Key specs: Amount range, approval time, credit requirement\n      - Star rating and review count\n      - \"View Details\" and \"Apply\" buttons\n    - Load more / pagination\n    \n    FILTER & SORT:\n    - Left sidebar or top bar filters:\n      - Funding type checkboxes\n      - Amount range slider\n      - Time to funding (same day, next day, within week, etc.)\n      - Credit score requirement\n      - Industry specialization\n    - Sort dropdown: Relevance, Speed, Amount, Rating\n    \n    COMPARISON TOOL:\n    - \"Compare Products\" checkbox on each card\n    - Sticky comparison bar at bottom\n    - Side-by-side comparison view (modal or new page)\n    - Feature matrix with checkmarks\n    \n    PARTNER SPOTLIGHT:\n    - Section highlighting 3-4 key funding partners\n    - Partner logo, brief description, specialties, \"View Products\" link\n    \n    EDUCATIONAL CONTENT:\n    - \"Funding Guides\" section\n    - Article cards: thumbnails, titles, excerpts\n    - Topics: \"How to Choose\", \"Credit Requirements\", \"Application Tips\"\n    \n    TRUST SIGNALS:\n    - Trust badge strip: \"80+ Partners | $500M+ Funded | 10K+ Businesses Served\"\n    - Client testimonials carousel\n    - Industry certifications and affiliations\n    \n    FOOTER:\n    - Comprehensive footer navigation\n    - Product categories\n    - Partner programs\n    - Resources\n    - Company info\n    - Contact and support\n    \n    DESIGN REQUIREMENTS:\n    - Instant search results (AJAX)\n    - Responsive grid (4 cols desktop, 2 tablet, 1 mobile)\n    - Lazy loading for images\n    - Accessibility: keyboard navigation, ARIA labels, screen reader support\n    - SEO-optimized (semantic HTML, meta tags, structured data)\n    - Fast page load (under 3 seconds)\n    - Clear CTAs throughout",
      "source_file": "Flash UI Prompts for Moonshine Capital Sites & Tools 🎨.md"
    },
    {
      "id": "community-forum-discussion-board",
      "name": "Community Forum / Discussion Board",
      "category": "community_engagement_tools",
      "asset_type": "Prompt Template",
      "audience": "TODO",
      "purpose": "Design a \"Community Forum / Discussion Board\" for Moonshine Capital network.",
      "visual_style": "Community-focused, Modern, Engaging. Light mode base (#ffffff), accent blue (#3b82f6), secondary purple (#8b5cf6), warm grays, friendly sans-serif. LAYOUT STRUCTURE: HEADER: - Moonshine Capital logo + \"Community Forum\" - Search bar: \"Search discussions...\" - Navigation: Home, Categories, Leaderboard",
      "core_sections": [
        "VISUAL STYLE",
        "LAYOUT STRUCTURE",
        "HEADER",
        "MAIN FEED",
        "DISCUSSION THREAD VIEW",
        "CREATE POST MODAL",
        "USER PROFILE PAGE",
        "LEADERBOARD PAGE",
        "DESIGN REQUIREMENTS"
      ],
      "primary_cta": "TODO",
      "prompt": "Design a \"Community Forum / Discussion Board\" for Moonshine Capital network.\n    \n    VISUAL STYLE: Community-focused, Modern, Engaging. Light mode base (#ffffff), accent blue (#3b82f6), secondary purple (#8b5cf6), warm grays, friendly sans-serif.\n    \n    LAYOUT STRUCTURE:\n    \n    HEADER:\n    - Moonshine Capital logo + \"Community Forum\"\n    - Search bar: \"Search discussions...\"\n    - Navigation: Home, Categories, Leaderboard, Rules, My Posts\n    - User avatar with dropdown: Profile, Settings, Logout\n    - Notification bell (with count)\n    \n    SIDEBAR (Left):\n    - Categories list:\n      - 🚀 Getting Started\n      - 💰 Funding Success Stories\n      - 🤝 Partner Strategies\n      - 📊 Credit Building Tips\n      - 🎯 Lead Generation\n      - 💻 Tech & Tools\n      - 🎓 Training & Resources\n      - ❓ General Discussion\n    - Each category: icon, name, unread post count\n    - \"Create New Post\" prominent button\n    \n    MAIN FEED:\n    - Filter tabs: Hot, New, Top (today/week/month), Unanswered\n    - Discussion list items:\n      - User avatar\n      - Post title (clickable)\n      - Preview of first few lines\n      - Meta info: Category, Author, Time posted, View count, Reply count\n      - Tags if applicable\n      - Upvote/like count\n    - Pagination or infinite scroll\n    \n    DISCUSSION THREAD VIEW:\n    - Original post at top:\n      - User info (avatar, username, join date, post count, reputation)\n      - Full post content (with formatting: bold, italic, lists, images, links)\n      - Timestamp\n      - Actions: Like, Reply, Share, Report, Bookmark\n    - Replies nested below:\n      - Threaded or flat view toggle\n      - Sort: Oldest, Newest, Most Likes\n      - Each reply: same structure as original post\n      - Quote reply option\n    - Rich text editor for new replies (formatting toolbar, emoji picker, file upload)\n    \n    SIDEBAR (Right):\n    - \"Related Discussions\" widget\n    - \"Top Contributors\" this week (avatars, names, post counts)\n    - \"Trending Tags\" cloud\n    - Ad space or promotional banner (Partner Program CTA)\n    \n    CREATE POST MODAL:\n    - Post title input\n    - Category selector\n    - Rich text editor (formatting, media upload)\n    - Tags input (suggestions as you type)\n    - Preview before posting\n    - \"Post\" and \"Save Draft\" buttons\n    \n    USER PROFILE PAGE:\n    - User info: avatar, username, bio, join date, location\n    - Stats: Posts, Replies, Likes Received, Reputation Score\n    - Recent activity feed\n    - Badges/achievements earned\n    - Follow button (if not own profile)\n    \n    LEADERBOARD PAGE:\n    - Top contributors (by posts, replies, likes)\n    - Filter by time period: This week, This month, All time\n    - Gamification: badges, levels, rewards\n    \n    MODERATION TOOLS (for admins/mods):\n    - Flag review queue\n    - Pin/unpin posts\n    - Lock/unlock threads\n    - Edit/delete content\n    - Ban users\n    - Category management\n    \n    DESIGN REQUIREMENTS:\n    - Real-time updates (new posts, replies without refresh)\n    - Markdown or WYSIWYG editor for formatting\n    - Emoji reactions (👍 ❤️ 😂 🎉 🤔)\n    - Mention users with @username autocomplete\n    - File/image upload (with preview)\n    - Mobile-optimized (collapsible sidebar, touch-friendly)\n    - Notifications for replies, mentions, likes\n    - Spam protection and rate limiting\n    - SEO-friendly URLs for discussions",
      "source_file": "Flash UI Prompts for Moonshine Capital Sites & Tools 🎨.md"
    },
    {
      "id": "private-facebook-style-groups-hub",
      "name": "Private Facebook-Style Groups Hub",
      "category": "community_engagement_tools",
      "asset_type": "Directory",
      "audience": "TODO",
      "purpose": "Design a \"Private Groups Hub\" (Facebook-style) for Moonshine Capital community.",
      "visual_style": "Social, Welcoming, Familiar. Light blue background (#e7f3ff), white cards (#ffffff), primary blue (#1877f2), accent green (#42b72a), friendly sans-serif. LAYOUT STRUCTURE: HEADER: - Moonshine Capital logo + \"Community Groups\" - Search: \"Search groups and posts...\" - Navigation: Home, Groups, Events,",
      "core_sections": [
        "VISUAL STYLE",
        "LAYOUT STRUCTURE",
        "HEADER",
        "LEFT SIDEBAR",
        "MAIN FEED",
        "RIGHT SIDEBAR",
        "GROUP PAGE VIEW",
        "POST DETAIL VIEW",
        "CREATE GROUP MODAL",
        "EVENTS FEATURE",
        "NOTIFICATIONS",
        "DESIGN REQUIREMENTS"
      ],
      "primary_cta": "TODO",
      "prompt": "Design a \"Private Groups Hub\" (Facebook-style) for Moonshine Capital community.\n    \n    VISUAL STYLE: Social, Welcoming, Familiar. Light blue background (#e7f3ff), white cards (#ffffff), primary blue (#1877f2), accent green (#42b72a), friendly sans-serif.\n    \n    LAYOUT STRUCTURE:\n    \n    HEADER:\n    - Moonshine Capital logo + \"Community Groups\"\n    - Search: \"Search groups and posts...\"\n    - Navigation: Home, Groups, Events, Notifications, Messages\n    - User profile icon with dropdown\n    \n    LEFT SIDEBAR:\n    - User profile summary (avatar, name, \"View Profile\")\n    - Your Groups section:\n      - List of groups you've joined\n      - Each with: group icon, name, unread count\n      - \"+ Discover New Groups\" link\n    - Quick links:\n      - Events\n      - Saved posts\n      - Members directory\n    \n    MAIN FEED:\n    - Post composer at top:\n      - \"What's on your mind, [Name]?\"\n      - Buttons: Photo/Video, Poll, Event\n      - Privacy selector: Public / Group-specific\n    - Feed of posts from all joined groups:\n      - User avatar and name\n      - Group name (if cross-posting)\n      - Timestamp\n      - Post content (text, images, videos, links, polls)\n      - Engagement buttons: Like, Comment, Share\n      - Comment count and preview of top comment\n    - Infinite scroll\n    \n    RIGHT SIDEBAR:\n    - \"Suggested Groups\" widget\n      - Group cards with: icon, name, member count, \"Join\" button\n    - \"Upcoming Events\" widget\n    - \"Group Announcements\" from admins\n    \n    GROUP PAGE VIEW:\n    - Cover photo and group icon\n    - Group name and description\n    - Member count and privacy status (Private/Public)\n    - Action buttons: Joined (checkmark), Invite, Share, More (dropdown)\n    - Tabs: Discussion, Members, Events, Media, Files\n    - Discussion tab: dedicated feed for this group only\n    - Members tab: searchable member list with ability to message or view profiles\n    - Events tab: calendar view and list of group events\n    - Media tab: grid of photos/videos shared in group\n    - Files tab: shared documents and resources\n    \n    POST DETAIL VIEW:\n    - Full post with all comments expanded\n    - Nested comments (reply to comment)\n    - Comment sorting: Most Relevant, Newest, Oldest\n    - Rich text comment editor\n    - Reactions (beyond Like: Love, Haha, Wow, Sad, Angry)\n    \n    CREATE GROUP MODAL:\n    - Group name input\n    - Group description (rich text)\n    - Privacy setting: Public / Private / Secret\n    - Cover photo upload\n    - Category selection\n    - Invite initial members (search directory)\n    \n    GROUP SETTINGS (for admins):\n    - Member approval queue (for private groups)\n    - Moderator management (add/remove)\n    - Post approval settings\n    - Group rules editor\n    - Scheduled posts\n    - Insights/analytics (post reach, engagement, member growth)\n    \n    EVENTS FEATURE:\n    - Create event within group\n    - Event details: Title, Date/Time, Location (virtual or physical), Description\n    - RSVP options: Going, Maybe, Can't Go\n    - Event discussion thread\n    - Reminders before event\n    \n    NOTIFICATIONS:\n    - Real-time notifications for:\n      - New posts in your groups\n      - Comments on your posts\n      - Mentions (@your name)\n      - Group invitations\n      - Event reminders\n    - Notification settings per group (All posts, Highlights, Off)\n    \n    DESIGN REQUIREMENTS:\n    - Familiar Facebook-like UX (minimal learning curve)\n    - Real-time updates (new posts, comments, likes)\n    - Rich media support (images, videos, GIFs, documents)\n    - Responsive design (mobile app feel)\n    - Privacy controls (who can see posts, who can join)\n    - Content moderation tools\n    - Accessibility features\n    - Push notifications (if web app or PWA)",
      "source_file": "Flash UI Prompts for Moonshine Capital Sites & Tools 🎨.md"
    },
    {
      "id": "user-account-portal",
      "name": "User Account Portal",
      "category": "account_onboarding",
      "asset_type": "Dashboard",
      "audience": "TODO",
      "purpose": "Design a \"User Account Portal\" for Moonshine Capital clients and partners.",
      "visual_style": "Clean, Professional, Trustworthy. White base (#ffffff), light gray (#f7f7f7), brand navy (#1e40af), success green (#10b981), clear hierarchy. LAYOUT STRUCTURE: SIDEBAR NAVIGATION: - User profile section: - Avatar (clickable to change) - Name and account type (Client / Partner / Admin) - Account stat",
      "core_sections": [
        "VISUAL STYLE",
        "LAYOUT STRUCTURE",
        "SIDEBAR NAVIGATION",
        "DASHBOARD (HOME)",
        "PROFILE PAGE",
        "APPLICATIONS / LEADS PAGE",
        "FUNDING HISTORY / COMMISSIONS",
        "DOCUMENTS PAGE",
        "SETTINGS PAGE",
        "SECURITY PAGE",
        "MESSAGES",
        "RESOURCES"
      ],
      "primary_cta": "TODO",
      "prompt": "Design a \"User Account Portal\" for Moonshine Capital clients and partners.\n    \n    VISUAL STYLE: Clean, Professional, Trustworthy. White base (#ffffff), light gray (#f7f7f7), brand navy (#1e40af), success green (#10b981), clear hierarchy.\n    \n    LAYOUT STRUCTURE:\n    \n    SIDEBAR NAVIGATION:\n    - User profile section:\n      - Avatar (clickable to change)\n      - Name and account type (Client / Partner / Admin)\n      - Account status badge (Active, Pending, etc.)\n    - Navigation menu:\n      - 🏠 Dashboard\n      - 👤 Profile\n      - 💳 Applications (for clients) / Leads (for partners)\n      - 💰 Funding History / Commissions\n      - 📄 Documents\n      - ⚙️ Settings\n      - 🔐 Security\n      - 💬 Messages\n      - 🎓 Resources\n      - ❓ Help & Support\n    \n    DASHBOARD (HOME):\n    - Welcome message: \"Welcome back, [Name]\"\n    - Quick action cards:\n      - \"Apply for Funding\" / \"Submit New Lead\"\n      - \"View Documents\"\n      - \"Contact Support\"\n    - Status overview:\n      - For Clients: Active applications, funding status, next steps\n      - For Partners: Active leads, pending commissions, recent activity\n    - Recent activity timeline\n    - Notifications panel\n    \n    PROFILE PAGE:\n    - Profile information form:\n      - Personal: Name, Email, Phone, Date of Birth\n      - Business: Company Name, EIN, Industry, Business Address\n      - Banking: Account details for payouts (partners)\n    - Avatar upload\n    - \"Save Changes\" button\n    - Account verification status (if applicable)\n    \n    APPLICATIONS / LEADS PAGE:\n    - For Clients:\n      - List of all funding applications\n      - Status: Draft, Submitted, Under Review, Approved, Funded, Declined\n      - Each item: Product name, amount, date submitted, status badge, \"View Details\"\n      - Filter by status, date\n      - \"Start New Application\" button\n    - For Partners:\n      - List of all submitted leads\n      - Status: New, Contacted, Submitted, Funded\n      - Each item: Client name, product, amount, date, status, actions\n      - Filter and search\n      - \"Submit New Lead\" button\n    \n    APPLICATION DETAIL VIEW (Clients):\n    - Application summary card\n    - Required documents checklist (with upload buttons)\n    - Communication log (messages with underwriter/support)\n    - Status updates timeline\n    - Next steps / action items\n    \n    FUNDING HISTORY / COMMISSIONS:\n    - For Clients:\n      - Table of funded deals: date, product, amount, term, status (active/paid off)\n      - Payment schedule\n      - Statements and invoices (downloadable)\n    - For Partners:\n      - Commission history: date, client, deal size, commission amount, status (pending/paid)\n      - Total earnings: This month, This year, Lifetime\n      - Payout schedule\n      - Request payout button (if balance exceeds threshold)\n    \n    DOCUMENTS PAGE:\n    - Organized folder structure\n    - Upload area (drag-and-drop or browse)\n    - Document list: name, type, size, upload date, actions (view, download, delete)\n    - Filter by document type (Tax docs, Financial statements, Contracts, etc.)\n    - Secure document storage notice\n    \n    SETTINGS PAGE:\n    - Account settings:\n      - Email preferences (notifications, newsletters)\n      - Communication preferences (email, SMS, phone)\n      - Timezone and language\n    - Notification settings:\n      - Toggle notifications by type (application updates, commission payments, messages, etc.)\n    - Privacy settings\n    \n    SECURITY PAGE:\n    - Change password form\n    - Two-factor authentication (enable/disable)\n    - Active sessions list (with \"Sign out other devices\" option)\n    - Login history / audit log\n    - Security questions setup\n    \n    MESSAGES:\n    - Inbox / Sent / Archived tabs\n    - Message list: sender, subject, date, read/unread status\n    - Message thread view (conversation style)\n    - Compose new message (to support or assigned rep)\n    - Attachments support\n    \n    RESOURCES:\n    - Knowledge base articles\n    - Video tutorials\n    - FAQs\n    - Download marketing materials (partners)\n    - Downloadable guides and templates\n    \n    HELP & SUPPORT:\n    - FAQs accordion\n    - Submit support ticket form (with priority selection)\n    - Live chat widget (if available)\n    - Contact information (phone, email)\n    - Schedule consultation button\n    \n    DESIGN REQUIREMENTS:\n    - Fully responsive (mobile-friendly sidebar collapses to hamburger)\n    - Secure authentication (OAuth or similar)\n    - Session timeout warnings\n    - Data encryption for sensitive information\n    - Accessibility compliant (WCAG 2.1 AA)\n    - Loading states and progress indicators\n    - Clear error messages and validation\n    - Confirmation dialogs for important actions\n    - Auto-save on forms (prevent data loss)",
      "source_file": "Flash UI Prompts for Moonshine Capital Sites & Tools 🎨.md"
    },
    {
      "id": "partner-onboarding-wizard",
      "name": "Partner Onboarding Wizard",
      "category": "account_onboarding",
      "asset_type": "Dashboard",
      "audience": "TODO",
      "purpose": "Design a \"Partner Onboarding Wizard\" for new Moonshine Capital affiliates.",
      "visual_style": "Welcoming, Progressive, Clean. White background (#ffffff), accent purple (#8b5cf6), progress indicators, friendly illustrations, clear CTAs. LAYOUT STRUCTURE: WELCOME SCREEN: - Hero section: - Large welcome headline: \"Welcome to Moonshine Capital Partners!\" - Subheadline: \"Let's get you set up in ju",
      "core_sections": [
        "VISUAL STYLE",
        "LAYOUT STRUCTURE",
        "WELCOME SCREEN",
        "STEP 1",
        "STEP 2",
        "STEP 3",
        "STEP 4",
        "STEP 5",
        "COMPLETION SCREEN",
        "DESIGN REQUIREMENTS"
      ],
      "primary_cta": "TODO",
      "prompt": "Design a \"Partner Onboarding Wizard\" for new Moonshine Capital affiliates.\n    \n    VISUAL STYLE: Welcoming, Progressive, Clean. White background (#ffffff), accent purple (#8b5cf6), progress indicators, friendly illustrations, clear CTAs.\n    \n    LAYOUT STRUCTURE:\n    \n    WELCOME SCREEN:\n    - Hero section:\n      - Large welcome headline: \"Welcome to Moonshine Capital Partners!\"\n      - Subheadline: \"Let's get you set up in just a few minutes\"\n      - Illustration or video (onboarding overview)\n    - What to expect:\n      - Icons showing steps: Account Setup → Profile Creation → Training → Go Live\n      - Estimated time: \"5-10 minutes\"\n    - \"Let's Get Started\" large button\n    \n    PROGRESS INDICATOR (Top):\n    - Visual progress bar showing current step\n    - Step numbers and labels:\n      - 1. Account Info\n      - 2. Business Details\n      - 3. Banking Info\n      - 4. Agreement\n      - 5. Training\n    - Completed steps show checkmarks\n    \n    STEP 1: ACCOUNT INFORMATION:\n    - Form fields:\n      - Full Name\n      - Email Address (pre-filled if signed up)\n      - Phone Number\n      - Password (with strength indicator)\n      - Confirm Password\n    - \"Continue\" button\n    - \"Save and finish later\" link\n    \n    STEP 2: BUSINESS DETAILS:\n    - Form fields:\n      - Business Name (or \"Operating as Individual\")\n      - Business Structure (sole proprietor, LLC, corporation, etc.)\n      - EIN / Tax ID (optional at this stage)\n      - Business Website (optional)\n      - Social Media Profiles (optional: LinkedIn, Facebook, Instagram)\n      - How did you hear about us? (dropdown)\n    - Previous / Continue buttons\n    \n    STEP 3: BANKING INFORMATION:\n    - Explanation: \"Where should we send your commissions?\"\n    - Form fields:\n      - Bank Name\n      - Account Holder Name\n      - Account Number\n      - Routing Number\n      - Account Type (Checking / Savings)\n    - Security notice: \"Your information is encrypted and secure\"\n    - Option: \"I'll add this later\" (skip for now)\n    - Previous / Continue buttons\n    \n    STEP 4: PARTNER AGREEMENT:\n    - Agreement document (scrollable):\n      - Terms and Conditions\n      - Commission structure\n      - Partner responsibilities\n    - Checkboxes:\n      - \"I have read and agree to the Partner Agreement\"\n      - \"I agree to the Privacy Policy\"\n    - E-signature capture\n    - Previous / Accept & Continue buttons\n    \n    STEP 5: INITIAL TRAINING:\n    - Welcome video from founder or team (3-5 minutes)\n    - Quick training modules (accordion or tabs):\n      - How the platform works\n      - Submitting your first lead\n      - Commission structure explained\n      - Best practices\n    - Downloadable resources:\n      - Partner Handbook (PDF)\n      - Quick Start Guide\n      - Marketing Materials\n    - \"Mark as Complete and Continue\" button\n    \n    COMPLETION SCREEN:\n    - Celebration illustration or confetti animation\n    - \"You're All Set!\" headline\n    - Summary of what's next:\n      - \"Your account is under review (up to 24 hours)\"\n      - \"Check your email for login credentials\"\n      - \"Access your dashboard and start submitting leads\"\n    - CTA buttons:\n      - \"Go to Dashboard\"\n      - \"Submit Your First Lead\"\n      - \"Explore Resources\"\n    \n    SIDEBAR (Persistent Throughout):\n    - Customer support contact info\n    - \"Need help?\" chat bubble\n    - Progress checklist (mini version)\n    - \"Save and exit\" option\n    \n    DESIGN REQUIREMENTS:\n    - Auto-save on every step (no data loss if they leave)\n    - Field validation (real-time and on submit)\n    - Clear error messages\n    - Back button always available\n    - Skip optional steps\n    - Mobile-responsive (multi-step forms work well on mobile)\n    - Accessibility (keyboard navigation, screen reader support)\n    - Option to upload documents (ID, business license) later\n    - Email confirmation sent after completion\n    - Confirmation emails at each major step",
      "source_file": "Flash UI Prompts for Moonshine Capital Sites & Tools 🎨.md"
    },
    {
      "id": "funding-calculator-and-pre-qualification-tool",
      "name": "Funding Calculator & Pre-Qualification Tool",
      "category": "specialized_tools",
      "asset_type": "Calculator",
      "audience": "TODO",
      "purpose": "Design a \"Funding Calculator & Pre-Qualification Tool\" for Moonshine Capital.",
      "visual_style": "Interactive, Calculator-focused, Results-driven. Clean white (#ffffff), brand blue (#2563eb), success green (#10b981), clear number displays, slider interactions. LAYOUT STRUCTURE: HERO SECTION: - Headline: \"See What You Qualify For in 60 Seconds\" - Subheadline: \"No impact on your credit score\" - Tr",
      "core_sections": [
        "VISUAL STYLE",
        "LAYOUT STRUCTURE",
        "HERO SECTION",
        "CALCULATOR INTERFACE",
        "STEP 1 - FUNDING NEEDS",
        "STEP 2 - BUSINESS INFO",
        "STEP 3 - CONTACT INFO",
        "RESULTS PAGE",
        "QUALIFICATION SUMMARY",
        "RECOMMENDED PRODUCTS",
        "COMPARISON TABLE",
        "NEXT STEPS SECTION"
      ],
      "primary_cta": "Complete Full Application",
      "prompt": "Design a \"Funding Calculator & Pre-Qualification Tool\" for Moonshine Capital.\n    \n    VISUAL STYLE: Interactive, Calculator-focused, Results-driven. Clean white (#ffffff), brand blue (#2563eb), success green (#10b981), clear number displays, slider interactions.\n    \n    LAYOUT STRUCTURE:\n    \n    HERO SECTION:\n    - Headline: \"See What You Qualify For in 60 Seconds\"\n    - Subheadline: \"No impact on your credit score\"\n    - Trust badges: \"Secure\" | \"Confidential\" | \"Free\"\n    \n    CALCULATOR INTERFACE:\n    \n    STEP 1 - FUNDING NEEDS:\n    - Large headline: \"How much funding do you need?\"\n    - Amount slider (or input):\n      - Range: $5,000 - $500,000+\n      - Large display of selected amount\n      - Drag slider or type amount\n    - Radio buttons: \"Purpose of funding\"\n      - Working Capital\n      - Equipment Purchase\n      - Expansion\n      - Inventory\n      - Marketing\n      - Debt Consolidation\n      - Other\n    - \"Next Step\" button\n    \n    STEP 2 - BUSINESS INFO:\n    - Questions (progressive disclosure):\n      - \"How long have you been in business?\"\n        - Dropdown: < 6 months, 6-12 months, 1-2 years, 2-5 years, 5+ years\n      - \"What is your average monthly revenue?\"\n        - Slider: $0 - $500,000+\n      - \"What is your credit score range?\"\n        - Buttons: Excellent (750+), Good (650-749), Fair (550-649), Poor (<550), Not Sure\n      - \"What industry are you in?\"\n        - Searchable dropdown with common industries\n    - Previous / Next buttons\n    \n    STEP 3 - CONTACT INFO:\n    - \"Get Your Custom Funding Options\"\n    - Form fields:\n      - First Name\n      - Last Name\n      - Email\n      - Phone Number\n      - Business Name (optional)\n    - Checkbox: \"I agree to receive funding options via email and phone\"\n    - \"See My Options\" button (prominent)\n    \n    RESULTS PAGE:\n    \n    QUALIFICATION SUMMARY:\n    - Large headline: \"Great News! You Pre-Qualify for Up to [Amount]\"\n    - Or: \"Here are your best funding options\"\n    - Summary card:\n      - Estimated funding amount\n      - Estimated approval time\n      - Credit score required\n      - Best product match\n    \n    RECOMMENDED PRODUCTS:\n    - 3-5 product cards matching their profile\n    - Each card:\n      - Product name and provider logo\n      - Amount range (with their qualified amount highlighted)\n      - Time to funding\n      - Key features (bullet points)\n      - APR or rate info\n      - \"Apply Now\" button\n      - \"Learn More\" link\n    - Sorting: Best Match, Fastest Funding, Highest Amount\n    \n    COMPARISON TABLE:\n    - Side-by-side comparison of top 3 products\n    - Rows: Amount, Speed, Credit Req, Fees, Term, Collateral\n    - Checkmarks and X marks for quick comparison\n    \n    NEXT STEPS SECTION:\n    - \"What happens next?\"\n    - Timeline visualization:\n      - Apply Now → Instant Decision → Receive Funds\n      - Time estimates for each step\n    - CTA: \"Complete Full Application\"\n    \n    EDUCATIONAL SIDEBAR:\n    - \"Understanding Your Options\" widget\n    - Links to articles:\n      - \"Revenue-Based Funding Explained\"\n      - \"How to Improve Your Approval Odds\"\n      - \"Comparing Funding Products\"\n    - Glossary of terms\n    \n    ALTERNATIVE OPTIONS:\n    - \"Didn't see what you need?\"\n    - Links to:\n      - Explore All Products\n      - Speak with a Funding Advisor (book consultation)\n      - Credit Building Resources (if score is limiting factor)\n    \n    SAVE/SHARE RESULTS:\n    - \"Email My Results\" button\n    - PDF download option\n    - Share link (if they want to discuss with partner)\n    \n    DESIGN REQUIREMENTS:\n    - Real-time calculations (instant results)\n    - Progress saving (if they leave and come back)\n    - No hard credit pull (soft inquiry only, or just pre-qualification logic)\n    - Mobile-optimized slider interactions\n    - Accessibility (keyboard controls for sliders)\n    - Clear disclaimers about pre-qualification vs. approval\n    - TCPA compliance for phone number collection\n    - Secure data transmission (SSL)\n    - Lead captured and routed to appropriate partner/product\n    - Follow-up email automation triggered",
      "source_file": "Flash UI Prompts for Moonshine Capital Sites & Tools 🎨.md"
    },
    {
      "id": "broker-commission-calculator",
      "name": "Broker Commission Calculator",
      "category": "specialized_tools",
      "asset_type": "Calculator",
      "audience": "TODO",
      "purpose": "Design a \"Broker Commission Calculator\" for Moonshine Capital partners.",
      "visual_style": "Financial, Motivational, Clear. White background (#ffffff), money green (#10b981), gold accent (#f59e0b), clean number displays, motivational messaging. LAYOUT STRUCTURE: HERO SECTION: - Headline: \"Calculate Your Earning Potential\" - Subheadline: \"See exactly how much you can earn as a Moonshine Cap",
      "core_sections": [
        "VISUAL STYLE",
        "LAYOUT STRUCTURE",
        "HERO SECTION",
        "CALCULATOR INTERFACE",
        "INPUT SECTION",
        "RESULTS DISPLAY",
        "EARNINGS BREAKDOWN",
        "INCOME SCENARIOS",
        "COMPARISON SECTION",
        "GROWTH PROJECTION",
        "BONUS EARNINGS",
        "PARTNER TIER SIMULATION"
      ],
      "primary_cta": "TODO",
      "prompt": "Design a \"Broker Commission Calculator\" for Moonshine Capital partners.\n    \n    VISUAL STYLE: Financial, Motivational, Clear. White background (#ffffff), money green (#10b981), gold accent (#f59e0b), clean number displays, motivational messaging.\n    \n    LAYOUT STRUCTURE:\n    \n    HERO SECTION:\n    - Headline: \"Calculate Your Earning Potential\"\n    - Subheadline: \"See exactly how much you can earn as a Moonshine Capital partner\"\n    - Illustration of money/growth\n    \n    CALCULATOR INTERFACE:\n    \n    INPUT SECTION:\n    - Card with form inputs:\n      \n      \"How many deals do you plan to close per month?\"\n      - Number input or slider (1-50+)\n      - Visual indicator: \"Conservative\" (1-5), \"Moderate\" (6-15), \"Aggressive\" (16+)\n      \n      \"What's your average deal size?\"\n      - Dropdown or slider: $10K, $25K, $50K, $100K, $250K, $500K+\n      \n      \"Which products do you focus on?\" (affects commission rate)\n      - Checkboxes:\n        - Business Capital (base rate)\n        - Revenue-Based Funding (higher rate)\n        - Asset-Backed (medium rate)\n        - SaaS/E-commerce (higher rate)\n        - Business Credit (recurring income potential)\n      - Default: \"All Products\" for average calculation\n    \n    RESULTS DISPLAY:\n    \n    EARNINGS SUMMARY (Large, Prominent):\n    - Monthly Commission: $X,XXX\n    - Annual Commission: $XX,XXX\n    - Lifetime Earnings (3 years): $XXX,XXX\n    - Animated counter that updates as inputs change\n    \n    EARNINGS BREAKDOWN:\n    - Pie chart showing commission by product type\n    - Table below:\n      - Product Type | Deals/Month | Avg Deal Size | Commission Rate | Monthly Earnings\n    \n    INCOME SCENARIOS:\n    - Toggle between: Conservative, Realistic, Optimistic\n    - Adjusts calculations automatically\n    - Shows range: \"You could earn between $X,XXX and $XX,XXX per month\"\n    \n    COMPARISON SECTION:\n    - \"How does this compare?\"\n    - Visual comparison:\n      - Average part-time income: $X,XXX\n      - Average full-time income: $XX,XXX\n      - Top 10% earners: $XXX,XXX\n      - YOUR potential: highlighted\n    \n    GROWTH PROJECTION:\n    - Line chart showing income growth over 12-36 months\n    - Assumes increasing deal volume and repeat clients\n    - Toggle: Monthly / Annually / 3-Year Projection\n    \n    BONUS EARNINGS:\n    - \"Don't forget about bonuses!\"\n    - Additional income opportunities:\n      - Recurring commissions (business credit products)\n      - Tiered bonuses (volume milestones)\n      - Team overrides (if applicable to partner program)\n    - Add bonus toggle to calculator\n    \n    PARTNER TIER SIMULATION:\n    - \"What tier could you reach?\"\n    - Show tier structure:\n      - Bronze: 1-10 deals/month → X% commission\n      - Silver: 11-25 deals/month → X+1% commission\n      - Gold: 26-50 deals/month → X+2% commission\n      - Platinum: 50+ deals/month → X+3% commission + bonuses\n    - Highlight tier they'd reach with current inputs\n    \n    CALL-TO-ACTION SECTION:\n    - \"Ready to start earning?\"\n    - Buttons:\n      - \"Become a Partner\" (primary CTA)\n      - \"Speak with Recruiter\"\n      - \"Download Partner Brochure\"\n    \n    REALISTIC EXPECTATIONS DISCLAIMER:\n    - \"Your results may vary\"\n    - Transparent messaging about typical ramp-up time\n    - Link to \"Partner Success Stories\" for real examples\n    \n    SHARE RESULTS:\n    - \"Share your potential earnings\"\n    - Social sharing (pre-populated with results)\n    - Email results to yourself\n    \n    DESIGN REQUIREMENTS:\n    - Real-time calculation updates (instant feedback)\n    - Smooth animations on number changes\n    - Mobile-responsive (sliders work well on touch)\n    - No login required (public tool)\n    - Accurate commission rate data (pulled from actual program)\n    - Optional: capture email to send full report and follow up with recruitment\n    - Motivational copy throughout (aspirational but realistic)\n    - Clear disclaimers about earnings not guaranteed",
      "source_file": "Flash UI Prompts for Moonshine Capital Sites & Tools 🎨.md"
    },
    {
      "id": "credit-score-simulator-and-builder-roadmap",
      "name": "Credit Score Simulator & Builder Roadmap",
      "category": "specialized_tools",
      "asset_type": "Dashboard",
      "audience": "TODO",
      "purpose": "Design a \"Credit Score Simulator & Builder Roadmap\" tool for Moonshine Capital.",
      "visual_style": "Educational, Progress-focused, Empowering. Clean white (#ffffff), score colors (red/orange/yellow/green gradient), progress bars, milestone visuals. LAYOUT STRUCTURE: HERO SECTION: - Headline: \"Build Business Credit Without Touching Personal Credit\" - Subheadline: \"See your path to $50K+ in credit i",
      "core_sections": [
        "VISUAL STYLE",
        "LAYOUT STRUCTURE",
        "HERO SECTION",
        "CURRENT STATUS INPUT",
        "STARTING POINT QUESTIONS",
        "CREDIT BUILDER ROADMAP",
        "PHASE 1",
        "PHASE 2",
        "PHASE 3",
        "PHASE 4",
        "CREDIT SCORE SIMULATOR",
        "SCORE PROJECTIONS"
      ],
      "primary_cta": "TODO",
      "prompt": "Design a \"Credit Score Simulator & Builder Roadmap\" tool for Moonshine Capital.\n    \n    VISUAL STYLE: Educational, Progress-focused, Empowering. Clean white (#ffffff), score colors (red/orange/yellow/green gradient), progress bars, milestone visuals.\n    \n    LAYOUT STRUCTURE:\n    \n    HERO SECTION:\n    - Headline: \"Build Business Credit Without Touching Personal Credit\"\n    - Subheadline: \"See your path to $50K+ in credit in 90 days\"\n    - Trust message: \"No personal credit checks or guarantees\"\n    \n    CURRENT STATUS INPUT:\n    \n    STARTING POINT QUESTIONS:\n    - \"Do you have a business entity?\"\n      - Yes (EIN established) / No (guidance to start)\n    - \"How old is your business?\"\n      - Dropdown: Just starting, < 6 months, 6-12 months, 1-2 years, 2+ years\n    - \"Do you have a business bank account?\"\n      - Yes / No\n    - \"Do you have a business phone and address?\"\n      - Yes / No\n    - \"Current business credit score (if known)\"\n      - Input or \"I don't know\"\n    \n    CREDIT BUILDER ROADMAP:\n    \n    VISUAL TIMELINE (Progressive):\n    - Horizontal or vertical timeline with milestones\n    - Each milestone: checkmark or locked icon\n    \n    PHASE 1: FOUNDATION (Days 1-30):\n    - Tasks:\n      - ☐ Establish EIN (if not done)\n      - ☐ Open business bank account\n      - ☐ Get business phone number (dedicated line)\n      - ☐ Register D-U-N-S number\n      - ☐ Set up business address (physical or virtual)\n      - ☐ Build simple business website\n    - Credit Impact: Foundation established\n    - Estimated Timeline: 1-2 weeks\n    - \"Start Phase 1\" button\n    \n    PHASE 2: VENDOR CREDIT (Days 30-60):\n    - Tasks:\n      - ☐ Apply for 5 Tier 1 vendor accounts (no PG required)\n      - ☐ Make purchases and pay on time\n      - ☐ Get vendor credit lines (Uline, Quill, Grainger examples)\n      - ☐ Ensure vendors report to credit bureaus\n    - Credit Impact: Initial credit history established\n    - Estimated Credit Available: $5,000 - $15,000\n    - Estimated Timeline: 30-45 days\n    - \"View Recommended Vendors\" link\n    \n    PHASE 3: RETAIL CREDIT (Days 60-90):\n    - Tasks:\n      - ☐ Apply for retail business credit cards (Staples, Home Depot, etc.)\n      - ☐ Use cards and maintain low utilization (<30%)\n      - ☐ Pay off balances monthly\n    - Credit Impact: Diversified credit mix\n    - Estimated Credit Available: $15,000 - $35,000\n    - Estimated Timeline: 15-30 days\n    \n    PHASE 4: REVOLVING CREDIT (Days 90+):\n    - Tasks:\n      - ☐ Apply for business credit cards (Amex, Chase, etc.)\n      - ☐ Apply for small business lines of credit\n      - ☐ Continue perfect payment history\n    - Credit Impact: Major credit lines without PG\n    - Estimated Credit Available: $50,000 - $150,000+\n    - Estimated Timeline: Ongoing\n    \n    CREDIT SCORE SIMULATOR:\n    \n    SCORE PROJECTIONS:\n    - Visual gauge showing:\n      - Starting Score: [Your current score or \"Not Established\"]\n      - 30-Day Projected Score\n      - 60-Day Projected Score\n      - 90-Day Projected Score\n    - Color-coded: Red (Poor) → Orange (Fair) → Yellow (Good) → Green (Excellent)\n    \n    SCENARIO MODELING:\n    - Toggles: \"What if I...\"\n      - Pay everything on time vs. miss a payment (impact visualization)\n      - Keep utilization below 30% vs. max out cards\n      - Add more accounts vs. fewer accounts\n    - Real-time score adjustment based on scenarios\n    \n    CREDIT LIMIT PROJECTION:\n    - Bar chart or progress bar\n    - \"Total Available Business Credit\"\n    - Starting: $0\n    - After 30 days: $5K - $15K\n    - After 60 days: $15K - $35K\n    - After 90 days: $50K - $150K+\n    - Factors affecting: business age, payment history, account mix\n    \n    ACTION PLAN DASHBOARD:\n    \n    PERSONALIZED TASK LIST:\n    - Based on their starting point\n    - Prioritized tasks with:\n      - Task name\n      - Why it matters\n      - Estimated time to complete\n      - Impact on credit score/limit\n      - \"Mark Complete\" checkbox\n    - Progress bar showing overall completion\n    \n    RESOURCES SECTION:\n    - Downloadable guides:\n      - \"Business Credit Building Blueprint\" (PDF)\n      - \"Vendor Account Application Checklist\"\n      - \"Credit Monitoring Best Practices\"\n    - Video tutorials for each phase\n    - Links to recommended services (business formation, virtual office, etc.)\n    \n    RECOMMENDED PRODUCTS:\n    - \"Accelerate Your Credit Building\"\n    - Moonshine Capital products that help:\n      - Business credit lines (for purchasing from vendors)\n      - Credit monitoring services (affiliate)\n      - Business formation services (affiliate)\n    - Each with: description, benefit, \"Learn More\" button\n    \n    PROGRESS TRACKING:\n    - User can create account to save progress\n    - Dashboard showing:\n      - Current phase\n      - Tasks completed\n      - Next milestones\n      - Estimated credit score\n    - Email reminders for next steps\n    \n    SUCCESS METRICS:\n    - \"Based on your progress, you're on track to reach:\"\n    - $XX,XXX in available credit by [date]\n    - Credit score of XXX by [date]\n    - Motivational messaging\n    \n    DESIGN REQUIREMENTS:\n    - Interactive and engaging (gamified feel)\n    - Clear visual hierarchy (timeline easy to follow)\n    - Mobile-responsive (touch-friendly checkboxes)\n    - Save progress (account creation optional but encouraged)\n    - Educational tooltips explaining terms (D-U-N-S, PG, utilization, etc.)\n    - Realistic projections based on actual data\n    - Compliance disclaimers (results may vary)\n    - CTA to Moonshine Capital products strategically placed\n    - Email automation: send reminders and next steps",
      "source_file": "Flash UI Prompts for Moonshine Capital Sites & Tools 🎨.md"
    }
  ]
}
```
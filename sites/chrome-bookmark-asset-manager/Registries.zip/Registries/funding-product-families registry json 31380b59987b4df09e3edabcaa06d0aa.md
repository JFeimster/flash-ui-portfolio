# funding-product-families.registry.json

Description: The 6 active funding lanes the /funding pages render. working-capital is fully specified; the others carry real qualification guides (min FICO / revenue / time-in-business) and relatedProviderIds derived from the Funding Partners Database. structured-growth-loans was merged into Working Capital + Startup Credit Leverage and kept as deprecated. Qualitative fields are flagged in needsReview rather than invented.
Suggested Fields: id, slug, route, name, publicName, category, summary, bestFitBorrower, avoidWhen, commonUseCases, qualificationSignals, speedProfile, requiredDocuments, fastDisqualifiers, relatedProductIds, relatedProviderIds, relatedToolIds, primaryCta, status, visibility
Last Updated: June 26, 2026 9:04 AM

<aside>
🗂️

The 7 funding lanes referenced by `funding-pages.registry.json`. This is the file that powers each lane page's qualification bands and lane grid.

</aside>

## Entries (6 active)

`*structured-growth-loans` was merged into Working Capital (term/SBA/expansion) + Startup Credit Leverage (franchise) and is retained as deprecated with no lane page.*

| Family id | Route | State |
| --- | --- | --- |
| `working-capital` | /funding/working-capital | 500+ FICO · $10k/mo · 6 mo TIB · 16 providers · now includes term/SBA loans (22 products) |
| `startup-credit-leverage` | /funding/startup-funding | 600+ FICO · $3k/mo · 6 mo TIB · 5 providers · now includes franchise financing (13 products) |
| `business-line-access` | /funding/business-line-of-credit | 500+ FICO · $3k/mo · 3 mo TIB · 7 providers |
| `equipment-finance` | /funding/equipment-financing | 600+ FICO · $3k/mo · 3 mo TIB · 4 providers |
| `real-estate-capital` | /funding/real-estate-capital | 600+ FICO · $3k/mo · 6 mo TIB · 8 providers |
| `marketplace-capital` | /funding/ecommerce-seller-funding | $3k/mo · FICO flexible · 4 providers |

<aside>
✅

All 6 lanes are now populated with **real qualification guides** (min credit score, monthly revenue, time-in-business) aggregated from matched partners in the Funding Partners Database, plus their `relatedProviderIds`. `needsData` is now `false`. The qualitative fields (`bestFitBorrower`, `commonUseCases`, `requiredDocuments`, `fastDisqualifiers`, `speedProfile`) are listed in each entry's `needsReview` — left empty rather than invented. **Update:** `structured-growth-loans` was folded into Working Capital (term/SBA/expansion) and Startup Credit Leverage (franchise), leaving 6 active lanes that each have a `/funding/[slug]` page.

</aside>

## Registry file

[funding-product-families.registry.json](funding-product-families%20registry%20json/funding-product-families.registry.json)

funding-product-families.registry.json
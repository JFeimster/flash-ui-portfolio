# affiliate-funding-agency-gpts.registry.json

Description: Catalog of custom GPTs that help affiliate partners launch, grow, and scale their own funding agency.
Suggested Fields: id, name, stage, access_url, description, core_pain_point, cta, use_case_vertical, funnel_stage, tier, suite_tag, privacy, related_brand, status
File: affiliate-funding-agency-gpts.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
🎯

**Purpose:** A single-responsibility registry of custom GPTs that help affiliate partners (loan brokers, referral agents, funding-agency owners) **launch**, **grow**, and **scale** their own funding agency. Sourced from the My Custom GPTs database; values are real where available and marked `TODO` where the source is blank.

</aside>

## 🚀 Launch

- [Start Your Own Funding Agency](https://chatgpt.com/g/g-1u8W1T1bM-start-your-own-funding-agency) — Recruit into the opportunity; start a funding business with zero experience.
- [Affiliate Agency GPT](https://chatgpt.com/g/g-sAsXvLr6H-affiliate-agency-gpt) — Attract and structure new affiliate partners around helping small businesses.
- [7-Day Broker Blitz](https://chatgpt.com/g/g-681c0b3d4ec88191bc169f0747fe7710-7-day-broker-blitz) — Onboarding sprint to close a new broker's first deal fast.
- [Beck — Broker Onboarding Coach](https://chatgpt.com/g/g-680ba7aacd288191800f5602b02a11cd-7-day-broker-blitz) — 7-day action plans, scripts, and success tracking for new brokers.
- [Getting Started Right](https://chatgpt.com/g/g-680ba7aacd288191800f5602b02a11cd-getting-started-right) — Foundational agency growth & sales orientation.
- [Funding Pathfinder GPT](https://chatgpt.com/g/g-6876b717ca808191aea5343f89c670e3-funding-pathfinder-gpt) — Client-facing funding strategist that maps a step-by-step funding plan.

## 📈 Grow

- [Affiliate Commission Estimator (F.A.R.E.)](https://chatgpt.com/g/g-FUKQjm8Yw-funding-agency-revenue-estimator) — Calculates commissions and rev-share for agents and brokers.
- [Affiliate Marketing Strategist](https://chatgpt.com/g/g-dRZknamEd-affiliate-marketing-strategist) — Growth strategies to dominate affiliate marketing and agency building.
- [Affiliate Ad Wizard](https://chatgpt.com/g/g-w0ehowMV9-deal-maker-ads) — High-voltage ad copy that recruits affiliates.
- [Deal Maker Ads](https://chatgpt.com/g/g-67bcaa62b38c81918d1d82a7a6ddf53e-deal-maker-ads) — Ad copy that recruits affiliates, partners, and dealmakers.
- [Affiliate Sizzle: Captions & Threads that Sell](https://chatgpt.com/g/g-680ed727dcfc8191a2d65bf89a7315fb-affiliate-sizzle-captions-threads-that-sell) — Captions and threads that drive affiliate sales.
- [Affiliate Email Wizard](https://chatgpt.com/g/g-w91bZd7up-dac-affiliate-email-wizard) — Personalized email campaigns for DAC affiliates.
- [Affiliate Review Firestarter](https://chatgpt.com/g/g-67f155f9bd60819187e703f6610e3ab2-affiliate-review-firestarter) — Punchy review articles for affiliate brands.
- [Affiliate Disclosure Writer](https://chatgpt.com/g/g-68713f530190819184196af0f5afc2c1-affiliate-disclosure-writer) — FTC-compliant affiliate disclosures and earnings disclaimers.
- [Social DACtivator](https://chatgpt.com/g/g-abNIHoRVX-socialmediagenie) — Guide-based social content for new DAC affiliates.
- [WebinarWizardPro](https://chatgpt.com/g/g-VtQqtsHI6-webinarwizardpro) — Webinar scripts for Moonshine Capital affiliates.
- [Get My Funding Offer](https://chatgpt.com/g/g-6876b24050208191948c872fb36dd3b1-get-my-funding-offer) — Qualifies leads and surfaces real-time offers from vetted lending partners.
- [Fundable Lead Finder](https://chatgpt.com/g/g-6a1a8152e8208191aa100266e5e94dd5-fundable-lead-finder) — Scores blue-collar service leads and writes funding outreach.

## ⚙️ Scale

- [Broker Follow-Up Machine GPT](https://chatgpt.com/g/g-6a2152c07e488191862b272d5e3a4b44-broker-follow-up-machine) — Borrower, referral, and pipeline follow-up systems.
- Dead Lead Revival GPT — Turns stale CRM notes into a reactivation plan. *(access URL: TODO)*
- [Funding Workflow SOP Builder GPT](https://chatgpt.com/g/g-6a21460c79d481918f2dd0f37cc9a01e-funding-workflow-sop-builder) — Turns messy broker processes into SOPs and delegation docs.
- [Loan Broker Automation Architect GPT](https://chatgpt.com/g/g-6a214c8c41d48191bebafa39c853412f-loan-broker-automation-architect) — Designs n8n / Zapier / Make workflows for broker ops.
- [Voice Agent Call Flow Builder](https://chatgpt.com/g/g-6a2da20c24a4819193256354e3cb4233-voice-agent-call-flow-builder) — Builds compliant AI voice-agent call flows for funding workflows.
- [Bank Statement Analyzer (Funding Readiness)](https://chatgpt.com/g/g-6a21969fa3a881918d75f5665c88ba60-bank-statement-analyzer) — Risk report from bank statements before applying.

---

- 📄 Full registry JSON (copy to save as affiliate-funding-agency-gpts.registry.json)
    
    ```json
    {
      "id": "affiliate-funding-agency-gpts",
      "name": "affiliate-funding-agency-gpts.registry.json",
      "description": "Catalog of custom GPTs that help affiliate partners launch, grow, and scale their own funding agency.",
      "source": "AI Generated",
      "visibility": "Public",
      "fields": {
        "id": "kebab-case unique id",
        "name": "GPT display name",
        "stage": "Launch | Grow | Scale",
        "access_url": "ChatGPT custom GPT URL",
        "description": "What the GPT does",
        "core_pain_point": "Primary pain it solves",
        "cta": "Primary call to action",
        "use_case_vertical": "Use case / vertical",
        "funnel_stage": "Lead Magnet | Tripwire | Core | Upsell",
        "tier": "Starter | Growth | Pro | DFY",
        "suite_tag": "Suite grouping",
        "privacy": "Everyone | Anyone with a link | Only me",
        "related_brand": "Brand the GPT supports",
        "status": "Built | Planned"
      },
      "entries": [
        {
          "id": "start-your-own-funding-agency",
          "name": "Start Your Own Funding Agency",
          "stage": "Launch",
          "access_url": "https://chatgpt.com/g/g-1u8W1T1bM-start-your-own-funding-agency",
          "description": "Turn hustle into income: start your own funding business with zero experience needed.",
          "core_pain_point": "Aspiring partners don't know how to start a funding agency.",
          "funnel_stage": null,
          "tier": null,
          "suite_tag": null,
          "privacy": "Anyone with a link",
          "related_brand": "Moonshine Capital",
          "status": "Built"
        },
        {
          "id": "affiliate-agency-gpt",
          "name": "Affiliate Agency GPT",
          "stage": "Launch",
          "access_url": "https://chatgpt.com/g/g-sAsXvLr6H-affiliate-agency-gpt",
          "description": "Attracts and structures new affiliate partners around helping small business owners secure funding.",
          "core_pain_point": "New partners are unsure how to launch and structure a funding agency.",
          "privacy": "Anyone with a link",
          "related_brand": "Moonshine Capital",
          "status": "Built"
        },
        {
          "id": "7-day-broker-blitz",
          "name": "7-Day Broker Blitz",
          "stage": "Launch",
          "access_url": "https://chatgpt.com/g/g-681c0b3d4ec88191bc169f0747fe7710-7-day-broker-blitz",
          "description": "Onboarding sprint to help a new funding broker close their first deal fast.",
          "related_brand": "Moonshine Capital",
          "status": "Built"
        },
        {
          "id": "beck-broker-onboarding-coach",
          "name": "Beck — Broker Onboarding Coach",
          "stage": "Launch",
          "access_url": "https://chatgpt.com/g/g-680ba7aacd288191800f5602b02a11cd-7-day-broker-blitz",
          "description": "Guides loan brokers with 7-day action plans, scripts, and success tracking to close the first deal.",
          "privacy": "Everyone",
          "related_brand": "Moonshine Capital",
          "status": "Built"
        },
        {
          "id": "getting-started-right",
          "name": "Getting Started Right",
          "stage": "Launch",
          "access_url": "https://chatgpt.com/g/g-680ba7aacd288191800f5602b02a11cd-getting-started-right",
          "description": "Foundational orientation for agency growth and sales for new partners.",
          "suite_tag": "Agency Growth & Sales",
          "privacy": "Anyone with a link",
          "status": "Built"
        },
        {
          "id": "funding-pathfinder-gpt",
          "name": "Funding Pathfinder GPT",
          "stage": "Launch",
          "access_url": "https://chatgpt.com/g/g-6876b717ca808191aea5343f89c670e3-funding-pathfinder-gpt",
          "description": "Client-facing funding strategist that analyzes a business and returns a personalized step-by-step funding roadmap.",
          "core_pain_point": "Confused by funding? Get a step-by-step plan before you apply.",
          "funnel_stage": "Core",
          "tier": "Starter",
          "suite_tag": "Money & Funding",
          "use_case_vertical": "Alternative Lending, Business Credit, Merchant Banking, Affiliate Funding",
          "privacy": "Anyone with a link",
          "related_brand": "Moonshine Capital",
          "status": "Built"
        },
        {
          "id": "affiliate-commission-estimator",
          "name": "Affiliate Commission Estimator (F.A.R.E.)",
          "stage": "Grow",
          "access_url": "https://chatgpt.com/g/g-FUKQjm8Yw-funding-agency-revenue-estimator",
          "description": "Helps agents and brokers calculate commissions and strategize revenue-sharing deals in alternative lending.",
          "privacy": "Anyone with a link",
          "related_brand": "Moonshine Capital",
          "status": "Built"
        },
        {
          "id": "affiliate-marketing-strategist",
          "name": "Affiliate Marketing Strategist",
          "stage": "Grow",
          "access_url": "https://chatgpt.com/g/g-dRZknamEd-affiliate-marketing-strategist",
          "description": "Growth strategies to dominate affiliate marketing and agency building.",
          "privacy": "Anyone with a link",
          "status": "Built"
        },
        {
          "id": "affiliate-ad-wizard",
          "name": "Affiliate Ad Wizard",
          "stage": "Grow",
          "access_url": "https://chatgpt.com/g/g-w0ehowMV9-deal-maker-ads",
          "description": "High-voltage ad copy that recruits affiliates with hustler edge.",
          "privacy": "Anyone with a link",
          "status": "Built"
        },
        {
          "id": "deal-maker-ads",
          "name": "Deal Maker Ads",
          "stage": "Grow",
          "access_url": "https://chatgpt.com/g/g-67bcaa62b38c81918d1d82a7a6ddf53e-deal-maker-ads",
          "description": "High-voltage ad copy that recruits affiliates, partners, and dealmakers.",
          "status": "Built"
        },
        {
          "id": "affiliate-sizzle-captions-threads",
          "name": "Affiliate Sizzle: Captions & Threads that Sell",
          "stage": "Grow",
          "access_url": "https://chatgpt.com/g/g-680ed727dcfc8191a2d65bf89a7315fb-affiliate-sizzle-captions-threads-that-sell",
          "description": "Generates captions and threads that drive affiliate sales on social media.",
          "privacy": "Only me",
          "status": "Built"
        },
        {
          "id": "affiliate-email-wizard",
          "name": "Affiliate Email Wizard",
          "stage": "Grow",
          "access_url": "https://chatgpt.com/g/g-w91bZd7up-dac-affiliate-email-wizard",
          "description": "Crafts personalized email campaigns for DAC affiliates.",
          "privacy": "Anyone with a link",
          "related_brand": "David Allen Capital",
          "status": "Built"
        },
        {
          "id": "affiliate-review-firestarter",
          "name": "Affiliate Review Firestarter",
          "stage": "Grow",
          "access_url": "https://chatgpt.com/g/g-67f155f9bd60819187e703f6610e3ab2-affiliate-review-firestarter",
          "description": "Writes raw, punchy, emotional review articles for affiliate brands.",
          "privacy": "Everyone",
          "status": "Built"
        },
        {
          "id": "affiliate-disclosure-writer",
          "name": "Affiliate Disclosure Writer",
          "stage": "Grow",
          "access_url": "https://chatgpt.com/g/g-68713f530190819184196af0f5afc2c1-affiliate-disclosure-writer",
          "description": "Creates FTC-compliant affiliate disclosures and earnings disclaimers in your brand voice.",
          "status": "Built"
        },
        {
          "id": "social-dactivator",
          "name": "Social DACtivator",
          "stage": "Grow",
          "access_url": "https://chatgpt.com/g/g-abNIHoRVX-socialmediagenie",
          "description": "Helps new DAC affiliates grow their funding business with engaging, guide-based social content.",
          "privacy": "Everyone",
          "related_brand": "David Allen Capital",
          "status": "Built"
        },
        {
          "id": "webinarwizardpro",
          "name": "WebinarWizardPro",
          "stage": "Grow",
          "access_url": "https://chatgpt.com/g/g-VtQqtsHI6-webinarwizardpro",
          "description": "Webinar script creator for Moonshine Capital's affiliates.",
          "related_brand": "Moonshine Capital",
          "status": "Built"
        },
        {
          "id": "get-my-funding-offer",
          "name": "Get My Funding Offer",
          "stage": "Grow",
          "access_url": "https://chatgpt.com/g/g-6876b24050208191948c872fb36dd3b1-get-my-funding-offer",
          "description": "Qualifies a lead and surfaces real-time business funding offers from vetted lending partners.",
          "suite_tag": "Money & Funding",
          "privacy": "Anyone with a link",
          "related_brand": "Moonshine Capital",
          "status": "Built"
        },
        {
          "id": "fundable-lead-finder",
          "name": "Fundable Lead Finder",
          "stage": "Grow",
          "access_url": "https://chatgpt.com/g/g-6a1a8152e8208191aa100266e5e94dd5-fundable-lead-finder",
          "description": "Scores blue-collar service leads and writes no-BS funding outreach.",
          "status": "Built"
        },
        {
          "id": "broker-follow-up-machine-gpt",
          "name": "Broker Follow-Up Machine GPT",
          "stage": "Scale",
          "access_url": "https://chatgpt.com/g/g-6a2152c07e488191862b272d5e3a4b44-broker-follow-up-machine",
          "description": "Builds borrower, referral partner, and pipeline follow-up systems so brokers stop losing deals to forgotten check-ins.",
          "core_pain_point": "Loan brokers lose funded deals because leads, missing docs, and referral partners fall through the cracks.",
          "funnel_stage": "Lead Magnet",
          "suite_tag": "Agency Growth & Sales",
          "use_case_vertical": "Loan broker CRM follow-up, borrower nurturing, referral partner retention",
          "privacy": "Only me",
          "related_brand": "Moonshine Capital",
          "status": "Built"
        },
        {
          "id": "dead-lead-revival-gpt",
          "name": "Dead Lead Revival GPT",
          "stage": "Scale",
          "access_url": "TODO",
          "description": "Turns stale CRM notes into a dead-lead reactivation plan with segment, angle, email, SMS, call script, next best action, and compliance warnings.",
          "core_pain_point": "Stale leads sit untouched in the CRM after one missed call, missing document, or forgotten follow-up.",
          "funnel_stage": "Lead Magnet",
          "tier": "Starter",
          "suite_tag": "Agency Growth & Sales",
          "use_case_vertical": "Funding broker follow-up, dead lead reactivation, CRM graveyard recovery",
          "privacy": "Everyone",
          "related_brand": "Moonshine Capital",
          "status": "Planned"
        },
        {
          "id": "funding-workflow-sop-builder-gpt",
          "name": "Funding Workflow SOP Builder GPT",
          "stage": "Scale",
          "access_url": "https://chatgpt.com/g/g-6a21460c79d481918f2dd0f37cc9a01e-funding-workflow-sop-builder",
          "description": "Turns messy loan broker processes into SOPs, checklists, delegation docs, and automation-ready workflows.",
          "core_pain_point": "Brokers need clean operating systems before they can delegate, hire, or automate.",
          "funnel_stage": "Tripwire",
          "suite_tag": "Ops & Templates",
          "use_case_vertical": "Funding agency SOPs, broker operations, processor replacement planning",
          "privacy": "Only me",
          "status": "Built"
        },
        {
          "id": "loan-broker-automation-architect-gpt",
          "name": "Loan Broker Automation Architect GPT",
          "stage": "Scale",
          "access_url": "https://chatgpt.com/g/g-6a214c8c41d48191bebafa39c853412f-loan-broker-automation-architect",
          "description": "Designs n8n, Zapier, and Make workflows for broker intake, document collection, lender matching, CRM updates, and follow-up.",
          "core_pain_point": "Loan brokers lose time to manual processor/admin tasks that can be automated.",
          "funnel_stage": "Core",
          "suite_tag": "Agency Growth & Sales",
          "use_case_vertical": "Loan broker automation, funding agency operations, n8n workflow design",
          "privacy": "Only me",
          "status": "Built"
        },
        {
          "id": "voice-agent-call-flow-builder",
          "name": "Voice Agent Call Flow Builder",
          "stage": "Scale",
          "access_url": "[https://chatgpt.com/g/g-6a2da20c24a4819193256354e3cb4233-voice-agent-call-flow-builder](https://chatgpt.com/g/g-6a2da20c24a4819193256354e3cb4233-voice-agent-call-flow-builder)",
          "description": "Builds AI voice-agent scripts, routing logic, CRM field maps, follow-up messages, and compliance-risk checklists for funding workflows.",
          "core_pain_point": "Teams want AI voice agents to qualify and follow up without making non-compliant funding promises.",
          "funnel_stage": "Lead Magnet",
          "suite_tag": "Creator & Content Ops",
          "use_case_vertical": "Broker intake, AI phone agents, inbound call automation, consent-aware follow-up",
          "privacy": "Only me",
          "status": "Built"
        },
        {
          "id": "bank-statement-analyzer",
          "name": "Bank Statement Analyzer (Funding Readiness)",
          "stage": "Scale",
          "access_url": "https://chatgpt.com/g/g-6a21969fa3a881918d75f5665c88ba60-bank-statement-analyzer",
          "description": "Reviews bank statements and returns a risk report (NSFs, average daily balance, deposit consistency, red flags) before applying.",
          "core_pain_point": "Hidden cash-flow red flags cause funding denials.",
          "funnel_stage": "Lead Magnet",
          "tier": "Starter",
          "suite_tag": "Money & Funding",
          "use_case_vertical": "Funding readiness / statement self-audit",
          "privacy": "Everyone",
          "status": "Built"
        }
      ]
    }
    ```
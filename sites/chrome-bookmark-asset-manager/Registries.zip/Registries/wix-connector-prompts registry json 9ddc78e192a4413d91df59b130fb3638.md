# wix-connector-prompts.registry.json

Description: Prompt library for the ChatGPT Wix Connector, grouped by workflow with numbered prompts and placeholder variables.
Suggested Fields: id, name, group, number, prompt, placeholders
File: wix-connector-prompts.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
🔌

**Single responsibility:** Store reusable ChatGPT Wix Connector prompts (grouped, numbered, with placeholder variables) so site audits and edits can be run consistently. 30 prompts captured.

</aside>

## Completed Registry — wix-connector-prompts.registry.json

[wix-connector-prompts.registry.json](wix-connector-prompts.registry.json)

wix-connector-prompts.registry.json

<aside>
✅

The attached completed JSON file is the primary source of truth. The sections below are secondary drafting/schema notes and compact previews.

</aside>

## Drafting & Schema Details

### Suggested fields

- `id` — kebab-case unique id
- `name` — prompt name
- `group` — workflow group
- `number` — order within library
- `prompt` — full prompt text
- `placeholders` — placeholder variables (e.g. PAGE_URL, SITE_NAME)

### Registry JSON

```json
{
  "id": "wix-connector-prompts",
  "name": "Wix Connector Prompts",
  "source": "Manual",
  "visibility": "Internal",
  "fields": {
    "id": "kebab-case unique id",
    "name": "prompt name",
    "group": "workflow group",
    "number": "order in library",
    "prompt": "full prompt text",
    "placeholders": "placeholder variables"
  },
  "entries": [
    {
      "id": "homepage-clarity-audit",
      "name": "Homepage clarity audit",
      "group": "Site audit + strategy",
      "number": 1,
      "prompt": "Using the Wix Connector, review the homepage at PAGE_URL. Identify the top 5 clarity issues and provide rewritten hero copy and a stronger primary CTA.",
      "placeholders": "PAGE_URL"
    }
  ]
}
```

### Example entries

- **Homepage clarity audit** — top 5 clarity issues + rewritten hero (PAGE_URL).
- **Navigation + IA audit** — improved information architecture (SITE_NAME).
- **Brand voice extraction** — infers brand voice + mini style guide (SITE_NAME).

*Complete data (30 prompts) is in the attached `wix-connector-prompts.registry.json`.*
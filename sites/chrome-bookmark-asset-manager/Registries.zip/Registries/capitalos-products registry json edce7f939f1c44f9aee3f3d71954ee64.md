# capitalos-products.registry.json

Description: Product catalog for the CapitalOS suite with tagline, core function, capabilities, ideal buyer, bundled tiers, revenue model, tier type, delivery mode, and status.
Suggested Fields: id, name, tagline, core_function, capabilities, ideal_buyer, bundled_tiers, offer_revenue_model, tier_type, delivery_mode, status
File: capitalos-products.registry.json
Last Updated: June 18, 2026 8:55 PM

<aside>
🏦

**Single responsibility:** Define the CapitalOS product suite (function, capabilities, buyer, revenue model, delivery mode) so the platform's modules and tiers are clearly catalogued. Source: CapitalOS Product Catalog (11 captured rows).

</aside>

## Completed Registry — capitalos-products.registry.json

[capitalos-products.registry.json](capitalos-products.registry.json)

capitalos-products.registry.json

<aside>
✅

The attached completed JSON file is the primary source of truth. The sections below are secondary drafting/schema notes and compact previews.

</aside>

## Drafting & Schema Details

### Suggested fields

- `id`, `name`, `tagline`, `core_function`, `capabilities`
- `ideal_buyer`, `bundled_tiers`, `offer_revenue_model`
- `tier_type`, `delivery_mode`, `status`

### Registry JSON

```json
{
  "id": "capitalos-products",
  "name": "CapitalOS Products",
  "source": "CSV Import",
  "visibility": "Internal",
  "fields": {
    "id": "kebab-case unique id",
    "name": "product name",
    "tagline": "tagline",
    "core_function": "core function",
    "capabilities": "capabilities",
    "ideal_buyer": "ideal buyer",
    "bundled_tiers": "bundled tiers",
    "offer_revenue_model": "revenue model",
    "tier_type": "tier type",
    "delivery_mode": "delivery mode",
    "status": "status"
  },
  "entries": [
    {
      "id": "capitalos-enterprise",
      "name": "CapitalOS Enterprise",
      "tagline": "Embedded capital infrastructure at scale.",
      "ideal_buyer": "Fintech builders, marketplaces, lending networks, large agencies.",
      "tier_type": "Managed",
      "delivery_mode": "DFY",
      "status": "Idea"
    }
  ]
}
```

### Example entries

- **CapitalOS Enterprise** — embedded, white-label capital infrastructure (Managed/DFY).
- **CapitalOS Insights** — intelligence layer for forecasting and funding readiness (Hybrid/DWY).
- **CapitalOS Automate** — workflow automation for funding tasks (Hybrid/DWY, MVP).

*Complete data (11 entries) is in the attached `capitalos-products.registry.json`.*
# tool-bundles.registry.json

Description: Productized packs. This is different from collections. Collections are public browsing groups. Bundles are productized packs.
Last Updated: June 9, 2026 4:22 AM
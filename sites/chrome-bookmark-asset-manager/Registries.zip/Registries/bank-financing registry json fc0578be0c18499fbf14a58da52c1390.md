# bank-financing.registry.json

Description: Tier 4 bank lines, term loans, and SBA products with documentation requirements. Could also extend funding-products.registry.json; doc lists reference funding-documents.
Suggested Fields: product_id, name, type, min_time_in_business_months, min_revenue, pg_required, docs_required, reports_to
File: bank-financing.registry.json
Last Updated: June 18, 2026 8:55 PM

<aside>
🎯

Tier 4 bank/SBA financing with documentation requirements. Reference doc IDs from `funding-documents.registry.json` instead of duplicating text.

</aside>

## Completed Registry — bank-financing.registry.json

```json
[
  {
    "product_id": "bank-loc",
    "name": "Bank Line of Credit",
    "type": "line-of-credit",
    "min_time_in_business_months": 24,
    "min_revenue": null,
    "pg_required": true,
    "docs_required": ["bank statements (6-12 mo)", "tax returns (1-2 yrs)", "P&L", "balance sheet", "debt schedule"],
    "reports_to": ["DNB", "Experian", "Equifax"]
  },
  {
    "product_id": "term-loan-nonsba",
    "name": "Fixed Term Loan (Non-SBA)",
    "type": "term-loan",
    "min_time_in_business_months": 24,
    "min_revenue": null,
    "pg_required": true,
    "docs_required": ["bank statements (6-12 mo)", "tax returns", "P&L", "DSCR support"],
    "reports_to": ["DNB", "Experian", "Equifax"]
  },
  {
    "product_id": "sba-7a",
    "name": "SBA 7(a) Loan",
    "type": "sba",
    "min_time_in_business_months": 24,
    "min_revenue": null,
    "pg_required": true,
    "docs_required": ["business plan", "tax returns (1-2 yrs)", "P&L", "balance sheet", "debt schedule", "bank statements (6-12 mo)", "financial projections"],
    "reports_to": ["DNB", "Experian", "Equifax"]
  },
  {
    "product_id": "sba-504",
    "name": "SBA 504 Loan",
    "type": "sba",
    "min_time_in_business_months": 24,
    "min_revenue": null,
    "pg_required": true,
    "docs_required": ["business plan", "tax returns (1-2 yrs)", "P&L", "balance sheet", "collateral documentation", "financial projections"],
    "reports_to": ["DNB", "Experian", "Equifax"]
  }
]
```

## Drafting & Schema Details

### 🧱 Suggested Fields

```json
{
  "product_id": "",
  "name": "",
  "type": "",
  "min_time_in_business_months": 24,
  "min_revenue": null,
  "pg_required": true,
  "docs_required": [],
  "reports_to": []
}
```

### 📌 Example entry

```json
{
  "product_id": "sba-7a",
  "name": "SBA 7(a) Loan",
  "type": "sba",
  "min_time_in_business_months": 24,
  "pg_required": true,
  "docs_required": ["business plan", "tax returns (1–2 yrs)", "P&L", "balance sheet", "debt schedule", "bank statements (6–12 mo)"],
  "reports_to": ["DNB", "Experian", "Equifax"]
}
```
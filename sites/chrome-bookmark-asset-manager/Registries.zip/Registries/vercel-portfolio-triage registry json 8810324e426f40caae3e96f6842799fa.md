# vercel-portfolio-triage.registry.json

Description: First-pass keep/review/archive/delete decisions and brand-alignment scores for the full Vercel project portfolio. Inference-based; pending revision-2 columns.
Suggested Fields: id, name, project_slug, github_repo, brand_owner, intended_use, brand_alignment_score, status, recommendation, last_edit, notes  (TODO rev-2: portfolio_bucket, primary_audience, monetization_path, platform_role, duplicate_cluster, replace_with, mvp_in_1_sprint, flagship_later, manual_override, decision_confidence)
File: vercel-portfolio-triage.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
🧹

**Purpose:** First-pass keep/review/archive/delete decisions and brand-alignment scores for the full Vercel project portfolio. Inference-based; pending revision-2 columns.

**Source:** AI Generated · **Visibility:** Internal · **Status:** In Progress · **Priority:** Medium

</aside>

## Completed Registry — vercel-portfolio-triage.registry.json

[vercel-portfolio-triage.registry.json](vercel-portfolio-triage.registry.json)

vercel-portfolio-triage.registry.json

<aside>
✅

The attached completed JSON file is the primary source of truth. The sections below are secondary drafting/schema notes and compact previews.

</aside>

## Drafting & Schema Details

### Registry JSON

```json
{
  "id": "vercel-portfolio-triage",
  "name": "vercel-portfolio-triage.registry.json",
  "description": "First-pass keep/review/archive/delete decisions and brand-alignment scores for the full Vercel project portfolio. Inference-based; pending revision-2 columns.",
  "source": "AI Generated",
  "visibility": "Internal",
  "fields": {
    "id": "", "name": "", "project_slug": "", "github_repo": "", "brand_owner": "", "intended_use": "", "brand_alignment_score": "", "status": "", "recommendation": "", "last_edit": "", "notes": ""
  },
  "entries": [
    {
      "id": "moonshine-capital",
      "name": "moonshine-capital",
      "project_slug": "moonshine-capital",
      "github_repo": "JFeimster/moonshine-capital",
      "brand_owner": "Moonshine Capital",
      "intended_use": "Funding / offer funnel",
      "brand_alignment_score": 95,
      "status": "Active",
      "recommendation": "Keep"
    },
    {
      "id": "moonshine-capital-portal",
      "name": "moonshine-capital-portal",
      "project_slug": "moonshine-capital-portal",
      "github_repo": "JFeimster/moonshine-capital-portal",
      "brand_owner": "Moonshine Capital",
      "intended_use": "Portal / dashboard",
      "brand_alignment_score": 95,
      "status": "Active",
      "recommendation": "Keep"
    },
    {
      "id": "distilledfunding",
      "name": "distilledfunding",
      "project_slug": "distilledfunding",
      "github_repo": "JFeimster/distilled-funding",
      "brand_owner": "Moonshine Capital",
      "intended_use": "Funding / offer funnel",
      "brand_alignment_score": 85,
      "status": "Dormant",
      "recommendation": "Keep"
    }
  ],
  "_note": "Showing 3 of 130 entries. The complete 130-entry registry is in the attached vercel-portfolio-triage.registry.json file."
}
```

### Example entries

- **moonshine-capital** (95, Active) — Keep. Core operating surface.
- **moonshine-capital-portal** (95, Active) — Keep. Core operating surface.
- **distilledfunding** (85, Dormant) — Keep. Needs manual business-context review.

TODO: scores and recommendations are inference-based and should be reviewed before locking. The matrix proposes rev-2 columns (portfolio_bucket, monetization_path, platform_role, duplicate_cluster, decision_confidence, etc.). The complete 130-row triage is attached in the **File** property above.
# flash-ui-brand-system.registry.json

Description: Registry of reusable Flash UI brand, CTA, trust-signal, SEO, mobile, and deployment standards for Moonshine / Distilled Funding prompt generation.
Suggested Fields: id, name, category, domain, guidance, examples, applies_to, source_file
File: flash-ui-brand-system.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
🗂️

**Purpose:** Registry of reusable Flash UI brand, CTA, trust-signal, SEO, mobile, and deployment standards for Moonshine / Distilled Funding prompt generation.

</aside>

## Registry summary

- **Registry:** `flash-ui-brand-system.registry.json`
- **Source:** Manual
- **Visibility:** Internal
- **Entries:** 7
- **Suggested fields:** id, name, category, domain, guidance, examples, applies_to, source_file

## Example entries

- [**go.distilledfunding.com**](http://go.distilledfunding.com) — Funnels and landing pages that turn traffic into qualified leads.
- [**tools.distilledfunding.com**](http://tools.distilledfunding.com) — Calculators, dashboards, and self-serve qualification tools.
- [**partners.distilledfunding.com**](http://partners.distilledfunding.com) — Partner recruitment, onboarding, and enablement experiences.

## Full registry JSON

```json
{
  "id": "flash-ui-brand-system",
  "name": "flash-ui-brand-system.registry.json",
  "description": "Registry of reusable Flash UI brand, CTA, trust-signal, SEO, mobile, and deployment standards for Moonshine / Distilled Funding prompt generation.",
  "source": "Manual",
  "visibility": "Internal",
  "fields": {
    "id": "kebab-case unique id",
    "name": "standard or domain name",
    "category": "domain | brand_standard | build_standard | conversion_standard",
    "domain": "related domain if applicable",
    "guidance": "operating guidance",
    "examples": "example uses",
    "applies_to": "asset classes this standard applies to",
    "source_file": "source file name"
  },
  "entries": [
    {
      "id": "go-distilledfunding-com",
      "name": "go.distilledfunding.com",
      "category": "domain",
      "domain": "go.distilledfunding.com",
      "guidance": "Funnels and landing pages that turn traffic into qualified leads.",
      "examples": [
        "Sales pages",
        "Conversion funnels",
        "Lead capture flows"
      ],
      "applies_to": "funnels and landing pages",
      "source_file": "Flash UI Prompt Library.md"
    },
    {
      "id": "tools-distilledfunding-com",
      "name": "tools.distilledfunding.com",
      "category": "domain",
      "domain": "tools.distilledfunding.com",
      "guidance": "Calculators, dashboards, and self-serve qualification tools.",
      "examples": [
        "Calculators",
        "Dashboards",
        "Resource tools"
      ],
      "applies_to": "funding calculators and tools",
      "source_file": "Flash UI Prompt Library.md"
    },
    {
      "id": "partners-distilledfunding-com",
      "name": "partners.distilledfunding.com",
      "category": "domain",
      "domain": "partners.distilledfunding.com",
      "guidance": "Partner recruitment, onboarding, and enablement experiences.",
      "examples": [
        "Partner pages",
        "Application flows",
        "Resource portals"
      ],
      "applies_to": "affiliate and partner assets",
      "source_file": "Flash UI Prompt Library.md"
    },
    {
      "id": "brand-voice",
      "name": "Brand Voice",
      "category": "brand_standard",
      "domain": "all",
      "guidance": "Build faster, ship sharper, convert harder; founder-friendly, practical, premium, and direct.",
      "examples": [
        "operator playbooks",
        "conversion assets"
      ],
      "applies_to": "all Flash UI prompts",
      "source_file": "Flash UI Prompt Library.md"
    },
    {
      "id": "mobile-first",
      "name": "Mobile First",
      "category": "build_standard",
      "domain": "all",
      "guidance": "Prioritize responsive mobile-first experiences with touch-friendly CTAs and scannable sections.",
      "examples": [
        "sticky mobile CTA",
        "single-column forms"
      ],
      "applies_to": "all Flash UI outputs",
      "source_file": "Flash UI Prompt Library.md"
    },
    {
      "id": "seo-best-practices",
      "name": "SEO Best Practices",
      "category": "build_standard",
      "domain": "all",
      "guidance": "Use clear page purpose, category structure, metadata, and internal linking paths for discoverable assets.",
      "examples": [
        "pillar pages",
        "resource hubs"
      ],
      "applies_to": "content hubs and landing pages",
      "source_file": "Flash UI Prompt Library.md"
    },
    {
      "id": "conversion-non-negotiables",
      "name": "Conversion Non-Negotiables",
      "category": "conversion_standard",
      "domain": "all",
      "guidance": "Every asset needs a clear hook, trust path, CTA, and next action.",
      "examples": [
        "primary CTA",
        "trust signals",
        "FAQ"
      ],
      "applies_to": "all conversion assets",
      "source_file": "Flash UI Prompt Library.md"
    }
  ]
}
```
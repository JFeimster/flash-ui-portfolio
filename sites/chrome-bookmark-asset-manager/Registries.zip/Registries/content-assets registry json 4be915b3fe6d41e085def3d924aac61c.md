# content-assets.registry.json

Description: For blogs, YouTube videos, lead magnets, podcast episodes, prompts, PDFs. This becomes your content-to-tool traffic map.
Last Updated: June 9, 2026 4:23 AM
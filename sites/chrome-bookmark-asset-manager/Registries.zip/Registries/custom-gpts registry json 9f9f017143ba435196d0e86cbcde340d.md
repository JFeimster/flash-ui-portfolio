# custom-gpts.registry.json

Description: Inventory of 100 custom GPTs (the brains) with access URLs and descriptions. Mirrors the My Custom GPTs database.
Suggested Fields: name, slug, description, access_url, duplicate
Last Updated: June 26, 2026 12:43 AM

<aside>
🧠

**100 custom GPTs** — the reasoning “brains” that pair with Vercel tools and sites. Each has an access URL ready to wire into a stack.

</aside>

## Summary

- **Total GPTs:** 100
- **Exact-name duplicates:** 0
- **Role in stacks:** brain layer (intake, generation, scoring, coaching)

## Full registry file

[custom-gpts.registry.json](custom-gpts%20registry%20json%209f9f-340d/custom-gpts.registry.json)

custom-gpts.registry.json
# assistant-stacks.registry.json

Description: Bundled assistants that stack a GPT brain + tool widgets + host site + API action, grouped by vertical. 10 stacks.
Suggested Fields: name, slug, sequence, vertical, status, goal, gpt_brains, tool_widgets, host_sites, ai_studio_apps, api_action, missing_pieces
Last Updated: June 26, 2026 12:43 AM

<aside>
🧩

Each entry stacks a **GPT brain** + **tool/widgets** + **host site** + **API/action** into one deployable assistant. Leading with **Partner / Affiliate Enablement**.

</aside>

## The 10 stacks

| # | Stack | Vertical | Status |
| --- | --- | --- | --- |
| 1 | Partner / Affiliate Enablement | partner-enablement | Assemble-ready |
| 2 | Borrower Qualification | funding-qualification | Assemble-ready |
| 3 | Fractional CFO / Cash Flow | cashflow-cfo | Assemble-ready |
| 4 | Acquisitions / M&A | acquisitions-m&a | Assemble-ready |
| 5 | Business Credit | business-credit | Brain needs tool |
| 6 | Ecommerce Capital | ecommerce-capital | Assemble-ready |
| 7 | Broker Ops / CRM Automation | broker-ops/crm | Assemble-ready |
| 8 | Asset Foundry (meta-builder) | asset-generation | Assemble-ready |
| 9 | SEO / Content / AI-Citation | seo-content-media | Brain-heavy |
| 10 | Real Estate / Fix-&-Flip | real-estate | Hands need brain |

## ⭐ Lead stack — Partner / Affiliate Enablement

**Goal:** Recruit, onboard, and activate funding affiliates/agents into daily producers.

- **🧠 GPT brains:** Start Your Own Funding Agency · Agent Growth Hub · Affiliate Marketing Strategist · 7-Day Broker Blitz · DAC Affiliate Email Wizard · Deal Maker Ads · Affiliate Commission Estimator
- **🛠️ Tools/widgets:** affiliate-launch-kit-generator · dac-goal-calculator · dac-comp
- **🌐 Host sites:** partner-enablement-os · start-your-agency · PartnerHub · Onboarding · agent-portal · dac-affiliate-enablement · myfigures-partner-onboarding · capital-launchpad
- **🟦 AI Studio:** PartnerLaunch - Funding Widget Suite · Moonshine Capital Partner Welcome · MyFigures Partner Program Onboarding · Funding Partners OS - Agent Dashboard
- **🔌 API/action:** Tally/CRM webhook → partner CRM (HubSpot via funding-applicant-ops)
- **🧱 Missing pieces:** single source-of-truth partner directory; unified commission calculator embedded in PartnerHub

## Full registry file

[assistant-stacks.registry.json](assistant-stacks%20registry%20json/assistant-stacks.registry.json)

assistant-stacks.registry.json

<details><summary>Registry JSON (preview)</summary>

```json
{
  "id": "assistant-stacks",
  "name": "Assistant Stacks",
  "source": "AI Generated",
  "visibility": "Internal",
  "count": 10,
  "fields": ["name","slug","sequence","vertical","status","goal","gpt_brains","tool_widgets","host_sites","ai_studio_apps","api_action","missing_pieces"]
}
```

The complete 10-stack JSON is attached as the file above.

</details>
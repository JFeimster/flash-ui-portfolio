# intake-verification-paths.registry.json

Description: Applicant verification paths used by the Applicant Intake CRM (Plaid vs document upload) with qualification thresholds and required items.
Suggested Fields: id, path_name, qualifying_criteria, required_items, skips_stage, notes
File: intake-verification-paths.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
✅

**Single responsibility** — Defines how the Applicant Intake CRM routes a borrower to a verification path (Plaid same-day, document upload, or does-not-qualify) based on revenue, time in business, and banking type.

</aside>

## Completed Registry — intake-verification-paths.registry.json

[intake-verification-paths.registry.json](intake-verification-paths.registry.json)

intake-verification-paths.registry.json

<aside>
✅

The attached completed JSON file is the primary source of truth. The sections below are secondary drafting/schema notes and compact previews.

</aside>

## Drafting & Schema Details

### Suggested fields

- `id` — kebab-case slug
- `path_name` — verification path name
- `qualifying_criteria` — thresholds that route an applicant to this path
- `required_items` — verification items required (array)
- `skips_stage` — pipeline stage skipped on this path
- `notes` — implementation notes

### Registry JSON

```json
{
  "id": "intake-verification-paths",
  "name": "intake-verification-paths",
  "source": "Manual",
  "visibility": "Internal",
  "fields": {
    "id": "kebab-case slug",
    "path_name": "Verification path name",
    "qualifying_criteria": "Thresholds that route an applicant here",
    "required_items": "Items required to complete the path (array)",
    "skips_stage": "Pipeline stage skipped"
  },
  "entries": [
    {
      "id": "plaid-verification",
      "path_name": "Plaid Verification (Same-Day Funding)",
      "qualifying_criteria": "Monthly revenue $3,000-$15,000 AND 3+ months in business; also used when revenue >$15,000 but banking is personal.",
      "required_items": ["Plaid Connected"],
      "skips_stage": "Docs Requested"
    },
    {
      "id": "document-upload",
      "path_name": "Document Upload",
      "qualifying_criteria": "Monthly revenue >$15,000 AND 3+ months in business AND business banking.",
      "required_items": ["Bank Statements", "Drivers License", "Voided Check", "Application Signed"],
      "skips_stage": "None"
    }
  ]
}
```

### Example entries

- **Plaid Verification** — same-day path; skips the Docs Requested stage.
- **Document Upload** — >$15k/mo business banking; requires four documents.
- **Does Not Qualify** — under $3k/mo or under 3 months in business.
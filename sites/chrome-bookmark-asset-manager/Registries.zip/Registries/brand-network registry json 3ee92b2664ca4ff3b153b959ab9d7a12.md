# brand-network.registry.json

Description: Your brand ecosystem map — brands, domains, roles, and channels.
Suggested Fields: brand_id, name, domain, role, channels, parent_brand
Last Updated: June 9, 2026 3:35 AM

<aside>
🎯

Your brand ecosystem map (Moonshine Capital, Distilled Funding, and the content channels). Captures domains, roles, and channels per brand.

</aside>

### 🧱 Suggested Fields

```json
{
  "brand_id": "",
  "name": "",
  "domain": "",
  "role": "",
  "channels": [],
  "parent_brand": ""
}
```
# borrower-qualification-stack.registry.json

Description: Build-ready spec for the Borrower Qualification assistant: GPT brains + pre-qual widgets + host sites + Tally→HubSpot intake router, with a shared scoring contract.
Suggested Fields: id, name, vertical, status, goal, flow, gpt_brains, tool_widgets, host_sites, api_actions, shared_data_contract, build_steps, missing_pieces
Last Updated: June 26, 2026 6:27 AM

<aside>
🎯

The first vertical detailed end-to-end. Turns cold traffic into **pre-qualified, routed funding applicants** using assets you already have live — one scoring model shared across the quiz, widget, and GPT.

</aside>

## Flow

1. **Capture** — visitor lands on a host site or hits the embedded pre-qual widget
2. **Score** — shared fundability model rates revenue, time-in-business, banking posture, FICO band
3. **Reason** — GPT brain explains the result, recommends a product lane, handles objections
4. **Route** — qualified lead posts to the intake router → CRM deal created → partner assigned

## Stack layers

### 🧠 GPT brains

- [Funding Pathfinder](https://chatgpt.com/g/g-6876b717ca808191aea5343f89c670e3-funding-pathfinder)
- [Get My Funding Offer](https://chatgpt.com/g/g-6876b24050208191948c872fb36dd3b1-get-my-funding-offer)
- [Same-Day Capital OS](https://chatgpt.com/g/g-680f278f022c8191aceede6f83658cd6-same-day-capital-os)
- [Bank Statement Analyzer (Funding Readiness)](https://chatgpt.com/g/g-6a21969fa3a881918d75f5665c88ba60-bank-statement-analyzer-funding-readiness)
- [Fundable Lead Finder](https://chatgpt.com/g/g-6a1a8152e8208191aa100266e5e94dd5-fundable-lead-finder)

### 🛠️ Tool / widget layer (live)

- [am-i-fundable](https://am-i-fundable.vercel.app/) · [funding-quiz](https://funding-quiz.vercel.app/) · [funding-embed](https://funding-embed.vercel.app/) · [moonshine-ai-directory](https://moonshine-ai-directory.vercel.app/) · [estimator](https://estimator-lyart.vercel.app/)

### 🌐 Host sites (live)

- [ai-funding-pathfinder](https://ai-funding-pathfinder.vercel.app/) · [distilledfunding](https://distilledfunding.vercel.app/) · [operator-funding-site](https://operator-funding-site.vercel.app/)

### 🔌 API / actions

- [moonshine-intake-router](https://github.com/JFeimster/moonshine-intake-router) — Tally/webhook intake router
- [funding-applicant-ops](https://github.com/JFeimster/funding-applicant-ops) — n8n → HubSpot deal + partner assignment

## Shared data contract

| Inputs | Outputs |
| --- | --- |
| legal_business_name | fundability_score_0_100 |
| monthly_revenue_low_90d | tier |
| time_in_business_months | recommended_product_lane |
| bank_account_type | disqualifiers[] |
| fico_band | next_action |
| requested_amount / use_of_funds | routed_partner |

## Build steps (all TODO)

- [ ]  Lift the 100-point fundability model into a shared scoring module (reuse `funding-scorecard.registry.json` logic)
- [ ]  Wire `funding-embed` to POST the shared input contract to the `moonshine-intake-router` webhook
- [ ]  Attach a no-auth GPT Action (OpenAPI) to Funding Pathfinder pointing at the same intake endpoint
- [ ]  Confirm `funding-applicant-ops` maps the router payload to a HubSpot deal + partner assignment
- [ ]  Set host-site CTAs (`am-i-fundable`, `funding-quiz`) to deep-link the GPT for explanation

<aside>
🧱

**Missing pieces:** single shared scoring model across quiz + widget + GPT (logic is currently duplicated) · OpenAPI schema for the intake action · partner-routing rules table.

</aside>

## Full spec file

[borrower-qualification-stack.registry.json](borrower-qualification-stack%20registry%20json/borrower-qualification-stack.registry.json)

borrower-qualification-stack.registry.json
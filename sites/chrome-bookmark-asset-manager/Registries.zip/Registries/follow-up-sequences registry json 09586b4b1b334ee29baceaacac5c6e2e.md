# follow-up-sequences.registry.json

Description: For email/SMS/call follow-up templates. Ties directly to your CRM automation work.
Last Updated: June 9, 2026 4:22 AM
# ui-code-templates.registry.json

Description: Static single-file UI code template variants (style explorations) for dashboards and landing pages, with variant style, use case, language, and brand.
Suggested Fields: id, name, variant_style, use_case, language, brand, has_source_code, notes
File: ui-code-templates.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
🎨

**Single responsibility:** Catalog reusable static UI code template variants (style + use case + source availability) so a design direction can be picked and shipped fast.

</aside>

## Completed Registry — ui-code-templates.registry.json

[ui-code-templates.registry.json](ui-code-templates.registry.json)

ui-code-templates.registry.json

<aside>
✅

The attached completed JSON file is the primary source of truth. The sections below are secondary drafting/schema notes and compact previews.

</aside>

## Drafting & Schema Details

### Suggested fields

- `id` — kebab-case unique id
- `name` — template / variant name
- `variant_style` — visual style description
- `use_case` — intended use case
- `language` — implementation language/format
- `brand` — brand / exploration context
- `has_source_code` — whether source code exists
- `notes` — extra notes (TODO where blank)

### Registry JSON

```json
{
  "id": "ui-code-templates",
  "name": "UI Code Templates",
  "source": "Manual",
  "visibility": "Internal",
  "fields": {
    "id": "kebab-case unique id",
    "name": "template / variant name",
    "variant_style": "visual style",
    "use_case": "intended use case",
    "language": "implementation format",
    "brand": "brand / context",
    "has_source_code": "boolean",
    "notes": "extra notes"
  },
  "entries": [
    {
      "id": "translucent-vellum-stratification",
      "name": "Translucent Vellum Stratification",
      "variant_style": "Vellum glassmorphism, layered paper sheets, grain overlay, parallax",
      "use_case": "Dashboard for Affiliate Loan Brokers",
      "language": "HTML/CSS/JS (static, single-file)",
      "brand": "Flash UI / Gemini 3 Flash explorations",
      "has_source_code": true
    }
  ]
}
```

### Example entries

- **Translucent Vellum Stratification** — vellum glassmorphism broker dashboard.
- **Kinetic Chromium Fluidity** — dark chromium liquid-blob dashboard.
- **Monolithic Basalt Gridwork** — basalt dark monolith grid with lava-green accent.

*Complete data (9 variants) is in the attached `ui-code-templates.registry.json`.*
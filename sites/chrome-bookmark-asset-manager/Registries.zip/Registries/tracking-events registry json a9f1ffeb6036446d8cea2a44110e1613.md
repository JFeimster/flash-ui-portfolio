# tracking-events.registry.json

Description: UTM conventions + event names every widget fires, so analytics stays consistent across embeds. One record per tracked event.
Suggested Fields: id, event, trigger, params, destination, status, schemaVersion, superseded, supersededBy, updatedAt
Last Updated: June 18, 2026 12:35 PM

<aside>
🎯

Canonical analytics contract: the event names, triggers, params, and destinations every widget/embed must fire. Keeps GA4/UTM/webhook data consistent across every site.

</aside>

### 🧱 Suggested Fields

```json
{
  "id": "",
  "event": "",
  "trigger": "",
  "params": [],
  "destination": "",
  "status": "active",
  "schemaVersion": "1.0.0",
  "superseded": false,
  "supersededBy": null,
  "updatedAt": ""
}
```

### 📌 Example entries

```json
[
  { "id": "lead-submit", "event": "lead_submitted", "trigger": "Funding application form submit", "params": ["utm_source", "utm_campaign", "product_id", "persona"], "destination": "GA4 + n8n webhook", "status": "active", "schemaVersion": "1.0.0", "superseded": false, "supersededBy": null, "updatedAt": "2026-06-18" },
  { "id": "cta-click", "event": "cta_clicked", "trigger": "Primary CTA button click", "params": ["cta_label", "slug", "partner_id"], "destination": "GA4", "status": "active", "schemaVersion": "1.0.0", "superseded": false, "supersededBy": null, "updatedAt": "2026-06-18" }
]
```
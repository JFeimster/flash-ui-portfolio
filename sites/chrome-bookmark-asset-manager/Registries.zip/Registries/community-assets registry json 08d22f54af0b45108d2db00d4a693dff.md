# community-assets.registry.json

Description: For Discord/forums/events/playbooks. Useful if Core Tools becomes the directory for all your deployable assets.
Last Updated: June 9, 2026 4:27 AM
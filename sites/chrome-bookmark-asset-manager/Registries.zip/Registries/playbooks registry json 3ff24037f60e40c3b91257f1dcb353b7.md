# playbooks.registry.json

Description: Great for packaged workflows: Funding Broker Starter Kit, Gig Worker Funding Path, etc.
Last Updated: June 9, 2026 4:16 AM
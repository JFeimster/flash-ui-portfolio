# tool-registry.json

Description: Embeddable tools/calculators the page registry's tool-grid pulls in by tag. 11 entries, all live with verified Vercel embed URLs — including the now-deployed Funding Readiness Scorecard, Burn Rate Runway Extender, Staged Funding Estimator, and an any-reason funding funnel.
Suggested Fields: id, name, slug, type, status, buildState, persona, problem, outputArtifact, tags, embed, pagePlacement, cta
Last Updated: June 26, 2026 8:22 AM

<aside>
🧮

Embeddable tools the page registry's `tool-grid` sections pull in by tag. Lives at `embeds/tool-registry.json` in your tree.

</aside>

## Entries (11)

**All 11 live** with verified Vercel embed URLs.

- **Cash Flow Gap Bridge Calculator** — `tool` · live · `/funding`, `/funding/working-capital` · working-capital
- **Amazon Payout Bridge Predictor** — `tool` · live · `/funding/ecommerce-seller-funding` · marketplace-capital
- **Inventory Turnover Accelerator** — `funnel` · live · `/funding/ecommerce-seller-funding` · marketplace-capital
- **Trucker Repair-to-Revenue Tracker** — `funnel` · live · `/funding/working-capital` · working-capital, equipment-finance
- **Equity Defender Simulator** — `funnel` · live · `/funding/startup-funding` · startup-credit-leverage
- **Investor Data Room Template** — `funnel` · live · `/funding/startup-funding` · startup-credit-leverage
- **Cash Command Center Dashboard** — `portal` · live · `/funding/working-capital` · working-capital
- **Funding Readiness Scorecard** — `widget` · ✅ live at `am-i-fundable.vercel.app` · `/funding` · routes across all 7 lanes (prequal)
- **Burn Rate Runway Extender** — `tool` · live · `/funding/startup-funding` · startup-credit-leverage
- **Staged Funding Estimator** — `tool` · live · `/funding` · structured-growth-loans, working-capital
- **Funding (Any Reason)** — `funnel` · live · `/funding` · all lanes (any-reason intake)

<aside>
✅

Now **11 tools, all live** with verified embed URLs. The Funding Readiness Scorecard is deployed at `am-i-fundable.vercel.app` (embed example: `funding-quiz.vercel.app`), and three new tools were added from your deployment list: **Burn Rate Runway Extender**, **Staged Funding Estimator** (widget at `estimator-lyart.vercel.app`, landing at `staged-funding.vercel.app`), and the **Funding (Any Reason)** intake funnel (pairs with Tally `w4R2Ad`).

</aside>

## Registry file

[tool-registry.json](tool-registry%20json/tool-registry.json)

tool-registry.json
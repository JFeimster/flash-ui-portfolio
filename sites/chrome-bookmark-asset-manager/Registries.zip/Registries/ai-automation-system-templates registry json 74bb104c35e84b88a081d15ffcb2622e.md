# ai-automation-system-templates.registry.json

Description: Registry of AI Automation Systems Library static site/template assets, including the parent systems library homepage, agent profile template, and automation profile template.
Suggested Fields: id, name, asset_type, slug, purpose, target_audience, output_format, visual_style, file_manifest, monetization_angle, prompt, source_file
File: ai-automation-system-templates.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
🗂️

**Purpose:** Registry of AI Automation Systems Library static site/template assets, including the parent systems library homepage, agent profile template, and automation profile template.

</aside>

## Registry summary

- **Registry:** `ai-automation-system-templates.registry.json`
- **Source:** Manual
- **Visibility:** Internal
- **Entries:** 3
- **Suggested fields:** id, name, asset_type, slug, purpose, target_audience, output_format, visual_style, file_manifest, monetization_angle, prompt, source_file

## Example entries

- **AI Automation Systems Library Homepage** — Master architectural directory cataloging user-facing AI Agents and operational backend Automations.
- **Standardized Agent Profile Template** — High-fidelity, productized documentation view displaying Custom GPT system roles, prompts, and conversion paths.
- **Standardized Automation Profile Template** — Standardized deployment documentation display exposing webhook data routes, schemas, and processing logic.

## Full registry JSON

```json
{
  "id": "ai-automation-system-templates",
  "name": "ai-automation-system-templates.registry.json",
  "description": "Registry of AI Automation Systems Library static site/template assets, including the parent systems library homepage, agent profile template, and automation profile template.",
  "source": "Manual",
  "visibility": "Internal",
  "fields": {
    "id": "kebab-case unique id",
    "name": "asset name",
    "asset_type": "asset type",
    "slug": "project slug",
    "purpose": "asset purpose",
    "target_audience": "target audience",
    "output_format": "output format",
    "visual_style": "visual style",
    "file_manifest": "files/components",
    "monetization_angle": "monetization/lead capture angle",
    "prompt": "prompt/spec",
    "source_file": "source file name"
  },
  "entries": [
    {
      "id": "ai-automation-systems-library",
      "name": "AI Automation Systems Library Homepage",
      "asset_type": "parent_library_portal",
      "slug": "ai-automation-systems-library",
      "purpose": "Master architectural directory cataloging user-facing AI Agents and operational backend Automations.",
      "target_audience": "Internal technical operations, scale-focused business founders, and system integration engineers.",
      "output_format": "Responsive semantic HTML5 framework with inline vanilla JS architecture filtering against a static JSON array.",
      "visual_style": "(Aesthetic: Swiss Minimalist Command Vault): - Layout Matrix: Fixed asymmetrical grid system using alternating CSS Grid blocks. Thick structural borders (2px solid #111) with a master 0px border-radius standard. - Color Palette: Deep Void Black background (#020202), Pure Stark White card canvases (#",
      "file_manifest": [
        "`index.html` — Master layout layout container featuring the bento controller layout grid.",
        "`library-data.json` — Static object store implementing the exact schemas for your first 25 AI Agent and Automation profiles.",
        "`core-engine.js` — Client-side parsing engine execution pipeline managing category state and dynamic keyword searches.",
        "`vault-style.css` — High-contrast structural layout framework with solid wireframe declarations."
      ],
      "monetization_angle": "The directory uses a progressive disclosure barrier. While basic system loglines are open to the public, downloading structural implementation checklists, copying deployment prompts, or viewing the webhook payload schema variables forces the user to register an operations developer account. This workflow captures precise enterprise lead data regarding their current infrastructure debt and tech stack bottlenecks.",
      "prompt": "Project Title: AI Automation Systems Library Homepage\nPurpose: Master architectural directory cataloging user-facing AI Agents and operational backend Automations.\nTarget Audience: Internal technical operations, scale-focused business founders, and system integration engineers.\nOutput Format: Responsive semantic HTML5 framework with inline vanilla JS architecture filtering against a static JSON array.\n\nVisual Style Instructions (Aesthetic: Swiss Minimalist Command Vault):\n- Layout Matrix: Fixed asymmetrical grid system using alternating CSS Grid blocks. Thick structural borders (2px solid #111) with a master 0px border-radius standard.\n- Color Palette: Deep Void Black background (#020202), Pure Stark White card canvases (#FFFFFF), Electric Cyan (#00E5FF) for interactive agent triggers, Matrix Green (#00E676) for automation state signals, and cold Technical Gray (#475569) text.\n- Accent Elements: Strict data density, zero blur, high-contrast monospace typographic telemetry indices, and high-visibility status tags.\n\nComponent Breakdown & Interaction Logic:\n1. INFRASTRUCTURE DUAL HEADER CONTROLLER:\n   - Split navigation bar showing total system capacity index: [LIVE AGENTS: 25] | [ACTIVE WORKFLOWS: 34].\n   - Search utility console with text input anchor: \"Query system identifiers, dependencies, or metadata tags...\"\n\n2. DUAL ARCHITECTURE CORE GRID PATHWAY:\n   - Left Master Block (Agent Stack): Accent border in Electric Cyan. Features display text: \"AI AGENTS [User-Interactive Interface Matrix]\".\n   - Right Master Block (Automation Stack): Accent border in Matrix Green. Features display text: \"BACKEND AUTOMATIONS [Programmatic Processing Pipelines]\".\n   - Interactive Logic: Clicking a node fires a client-side filter array updating the downstream directory layout instantly.\n\n3. DIRECTORY METADATA CARD ARCHITECTURE:\n   - Item row components driven by static JSON blocks. Each cell features:\n     - Header: Unified Title string + Slug lookup ID indicator.\n     - Metadata Block: Mono-spaced grid rows pulling: [Category] | [Platforms Involved] | [Difficulty Level (Beginner/Intermediate/Advanced)] | [Monetization Code].\n     - Interactive Trigger Actions: Primary \"Inspect Blueprint Architecture\" button executing a deep layout takeover or detail modal routing path.\n\nMobile/Accessibility Standards:\n- Complete structural compilation for mobile viewports: Layout rows re-stack seamlessly on a single-column block system.\n- Touch target dimensions strict at a minimum of 48px footprint. High-contrast ratio enforced natively via solid stark black characters layered across flat paper-white panels. No low-contrast typography overlaps.",
      "source_file": "AI Automation Systems Library.md"
    },
    {
      "id": "agent-profile-template",
      "name": "Standardized Agent Profile Template",
      "asset_type": "agent_profile_template",
      "slug": "agent-profile-template",
      "purpose": "High-fidelity, productized documentation view displaying Custom GPT system roles, prompts, and conversion paths.",
      "target_audience": "Searchers, affiliates, automation engineers, & SMB operatos.",
      "output_format": "Standardized static HTML5/Tailwind layout structured for seamless MDX content injection workflows.",
      "visual_style": "** *(Aesthetic: Technical Blueprint / Cyber-SaaS Dossier)*: - Visual Structure: Asymmetrical 3-column layout grid maximizing reading scannability and structural clarity. - Palette: Pure Slate-Dark background (#090D16), Clean White content boards (#FFFFFF), High-Vis Cyan accents (#06B6D4), and monoch",
      "file_manifest": [
        "`/data/templates/agent-profile-template.mdx` (MDX master schema definition layout)",
        "`/components/AgentProfileView.jsx` (React component container mapping markdown tokens directly to custom styled nodes)",
        "`/public/styles/blueprint.css` (Dense text presentation utilities)"
      ],
      "monetization_angle": "TODO",
      "prompt": "## 2. Standardized Agent Profile Template (`agent-profile-template`)\n\n**Project Title: AI Agent Profile Detail Template — Architectural Specification Page**\n\n- Purpose: High-fidelity, productized documentation view displaying Custom GPT system roles, prompts, and conversion paths.\n- Target Audience: Searchers, affiliates, automation engineers, & SMB operatos.\n- Output Format: Standardized static HTML5/Tailwind layout structured for seamless MDX content injection workflows.\n\n**Visual Style Instructions** *(Aesthetic: Technical Blueprint / Cyber-SaaS Dossier)*:\n\n- Visual Structure: Asymmetrical 3-column layout grid maximizing reading scannability and structural clarity.\n- Palette: Pure Slate-Dark background (#090D16), Clean White content boards (#FFFFFF), High-Vis Cyan accents (#06B6D4), and monochrome sub-borders.\n- Typography: Display Serif for section titles, Monospace characters for instructions block fields and frontmatter displays.\n\n**Layout Section Architecture:** \n\n1. METADATA FRONTMATTER VAULT *(Top Box)*:\nStyled block reading out raw configuration metrics:\n[TITLE: Funding Pathfinder GPT]\n[SHORT DESCRIPTION: Autonomous pre-qualification diagnostic matching business parameters to alternative capital products.]\n[SLUG: funding-pathfinder-gpt]\n[CATEGORY: Funding Broker Agents]\n[AGENT TYPE: Custom GPT]\n[PLATFORM: ChatGPT]\n[AUDIENCE: Business Owners, Funding Affiliates]\n[USE CASE: Lead Qualification & Pipeline Triage]\n[DIFFICULTY: Beginner]\n[STATUS: Live]\n[MONETIZATION: Lead Magnet / Partner Enablement]\n\n2. OPERATIONAL ARCHITECTURE CORE (Main Content Block):\n    1. Structural text segments addressing: \"Core Problem Solved\", \"Guided User Interaction Workflow\", and \"Expected Input/Output Mechanics\".\n    2. System Prompt Container: A dedicated styling module containing the master prompt payload with an embedded \"Copy Master Instructions to Clipboard\" execution tool.\n    \n3. CONVERSION ACTION PANEL (Right Sticky Sidebar):\n   - Primary Transaction Link: \"Deploy Custom GPT Instance\" (Glowing Cyan block layout with hard drop shadow, interactive translation transformations on hover states).\n   - Secondary Action Path: \"Request Bespoke Infrastructure Customization\" (Triggers inline form element capture).\n\n**Compliance Guardrails:**\n- Persistent footer banner notice string: \"Operational Notice: This AI Agent operates strictly as an educational optimization and processing copilot. It does not issue absolute credit decisions, legal securities execution, or contractually binding lending underwriting. Final transaction approval remains dependent on formal verification rules executed by certified Moonshine Capital platform administrators.\"\n\n**File/Component Manifest:**\n- `/data/templates/agent-profile-template.mdx` (MDX master schema definition layout)\n- `/components/AgentProfileView.jsx` (React component container mapping markdown tokens directly to custom styled nodes)\n- `/public/styles/blueprint.css` (Dense text presentation utilities)\n\nSuggested Project Slug: `agent-profile-template`\n\n---",
      "source_file": "AI Automation Systems Library.md"
    },
    {
      "id": "automation-profile-template",
      "name": "Standardized Automation Profile Template",
      "asset_type": "automation_profile_template",
      "slug": "automation-profile-template",
      "purpose": "Standardized deployment documentation display exposing webhook data routes, schemas, and processing logic.",
      "target_audience": "Scale-oriented software developers, infrastructure teams, and operations builders.",
      "output_format": "Responsive technical documentation canvas optimizing code block processing views.",
      "visual_style": "(Aesthetic: Terminal Operator Terminal): - Layout Matrix: Rigorous, data-dense document outline utilizing a side-sticky Table of Contents anchor network. - Palette: Jet Matte Black canvas (#000000), Stark Paper-White data modules (#F8FAFC), System Success Green Highlights (#10B981), and terminal war",
      "file_manifest": [
        "`/data/templates/automation-profile-template.mdx` (MDX documentation component blueprint)",
        "`/components/AutomationSpecsPanel.jsx` (Tailwind-powered view engine formatting source code arrays)",
        "`/public/styles/terminal-docs.css` (Syntax formatting and component layout definitions)"
      ],
      "monetization_angle": "TODO",
      "prompt": "Project Title: Automation Profile Detail Template — Backend Pipeline Documentation Spec\nPurpose: Standardized deployment documentation display exposing webhook data routes, schemas, and processing logic.\nTarget Audience: Scale-oriented software developers, infrastructure teams, and operations builders.\nOutput Format: Responsive technical documentation canvas optimizing code block processing views.\n\nVisual Style Instructions (Aesthetic: Terminal Operator Terminal):\n- Layout Matrix: Rigorous, data-dense document outline utilizing a side-sticky Table of Contents anchor network.\n- Palette: Jet Matte Black canvas (#000000), Stark Paper-White data modules (#F8FAFC), System Success Green Highlights (#10B981), and terminal warning highlights.\n- Graphic Details: Code highlighting syntax blocks, clean key-value layout matrices, and visual webhook flow routing diagrams.\n\nLayout Section Architecture:\n1. PIPELINE INITIALIZATION VAULT (Top Box):\n   - Standard block reading out operational indices:\n     [TITLE: Tally to HubSpot Contact Upsert Workflow]\n     [SHORT DESCRIPTION: Automated data normalization pipeline parsing inbound intake form payloads into underwritten CRM contacts and deals.]\n     [SLUG: tally-to-hubspot-contact-upsert-workflow]\n     [CATEGORY: Intake Automations]\n     [AUTOMATION TYPE: Webhook Processing Pipeline]\n     [PLATFORMS: Tally, HubSpot, n8n, Gmail]\n     [AUDIENCE: Operations Administrators, Funding Agencies]\n     [USE CASE: Automated Lead Intake & Pipeline Routing]\n     [DIFFICULTY: Intermediate]\n     [STATUS: Build Ready]\n     [MONETIZATION: Internal Overhead Reduction / Productized Automation Template]\n     [PUBLISHED DATE: 2026-05-28]\n\n2. PIPELINE STEP LOGIC LEDGER (Main Content Area):\n   - Detailed sequence mapping rows: Step 1 (Webhook Intake Execution) → Step 2 (Data Normalization Filter) → Step 3 (Duplicate Record Verification Routine) → Step 4 (CRM Record Generation).\n   - Data Schema Sandbox: Interactive tab view showcasing a copy-ready valid JSON payload block mapping exact inbound fields to destination data objects.\n\n3. IMPLEMENTATION ACTION CONSOLE (Right Sticky Sidebar):\n   - Master Call to Action: \"Download JSON Workflow Blueprint\" (Solid black background with Matrix Green neon edge highlight, instant color inversion transformation state on hover action).\n   - Technical Support Link: \"Review Field Mapping Documentation\".\n\nCompliance Guardrails:\n- Embedded validation warning text block: \n\"Technical Configuration Notice: Field mapping schemas are pre-configured to match traditional HubSpot transaction matrices. \nEnsure explicit validation checks are performed on target sandbox environments prior to live production execution to avoid data collision or account duplication metrics.\"\n\nFile/Component Manifest:\n- `/data/templates/automation-profile-template.mdx` (MDX documentation component blueprint)\n- `/components/AutomationSpecsPanel.jsx` (Tailwind-powered view engine formatting source code arrays)\n- `/public/styles/terminal-docs.css` (Syntax formatting and component layout definitions)\n\nSuggested Project Slug: `automation-profile-template`",
      "source_file": "AI Automation Systems Library.md"
    }
  ]
}
```
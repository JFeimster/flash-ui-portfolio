# moonshine-partners.registry.json

Description: Partner/recruit records from the Moonshine Capital Partners CRM. Most are network-imported active partners; a few are inbound applicants. Contains contact PII.
Suggested Fields: id, name, email, number, company, current_position, status, sequence_stage, onboarding_path, partner_lane, lead_source, sales_experience, wants_strategy_call, preferred_start, application_date, follow_up_date, interest_reason, notes
File: moonshine-partners.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
🤝

**Single responsibility** — One row per partner/recruit in the Moonshine Capital Partners CRM (50 records). ⚠️ Contains contact PII — Internal visibility. Most rows are network-imported Active Partners (name + lineage notes only); a couple are detailed inbound Tally applicants.

</aside>

## Completed Registry — moonshine-partners.registry.json

[moonshine-partners.registry.json](moonshine-partners.registry.json)

moonshine-partners.registry.json

<aside>
✅

The attached completed JSON file is the primary source of truth. The sections below are secondary drafting/schema notes and compact previews.

</aside>

## Drafting & Schema Details

### Suggested fields

- `id` — kebab-case slug or `new-lead-NN`
- `name`, `email`, `number`, `company`, `current_position`
- `status`, `sequence_stage`, `onboarding_path`, `partner_lane`, `lead_source`
- `sales_experience`, `wants_strategy_call`, `preferred_start`, `application_date`, `follow_up_date`, `interest_reason`, `notes`

### Registry JSON

```json
{
  "id": "moonshine-partners",
  "name": "moonshine-partners",
  "source": "CSV Import",
  "visibility": "Internal",
  "fields": {
    "id": "kebab-case slug or new-lead-NN",
    "name": "Partner name",
    "status": "Partner status",
    "onboarding_path": "Onboarding path",
    "partner_lane": "Partner lane chosen",
    "lead_source": "Lead source"
  },
  "entries": [
    { "id": "junaid-ahmed", "name": "Junaid Ahmed", "status": "New Lead", "onboarding_path": "Beginner", "partner_lane": "Affiliate / Content", "lead_source": "Tally Form", "sales_experience": "Yes", "preferred_start": "This month" },
    { "id": "300-financing-consultants", "name": "300 Financing Consultants", "status": "Active Partner", "onboarding_path": "DAC", "lead_source": "Other" }
  ]
}
```

### Example entries

- **Junaid Ahmed** — New Lead, Beginner, Affiliate / Content, Tally Form.
- **300 Financing Consultants** — Active Partner, DAC onboarding path.
- **Jake Thornhill LLC** — Active Partner (network root).
# moonshine.registry-map.json

Description: Visibility/exposure control map for the Moonshine/Funding registries — classifies 19 registries as public-safe, build-time only, or server-side internal to prevent frontend leakage of provider economics, affiliate URLs, routing rules, and partner PII.
Suggested Fields: registry_key, file_name, recommended_path, visibility_class, frontend_exposure, raw_file_public_endpoint, primary_use, used_by, guardrails
Last Updated: July 3, 2026 8:23 PM

<aside>
🎯

Visibility/exposure control map for the Moonshine/Funding registries. Classifies 19 registries as public-safe, build-time only, or server-side internal so the frontend never leaks provider economics, affiliate/apply URLs, internal routing rules, or partner PII.

</aside>

## moonshine.registry-map.json

[moonshine.registry-map.json](moonshine%20registry-map%20json/3d401dd0-ce43-4d6c-b267-5f8da0f68dea.json)

moonshine.registry-map.json

<aside>
✅

The attached file is the source of truth for this entry.

</aside>

### 🧱 Suggested Fields

```json
{
  "registry_key": "",
  "file_name": "",
  "recommended_path": "",
  "visibility_class": "",
  "frontend_exposure": "",
  "raw_file_public_endpoint": "",
  "primary_use": [],
  "used_by": [],
  "guardrails": []
}
```
# FLASH-UI-Site-Ideas-&-Prompts.md

Description: Source prompt bank of 35 FLASH-UI site-build prompts (partner portals, funnels, dashboards, lead magnets, and partner tools) for Moonshine / Distilled Funding. Source material behind the flash-ui-prompts registries.
Suggested Fields: id, name, site_concept, use_case, type, visual_style, visitor_psychology, primary_cta, prompt
File: FLASH-UI-Site-Ideas--Prompts.md
Last Updated: July 3, 2026 8:28 PM

<aside>
🎯

Source prompt bank of 35 FLASH-UI site-build prompts (partner portals, funnels, dashboards, lead magnets, and partner tools) for Moonshine / Distilled Funding. Source material behind the flash-ui-prompts registries.

</aside>

## FLASH-UI-Site-Ideas-&-[Prompts.md](http://Prompts.md)

[FLASH-UI-Site-Ideas-&-[Prompts.md](http://Prompts.md)](FLASH-UI-Site-Ideas-&-Prompts%20md/1a02cc97-2922-40fe-9db1-bc4adeed9b15.md)

FLASH-UI-Site-Ideas-&-[Prompts.md](http://Prompts.md)

<aside>
✅

The attached file is the source of truth for this entry.

</aside>

### 🧱 Suggested Fields

```json
{
  "id": "",
  "name": "",
  "site_concept": "",
  "use_case": "",
  "type": "",
  "visual_style": "",
  "visitor_psychology": "",
  "primary_cta": "",
  "prompt": ""
}
```
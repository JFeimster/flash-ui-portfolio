# funding-products.registry.json

Description: Concrete funding products tied to a provider + family. Full catalog of 59 active products across 19 providers, imported from the portfolio report — each with amounts, credit tier, term, rate, time-to-funding, and min credit/revenue/TIB. The 3 DB-verified entries (7 Figures BLOC, Bank Breezy CoreRate/FlexRate) keep verified status.
Suggested Fields: id, slug, name, providerId, providerName, productFamily, category, fundingType, summary, minAmount, maxAmount, minCreditScore, minMonthlyRevenue, minTimeInBusinessMonths, creditTier, termLength, paymentType, rateCostRange, timeToFunding, startupEligible, geography, industryFit, useCases, requiredDocuments, commonDisqualifiers, bestFitProfile, publicPage, cta, source, status, visibility
Last Updated: June 26, 2026 9:04 AM

<aside>
📦

Concrete products, each tied to a `providerId` and a `productFamily`. Internal visibility — these carry underwriting detail.

</aside>

## Entries (59)

Full product catalog imported from `funding_product_portfolio_report.md` — **59 active products across 19 providers**. Each product carries real amounts, credit tier, term, rate, time-to-funding, min credit / revenue / time-in-business, funding type, and provider, mapped across the 6 funding lanes.

| Family | Products |
| --- | --- |
| `working-capital` | 22 |
| `startup-credit-leverage` | 13 |
| `real-estate-capital` | 10 |
| `equipment-finance` | 5 |
| `marketplace-capital` | 5 |
| `business-line-access` | 4 |

Top providers by product count: **GoKapital (14)**, **7 Figures Funding (12)**, **ROK Financial (10)**, **Bank Breezy / DAC (5)**.

<aside>
✅

Expanded from 3 to **59 products** by parsing the Full Product Inventory in your portfolio report. Each entry maps to a provider + family with full underwriting detail. The 3 originally DB-verified entries (7 Figures BLOC, Bank Breezy CoreRate/FlexRate) keep `verified` status; the rest are `imported_from_portfolio_report`.

</aside>

<aside>
⚠️

One conflict surfaced: the **7 Figures BLOC** product sheet lists **600** min FICO, but the provider-level affiliate requirement we used earlier was **680**. I kept the product-level 600 and flagged it in that entry's `source.notes` — tell me which should win.

</aside>

<aside>
🔗

`providerId`s normalized to the providers registry: 17 of 19 link cleanly (fixed `finance-factory`→`the-finance-factory`, `fund-grow`→`fundandgrow`, `guidant-financial`→`guidant`, `onramp-funds`→`onramp`). Two products — **Blue Bridge Financial** (`bluebridge-efa`) and **National Business Capital** (`nbc-term`) — reference providers not yet in the providers registry; both are flagged in `needsReview`. **Folded in:** the `structured-growth-loans` family was merged into existing lanes — 11 term/SBA/expansion products moved to `working-capital` (now 22) and franchise financing to `startup-credit-leverage` (now 13), so every product maps to a lane with a page. Registry version → `0.5.0`.

</aside>

## Registry file

[funding-products.registry.json](funding-products%20registry%20json%2023e1-81da/funding-products.registry.json)

funding-products.registry.json

[funding_product_portfolio_report.md](funding-products%20registry%20json%2023e1-81da/funding_product_portfolio_report.md)
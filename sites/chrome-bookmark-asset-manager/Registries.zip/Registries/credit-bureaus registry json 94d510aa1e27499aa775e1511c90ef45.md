# credit-bureaus.registry.json

Description: Business credit bureaus, their score models, and monitoring products (D&B/Paydex, Experian/Intelliscore, Equifax Business, SBFE).
Suggested Fields: bureau_id, name, score_models, monitoring_products, free_tier, id_required
File: credit-bureaus.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
🎯

Reference list of business credit bureaus, score models, and where to monitor each.

</aside>

## Completed Registry — credit-bureaus.registry.json

```json
[
  {
    "bureau_id": "dnb",
    "name": "Dun & Bradstreet",
    "score_models": ["Paydex"],
    "monitoring_products": ["CreditSignal", "CreditSignal Plus"],
    "free_tier": true,
    "id_required": "D-U-N-S number"
  },
  {
    "bureau_id": "experian-business",
    "name": "Experian Business",
    "score_models": ["Intelliscore Plus", "Financial Stability Risk"],
    "monitoring_products": ["Business Credit Advantage"],
    "free_tier": false,
    "id_required": "EIN"
  },
  {
    "bureau_id": "equifax-business",
    "name": "Equifax Business",
    "score_models": ["Business Credit Risk Score", "Business Failure Score"],
    "monitoring_products": ["Equifax Business"],
    "free_tier": false,
    "id_required": "EIN"
  },
  {
    "bureau_id": "sbfe",
    "name": "Small Business Financial Exchange (SBFE)",
    "score_models": [],
    "monitoring_products": [],
    "free_tier": false,
    "id_required": "EIN"
  },
  {
    "bureau_id": "nav",
    "name": "Nav (aggregator)",
    "score_models": ["D&B Paydex", "Experian Intelliscore", "Equifax"],
    "monitoring_products": ["Nav Free", "Nav Prime"],
    "free_tier": true,
    "id_required": "EIN"
  }
]
```

## Drafting & Schema Details

### 🧱 Suggested Fields

```json
{
  "bureau_id": "",
  "name": "",
  "score_models": [],
  "monitoring_products": [],
  "free_tier": false,
  "id_required": ""
}
```

### 📌 Example entry

```json
{
  "bureau_id": "dnb",
  "name": "Dun & Bradstreet",
  "score_models": ["Paydex"],
  "monitoring_products": ["CreditSignal"],
  "free_tier": true,
  "id_required": "D-U-N-S number"
}
```
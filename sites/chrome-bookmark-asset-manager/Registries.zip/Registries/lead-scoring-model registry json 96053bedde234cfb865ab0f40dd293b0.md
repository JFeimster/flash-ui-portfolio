# lead-scoring-model.registry.json

Description: The Fit Score model (0-100) used by the Applicant Intake CRM, broken into five weighted components and scoring bands.
Suggested Fields: id, component, max_points, scoring_bands
File: lead-scoring-model.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
📊

**Single responsibility** — Documents the Fit Score (0-100) weighting used to rank applicants in the Applicant Intake CRM.

</aside>

## Completed Registry — lead-scoring-model.registry.json

[lead-scoring-model.registry.json](lead-scoring-model.registry.json)

lead-scoring-model.registry.json

<aside>
✅

The attached completed JSON file is the primary source of truth. The sections below are secondary drafting/schema notes and compact previews.

</aside>

## Drafting & Schema Details

### Suggested fields

- `id` — kebab-case slug
- `component` — scoring component
- `max_points` — maximum points for this component (number)
- `scoring_bands` — point bands within the component (array)

### Registry JSON

```json
{
  "id": "lead-scoring-model",
  "name": "lead-scoring-model",
  "source": "Manual",
  "visibility": "Internal",
  "fields": {
    "id": "kebab-case slug",
    "component": "Scoring component",
    "max_points": "Maximum points (number)",
    "scoring_bands": "Point bands (array)"
  },
  "entries": [
    { "id": "credit-score", "component": "Credit Score", "max_points": 30, "scoring_bands": ["750+ = 30", "700-749 = 25", "650-699 = 20", "600-649 = 15", "550-599 = 8", "<550 = 0"] },
    { "id": "monthly-revenue", "component": "Monthly Revenue", "max_points": 25, "scoring_bands": ["$50k+ = 25", "$25k-$50k = 20", "$10k-$25k = 15", "$5k-$10k = 8", "<$5k = 0"] }
  ]
}
```

### Example entries

- **Credit Score** — 30 pts max.
- **Monthly Revenue** — 25 pts max.
- **Time in Business** — 20 pts; **Funding Reasonability** — 15 pts; **Profile Completeness** — 10 pts. Total = 100.
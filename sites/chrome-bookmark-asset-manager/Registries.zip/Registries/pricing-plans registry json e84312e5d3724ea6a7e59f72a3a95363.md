# pricing-plans.registry.json

Description: Structured pricing tiers feeding pricing widgets (distinct from monetization, which is strategy). One record per plan.
Suggested Fields: id, plan_id, name, price, interval, features, cta, status, schemaVersion, superseded, supersededBy, updatedAt
Last Updated: June 18, 2026 12:35 PM

<aside>
🎯

Structured pricing tiers that feed pricing widgets and landing pages. Distinct from `monetization.registry.json`, which reads more like strategy — this is the renderable plan data.

</aside>

### 🧱 Suggested Fields

```json
{
  "id": "",
  "plan_id": "",
  "name": "",
  "price": 0,
  "interval": "month",
  "features": [],
  "cta": "",
  "status": "active",
  "schemaVersion": "1.0.0",
  "superseded": false,
  "supersededBy": null,
  "updatedAt": ""
}
```

### 📌 Example entries

```json
[
  { "id": "starter", "plan_id": "starter", "name": "Starter", "price": 0, "interval": "month", "features": ["Fundability checklist", "1 registry export"], "cta": "Start free", "status": "active", "schemaVersion": "1.0.0", "superseded": false, "supersededBy": null, "updatedAt": "2026-06-18" },
  { "id": "pro", "plan_id": "pro", "name": "Pro", "price": 49, "interval": "month", "features": ["All registries", "Tier roadmap tracker", "Priority support"], "cta": "Upgrade", "status": "active", "schemaVersion": "1.0.0", "superseded": false, "supersededBy": null, "updatedAt": "2026-06-18" }
]
```
# compliance-rules.registry.json

Description: Disclaimers and human-review flags for funding/credit/tax/earnings tools. Guardrail infrastructure.
Suggested Fields: rule_id, applies_to, category, disclaimer_text, requires_human_review, severity
Last Updated: June 9, 2026 3:34 AM

<aside>
🎯

Guardrail infrastructure. Funding, credit, tax, and earnings tools need disclaimers and human-review flags. This registry holds those rules.

</aside>

### 🧱 Suggested Fields

```json
{
  "rule_id": "",
  "applies_to": [],
  "category": "",
  "disclaimer_text": "",
  "requires_human_review": false,
  "severity": ""
}
```
# geo-eligibility.registry.json

Description: State/region restrictions for funding products (MCA/lending vary heavily by state). One record per product with allowed/excluded states.
Suggested Fields: id, product_id, allowed_states, excluded_states, notes, status, schemaVersion, superseded, supersededBy, updatedAt
Last Updated: June 18, 2026 12:35 PM

<aside>
🎯

State/region eligibility for funding products. MCA and lending rules vary heavily by state — routing and directory widgets should check here before showing or recommending a product.

</aside>

### 🧱 Suggested Fields

```json
{
  "id": "",
  "product_id": "",
  "allowed_states": [],
  "excluded_states": [],
  "notes": "",
  "status": "active",
  "schemaVersion": "1.0.0",
  "superseded": false,
  "supersededBy": null,
  "updatedAt": ""
}
```

### 📌 Example entry

```json
[
  { "id": "mca-default", "product_id": "merchant-cash-advance", "allowed_states": ["*"], "excluded_states": ["CA", "NY", "NJ", "VA", "UT"], "notes": "Several states regulate or restrict MCA disclosures; confirm current rules before routing.", "status": "active", "schemaVersion": "1.0.0", "superseded": false, "supersededBy": null, "updatedAt": "2026-06-18" }
]
```
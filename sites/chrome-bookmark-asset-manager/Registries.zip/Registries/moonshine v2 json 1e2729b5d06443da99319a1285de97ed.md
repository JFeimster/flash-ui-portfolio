# moonshine.v2.json

Description: Moonshine Capital Master Funnel config (v2) — master config for partner acquisition, borrower funding routing, tool-led lead capture, and partner command-center handoff (brand, hero, sections, funding lanes, routing engines, CRM/automation, compliance).
Suggested Fields: id, name, brand, hero, sections, navigation, fundingLanes, routing, routingEngines, leadCapture, partnerOnboarding, crmAndAutomation, compliance, seo
Last Updated: July 3, 2026 8:29 PM

<aside>
🎯

Moonshine Capital Master Funnel config (v2). Master config for partner acquisition, borrower funding routing, tool-led lead capture, and partner command-center handoff — brand, hero, sections, funding lanes, routing engines, CRM/automation, and compliance.

</aside>

## moonshine.v2.json

[moonshine.v2.json](moonshine%20v2%20json/d0072e45-0a9c-47f9-b19e-1d4ad035aa6b.json)

moonshine.v2.json

<aside>
✅

The attached file is the source of truth for this entry.

</aside>

### 🧱 Suggested Fields

```json
{
  "id": "",
  "name": "",
  "brand": {},
  "hero": {},
  "sections": [],
  "fundingLanes": [],
  "routingEngines": [],
  "leadCapture": {},
  "compliance": {}
}
```
# offer-catalog.registry.json

Description: Canonical catalog of the 20 productized offers across brand lanes, with pricing, funnel role, and recommended build/checkout stack.
Suggested Fields: id, name, rank, brand_lane, offer_family, primary_audience, core_promise, offer_type, price_low, price_high, billing_model, tier_notes, funnel_role, launch_priority, rapid_launch_score, primary_surface, alternate_surface, build_stack, gpt_build_path, widget_potential, checkout_primary, checkout_alternate, crm_pipeline, fulfillment, asset_engine, code_repo_home, why_surface_wins, use_wix, use_wordpress, use_stripe, use_vercel, notes
File: offer-catalog.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
🧾

**Purpose:** Canonical catalog of the 20 productized offers across brand lanes, with pricing, funnel role, and recommended build/checkout stack.

**Source:** CSV Import · **Visibility:** Internal · **Status:** In Progress · **Priority:** High

</aside>

## Completed Registry — offer-catalog.registry.json

[offer-catalog.registry.json](offer-catalog.registry.json)

offer-catalog.registry.json

<aside>
✅

The attached completed JSON file is the primary source of truth. The sections below are secondary drafting/schema notes and compact previews.

</aside>

## Drafting & Schema Details

### Registry JSON

```json
{
  "id": "offer-catalog",
  "name": "offer-catalog.registry.json",
  "description": "Canonical catalog of the 20 productized offers across brand lanes, with pricing, funnel role, and recommended build/checkout stack.",
  "source": "CSV Import",
  "visibility": "Internal",
  "fields": {
    "id": "",
    "name": "",
    "rank": "",
    "brand_lane": "",
    "offer_family": "",
    "primary_audience": "",
    "core_promise": "",
    "offer_type": "",
    "price_low": "",
    "price_high": "",
    "billing_model": "",
    "tier_notes": "",
    "funnel_role": "",
    "launch_priority": "",
    "rapid_launch_score": "",
    "primary_surface": "",
    "alternate_surface": "",
    "build_stack": "",
    "gpt_build_path": "",
    "widget_potential": "",
    "checkout_primary": "",
    "checkout_alternate": "",
    "crm_pipeline": "",
    "fulfillment": "",
    "asset_engine": "",
    "code_repo_home": "",
    "why_surface_wins": "",
    "use_wix": "",
    "use_wordpress": "",
    "use_stripe": "",
    "use_vercel": "",
    "notes": ""
  },
  "entries": [
    {
      "id": "magnet-forge",
      "name": "Magnet Forge",
      "rank": 1,
      "brand_lane": "Moonshine Capital",
      "offer_family": "Lead Magnet / Entry",
      "primary_audience": "Founders, brokers, affiliates",
      "core_promise": "Turn one source asset into a fast lead magnet that captures email and qualifies intent",
      "offer_type": "Free / Tripwire",
      "price_low": 0,
      "price_high": 49,
      "billing_model": "Free or one-time",
      "funnel_role": "TOFU",
      "launch_priority": "High",
      "rapid_launch_score": 5,
      "use_stripe": "Yes",
      "use_vercel": "Yes"
    },
    {
      "id": "creator-toolkit-vault",
      "name": "Creator Toolkit Vault",
      "rank": 2,
      "brand_lane": "Full-Time Hustler",
      "offer_family": "Digital Product",
      "offer_type": "Digital Product",
      "price_low": 29,
      "price_high": 99,
      "funnel_role": "Tripwire",
      "launch_priority": "High",
      "rapid_launch_score": 5
    },
    {
      "id": "asset-studio",
      "name": "Asset Studio",
      "rank": 19,
      "brand_lane": "Cross-Brand",
      "offer_family": "Engineering-as-Marketing",
      "offer_type": "Premium Build",
      "price_low": 4000,
      "price_high": 12000,
      "funnel_role": "BOFU / Differentiator",
      "launch_priority": "High",
      "rapid_launch_score": 5
    }
  ],
  "_note": "Showing 3 of 20 entries. The complete 20-entry registry is in the attached offer-catalog.registry.json file."
}
```

### Example entries

- **Magnet Forge** (Moonshine Capital) — Free/Tripwire lead magnet, $0–49, TOFU.
- **Creator Toolkit Vault** (Full-Time Hustler) — Digital product, $29–99, Tripwire.
- **Asset Studio** (Cross-Brand) — Premium build, $4,000–12,000, BOFU differentiator.

The complete 20-offer registry is attached in the **File** property above.
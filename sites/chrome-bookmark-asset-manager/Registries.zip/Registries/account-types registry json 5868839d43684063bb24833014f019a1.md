# account-types.registry.json

Description: Normalizes the kinds of credit referenced across the tiers (net-30, fleet-fuel, store-revolving, installment, business card, bank LOC, term loan, SBA).
Suggested Fields: type_id, name, tier, builds, typical_use
File: account-types.registry.json
Last Updated: June 18, 2026 8:55 PM

<aside>
🎯

Canonical account-type taxonomy so vendors, tiers, and products all reference the same keys.

</aside>

## Completed Registry — account-types.registry.json

```json
[
  { "type_id": "net-30", "name": "Net 30 Vendor Tradeline", "tier": 1, "builds": "tradeline", "typical_use": "Starter EIN-only credit; pay invoices early to build Paydex." },
  { "type_id": "service", "name": "Service / Credit-Builder Subscription", "tier": 1, "builds": "tradeline", "typical_use": "Paid services (NAV, eCredable, Tillful) that report payment history as tradelines." },
  { "type_id": "installment", "name": "Installment Credit Builder", "tier": 1, "builds": "installment", "typical_use": "CreditStrong-style installment loans that add depth without borrowing cash." },
  { "type_id": "fleet-fuel", "name": "Fleet & Fuel Card", "tier": 2, "builds": "revolving", "typical_use": "Vehicle/fuel expenses; signals a maturing business managing recurring spend." },
  { "type_id": "store-revolving", "name": "Revolving Store Account", "tier": 2, "builds": "revolving", "typical_use": "Higher-limit retail accounts (Amazon, Lowe's, Home Depot); keep utilization under 30%." },
  { "type_id": "business-credit-card", "name": "Business Credit Card (Cash Credit)", "tier": 3, "builds": "revolving", "typical_use": "Visa/Mastercard or fintech cards (Brex, Ramp, Divvy); true revolving cash credit." },
  { "type_id": "bank-LOC", "name": "Bank Line of Credit", "tier": 4, "builds": "revolving", "typical_use": "Reusable draw-down funds; banks weigh time in business, revenue, and cash flow." },
  { "type_id": "term-loan", "name": "Fixed Term Loan (Non-SBA)", "tier": 4, "builds": "installment", "typical_use": "Lump-sum financing from a bank or online lender; depends on DSCR and credit strength." },
  { "type_id": "sba-loan", "name": "SBA Loan (7a / 504)", "tier": 4, "builds": "installment", "typical_use": "Government-backed financing; longest terms, lowest rates, heaviest documentation." }
]
```

## Drafting & Schema Details

### 🧱 Suggested Fields

```json
{
  "type_id": "",
  "name": "",
  "tier": 1,
  "builds": "",
  "typical_use": ""
}
```

### 📌 Example entry

```json
{
  "type_id": "net-30",
  "name": "Net 30 Vendor Tradeline",
  "tier": 1,
  "builds": "tradeline",
  "typical_use": "Starter EIN-only credit; pay invoices early to build Paydex."
}
```
# partner-onboarding-config.registry.json

Description: Taxonomy/config for the Moonshine Capital Partners CRM recruitment pipeline: statuses, sequence stages, onboarding paths, partner lanes, lead sources, engagement levels, and self-description archetypes.
Suggested Fields: id, dimension, value, notes
File: partner-onboarding-config.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
⚙️

**Single responsibility** — The option/config values powering the Moonshine Capital Partners CRM partner-recruitment pipeline: every dropdown dimension and its allowed values (54 options).

</aside>

## Completed Registry — partner-onboarding-config.registry.json

[partner-onboarding-config.registry.json](partner-onboarding-config.registry.json)

partner-onboarding-config.registry.json

<aside>
✅

The attached completed JSON file is the primary source of truth. The sections below are secondary drafting/schema notes and compact previews.

</aside>

## Drafting & Schema Details

### Suggested fields

- `id` — kebab-case slug
- `dimension` — config dimension
- `value` — option value
- `notes` — optional notes

### Registry JSON

```json
{
  "id": "partner-onboarding-config",
  "name": "partner-onboarding-config",
  "source": "Manual",
  "visibility": "Internal",
  "fields": {
    "id": "kebab-case slug",
    "dimension": "Config dimension",
    "value": "Option value"
  },
  "entries": [
    { "id": "partner-lane-broker-closer", "dimension": "Partner Lane", "value": "Broker / Closer" },
    { "id": "onboarding-path-dac", "dimension": "Onboarding Path", "value": "DAC" }
  ]
}
```

### Example entries

- **Status** — New Lead, Contacted, In Discussion, Onboarding, Active Partner, Not Interested.
- **Partner Lane** — Broker / Closer, Affiliate / Content, Agency / Team Lead, Lender / Funding Source, Other.
- **Self Description** — 9 archetypes (e.g. “Street-smart and resourceful”, “Coachable and hungry”).
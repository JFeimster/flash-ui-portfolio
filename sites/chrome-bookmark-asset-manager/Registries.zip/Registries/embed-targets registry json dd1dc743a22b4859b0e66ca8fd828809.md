# embed-targets.registry.json

Description: Useful once tools get embedded on Moonshine, Full-Time Hustler, partner sites, etc.
Last Updated: June 9, 2026 4:16 AM
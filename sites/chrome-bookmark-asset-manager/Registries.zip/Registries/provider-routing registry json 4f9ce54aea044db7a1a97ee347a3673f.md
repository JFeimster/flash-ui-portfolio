# provider-routing.registry.json

Description: Maps tool outcomes / personas / categories to internal partner destinations.
Suggested Fields: rule_id, persona, category, outcome, provider, destination_url, weight
Last Updated: June 9, 2026 3:35 AM

<aside>
🎯

Maps tool outcomes, personas, and categories to internal partner destinations. The decision layer behind routing.

</aside>

### 🧱 Suggested Fields

```json
{
  "rule_id": "",
  "persona": "",
  "category": "",
  "outcome": "",
  "provider": "",
  "destination_url": "",
  "weight": 0
}
```
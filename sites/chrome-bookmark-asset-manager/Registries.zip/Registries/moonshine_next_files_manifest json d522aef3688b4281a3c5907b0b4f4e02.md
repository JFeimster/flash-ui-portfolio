# moonshine_next_files_manifest.json

Description: Generation-order manifest listing the 15 supporting files to build after moonshine.v2.json, with order, priority, purpose, and output mode.
Suggested Fields: filename, order, priority, purpose, outputMode
Last Updated: July 3, 2026 8:34 PM

<aside>
🎯

Generation-order manifest listing the 15 supporting files to build after moonshine.v2.json, with order, priority, purpose, and output mode.

</aside>

## moonshine_next_files_manifest.json

[moonshine_next_files_manifest.json](moonshine_next_files_manifest%20json/9559cf17-444c-4d2a-ae59-e1d504f70371.json)

moonshine_next_files_manifest.json

<aside>
✅

The attached file is the source of truth for this entry.

</aside>

### 🧱 Suggested Fields

```json
{
  "filename": "",
  "order": 0,
  "priority": "",
  "purpose": "",
  "outputMode": ""
}
```
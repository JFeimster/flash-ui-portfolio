# flash-ui-vertical-prompts.registry.json

Description: Registry of vertical-specific Flash UI prompt concepts for industry pages and niche business tools.
Suggested Fields: id, name, vertical, asset_type, business_problem, funding_angle, visual_style, prompt, source_file
File: flash-ui-vertical-prompts.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
🗂️

**Purpose:** Registry of vertical-specific Flash UI prompt concepts for industry pages and niche business tools.

</aside>

## Registry summary

- **Registry:** `flash-ui-vertical-prompts.registry.json`
- **Source:** Manual
- **Visibility:** Internal
- **Entries:** 28
- **Suggested fields:** id, name, vertical, asset_type, business_problem, funding_angle, visual_style, prompt, source_file

## Example entries

- **HVAC & Home Services Vertical** — TODO: source section needs full prompt expansion or extraction from nearby lines
- **Commercial Cleaning Vertical** — TODO: source section needs full prompt expansion or extraction from nearby lines
- **Beauty & Salon Vertical** — TODO: source section needs full prompt expansion or extraction from nearby lines

## Full registry JSON

```json
{
  "id": "flash-ui-vertical-prompts",
  "name": "flash-ui-vertical-prompts.registry.json",
  "description": "Registry of vertical-specific Flash UI prompt concepts for industry pages and niche business tools.",
  "source": "Manual",
  "visibility": "Internal",
  "fields": {
    "id": "kebab-case unique id",
    "name": "vertical prompt name",
    "vertical": "vertical identifier",
    "asset_type": "asset type",
    "business_problem": "problem addressed",
    "funding_angle": "funding/finance angle",
    "visual_style": "visual style",
    "prompt": "prompt or TODO if source section needs expansion",
    "source_file": "source file name"
  },
  "entries": [
    {
      "id": "hvac-and-home-services-vertical",
      "name": "HVAC & Home Services Vertical",
      "vertical": "hvac-and-home-services",
      "asset_type": "vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: source section needs full prompt expansion or extraction from nearby lines",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "commercial-cleaning-vertical",
      "name": "Commercial Cleaning Vertical",
      "vertical": "commercial-cleaning",
      "asset_type": "vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: source section needs full prompt expansion or extraction from nearby lines",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "beauty-and-salon-vertical",
      "name": "Beauty & Salon Vertical",
      "vertical": "beauty-and-salon",
      "asset_type": "vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: source section needs full prompt expansion or extraction from nearby lines",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "mobile-app-and-saas-startup-vertical",
      "name": "Mobile App & SaaS Startup Vertical",
      "vertical": "mobile-app-and-saas-startup",
      "asset_type": "vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: source section needs full prompt expansion or extraction from nearby lines",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "manufacturing-and-production-vertical",
      "name": "Manufacturing & Production Vertical",
      "vertical": "manufacturing-and-production",
      "asset_type": "vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: source section needs full prompt expansion or extraction from nearby lines",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "online-course-creator-vertical",
      "name": "Online Course Creator Vertical",
      "vertical": "online-course-creator",
      "asset_type": "vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: source section needs full prompt expansion or extraction from nearby lines",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "bicycle-and-outdoor-recreation-shop-vertical",
      "name": "Bicycle & Outdoor Recreation Shop Vertical",
      "vertical": "bicycle-and-outdoor-recreation-shop",
      "asset_type": "vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: source section needs full prompt expansion or extraction from nearby lines",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "pet-services-and-veterinary-vertical",
      "name": "Pet Services & Veterinary Vertical",
      "vertical": "pet-services-and-veterinary",
      "asset_type": "vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: source section needs full prompt expansion or extraction from nearby lines",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "subscription-box-business-vertical",
      "name": "Subscription Box Business Vertical",
      "vertical": "subscription-box-business",
      "asset_type": "vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: source section needs full prompt expansion or extraction from nearby lines",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "vacation-rental-and-airbnb-host-vertical",
      "name": "Vacation Rental & Airbnb Host Vertical",
      "vertical": "vacation-rental-and-airbnb-host",
      "asset_type": "vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: source section needs full prompt expansion or extraction from nearby lines",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "laboratory-and-testing-services-vertical",
      "name": "Laboratory & Testing Services Vertical",
      "vertical": "laboratory-and-testing-services",
      "asset_type": "vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: source section needs full prompt expansion or extraction from nearby lines",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "construction-and-contractor-vertical",
      "name": "Construction & Contractor Vertical",
      "vertical": "construction-and-contractor",
      "asset_type": "vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: source section needs full prompt expansion or extraction from nearby lines",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "e-commerce-and-amazon-seller-vertical",
      "name": "E-commerce & Amazon Seller Vertical",
      "vertical": "e-commerce-and-amazon-seller",
      "asset_type": "vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: source section needs full prompt expansion or extraction from nearby lines",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "restaurant-and-hospitality-vertical",
      "name": "Restaurant & Hospitality Vertical",
      "vertical": "restaurant-and-hospitality",
      "asset_type": "vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: source section needs full prompt expansion or extraction from nearby lines",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "auto-repair-and-service-vertical",
      "name": "Auto Repair & Service Vertical",
      "vertical": "auto-repair-and-service",
      "asset_type": "vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: source section needs full prompt expansion or extraction from nearby lines",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "law-firm-and-legal-services-vertical",
      "name": "Law Firm & Legal Services Vertical",
      "vertical": "law-firm-and-legal-services",
      "asset_type": "vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: source section needs full prompt expansion or extraction from nearby lines",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "fitness-studio-and-gym-vertical",
      "name": "Fitness Studio & Gym Vertical",
      "vertical": "fitness-studio-and-gym",
      "asset_type": "vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: source section needs full prompt expansion or extraction from nearby lines",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "real-estate-investor-vertical",
      "name": "Real Estate Investor Vertical",
      "vertical": "real-estate-investor",
      "asset_type": "vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: source section needs full prompt expansion or extraction from nearby lines",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "event-planning-and-catering-vertical",
      "name": "Event Planning & Catering Vertical",
      "vertical": "event-planning-and-catering",
      "asset_type": "vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: source section needs full prompt expansion or extraction from nearby lines",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "healthcare-practice-vertical",
      "name": "Healthcare Practice Vertical",
      "vertical": "healthcare-practice",
      "asset_type": "vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: source section needs full prompt expansion or extraction from nearby lines",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "creative-agency-and-studio-vertical",
      "name": "Creative Agency & Studio Vertical",
      "vertical": "creative-agency-and-studio",
      "asset_type": "vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: source section needs full prompt expansion or extraction from nearby lines",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "education-and-tutoring-vertical",
      "name": "Education & Tutoring Vertical",
      "vertical": "education-and-tutoring",
      "asset_type": "vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: source section needs full prompt expansion or extraction from nearby lines",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "logistics-and-transportation-vertical",
      "name": "Logistics & Transportation Vertical",
      "vertical": "logistics-and-transportation",
      "asset_type": "vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: source section needs full prompt expansion or extraction from nearby lines",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "nonprofit-and-social-enterprise-vertical",
      "name": "Nonprofit & Social Enterprise Vertical",
      "vertical": "nonprofit-and-social-enterprise",
      "asset_type": "vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: source section needs full prompt expansion or extraction from nearby lines",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "business-credit-building-credit-stacking-pillar",
      "name": "Business Credit Building / Credit Stacking Pillar",
      "vertical": "business-credit-building-credit-stacking-pillar",
      "asset_type": "pillar_or_vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: expand from source section",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "embedded-financing-for-b2b-platforms-saas",
      "name": "Embedded Financing for B2B Platforms / SaaS",
      "vertical": "embedded-financing-for-b2b-platforms-saas",
      "asset_type": "pillar_or_vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: expand from source section",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "lead-generation-and-marketing-automation-tools",
      "name": "Lead Generation & Marketing Automation Tools",
      "vertical": "lead-generation-and-marketing-automation-tools",
      "asset_type": "pillar_or_vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: expand from source section",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    },
    {
      "id": "network-growth-and-community-building",
      "name": "Network Growth & Community Building",
      "vertical": "network-growth-and-community-building",
      "asset_type": "pillar_or_vertical_prompt",
      "business_problem": "TODO",
      "funding_angle": "TODO",
      "visual_style": "TODO",
      "prompt": "TODO: expand from source section",
      "source_file": "FLASH UI Template Library (Google AI Studio).md"
    }
  ]
}
```
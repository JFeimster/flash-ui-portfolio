# personas.registry.json

Description: Personas extracted from funding tools so tools, content, and CTAs can reuse them.
Suggested Fields: persona_id, name, segment, pains, goals, funding_fit, tone
Last Updated: June 9, 2026 3:34 AM

<aside>
🎯

You already have personas inside funding tools. Extract them here so tools, content, and CTAs can reuse them.

</aside>

### 🧱 Suggested Fields

```json
{
  "persona_id": "",
  "name": "",
  "segment": "",
  "pains": [],
  "goals": [],
  "funding_fit": "",
  "tone": ""
}
```
# imported.registry.json

Last Updated: June 9, 2026 3:36 AM

<aside>
📄

Template for registries built from a CSV / export. Attach the source file below and normalize it with the **Normalize pasted CSV** AI block or the Import Engine.

</aside>

### 📎 Source file

Drop the CSV/export into the **File** property, then note the original column headers here:

```
column_1, column_2, column_3, ...
```

### 🧱 Target schema

```json
{
  "id": "",
  "title": "",
  "brand": "",
  "audience": "",
  "problem": "",
  "assetType": "",
  "tier": "",
  "coreLogic": ""
}
```

### ✅ Import checklist

- [ ]  File attached
- [ ]  Columns mapped to schema fields
- [ ]  Rows normalized
- [ ]  Validated against schema
- [ ]  Source set to `CSV Import`
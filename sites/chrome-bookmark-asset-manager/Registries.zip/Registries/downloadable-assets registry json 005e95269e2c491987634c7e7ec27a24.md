# downloadable-assets.registry.json

Description: Useful once PDFs/checklists/templates become outputs.
Last Updated: June 9, 2026 4:16 AM
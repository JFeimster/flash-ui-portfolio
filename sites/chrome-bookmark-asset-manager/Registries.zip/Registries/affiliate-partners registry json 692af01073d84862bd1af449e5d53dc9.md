# affiliate-partners.registry.json

Description: The routing brain — private registry of affiliate partners, payouts, and links.
Suggested Fields: partner_id, name, category, payout, links, status
Last Updated: June 9, 2026 3:35 AM

<aside>
🎯

The routing brain. A private registry of affiliate partners with payouts, links, and status. Connect rows to the Funding Partners Database via **Linked Sources / Tools**.

</aside>

### 🧱 Suggested Fields

```json
{
  "partner_id": "",
  "name": "",
  "category": "",
  "payout": "",
  "links": [],
  "status": ""
}
```

### 🤝 Known partners to seed

DAC / Bank Breezy, GoKapital, National Business Capital, Lendio, Fundera, Fund&Grow, Credit Suite, Nav, Sphere, Rellevate, SellersFi, Uncapped, Capchase, Onramp Funds, 8fig
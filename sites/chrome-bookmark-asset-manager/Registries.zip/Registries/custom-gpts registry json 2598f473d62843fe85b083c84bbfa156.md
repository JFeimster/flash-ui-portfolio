# custom-gpts.registry.json

Description: Catalog of built/published custom GPTs with their pain point, funnel stage, audience persona, output type, category, tier, and access URL.
Suggested Fields: id, name, description, core_pain_point, funnel_stage, audience_persona, output_type, category, tier, access_url, status
File: custom-gpts.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
🤖

**Single responsibility:** Track every custom GPT asset (name, purpose, audience, funnel role, access link) so the portfolio is searchable and deployable. Source: My Custom GPTs database (52 captured rows).

</aside>

## Completed Registry — custom-gpts.registry.json

[custom-gpts.registry.json](custom-gpts.registry.json)

custom-gpts.registry.json

<aside>
✅

The attached completed JSON file is the primary source of truth. The sections below are secondary drafting/schema notes and compact previews.

</aside>

## Drafting & Schema Details

### Suggested fields

- `id` — kebab-case unique id
- `name` — GPT name
- `description` — what the GPT does
- `core_pain_point` — pain it solves (TODO where source was blank)
- `funnel_stage` — Lead Magnet / Front-End / etc.
- `audience_persona` — target personas
- `output_type` — Report / Template / Plan / etc.
- `category` — domain categories
- `tier` — Starter / Pro / etc.
- `access_url` — ChatGPT GPT URL
- `status` — In Development / Published

### Registry JSON

```json
{
  "id": "custom-gpts",
  "name": "Custom GPTs",
  "source": "CSV Import",
  "visibility": "Internal",
  "fields": {
    "id": "kebab-case unique id",
    "name": "GPT name",
    "description": "what the GPT does",
    "core_pain_point": "pain it solves",
    "funnel_stage": "funnel role",
    "audience_persona": "target personas",
    "output_type": "output produced",
    "category": "domain categories",
    "tier": "pricing/access tier",
    "access_url": "GPT URL",
    "status": "lifecycle status"
  },
  "entries": [
    {
      "id": "gig-income-organizer-gpt",
      "name": "Gig Income Organizer GPT",
      "description": "Organizes gig worker bank statements and platform earnings into income categories, averages, gaps, readiness notes, and lender-fit recommendations.",
      "funnel_stage": "Lead Magnet",
      "audience_persona": ["Side Hustler", "Freelancer", "Pre-Bankable SMB"],
      "tier": "Starter",
      "access_url": "https://chatgpt.com/g/g-6a20fe02fe288191ad5733e3da824b74-gig-income-organizer",
      "status": "In Development"
    },
    {
      "id": "resumetailor-ai",
      "name": "ResumeTailor AI",
      "description": "Upload docs, paste job descriptions, export tailored resumes (PDF/DOCX), auto-detect missing skills, generate cover letters, job fit score.",
      "tier": "Starter",
      "status": "Published"
    }
  ]
}
```

### Example entries

- **Gig Income Organizer GPT** — organizes gig income into lender-ready readiness notes (Lead Magnet, In Development).
- **ResumeTailor AI** — tailors resumes to job descriptions with fit scoring (Published).
- **Sales Funnel Builder GPT** — builds sales funnels (Sales & Client Relations, Published).

*Complete data (52 entries) is in the attached `custom-gpts.registry.json`.*
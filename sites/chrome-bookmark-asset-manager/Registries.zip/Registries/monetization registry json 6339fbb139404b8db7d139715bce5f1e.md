# monetization.registry.json

Description: Useful, but keep internal. Tie tools to affiliate products, paid packs, sponsor placements.
Last Updated: June 9, 2026 4:16 AM
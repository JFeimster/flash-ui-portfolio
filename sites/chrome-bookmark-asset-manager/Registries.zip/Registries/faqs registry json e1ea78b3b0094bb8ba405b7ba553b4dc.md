# faqs.registry.json

Description: Reusable Q&A across every landing page/embed instead of re-authoring per site. One record per FAQ with category and tags.
Suggested Fields: id, question, answer, category, tags, status, schemaVersion, superseded, supersededBy, updatedAt
Last Updated: June 18, 2026 12:35 PM

<aside>
🎯

A single reusable FAQ bank shared across every landing page and embed — author once, reference everywhere instead of re-writing per site.

</aside>

### 🧱 Suggested Fields

```json
{
  "id": "",
  "question": "",
  "answer": "",
  "category": "",
  "tags": [],
  "status": "active",
  "schemaVersion": "1.0.0",
  "superseded": false,
  "supersededBy": null,
  "updatedAt": ""
}
```

### 📌 Example entry

```json
[
  { "id": "what-is-net-30", "question": "What is a net-30 vendor account?", "answer": "A trade account that lets your business buy now and pay within 30 days; paying early builds your business credit.", "category": "Business Credit", "tags": ["net-30", "tradelines"], "status": "active", "schemaVersion": "1.0.0", "superseded": false, "supersededBy": null, "updatedAt": "2026-06-18" }
]
```
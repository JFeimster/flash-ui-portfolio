# vertical-microsite-config.registry.json

Description: Config registry for vertical referral microsites (real estate, CPAs, contractors, insurance, e-commerce) with hero copy, colors, pain points, benefits, steps, products, and social proof.
Suggested Fields: id, vertical_name, vertical_slug, hero_headline, hero_subheadline, primary_cta, secondary_cta, colors, pain_points, benefits, steps, products, social_proof, domain
File: vertical-microsite-config.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
🌐

**Single responsibility:** Hold the per-vertical content/config that drives the referral microsite/landing-page generator so each vertical page renders from data.

</aside>

## Completed Registry — vertical-microsite-config.registry.json

[vertical-microsite-config.registry.json](vertical-microsite-config.registry.json)

vertical-microsite-config.registry.json

<aside>
✅

The attached completed JSON file is the primary source of truth. The sections below are secondary drafting/schema notes and compact previews.

</aside>

## Drafting & Schema Details

### Suggested fields

- `id`, `vertical_name`, `vertical_slug`
- `hero_headline`, `hero_subheadline`, `primary_cta`, `secondary_cta`
- `colors` — palette
- `pain_points`, `benefits`, `steps`, `products`, `social_proof`
- `domain` — target domain (TODO where not set)

### Registry JSON

```json
{
  "id": "vertical-microsite-config",
  "name": "Vertical Microsite Config",
  "source": "Manual",
  "visibility": "Internal",
  "fields": {
    "vertical_name": "vertical display name",
    "vertical_slug": "url slug",
    "hero_headline": "hero headline",
    "primary_cta": "primary CTA",
    "colors": "palette",
    "pain_points": "pain points",
    "benefits": "benefits",
    "steps": "how-it-works steps",
    "products": "funding products",
    "social_proof": "social proof figures",
    "domain": "target domain"
  },
  "entries": [
    {
      "id": "real-estate",
      "vertical_name": "Real Estate Agents",
      "vertical_slug": "real-estate",
      "hero_headline": "Turn Your Closed Deals Into Recurring Income",
      "primary_cta": "Become a Funding Partner",
      "colors": "Primary #2563eb, Secondary #10b981, Accent #f59e0b",
      "social_proof": "$2K-$10K/month; 500+ active real estate partners; $12M funded",
      "domain": "TODO"
    }
  ]
}
```

### Example entries

- **Real Estate Agents** — "Turn Your Closed Deals Into Recurring Income" (blue/green/gold).
- **CPAs & Tax Professionals** — "Help Clients Grow While Growing Your Practice".
- **Contractors** — "Stop Losing Bids Because of Cash Flow".

*Complete data (5 verticals) is in the attached `vertical-microsite-config.registry.json`.*
# gpt-assets.registry.json

Description: Catalog of GPT / AI assets and their outputs (the attached registry file).
Suggested Fields: asset_id, name, type, source_gpt, file, tags, status
File: gpt-assets.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
🎯

Catalog of GPT / AI assets and their outputs. This is the registry you attached (`gpt-assets.registry.json`) — drop the file into the **File** property to keep the source with the entry.

</aside>

## Completed Registry — gpt-assets.registry.json

[gpt-assets.registry.json](gpt-assets.registry.json)

gpt-assets.registry.json

<aside>
✅

The attached completed JSON file is the primary source of truth. The sections below are secondary drafting/schema notes and schema placeholders.

</aside>

## Drafting & Schema Details

### 🧱 Suggested Fields

```json
{
  "asset_id": "",
  "name": "",
  "type": "",
  "source_gpt": "",
  "file": "",
  "tags": [],
  "status": ""
}
```
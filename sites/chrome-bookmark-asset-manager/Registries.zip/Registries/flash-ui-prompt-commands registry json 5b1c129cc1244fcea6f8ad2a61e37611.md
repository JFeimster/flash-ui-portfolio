# flash-ui-prompt-commands.registry.json

Description: Registry of reusable Flash-UI Prompt Architect slash commands and command intents for turning rough concepts into structured prompts, tools, dashboards, widgets, repo guidance, and monetization layers.
Suggested Fields: id, name, command, purpose, output_type, best_for, input_needed, expected_output, source_file
File: flash-ui-prompt-commands.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
🗂️

**Purpose:** Registry of reusable Flash-UI Prompt Architect slash commands and command intents for turning rough concepts into structured prompts, tools, dashboards, widgets, repo guidance, and monetization layers.

</aside>

## Registry summary

- **Registry:** `flash-ui-prompt-commands.registry.json`
- **Source:** Manual
- **Visibility:** Internal
- **Entries:** 12
- **Suggested fields:** id, name, command, purpose, output_type, best_for, input_needed, expected_output, source_file

## Example entries

- **Flashprompt** — Turn a raw idea into a complete optimized Flash-UI prompt.
- **Landingpage** — Generate a Flash-UI prompt for a conversion-focused landing page.
- **Tool** — Generate a Flash-UI prompt for an interactive tool, calculator, quiz, checklist, or assessment.

## Full registry JSON

```json
{
  "id": "flash-ui-prompt-commands",
  "name": "flash-ui-prompt-commands.registry.json",
  "description": "Registry of reusable Flash-UI Prompt Architect slash commands and command intents for turning rough concepts into structured prompts, tools, dashboards, widgets, repo guidance, and monetization layers.",
  "source": "Manual",
  "visibility": "Internal",
  "fields": {
    "id": "kebab-case unique id",
    "name": "command display name",
    "command": "slash command",
    "purpose": "what the command does",
    "output_type": "expected artifact type",
    "best_for": "best use case",
    "input_needed": "what the user should provide",
    "expected_output": "what the command returns",
    "source_file": "source file name"
  },
  "entries": [
    {
      "id": "flashprompt",
      "name": "Flashprompt",
      "command": "/flashprompt",
      "purpose": "Turn a raw idea into a complete optimized Flash-UI prompt.",
      "output_type": "Prompt Template",
      "best_for": "TODO",
      "input_needed": "raw idea or prompt",
      "expected_output": "structured Flash-UI instructions",
      "source_file": "Flash-UI Prompt Architect.md"
    },
    {
      "id": "landingpage",
      "name": "Landingpage",
      "command": "/landingpage",
      "purpose": "Generate a Flash-UI prompt for a conversion-focused landing page.",
      "output_type": "Landing Page",
      "best_for": "TODO",
      "input_needed": "raw idea or prompt",
      "expected_output": "structured Flash-UI instructions",
      "source_file": "Flash-UI Prompt Architect.md"
    },
    {
      "id": "tool",
      "name": "Tool",
      "command": "/tool",
      "purpose": "Generate a Flash-UI prompt for an interactive tool, calculator, quiz, checklist, or assessment.",
      "output_type": "Calculator",
      "best_for": "TODO",
      "input_needed": "raw idea or prompt",
      "expected_output": "structured Flash-UI instructions",
      "source_file": "Flash-UI Prompt Architect.md"
    },
    {
      "id": "dashboard",
      "name": "Dashboard",
      "command": "/dashboard",
      "purpose": "Generate a Flash-UI prompt for a dashboard or command center interface.",
      "output_type": "Dashboard",
      "best_for": "TODO",
      "input_needed": "raw idea or prompt",
      "expected_output": "structured Flash-UI instructions",
      "source_file": "Flash-UI Prompt Architect.md"
    },
    {
      "id": "widget",
      "name": "Widget",
      "command": "/widget",
      "purpose": "Generate a Flash-UI prompt for an embeddable widget.",
      "output_type": "Prompt Template",
      "best_for": "TODO",
      "input_needed": "raw idea or prompt",
      "expected_output": "structured Flash-UI instructions",
      "source_file": "Flash-UI Prompt Architect.md"
    },
    {
      "id": "repo",
      "name": "Repo",
      "command": "/repo",
      "purpose": "Convert a Flash-UI concept into repo-ready project guidance.",
      "output_type": "Prompt Template",
      "best_for": "TODO",
      "input_needed": "raw idea or prompt",
      "expected_output": "structured Flash-UI instructions",
      "source_file": "Flash-UI Prompt Architect.md"
    },
    {
      "id": "monetize",
      "name": "Monetize",
      "command": "/monetize",
      "purpose": "Add monetization strategy to an existing Flash-UI project prompt.",
      "output_type": "Prompt Template",
      "best_for": "TODO",
      "input_needed": "raw idea or prompt",
      "expected_output": "structured Flash-UI instructions",
      "source_file": "Flash-UI Prompt Architect.md"
    },
    {
      "id": "upgrade",
      "name": "Upgrade",
      "command": "/upgrade",
      "purpose": "Improve an existing Flash-UI prompt.",
      "output_type": "Prompt Template",
      "best_for": "TODO",
      "input_needed": "raw idea or prompt",
      "expected_output": "structured Flash-UI instructions",
      "source_file": "Flash-UI Prompt Architect.md"
    },
    {
      "id": "variants",
      "name": "Variants",
      "command": "/variants",
      "purpose": "Generate multiple prompt directions from one idea.",
      "output_type": "Prompt Template",
      "best_for": "TODO",
      "input_needed": "raw idea or prompt",
      "expected_output": "structured Flash-UI instructions",
      "source_file": "Flash-UI Prompt Architect.md"
    },
    {
      "id": "killfluff",
      "name": "Killfluff",
      "command": "/killfluff",
      "purpose": "Remove vague language from a prompt.",
      "output_type": "Prompt Template",
      "best_for": "TODO",
      "input_needed": "raw idea or prompt",
      "expected_output": "structured Flash-UI instructions",
      "source_file": "Flash-UI Prompt Architect.md"
    },
    {
      "id": "brandfit",
      "name": "Brandfit",
      "command": "/brandfit",
      "purpose": "Align a Flash-UI prompt with a specific brand or business ecosystem.",
      "output_type": "Prompt Template",
      "best_for": "TODO",
      "input_needed": "raw idea or prompt",
      "expected_output": "structured Flash-UI instructions",
      "source_file": "Flash-UI Prompt Architect.md"
    },
    {
      "id": "staticexport",
      "name": "Staticexport",
      "command": "/staticexport",
      "purpose": "Optimize a prompt for static HTML/CSS/JS or static deployability.",
      "output_type": "Prompt Template",
      "best_for": "TODO",
      "input_needed": "raw idea or prompt",
      "expected_output": "structured Flash-UI instructions",
      "source_file": "Flash-UI Prompt Architect.md"
    }
  ]
}
```
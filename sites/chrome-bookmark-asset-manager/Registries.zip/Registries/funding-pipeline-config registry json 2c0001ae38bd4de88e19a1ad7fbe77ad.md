# funding-pipeline-config.registry.json

Description: Taxonomy/config for the funding applicant pipeline: lead statuses, funding lanes, revenue bands, business age, account type, sources, priorities, close reasons, and partner review statuses.
Suggested Fields: id, dimension, value, applies_to, notes
File: funding-pipeline-config.registry.json
Last Updated: June 26, 2026 12:46 AM

<aside>
⚙️

**Single responsibility** — The option/config values powering the funding pipeline (CRM - Funding Review Requests): every dropdown dimension and its allowed values (43 options).

</aside>

## Completed Registry — funding-pipeline-config.registry.json

[funding-pipeline-config.registry.json](funding-pipeline-config.registry.json)

funding-pipeline-config.registry.json

<aside>
✅

The attached completed JSON file is the primary source of truth. The sections below are secondary drafting/schema notes and compact previews.

</aside>

## Drafting & Schema Details

### Suggested fields

- `id` — kebab-case slug
- `dimension` — config dimension
- `value` — option value
- `applies_to` — source database
- `notes` — optional notes

### Registry JSON

```json
{
  "id": "funding-pipeline-config",
  "name": "funding-pipeline-config",
  "source": "Manual",
  "visibility": "Internal",
  "fields": {
    "id": "kebab-case slug",
    "dimension": "Config dimension",
    "value": "Option value",
    "applies_to": "Source database"
  },
  "entries": [
    { "id": "funding-lane-giggle-instant-approval", "dimension": "Funding Lane", "value": "Giggle Instant Approval", "applies_to": "Funding Pipeline" },
    { "id": "lead-status-needs-applicant-action", "dimension": "Lead Status", "value": "Needs Applicant Action", "applies_to": "Funding Pipeline" }
  ]
}
```

### Example entries

- **Funding Lane** — Giggle Instant Approval, BankBreezy CoreRate, BankBreezy FlexRate, Needs Manual Review.
- **Lead Status** — New, Contacted, In Progress, Needs Applicant Action, Won, Lost, Closed.
- **Revenue Band**, **Source**, **Close Reason**, **Partner Status** (Funding Status Updates).
# manifest.json

Description: Control-file manifest for Moonshine Capital mapping brand/vertical paths to their *.control.json files, guaranteeing each carries a contentSources object (notion, repos, sites, templates).
Suggested Fields: label, path, filename, version, guarantee
Last Updated: July 3, 2026 8:36 PM

<aside>
🎯

Control-file manifest for Moonshine Capital. Maps brand/vertical paths to their control.json files and guarantees each carries a contentSources object (notion, repos, sites, templates).

</aside>

## manifest.json

[manifest.json](manifest%20json/d5b4ddc5-7bff-4f62-b09a-99e78dd54132.json)

manifest.json

<aside>
✅

The attached file is the source of truth for this entry.

</aside>

### 🧱 Suggested Fields

```json
{
  "version": "",
  "generatedFor": "",
  "guarantee": "",
  "files": [
    { "label": "", "path": "", "filename": "" }
  ]
}
```
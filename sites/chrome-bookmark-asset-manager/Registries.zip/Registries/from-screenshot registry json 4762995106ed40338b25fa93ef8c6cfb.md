# from-screenshot.registry.json

Last Updated: June 9, 2026 3:36 AM

<aside>
📸

Template for capturing a registry from a screenshot (e.g. a ChatGPT "Core Tools" review). Drop the image into **File**, then run the **Extract from screenshot** AI block.

</aside>

### 🖼️ Screenshot

Attach the screenshot to the **File** property above.

### 🧠 Extracted notes

*Paste or let AI fill what the screenshot says about this registry: purpose, priority, visibility, fields.*

### 🧱 Suggested Fields

```json
{
  "id": "",
  "name": ""
}
```

<aside>
✅

Once reviewed, change **Source** to `Manual` and update **Status**.

</aside>
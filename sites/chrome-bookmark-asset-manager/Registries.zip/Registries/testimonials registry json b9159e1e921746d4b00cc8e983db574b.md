# testimonials.registry.json

Description: Reusable social-proof quotes across every landing page/embed. One record per testimonial. Use only real, permissioned quotes.
Suggested Fields: id, name, title, company, quote, avatar_url, rating, status, schemaVersion, superseded, supersededBy, updatedAt
Last Updated: June 18, 2026 12:35 PM

<aside>
🎯

Reusable social-proof bank shared across landing pages and embeds. ⚠️ Populate only with real, permissioned quotes — the example below is a placeholder.

</aside>

### 🧱 Suggested Fields

```json
{
  "id": "",
  "name": "",
  "title": "",
  "company": "",
  "quote": "",
  "avatar_url": "",
  "rating": 5,
  "status": "active",
  "schemaVersion": "1.0.0",
  "superseded": false,
  "supersededBy": null,
  "updatedAt": ""
}
```

### 📌 Example entry

```json
[
  { "id": "sample-1", "name": "Sample Client", "title": "Owner", "company": "Acme LLC", "quote": "Placeholder testimonial — replace with a real, permissioned quote.", "avatar_url": "", "rating": 5, "status": "active", "schemaVersion": "1.0.0", "superseded": false, "supersededBy": null, "updatedAt": "2026-06-18" }
]
```
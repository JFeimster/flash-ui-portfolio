# credit-building-stages.registry.json

Description: The staged build sequence (phases/stages with month ranges, target tradelines/Paydex, and recommended vendors) — feeds a roadmap/progress tracker.
Suggested Fields: stage_id, name, month_range, target_tradelines, target_paydex, actions, recommended_vendors
File: credit-building-stages.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
🎯

The month-by-month build sequence. References vendor `id`s from `credit-vendors.registry.json`.

</aside>

## Completed Registry — credit-building-stages.registry.json

```json
[
  {
    "stage_id": "stage-0-foundation",
    "name": "Prepare the Fundability Foundation",
    "month_range": "pre-launch",
    "target_tradelines": 0,
    "target_paydex": null,
    "actions": ["Register entity and obtain EIN", "List business phone with 411", "Set up business address, domain, email, and bank account", "Obtain D-U-N-S number"],
    "recommended_vendors": []
  },
  {
    "stage_id": "phase-1",
    "name": "Establish First 3-5 Vendor Tradelines",
    "month_range": "0-2",
    "target_tradelines": 5,
    "target_paydex": null,
    "actions": ["Apply to 3-5 starter vendors", "Place prepaid orders, then request Net 30", "Pay invoices 10-15 days early", "Allow 30-60 days for tradelines to post"],
    "recommended_vendors": ["uline", "quill", "crown-office", "summa-office-supplies", "the-ceo-creative"]
  },
  {
    "stage_id": "phase-2",
    "name": "Diversify and Build Depth",
    "month_range": "2-4",
    "target_tradelines": 8,
    "target_paydex": 75,
    "actions": ["Add 3-4 more reporting vendors", "Add physical-supply vendors once 2-3 accounts report", "Span multiple bureaus and categories"],
    "recommended_vendors": ["nav-business-credit-builder", "strategic-network-solutions", "shirtsy", "creative-analytics", "grainger", "hd-supply", "seton"]
  },
  {
    "stage_id": "phase-3",
    "name": "Add Fleet & Fuel Cards",
    "month_range": "4-6",
    "target_tradelines": 8,
    "target_paydex": 75,
    "actions": ["Apply for fleet/fuel cards once 5-6 accounts report and Paydex 75+", "Use for legitimate vehicle/fuel expenses", "Pay early and consistently"],
    "recommended_vendors": ["wex-fleet", "fleetcor-bp", "fuelman"]
  },
  {
    "stage_id": "phase-4",
    "name": "Add Installment Accounts & Credit Builders",
    "month_range": "4-6",
    "target_tradelines": 9,
    "target_paydex": 80,
    "actions": ["Add installment tradelines to show revolving + installment mix", "Convert utilities into tradelines"],
    "recommended_vendors": ["creditstrong-business", "ecredable-business-lift", "tillful-credit-builder"]
  },
  {
    "stage_id": "stage-6-evaluate",
    "name": "Evaluate Credit Reports",
    "month_range": "6-9",
    "target_tradelines": 10,
    "target_paydex": 80,
    "actions": ["Check D&B CreditSignal, Nav, Experian, Equifax", "Confirm 8-10 tradelines, Paydex 80+, no delinquencies", "Qualify for Tier 2 and Tier 3 accounts"],
    "recommended_vendors": []
  }
]
```

## Drafting & Schema Details

### 🧱 Suggested Fields

```json
{
  "stage_id": "",
  "name": "",
  "month_range": "",
  "target_tradelines": 0,
  "target_paydex": null,
  "actions": [],
  "recommended_vendors": []
}
```

### 📌 Example entry

```json
{
  "stage_id": "phase-1",
  "name": "Establish First 3–5 Vendor Tradelines",
  "month_range": "0-2",
  "target_tradelines": 5,
  "target_paydex": null,
  "actions": ["Apply to 3–5 starter vendors", "Pay invoices 10–15 days early"],
  "recommended_vendors": ["uline", "quill", "crown-office", "summa", "the-ceo-creative"]
}
```
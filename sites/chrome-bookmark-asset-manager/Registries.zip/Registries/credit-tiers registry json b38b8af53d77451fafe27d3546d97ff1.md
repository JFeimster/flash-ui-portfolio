# credit-tiers.registry.json

Description: Tier 1→4 definitions with entry criteria (Paydex, tradelines, time in business, revenue) — drives 'what can I apply for now?' logic.
Suggested Fields: tier_id, name, description, entry_criteria, account_types, goal
File: credit-tiers.registry.json
Last Updated: June 26, 2026 12:43 AM

<aside>
🎯

The four-tier progression model. Each record defines a tier's entry criteria and which account types unlock at that stage.

</aside>

## Completed Registry — credit-tiers.registry.json

```json
[
  {
    "tier_id": 1,
    "name": "Starter Vendor Tradelines",
    "description": "EIN-only net-30 starter vendors that report to D&B/Experian/Equifax. Builds the first 3-8 tradelines and a Paydex score.",
    "entry_criteria": { "paydex_min": null, "tradelines_min": 0, "time_in_business_months": 0, "monthly_revenue_min": null },
    "account_types": ["net-30", "service", "installment"],
    "goal": "Reach a Paydex of 80+ with 5-8 reporting tradelines using only the EIN."
  },
  {
    "tier_id": 2,
    "name": "Revolving Store & Fleet Accounts",
    "description": "Higher-limit store and fleet/fuel accounts. Expects some history but usually no PG with strong fundability.",
    "entry_criteria": { "paydex_min": 80, "tradelines_min": 5, "time_in_business_months": 3, "monthly_revenue_min": null },
    "account_types": ["store-revolving", "fleet-fuel"],
    "goal": "Add operational store/fleet credit; keep utilization under 30% and pay early."
  },
  {
    "tier_id": 3,
    "name": "High-Limit Revolving & Cash Credit",
    "description": "Major store accounts plus true revolving cash credit (Brex, Ramp, Divvy) and early bank lines.",
    "entry_criteria": { "paydex_min": 80, "tradelines_min": 8, "time_in_business_months": 9, "monthly_revenue_min": null },
    "account_types": ["store-revolving", "business-credit-card", "bank-LOC"],
    "goal": "Acquire credit with little or no PG; diversify vendor/fleet/store/revolving mix."
  },
  {
    "tier_id": 4,
    "name": "Bank & SBA Financing",
    "description": "Cash credit lines, bank term loans, SBA loans, and corporate-style cards. Underwritten on business numbers; PG common until business strength is proven.",
    "entry_criteria": { "paydex_min": 80, "tradelines_min": 10, "time_in_business_months": 24, "monthly_revenue_min": 10000 },
    "account_types": ["business-credit-card", "bank-LOC", "term-loan", "sba-loan"],
    "goal": "Access bank lines, term loans, and SBA financing; reduce dependence on the personal guarantee over time."
  }
]
```

## Drafting & Schema Details

### 🧱 Suggested Fields

```json
{
  "tier_id": 1,
  "name": "",
  "description": "",
  "entry_criteria": {
    "paydex_min": null,
    "tradelines_min": 0,
    "time_in_business_months": 0,
    "monthly_revenue_min": null
  },
  "account_types": [],
  "goal": ""
}
```

### 📌 Example entry

```json
{
  "tier_id": 2,
  "name": "Revolving Store & Fleet Accounts",
  "entry_criteria": { "paydex_min": 80, "tradelines_min": 5, "time_in_business_months": 3 },
  "account_types": ["store-revolving", "fleet-fuel"],
  "goal": "Add higher-limit revolving accounts; usually no PG with strong fundability."
}
```
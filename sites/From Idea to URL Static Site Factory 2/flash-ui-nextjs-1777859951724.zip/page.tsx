import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<div class="grid-bg"></div>

    <nav>
        <div class="logo">FLASH_UI / SITE_FACTORY</div>
        <div class="nav-links">
            <a href="#how-it-works">WORKFLOW</a>
            <a href="#examples">EXAMPLES</a>
            <a href="#pricing">PRICING</a>
            <a href="#generate">DASHBOARD</a>
        </div>
    </nav>

    <header>
        <div class="badge">Generation Engine v2.4.0</div>
        <h1 class="neon-text">Turn one prompt into <span>deployable site files.</span></h1>
        <p class="hero-sub">Describe your vision. Our factory compiles multiple optimized HTML/CSS versions ready for your server. No drag-and-drop. No bloat.</p>
        
        <div class="prompt-container">
            <div class="prompt-header">
                <div class="dot active"></div>
                <div class="dot"></div>
                <div class="dot"></div>
            </div>
            <div class="prompt-input-wrapper">
                <span>&gt;</span>
                <input type="text" placeholder="e.g. A dark sleek SaaS landing page for a Web3 analytics tool with price cards and terminal theme..." id="main-prompt">
                <div class="cursor"></div>
            </div>
        </div>
        <button class="btn-generate">Generate My Site</button>
    </header>

    <section id="how-it-works">
        <div class="section-title">Output Variants</div>
        <div class="version-grid">
            <div class="version-card">
                <div class="code-tag">V1 / MODERN</div>
                <div class="preview-pane">
                    <svg width="60" height="40" viewBox="0 0 60 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect width="60" height="40" rx="4" fill="#111"/>
                        <rect x="5" y="5" width="20" height="4" rx="2" fill="var(--electric-blue)"/>
                        <rect x="5" y="15" width="50" height="2" rx="1" fill="#333"/>
                        <rect x="5" y="20" width="40" height="2" rx="1" fill="#333"/>
                    </svg>
                </div>
                <div class="card-meta">
                    <h3>Clean Landing</h3>
                    <p>High-conversion layout with Inter typography and utility CSS.</p>
                </div>
            </div>
            <div class="version-card">
                <div class="code-tag">V2 / DARK</div>
                <div class="preview-pane">
                    <svg width="60" height="40" viewBox="0 0 60 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect width="60" height="40" rx="4" fill="#000"/>
                        <circle cx="30" cy="20" r="10" stroke="var(--cyber-pink)" stroke-width="1"/>
                        <rect x="20" y="32" width="20" height="2" rx="1" fill="#222"/>
                    </svg>
                </div>
                <div class="card-meta">
                    <h3>Cyber Visuals</h3>
                    <p>Neon accents, grid backgrounds, and framer-motion ready components.</p>
                </div>
            </div>
            <div class="version-card">
                <div class="code-tag">V3 / APP</div>
                <div class="preview-pane">
                    <svg width="60" height="40" viewBox="0 0 60 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect width="60" height="40" rx="4" fill="#111"/>
                        <rect x="0" y="0" width="15" height="40" fill="#0a0a0a"/>
                        <rect x="20" y="5" width="35" height="10" rx="2" fill="#1a1a1a"/>
                        <rect x="20" y="20" width="15" height="15" rx="2" fill="#1a1a1a"/>
                        <rect x="40" y="20" width="15" height="15" rx="2" fill="#1a1a1a"/>
                    </svg>
                </div>
                <div class="card-meta">
                    <h3>SaaS Dashboard</h3>
                    <p>Sidebar navigation, data viz containers, and user settings UI.</p>
                </div>
            </div>
        </div>
    </section>

    <section style="background: #080808;">
        <div class="section-title">Static Asset Preview</div>
        <div class="zip-preview">
            <div style="margin-bottom: 20px; color: var(--acid-green);">// output_bundle_v1.zip</div>
            <div class="file-row">
                <span class="file-name">📁 /css</span>
                <span class="file-size">--</span>
            </div>
            <div class="file-row">
                <span class="file-name">&nbsp;&nbsp;&nbsp;📄 styles.css</span>
                <span class="file-size">12.4 KB</span>
            </div>
            <div class="file-row">
                <span class="file-name">📁 /js</span>
                <span class="file-size">--</span>
            </div>
            <div class="file-row">
                <span class="file-name">&nbsp;&nbsp;&nbsp;📄 main.js</span>
                <span class="file-size">4.2 KB</span>
            </div>
            <div class="file-row">
                <span class="file-name">📄 index.html</span>
                <span class="file-size">8.1 KB</span>
            </div>
            <div class="file-row">
                <span class="file-name">📄 README.md</span>
                <span class="file-size">1.2 KB</span>
            </div>
        </div>
    </section>

    <section>
        <div class="section-title">Use Cases</div>
        <div class="use-cases">
            <div class="case-box">
                <h4>Rapid Prototyping</h4>
                <p>Go from a client call to a functional HTML mockup in 30 seconds. No Figma needed.</p>
            </div>
            <div class="case-box">
                <h4>Ad Campaign Funnels</h4>
                <p>Generate 5 different landing page variations to A/B test your conversion rates.</p>
            </div>
            <div class="case-box">
                <h4>MVP Launch</h4>
                <p>Deploy a professional waitlist or product page without touching a single line of code.</p>
            </div>
        </div>
    </section>

    <section id="pricing">
        <div class="section-title">Pricing</div>
        <div class="pricing-grid">
            <div class="price-card">
                <p>Starter</p>
                <h2>\$0</h2>
                <ul style="list-style: none; color: var(--text-dim); margin-bottom: 20px; font-size: 0.9rem;">
                    <li>3 Generations / Month</li>
                    <li>Standard HTML/CSS</li>
                    <li>Community Support</li>
                </ul>
                <button class="btn-generate" style="width:100%; font-size: 0.8rem; padding: 10px;">Get Started</button>
            </div>
            <div class="price-card featured">
                <p style="color: var(--electric-blue);">Pro Factory</p>
                <h2>\$29<span>/mo</span></h2>
                <ul style="list-style: none; color: var(--text-dim); margin-bottom: 20px; font-size: 0.9rem;">
                    <li>Unlimited Generations</li>
                    <li>React/Vue Components</li>
                    <li>Dark/Light Mode Sync</li>
                    <li>Custom Assets & Icons</li>
                </ul>
                <button class="btn-generate" style="width:100%; font-size: 0.8rem; padding: 10px;">Go Pro</button>
            </div>
        </div>
    </section>

    <section id="faq">
        <div class="section-title">FAQ</div>
        <div class="faq-grid">
            <div class="faq-item">
                <h4>Can I export the code?</h4>
                <p>Yes. Every generation provides a direct ZIP download with clean, human-readable HTML, CSS, and JS.</p>
            </div>
            <div class="faq-item">
                <h4>Is the CSS bloated?</h4>
                <p>No. We use a proprietary minification engine that only includes the styles your specific prompt requires.</p>
            </div>
            <div class="faq-item">
                <h4>Can I describe mobile versions?</h4>
                <p>All generated sites are responsive by default using a mobile-first flexbox/grid approach.</p>
            </div>
        </div>
    </section>

    <section style="text-align: center; padding-bottom: 150px;">
        <h2 style="font-size: 3rem; margin-bottom: 30px;">Ready to deploy?</h2>
        <button class="btn-generate">Generate My Site Now</button>
    </section>

    <footer>
        <div class="logo">FLASH-UI</div>
        <div style="color: var(--text-dim); font-family: 'JetBrains Mono'; font-size: 0.7rem;">
            &copy; 2024 STATIC SITE FACTORY. ALL RIGHTS RESERVED.
        </div>
        <div class="nav-links">
            <a href="#">GITHUB</a>
            <a href="#">TWITTER</a>
        </div>
    </footer>
      ` }} />
    </main>
  );
}
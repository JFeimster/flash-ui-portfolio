### Generated UI Component

To use this in Notion:
1. Create a "/code" block
2. Set language to "HTML"
3. Paste the following:

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moonshine Capital | User Account Portal</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --brand-navy: #1e40af;
            --brand-navy-dark: #1e3a8a;
            --brand-navy-light: #3b82f6;
            --success-green: #10b981;
            --warning-orange: #f59e0b;
            --danger-red: #ef4444;
            --bg-light: #f7f7f7;
            --white: #ffffff;
            --text-main: #1f2937;
            --text-muted: #6b7280;
            --border-color: #e5e7eb;
            --sidebar-width: 280px;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            background-color: var(--bg-light);
            color: var(--text-main);
            display: flex;
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* --- SIDEBAR --- */
        aside {
            width: var(--sidebar-width);
            background-color: var(--brand-navy);
            color: var(--white);
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            display: flex;
            flex-direction: column;
            z-index: 1000;
            transition: var(--transition);
        }

        .user-profile-section {
            padding: 32px 24px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center;
        }

        .avatar-container {
            position: relative;
            width: 80px;
            height: 80px;
            margin: 0 auto 16px;
            cursor: pointer;
        }

        .avatar-container img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid rgba(255, 255, 255, 0.2);
            transition: var(--transition);
        }

        .avatar-container:hover img {
            border-color: var(--success-green);
        }

        .avatar-overlay {
            position: absolute;
            bottom: 0;
            right: 0;
            background: var(--success-green);
            width: 24px;
            height: 24px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            border: 2px solid var(--brand-navy);
        }

        .user-name {
            font-weight: 600;
            font-size: 1.1rem;
            margin-bottom: 4px;
        }

        .user-role {
            font-size: 0.85rem;
            color: rgba(255, 255, 255, 0.7);
            margin-bottom: 12px;
            display: block;
        }

        .status-badge {
            background: rgba(16, 185, 129, 0.2);
            color: var(--success-green);
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .nav-menu {
            flex: 1;
            padding: 24px 0;
            overflow-y: auto;
        }

        .nav-item {
            display: flex;
            align-items: center;
            padding: 12px 24px;
            color: rgba(255, 255, 255, 0.7);
            text-decoration: none;
            transition: var(--transition);
            font-size: 0.95rem;
            border-left: 4px solid transparent;
        }

        .nav-item i {
            width: 24px;
            margin-right: 12px;
            font-size: 1.1rem;
        }

        .nav-item:hover, .nav-item.active {
            color: var(--white);
            background: rgba(255, 255, 255, 0.05);
            border-left-color: var(--success-green);
        }

        .nav-item.active {
            background: rgba(255, 255, 255, 0.1);
        }

        /* --- MAIN CONTENT --- */
        main {
            margin-left: var(--sidebar-width);
            flex: 1;
            padding: 40px;
            max-width: 1600px;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
        }

        .welcome-text h1 {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--brand-navy);
        }

        .welcome-text p {
            color: var(--text-muted);
            margin-top: 4px;
        }

        .header-actions {
            display: flex;
            gap: 20px;
            align-items: center;
        }

        .search-bar {
            background: var(--white);
            border: 1px solid var(--border-color);
            padding: 8px 16px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            width: 300px;
        }

        .search-bar input {
            border: none;
            outline: none;
            background: transparent;
            margin-left: 10px;
            width: 100%;
        }

        .notification-bell {
            position: relative;
            cursor: pointer;
            color: var(--text-muted);
            font-size: 1.2rem;
        }

        .notification-dot {
            position: absolute;
            top: -2px;
            right: -2px;
            width: 8px;
            height: 8px;
            background: var(--danger-red);
            border-radius: 50%;
            border: 2px solid var(--bg-light);
        }

        /* --- DASHBOARD GRID --- */
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 24px;
        }

        .card {
            background: var(--white);
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
            border: 1px solid var(--border-color);
        }

        .quick-action-card {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            cursor: pointer;
            transition: var(--transition);
        }

        .quick-action-card:hover {
            transform: translateY(-5px);
            border-color: var(--brand-navy-light);
        }

        .icon-circle {
            width: 56px;
            height: 56px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin-bottom: 16px;
        }

        .navy-icon { background: rgba(30, 64, 175, 0.1); color: var(--brand-navy); }
        .green-icon { background: rgba(16, 185, 129, 0.1); color: var(--success-green); }
        .orange-icon { background: rgba(245, 158, 11, 0.1); color: var(--warning-orange); }

        .card-title {
            font-weight: 600;
            font-size: 1.1rem;
            margin-bottom: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        /* --- TABLES & LISTS --- */
        .full-width { grid-column: span 3; }
        .two-thirds { grid-column: span 2; }
        .one-third { grid-column: span 1; }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th {
            text-align: left;
            font-size: 0.8rem;
            text-transform: uppercase;
            color: var(--text-muted);
            padding: 12px 0;
            border-bottom: 1px solid var(--border-color);
        }

        td {
            padding: 16px 0;
            border-bottom: 1px solid var(--border-color);
            font-size: 0.95rem;
        }

        .status-pill {
            padding: 4px 10px;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .pill-funded { background: #dcfce7; color: #166534; }
        .pill-review { background: #fef3c7; color: #92400e; }
        .pill-draft { background: #f3f4f6; color: #374151; }

        /* --- PROGRESS BAR --- */
        .progress-container {
            width: 100%;
            height: 8px;
            background: #e5e7eb;
            border-radius: 4px;
            margin: 12px 0;
            overflow: hidden;
        }

        .progress-bar {
            height: 100%;
            background: var(--brand-navy);
            border-radius: 4px;
        }

        /* --- TIMELINE --- */
        .timeline {
            position: relative;
            padding-left: 30px;
        }

        .timeline-item {
            position: relative;
            padding-bottom: 24px;
        }

        .timeline-item::before {
            content: '';
            position: absolute;
            left: -30px;
            top: 5px;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: var(--brand-navy);
            border: 3px solid var(--white);
            box-shadow: 0 0 0 2px var(--brand-navy);
            z-index: 2;
        }

        .timeline-item::after {
            content: '';
            position: absolute;
            left: -25px;
            top: 15px;
            bottom: 0;
            width: 2px;
            background: var(--border-color);
            z-index: 1;
        }

        .timeline-item:last-child::after { display: none; }

        .timeline-content h4 { font-size: 0.9rem; margin-bottom: 4px; }
        .timeline-content p { font-size: 0.8rem; color: var(--text-muted); }

        /* --- BUTTONS --- */
        .btn {
            padding: 10px 20px;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            border: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 0.9rem;
        }

        .btn-primary { background: var(--brand-navy); color: var(--white); }
        .btn-primary:hover { background: var(--brand-navy-dark); }
        
        .btn-outline { background: transparent; border: 1px solid var(--border-color); color: var(--text-main); }
        .btn-outline:hover { background: var(--bg-light); }

        /* --- RESPONSIVE --- */
        @media (max-width: 1200px) {
            .dashboard-grid { grid-template-columns: repeat(2, 1fr); }
            .two-thirds, .one-third, .full-width { grid-column: span 2; }
        }

        @media (max-width: 768px) {
            aside { transform: translateX(-100%); }
            main { margin-left: 0; padding: 20px; }
            .dashboard-grid { grid-template-columns: 1fr; }
            .two-thirds, .one-third, .full-width { grid-column: span 1; }
            .header-actions .search-bar { display: none; }
        }
    </style>
</head>
<body>

    <!-- SIDEBAR -->
    <aside>
        <div class="user-profile-section">
            <div class="avatar-container">
                <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150&h=150" alt="User Avatar">
                <div class="avatar-overlay">
                    <i class="fas fa-camera"></i>
                </div>
            </div>
            <h3 class="user-name">Jonathan Miller</h3>
            <span class="user-role">Premium Partner</span>
            <span class="status-badge">Active</span>
        </div>

        <nav class="nav-menu">
            <a href="#" class="nav-item active"><i class="fas fa-th-large"></i> Dashboard</a>
            <a href="#" class="nav-item"><i class="fas fa-user"></i> Profile</a>
            <a href="#" class="nav-item"><i class="fas fa-file-invoice-dollar"></i> Leads</a>
            <a href="#" class="nav-item"><i class="fas fa-hand-holding-usd"></i> Commissions</a>
            <a href="#" class="nav-item"><i class="fas fa-folder-open"></i> Documents</a>
            <a href="#" class="nav-item"><i class="fas fa-cog"></i> Settings</a>
            <a href="#" class="nav-item"><i class="fas fa-shield-alt"></i> Security</a>
            <a href="#" class="nav-item"><i class="fas fa-comment-alt"></i> Messages</a>
            <a href="#" class="nav-item"><i class="fas fa-graduation-cap"></i> Resources</a>
            <a href="#" class="nav-item"><i class="fas fa-question-circle"></i> Help & Support</a>
        </nav>
    </aside>

    <!-- MAIN CONTENT -->
    <main>
        <header>
            <div class="welcome-text">
                <h1>Welcome back, Jonathan</h1>
                <p>Here's what's happening with your portfolio today.</p>
            </div>
            <div class="header-actions">
                <div class="search-bar">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search leads, docs...">
                </div>
                <div class="notification-bell">
                    <i class="fas fa-bell"></i>
                    <div class="notification-dot"></div>
                </div>
                <button class="btn btn-primary">
                    <i class="fas fa-plus"></i> Submit New Lead
                </button>
            </div>
        </header>

        <div class="dashboard-grid">
            <!-- QUICK ACTIONS -->
            <div class="card quick-action-card">
                <div class="icon-circle navy-icon"><i class="fas fa-paper-plane"></i></div>
                <h4>Submit Lead</h4>
                <p style="font-size: 0.85rem; color: var(--text-muted); margin-top: 8px;">Start a new funding request for a client.</p>
            </div>

            <div class="card quick-action-card">
                <div class="icon-circle green-icon"><i class="fas fa-file-upload"></i></div>
                <h4>Upload Docs</h4>
                <p style="font-size: 0.85rem; color: var(--text-muted); margin-top: 8px;">Drag and drop financial statements here.</p>
            </div>

            <div class="card quick-action-card">
                <div class="icon-circle orange-icon"><i class="fas fa-headset"></i></div>
                <h4>Support</h4>
                <p style="font-size: 0.85rem; color: var(--text-muted); margin-top: 8px;">Chat with your dedicated account manager.</p>
            </div>

            <!-- STATUS OVERVIEW (For Partner Style) -->
            <div class="card two-thirds">
                <div class="card-title">
                    Active Leads Overview
                    <a href="#" style="font-size: 0.8rem; color: var(--brand-navy-light); text-decoration: none;">View All</a>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>Client Name</th>
                            <th>Product</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Apex Logistics LLC</td>
                            <td>Working Capital</td>
                            <td>$125,000</td>
                            <td><span class="status-pill pill-funded">Funded</span></td>
                            <td><button class="btn btn-outline" style="padding: 5px 10px;">Details</button></td>
                        </tr>
                        <tr>
                            <td>Green Valley Retail</td>
                            <td>SBA Loan</td>
                            <td>$450,000</td>
                            <td><span class="status-pill pill-review">Under Review</span></td>
                            <td><button class="btn btn-outline" style="padding: 5px 10px;">Details</button></td>
                        </tr>
                        <tr>
                            <td>Blue Wave Tech</td>
                            <td>Equipment Fin.</td>
                            <td>$68,000</td>
                            <td><span class="status-pill pill-draft">Draft</span></td>
                            <td><button class="btn btn-outline" style="padding: 5px 10px;">Details</button></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- COMMISSIONS STATS -->
            <div class="card one-third">
                <div class="card-title">Earnings</div>
                <div style="margin-top: 20px;">
                    <span style="font-size: 0.85rem; color: var(--text-muted);">This Month</span>
                    <h2 style="font-size: 2rem; color: var(--brand-navy);">$12,450.00</h2>
                    <div class="progress-container">
                        <div class="progress-bar" style="width: 75%;"></div>
                    </div>
                    <p style="font-size: 0.75rem; color: var(--text-muted);">75% of your monthly goal</p>
                </div>
                <div style="margin-top: 24px; display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                    <div style="background: var(--bg-light); padding: 12px; border-radius: 8px;">
                        <span style="font-size: 0.75rem; color: var(--text-muted);">Pending</span>
                        <div style="font-weight: 700; color: var(--warning-orange);">$3,200</div>
                    </div>
                    <div style="background: var(--bg-light); padding: 12px; border-radius: 8px;">
                        <span style="font-size: 0.75rem; color: var(--text-muted);">Lifetime</span>
                        <div style="font-weight: 700; color: var(--success-green);">$142.8k</div>
                    </div>
                </div>
                <button class="btn btn-primary" style="width: 100%; margin-top: 20px; justify-content: center;">Request Payout</button>
            </div>

            <!-- RECENT ACTIVITY -->
            <div class="card one-third">
                <div class="card-title">Recent Activity</div>
                <div class="timeline">
                    <div class="timeline-item">
                        <div class="timeline-content">
                            <h4>Commission Paid</h4>
                            <p>Deal #8842 funded successfully. +$1,200 credited.</p>
                            <small style="color: var(--text-muted);">2 hours ago</small>
                        </div>
                    </div>
                    <div class="timeline-item">
                        <div class="timeline-content">
                            <h4>Document Approved</h4>
                            <p>Tax returns for "Apex Logistics" verified.</p>
                            <small style="color: var(--text-muted);">Yesterday, 4:15 PM</small>
                        </div>
                    </div>
                    <div class="timeline-item">
                        <div class="timeline-content">
                            <h4>New Message</h4>
                            <p>From Underwriter: "Need clarify on Q3 P&L."</p>
                            <small style="color: var(--text-muted);">Oct 24, 10:30 AM</small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- DOCUMENTS SUMMARY -->
            <div class="card two-thirds">
                <div class="card-title">
                    Missing Documents
                    <span style="background: var(--danger-red); color: white; padding: 2px 8px; border-radius: 10px; font-size: 0.7rem;">3 Action Items</span>
                </div>
                <div style="display: flex; flex-direction: column; gap: 12px; margin-top: 10px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 12px; border: 1px dashed var(--warning-orange); border-radius: 8px; background: rgba(245, 158, 11, 0.02);">
                        <div style="display: flex; align-items: center; gap: 12px;">
                            <i class="fas fa-file-pdf" style="color: #ef4444; font-size: 1.5rem;"></i>
                            <div>
                                <h5 style="font-size: 0.9rem;">2023 Corporate Tax Returns</h5>
                                <p style="font-size: 0.75rem; color: var(--text-muted);">Required for Green Valley Retail</p>
                            </div>
                        </div>
                        <button class="btn btn-outline" style="padding: 6px 12px; font-size: 0.8rem;">Upload</button>
                    </div>
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 12px; border: 1px dashed var(--border-color); border-radius: 8px;">
                        <div style="display: flex; align-items: center; gap: 12px;">
                            <i class="fas fa-file-invoice" style="color: var(--brand-navy); font-size: 1.5rem;"></i>
                            <div>
                                <h5 style="font-size: 0.9rem;">Voided Check / Bank Letter</h5>
                                <p style="font-size: 0.75rem; color: var(--text-muted);">Required for payout setup</p>
                            </div>
                        </div>
                        <button class="btn btn-outline" style="padding: 6px 12px; font-size: 0.8rem;">Upload</button>
                    </div>
                </div>
            </div>

        </div>
    </main>

    <!-- MOBILE OVERLAY -->
    <script>
        // Simple script to handle navigation "active" states
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', function(e) {
                document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
                this.classList.add('active');
            });
        });
    </script>
</body>
</html>
```
### Generated UI Component

To use this in Notion:
1. Create a "/code" block
2. Set language to "HTML"
3. Paste the following:

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'JetBrains Mono', monospace;
            background-color: #05080a;
            background-image: 
                radial-gradient(circle at 50% -20%, #064e3b 0%, transparent 50%),
                linear-gradient(to bottom, #0a0f12 0%, #05080a 100%);
            color: #e2e8f0;
        }
        .bento-card {
            background: rgba(15, 23, 42, 0.6);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(16, 185, 129, 0.2);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.5);
            transition: all 0.3s ease;
        }
        .bento-card:hover {
            border-color: rgba(16, 185, 129, 0.5);
            box-shadow: 0 0 20px rgba(16, 185, 129, 0.1);
        }
        .emerald-glow {
            text-shadow: 0 0 10px rgba(16, 185, 129, 0.6);
        }
        .terminal-input {
            background: rgba(5, 8, 10, 0.8);
            border: 1px solid #1e293b;
            color: #10b981;
            transition: all 0.2s;
        }
        .terminal-input:focus {
            border-color: #10b981;
            outline: none;
            box-shadow: 0 0 8px rgba(16, 185, 129, 0.3);
        }
        .execute-btn {
            background: #10b981;
            color: #05080a;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.1em;
            transition: all 0.2s;
            clip-path: polygon(0 0, 95% 0, 100% 30%, 100% 100%, 5% 100%, 0 70%);
        }
        .execute-btn:hover {
            background: #34d399;
            transform: translateY(-1px);
            box-shadow: 0 0 20px rgba(16, 185, 129, 0.4);
        }
        .execute-btn:active {
            transform: translateY(1px);
        }
        .custom-scrollbar::-webkit-scrollbar {
            width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
            background: #0a0f12;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #10b981;
            border-radius: 2px;
        }
        @keyframes blink { 50% { opacity: 0; } }
        .cursor-blink { animation: blink 1s step-end infinite; }
    </style>
</head>
<body class="min-h-screen p-4 lg:p-8">

    <div class="max-w-7xl mx-auto space-y-6">
        
        <!-- HEADER -->
        <header class="flex justify-between items-end border-b border-emerald-900/50 pb-4">
            <div>
                <h1 class="text-2xl font-bold tracking-tighter emerald-glow">MOONSHINE CAPITAL</h1>
                <p class="text-xs text-emerald-500/60 uppercase tracking-[0.3em]">Partner Provisioning Terminal v4.0.1</p>
            </div>
            <div class="text-right hidden md:block">
                <p class="text-[10px] text-slate-500 uppercase tracking-widest">System Status</p>
                <p class="text-xs text-emerald-400 font-bold uppercase tracking-widest flex items-center gap-2">
                    <span class="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span> Encrypted / Operational
                </p>
            </div>
        </header>

        <!-- MAIN BENTO GRID -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            <!-- NEW ENTRY FORM -->
            <div class="lg:col-span-8 bento-card p-6 rounded-sm relative overflow-hidden">
                <div class="absolute top-0 right-0 p-2 opacity-10 pointer-events-none">
                    <svg width="100" height="100" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="50" cy="50" r="48" stroke="#10b981" stroke-width="0.5"/>
                        <path d="M50 0V100M0 50H100" stroke="#10b981" stroke-width="0.5"/>
                    </svg>
                </div>

                <h2 class="text-sm font-bold text-emerald-400 mb-6 flex items-center gap-2">
                    <span class="w-1 h-4 bg-emerald-500"></span> [01] NEW PARTNER DATA ENTRY
                </h2>

                <form id="provisionForm" class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="space-y-1">
                        <label class="text-[10px] uppercase text-slate-400 tracking-wider">Full Name <span class="text-emerald-500">*</span></label>
                        <input type="text" id="fullName" required placeholder="JOHN DOE" class="terminal-input w-full p-3 text-sm uppercase">
                    </div>
                    
                    <div class="space-y-1">
                        <label class="text-[10px] uppercase text-slate-400 tracking-wider">Date Registered</label>
                        <input type="date" id="regDate" class="terminal-input w-full p-3 text-sm">
                    </div>

                    <div class="space-y-1">
                        <label class="text-[10px] uppercase text-slate-400 tracking-wider">Partner Type</label>
                        <select id="partnerType" class="terminal-input w-full p-3 text-sm appearance-none">
                            <option value="BRK">BROKER</option>
                            <option value="REF">REFERRAL SOURCE</option>
                            <option value="AFF">AFFILIATE</option>
                            <option value="VND">VENDOR</option>
                        </select>
                    </div>

                    <div class="space-y-1">
                        <label class="text-[10px] uppercase text-slate-400 tracking-wider">Company Name</label>
                        <input type="text" id="company" placeholder="OPTIONAL" class="terminal-input w-full p-3 text-sm uppercase">
                    </div>

                    <div class="space-y-1">
                        <label class="text-[10px] uppercase text-slate-400 tracking-wider">Birthday</label>
                        <input type="date" id="birthday" class="terminal-input w-full p-3 text-sm">
                    </div>

                    <div class="space-y-1">
                        <label class="text-[10px] uppercase text-slate-400 tracking-wider">Email Address</label>
                        <input type="email" id="email" placeholder="USER@DOMAIN.COM" class="terminal-input w-full p-3 text-sm uppercase">
                    </div>

                    <div class="md:col-span-2 space-y-1">
                        <label class="text-[10px] uppercase text-slate-400 tracking-wider">Physical Address</label>
                        <input type="text" id="address" placeholder="STREET, CITY, ZIP" class="terminal-input w-full p-3 text-sm uppercase">
                    </div>

                    <div class="md:col-span-2 pt-4">
                        <button type="button" onclick="generatePartnerID()" class="execute-btn w-full py-4 text-sm">
                            Generate Secure ID & Provision
                        </button>
                    </div>
                </form>
            </div>

            <!-- PROVISIONING RESULT -->
            <div class="lg:col-span-4 flex flex-col gap-6">
                <div class="bento-card p-6 rounded-sm flex-1 flex flex-col justify-between border-emerald-500/40">
                    <div>
                        <h2 class="text-sm font-bold text-emerald-400 mb-6 flex items-center gap-2">
                            <span class="w-1 h-4 bg-emerald-500"></span> [02] PROVISIONING RESULT
                        </h2>
                        
                        <div id="resultDisplay" class="hidden space-y-4">
                            <div class="bg-black/40 border border-emerald-500/20 p-4 rounded-sm">
                                <p class="text-[10px] text-slate-500 uppercase mb-2 tracking-widest">Unique Mission ID</p>
                                <p id="generatedID" class="text-2xl font-bold text-emerald-400 tracking-tighter">MC-BRK-JS26</p>
                            </div>

                            <div class="bg-black/40 border border-emerald-500/20 p-4 rounded-sm">
                                <p class="text-[10px] text-slate-500 uppercase mb-2 tracking-widest">Tracking Endpoint</p>
                                <div class="flex items-center gap-2 overflow-hidden">
                                    <p id="trackingURL" class="text-xs text-slate-300 truncate font-light italic">moonshinecapital.com/ref/MC-BRK-JS26</p>
                                </div>
                                <button onclick="copyToClipboard()" class="mt-4 text-[10px] bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 px-3 py-1 hover:bg-emerald-500 hover:text-black transition-colors uppercase">
                                    Copy Link
                                </button>
                            </div>
                        </div>

                        <div id="placeholderDisplay" class="h-48 flex flex-col items-center justify-center text-center opacity-30">
                            <div class="w-12 h-12 border border-dashed border-emerald-500 rounded-full animate-spin-slow mb-4"></div>
                            <p class="text-xs uppercase tracking-widest">Awaiting Command<span class="cursor-blink">_</span></p>
                        </div>
                    </div>
                </div>

                <!-- SYSTEM STATS -->
                <div class="bento-card p-4 rounded-sm bg-emerald-950/10 border-emerald-900/30">
                    <div class="flex justify-between items-center text-[10px] text-emerald-500/60 uppercase">
                        <span>Entropy: 0.9982</span>
                        <span>Key: AES-256</span>
                    </div>
                </div>
            </div>

            <!-- AUDIT LOG -->
            <div class="lg:col-span-12 bento-card p-6 rounded-sm">
                <h2 class="text-sm font-bold text-emerald-400 mb-4 flex items-center gap-2">
                    <span class="w-1 h-4 bg-emerald-500"></span> [03] AUDIT LOG / RECENT PROVISIONS
                </h2>
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="text-[10px] text-slate-500 uppercase tracking-widest border-b border-slate-800">
                                <th class="py-3 px-4">Partner Name</th>
                                <th class="py-3 px-4">Entity Type</th>
                                <th class="py-3 px-4 text-emerald-500">Mission ID</th>
                                <th class="py-3 px-4">Date Added</th>
                                <th class="py-3 px-4 text-right">Status</th>
                            </tr>
                        </thead>
                        <tbody id="auditLog" class="text-xs">
                            <tr class="border-b border-slate-900/50 hover:bg-emerald-500/5 transition-colors">
                                <td class="py-4 px-4 text-slate-300">ALEXANDER VANCE</td>
                                <td class="py-4 px-4 text-slate-500 italic">BROKER</td>
                                <td class="py-4 px-4 font-bold text-emerald-400">MC-BRK-AV24</td>
                                <td class="py-4 px-4 text-slate-500">2024-05-12</td>
                                <td class="py-4 px-4 text-right text-emerald-500 opacity-60 italic">ACTIVE</td>
                            </tr>
                            <tr class="border-b border-slate-900/50 hover:bg-emerald-500/5 transition-colors">
                                <td class="py-4 px-4 text-slate-300">SARAH JENKINS</td>
                                <td class="py-4 px-4 text-slate-500 italic">AFFILIATE</td>
                                <td class="py-4 px-4 font-bold text-emerald-400">MC-AFF-SJ24</td>
                                <td class="py-4 px-4 text-slate-500">2024-05-11</td>
                                <td class="py-4 px-4 text-right text-emerald-500 opacity-60 italic">ACTIVE</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>

    <script>
        const auditData = [];

        function generatePartnerID() {
            const name = document.getElementById('fullName').value;
            const type = document.getElementById('partnerType').value;
            const regDate = document.getElementById('regDate').value;

            if (!name) {
                alert("CRITICAL ERROR: PARTNER NAME REQUIRED");
                return;
            }

            // Initials Logic
            const nameParts = name.trim().split(' ');
            let initials = "XX";
            if (nameParts.length >= 2) {
                initials = (nameParts[0][0] + nameParts[nameParts.length - 1][0]).toUpperCase();
            } else if (nameParts.length === 1) {
                initials = (nameParts[0][0] + (nameParts[0][1] || 'X')).toUpperCase();
            }

            // Year Logic
            const year = regDate ? regDate.substring(2, 4) : new Date().getFullYear().toString().substring(2, 4);

            // MC + [TYPE_CODE] + [INITIALS][YEAR]
            const missionID = `MC-${type}-${initials}${year}`;
            const trackingURL = `moonshinecapital.com/ref/${missionID}`;

            // UI Update
            document.getElementById('placeholderDisplay').classList.add('hidden');
            document.getElementById('resultDisplay').classList.remove('hidden');
            document.getElementById('generatedID').innerText = missionID;
            document.getElementById('trackingURL').innerText = trackingURL;

            // Add to Audit Log
            addToAudit(name.toUpperCase(), type, missionID, regDate || new Date().toISOString().split('T')[0]);
        }

        function addToAudit(name, type, id, date) {
            const log = document.getElementById('auditLog');
            const row = document.createElement('tr');
            row.className = "border-b border-slate-900/50 hover:bg-emerald-500/5 transition-colors animate-pulse";
            row.innerHTML = `
                <td class="py-4 px-4 text-slate-300">${name}</td>
                <td class="py-4 px-4 text-slate-500 italic">${type}</td>
                <td class="py-4 px-4 font-bold text-emerald-400">${id}</td>
                <td class="py-4 px-4 text-slate-500">${date}</td>
                <td class="py-4 px-4 text-right text-emerald-500 opacity-60 italic">PROVISIONED</td>
            `;
            
            if (log.firstChild) {
                log.insertBefore(row, log.firstChild);
            } else {
                log.appendChild(row);
            }

            // Maintain only last 5 entries + the mock ones
            if (log.children.length > 7) {
                log.removeChild(log.lastChild);
            }

            setTimeout(() => row.classList.remove('animate-pulse'), 1000);
        }

        function copyToClipboard() {
            const text = document.getElementById('trackingURL').innerText;
            navigator.clipboard.writeText(text);
            const btn = event.target;
            btn.innerText = "COPIED";
            btn.style.backgroundColor = "#10b981";
            btn.style.color = "#000";
            setTimeout(() => {
                btn.innerText = "COPY LINK";
                btn.style.backgroundColor = "transparent";
                btn.style.color = "#10b981";
            }, 2000);
        }
    </script>
</body>
</html>
```
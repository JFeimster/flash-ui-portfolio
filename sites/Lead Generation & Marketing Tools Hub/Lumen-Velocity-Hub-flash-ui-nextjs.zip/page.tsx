import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<nav>
        <div class="container nav-content">
            <div class="logo">MOONSHINE <span>CAPITAL</span></div>
            <div class="nav-links">
                <a href="#free">Free Tools</a>
                <a href="#premium">Premium</a>
                <a href="#strategies">Strategies</a>
                <a href="#compare">Comparison</a>
            </div>
            <a href="#" class="btn btn-primary" style="padding: 10px 20px; font-size: 0.8rem;">Partner Login</a>
        </div>
    </nav>

    <header class="hero">
        <div class="container hero-grid">
            <div>
                <h1>Stop Chasing Leads. Start Attracting Them.</h1>
                <p>Free tools, templates, and automation to help you generate qualified funding leads on autopilot. Built by experts for high-performing partners.</p>
                <div class="cta-group">
                    <a href="#free" class="btn btn-primary">Access Free Tools</a>
                    <a href="#premium" class="btn btn-outline">View Premium Tools</a>
                </div>
                <div class="trust-signal">
                    <div class="dots">
                        <div class="dot" style="background: #fb923c;"></div>
                        <div class="dot" style="background: #8b5cf6;"></div>
                        <div class="dot" style="background: #10b981;"></div>
                    </div>
                    <span>Used by <strong>500+ partners</strong> to generate <strong>50,000+ leads</strong></span>
                </div>
            </div>
            <div class="hero-visual">
                <div class="dashboard-mock">
                    <div style="width: 100%; height: 10px; background: #e2e8f0; margin-bottom: 20px;"></div>
                    <div style="display: flex; gap: 10px; margin-bottom: 20px;">
                        <div style="flex: 1; height: 100px; background: white; border-radius: 8px;"></div>
                        <div style="flex: 1; height: 100px; background: white; border-radius: 8px;"></div>
                        <div style="flex: 1; height: 100px; background: white; border-radius: 8px;"></div>
                    </div>
                    <div style="width: 100%; height: 80px; background: white; border-radius: 8px;"></div>
                    <div class="notification">New Lead: \$250k MCA Opportunity 🚀</div>
                </div>
            </div>
        </div>
    </header>

    <div class="container">
        <div class="benefits-box">
            <div class="benefit-item"><span>✓</span> Pre-built funnels optimized for funding leads</div>
            <div class="benefit-item"><span>✓</span> Done-for-you email sequences and follow-ups</div>
            <div class="benefit-item"><span>✓</span> Landing page templates that convert at 12%+</div>
            <div class="benefit-item"><span>✓</span> CRM integration (HubSpot, Salesforce, GHL)</div>
            <div class="benefit-item"><span>✓</span> Social media content calendar (30+ posts)</div>
            <div class="benefit-item"><span>✓</span> Free training on each tool</div>
        </div>
    </div>

    <section id="free">
        <div class="container">
            <div class="section-header">
                <h2>Free Lead Generation Tools</h2>
                <p>Everything you need to launch your marketing engine today.</p>
            </div>
            <div class="tools-grid">
                <!-- Tool 1 -->
                <div class="tool-card">
                    <div class="tool-badge">Widget</div>
                    <h3>Funding Calculator Widget</h3>
                    <p class="desc">Embeddable calculator that captures leads while providing instant value.</p>
                    <div class="tool-meta">
                        <div class="meta-item"><strong>Conv. Rate</strong><span>8-12%</span></div>
                        <div class="meta-item"><strong>Setup</strong><span>5 Mins</span></div>
                    </div>
                    <ul class="feature-list">
                        <li>Estimates funding based on revenue</li>
                        <li>Captures email for results</li>
                        <li>Automated follow-up email</li>
                        <li>CRM tracking included</li>
                    </ul>
                    <a href="#" class="btn btn-primary">Get Embed Code</a>
                </div>

                <!-- Tool 2 -->
                <div class="tool-card">
                    <div class="tool-badge">Funnel</div>
                    <h3>Qualifying Quiz Funnel</h3>
                    <p class="desc">Interactive quiz that segments leads by funding need and credit score.</p>
                    <div class="tool-meta">
                        <div class="meta-item"><strong>Conv. Rate</strong><span>15-20%</span></div>
                        <div class="meta-item"><strong>Setup</strong><span>10 Mins</span></div>
                    </div>
                    <ul class="feature-list">
                        <li>5-7 qualifying questions</li>
                        <li>Personalized results page</li>
                        <li>In-built email capture</li>
                        <li>Lead tagging based on answers</li>
                    </ul>
                    <a href="#" class="btn btn-primary">Clone Quiz Template</a>
                </div>

                <!-- Tool 3 -->
                <div class="tool-card">
                    <div class="tool-badge">Email</div>
                    <h3>DFY Email Sequences</h3>
                    <p class="desc">12 pre-written nurture sequences to automate your entire follow-up process.</p>
                    <div class="tool-meta">
                        <div class="meta-item"><strong>Conv. Rate</strong><span>5-8%</span></div>
                        <div class="meta-item"><strong>Templates</strong><span>14 Total</span></div>
                    </div>
                    <ul class="feature-list">
                        <li>New lead welcome series</li>
                        <li>Abandoned application follow-up</li>
                        <li>Post-funding nurture</li>
                        <li>Referral request sequence</li>
                    </ul>
                    <a href="#" class="btn btn-primary">Download Templates</a>
                </div>

                <!-- Tool 4 -->
                <div class="tool-card">
                    <div class="tool-badge">Design</div>
                    <h3>Landing Page Templates</h3>
                    <p class="desc">10+ high-converting designs tested across \$1M+ in ad spend.</p>
                    <div class="tool-meta">
                        <div class="meta-item"><strong>Conv. Rate</strong><span>12%+</span></div>
                        <div class="meta-item"><strong>Types</strong><span>10 Layouts</span></div>
                    </div>
                    <ul class="feature-list">
                        <li>Same-day funding focus</li>
                        <li>Industry-specific pages</li>
                        <li>Mobile-responsive designs</li>
                        <li>A/B tested headlines</li>
                    </ul>
                    <a href="#" class="btn btn-primary">Preview Templates</a>
                </div>

                <!-- Tool 5 -->
                <div class="tool-card">
                    <div class="tool-badge">Social</div>
                    <h3>Social Content Calendar</h3>
                    <p class="desc">30 days of ready-to-post content including captions and Canva links.</p>
                    <div class="tool-meta">
                        <div class="meta-item"><strong>Posts</strong><span>30 Ready</span></div>
                        <div class="meta-item"><strong>Platform</strong><span>Multi</span></div>
                    </div>
                    <ul class="feature-list">
                        <li>Educational & Social Proof</li>
                        <li>Done-for-you captions</li>
                        <li>Hashtag research included</li>
                        <li>Direct link to Canva assets</li>
                    </ul>
                    <a href="#" class="btn btn-primary">Download Calendar</a>
                </div>

                <!-- Tool 6 -->
                <div class="tool-card">
                    <div class="tool-badge">System</div>
                    <h3>CRM Quick-Start</h3>
                    <p class="desc">Pre-configured pipelines and automated workflows for popular CRMs.</p>
                    <div class="tool-meta">
                        <div class="meta-item"><strong>Speed</strong><span>Instant</span></div>
                        <div class="meta-item"><strong>Comp.</strong><span>GHL, HubSpot</span></div>
                    </div>
                    <ul class="feature-list">
                        <li>Sales pipeline stages</li>
                        <li>Automated task creation</li>
                        <li>Dashboard reporting</li>
                        <li>Email integration setup</li>
                    </ul>
                    <a href="#" class="btn btn-primary">Get CRM Templates</a>
                </div>
            </div>
        </div>
    </section>

    <section id="premium" class="premium-section">
        <div class="container">
            <div class="section-header">
                <h2 style="color: var(--accent);">Premium Scaling Tools</h2>
                <p>Advanced services for partners ready to dominate the market.</p>
            </div>
            <div class="tools-grid">
                <div class="tool-card premium-card">
                    <div class="price">\$497 <small>one-time</small></div>
                    <h3>Done-For-You Funnel</h3>
                    <p class="desc">Complete lead generation system built and integrated for you.</p>
                    <ul class="feature-list">
                        <li>5 Customized landing pages</li>
                        <li>FB/IG Ad campaign setup</li>
                        <li>30-day automated nurture</li>
                        <li>1-hour strategy coaching</li>
                    </ul>
                    <a href="#" class="btn btn-primary" style="background: var(--accent);">Invest in Funnel</a>
                </div>
                <div class="tool-card premium-card">
                    <div class="price">\$297 <small>flat-fee</small></div>
                    <h3>Lead Magnet Creation</h3>
                    <p class="desc">We create a professional custom eBook or Guide to build your list.</p>
                    <ul class="feature-list">
                        <li>Market topic research</li>
                        <li>Copywriting & Professional design</li>
                        <li>Lead capture page</li>
                        <li>Delivery automation setup</li>
                    </ul>
                    <a href="#" class="btn btn-primary" style="background: var(--accent);">Get Custom Magnet</a>
                </div>
                <div class="tool-card premium-card">
                    <div class="price">\$997 <small>/month</small></div>
                    <h3>Lead Generation Service</h3>
                    <p class="desc">Hands-off growth. We run the ads and deliver leads directly to your CRM.</p>
                    <ul class="feature-list">
                        <li>50-100 Qualified leads monthly</li>
                        <li>Complete ad management</li>
                        <li>Landing page optimization</li>
                        <li>Real-time lead tagging</li>
                    </ul>
                    <a href="#" class="btn btn-primary" style="background: var(--accent);">Apply for Service</a>
                </div>
            </div>
        </div>
    </section>

    <section id="strategies">
        <div class="container">
            <div class="section-header">
                <h2>Lead Generation Strategies</h2>
                <p>Master the art of high-volume business funding acquisition.</p>
            </div>
            
            <!-- Strategy 1 -->
            <div class="strategy-item">
                <div class="strat-info">
                    <h4>LinkedIn Outreach</h4>
                    <p>Build relationships with business owners at scale via automated outreach.</p>
                    <div class="tool-badge" style="margin-top:10px;">Medium Skill</div>
                </div>
                <div class="strat-steps">
                    <ol>
                        <li>Optimize profile for "Funding Specialist" credibility.</li>
                        <li>Send 20-30 personalized connections daily.</li>
                        <li>Share value-first content twice weekly.</li>
                        <li>Move conversations to phone/application links.</li>
                    </ol>
                </div>
                <div class="strat-stats">
                    <span class="stat-val">10-20</span>
                    <span class="stat-label">Leads Per Week</span>
                    <a href="#" class="btn btn-outline" style="font-size: 0.7rem; margin-top: 10px; padding: 5px 10px;">Get Scripts</a>
                </div>
            </div>

            <!-- Strategy 2 -->
            <div class="strategy-item">
                <div class="strat-info">
                    <h4>Facebook Group Engine</h4>
                    <p>Free, organic lead generation by engaging in high-intent communities.</p>
                    <div class="tool-badge" style="margin-top:10px;">Low Skill</div>
                </div>
                <div class="strat-steps">
                    <ol>
                        <li>Identify 20 niche-specific entrepreneur groups.</li>
                        <li>Provide genuine value (answering questions).</li>
                        <li>Use "Comment for Details" strategy on posts.</li>
                        <li>Qualify leads in DMs using our script.</li>
                    </ol>
                </div>
                <div class="strat-stats">
                    <span class="stat-val">5-15</span>
                    <span class="stat-label">Leads Per Week</span>
                    <a href="#" class="btn btn-outline" style="font-size: 0.7rem; margin-top: 10px; padding: 5px 10px;">Get Playbook</a>
                </div>
            </div>

            <!-- Strategy 3 -->
            <div class="strategy-item">
                <div class="strat-info">
                    <h4>Paid Advertising</h4>
                    <p>Scalable, predictable lead flow using Facebook and Google Ads.</p>
                    <div class="tool-badge" style="margin-top:10px; background: #fee2e2; color: #ef4444;">High Skill</div>
                </div>
                <div class="strat-steps">
                    <ol>
                        <li>Target business owner interests & demographics.</li>
                        <li>Deploy proven "Funding" ad creative.</li>
                        <li>Drive traffic to a 12%+ converting landing page.</li>
                        <li>Follow up within 5 minutes of capture.</li>
                    </ol>
                </div>
                <div class="strat-stats">
                    <span class="stat-val">20-100+</span>
                    <span class="stat-label">Leads Per Month</span>
                    <a href="#" class="btn btn-outline" style="font-size: 0.7rem; margin-top: 10px; padding: 5px 10px;">Get Ad Kits</a>
                </div>
            </div>
        </div>
    </section>

    <section id="compare" style="background: white;">
        <div class="container">
            <div class="section-header">
                <h2>Methods Compared</h2>
                <p>Find the strategy that matches your budget and timeline.</p>
            </div>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Strategy</th>
                            <th>Cost</th>
                            <th>Time</th>
                            <th>Lead Quality</th>
                            <th>Speed</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>Facebook Groups</strong></td>
                            <td><span class="badge-table bg-green">Free</span></td>
                            <td>Medium</td>
                            <td>Medium</td>
                            <td>Slow</td>
                        </tr>
                        <tr>
                            <td><strong>LinkedIn Outreach</strong></td>
                            <td><span class="badge-table bg-orange">Low</span></td>
                            <td>Medium</td>
                            <td>High</td>
                            <td>Medium</td>
                        </tr>
                        <tr>
                            <td><strong>Paid Ads</strong></td>
                            <td><span class="badge-table bg-purple">High</span></td>
                            <td>Medium</td>
                            <td>Medium</td>
                            <td><span class="badge-table bg-green">Fast</span></td>
                        </tr>
                        <tr>
                            <td><strong>Local Referrals</strong></td>
                            <td><span class="badge-table bg-green">Free</span></td>
                            <td>High</td>
                            <td><span class="badge-table bg-green">Very High</span></td>
                            <td>Slow</td>
                        </tr>
                        <tr>
                            <td><strong>Our Tools</strong></td>
                            <td><span class="badge-table bg-orange">Free-Premium</span></td>
                            <td><span class="badge-table bg-green">Low</span></td>
                            <td>High</td>
                            <td><span class="badge-table bg-green">Fast</span></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

    <section>
        <div class="container">
            <div class="qual-grid">
                <div class="qual-card green-zone">
                    <h3>✅ Qualification Checklist</h3>
                    <div class="checklist-item">☑ Business 3+ Months Old</div>
                    <div class="checklist-item">☑ Monthly Revenue \$10k+</div>
                    <div class="checklist-item">☑ Accurate Phone/Email Provided</div>
                    <div class="checklist-item">☑ Decision-Maker Status Confirmed</div>
                    <div class="checklist-item">☑ Clear Use of Funds Identified</div>
                </div>
                <div class="qual-card red-zone">
                    <h3>❌ Red Flags to Watch</h3>
                    <div class="checklist-item">☒ New Business / Pre-Revenue</div>
                    <div class="checklist-item">☒ Personal Credit Below 500</div>
                    <div class="checklist-item">☒ Active Unreported Bankruptcies</div>
                    <div class="checklist-item">☒ Unrealistic Funding Expectations</div>
                    <div class="checklist-item">☒ Evasive About Business Model</div>
                </div>
            </div>
        </div>
    </section>

    <section>
        <div class="container">
            <div class="section-header">
                <h2>Which Strategy Should You Use?</h2>
                <p>Select your current situation to see our recommendation.</p>
            </div>
            <div class="tree-grid">
                <div class="tree-node">
                    <h4>No Budget</h4>
                    <p style="font-size: 0.8rem; color: var(--slate); margin-bottom: 15px;">Focus on organic outreach.</p>
                    <span class="badge-table bg-orange" style="display:block; margin-bottom: 10px;">LinkedIn + FB Groups</span>
                    <a href="#" style="color: var(--primary); font-size: 0.8rem; font-weight: 700;">Get Starter Kit</a>
                </div>
                <div class="tree-node">
                    <h4>Budget (\$500+)</h4>
                    <p style="font-size: 0.8rem; color: var(--slate); margin-bottom: 15px;">Leverage speed and scale.</p>
                    <span class="badge-table bg-purple" style="display:block; margin-bottom: 10px;">Paid Ads + Funnels</span>
                    <a href="#" style="color: var(--primary); font-size: 0.8rem; font-weight: 700;">Go Premium</a>
                </div>
                <div class="tree-node">
                    <h4>Big Network</h4>
                    <p style="font-size: 0.8rem; color: var(--slate); margin-bottom: 15px;">Monetize existing trust.</p>
                    <span class="badge-table bg-green" style="display:block; margin-bottom: 10px;">Referral Partner Kit</span>
                    <a href="#" style="color: var(--primary); font-size: 0.8rem; font-weight: 700;">Get Referral Kit</a>
                </div>
                <div class="tree-node">
                    <h4>Total Hands-Off</h4>
                    <p style="font-size: 0.8rem; color: var(--slate); margin-bottom: 15px;">Let our experts do it.</p>
                    <span class="badge-table bg-orange" style="display:block; margin-bottom: 10px;">Lead Gen Service</span>
                    <a href="#" style="color: var(--primary); font-size: 0.8rem; font-weight: 700;">Apply Now</a>
                </div>
            </div>
        </div>
    </section>

    <section class="final-cta">
        <div class="container">
            <h2>Stop Wasting Time on Bad Leads.</h2>
            <p>Access all free tools instantly—no credit card required. Join 500+ partners closing more deals.</p>
            <div class="cta-group" style="justify-content: center;">
                <a href="#" class="btn btn-primary" style="background: var(--white); color: var(--primary);">Get Free Lead Gen Tools</a>
                <a href="#" class="btn btn-outline" style="color: white; border-color: rgba(255,255,255,0.3);">Upgrade to Premium</a>
            </div>
            <div style="margin-top: 40px; font-size: 0.9rem; color: #64748b;">
                Average partner closes 3 deals per month using our system.
            </div>
        </div>
    </section>
      ` }} />
    </main>
  );
}
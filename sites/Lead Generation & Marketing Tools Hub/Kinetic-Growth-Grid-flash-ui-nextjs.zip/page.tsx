import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<!-- Hero Section -->
<section class="hero">
    <div class="container hero-flex">
        <div class="hero-content">
            <span class="badge-trust"><i class="fas fa-users"></i> Used by 500+ partners to generate 50k+ leads</span>
            <h1>Stop Chasing Leads.<br><span style="color:var(--primary-orange)">Start Attracting Them.</span></h1>
            <p class="subheadline">Free tools, templates, and automation to help you generate qualified funding leads on autopilot.</p>
            <div class="cta-group">
                <a href="#free-tools" class="btn btn-primary">Access Free Tools</a>
                <a href="#premium-tools" class="btn btn-secondary">View Premium Tools</a>
            </div>
        </div>
        <div class="hero-visual">
            <div class="growth-chart-sim">
                <div class="notification-pop"><i class="fas fa-bell"></i> New Lead: \$250k Funding Need</div>
                <div style="font-weight: 700; margin-bottom: 10px;">Monthly Lead Velocity</div>
                <div class="chart-bar-group">
                    <div class="bar" style="height: 30%; opacity: 0.4;"></div>
                    <div class="bar" style="height: 45%; opacity: 0.6;"></div>
                    <div class="bar" style="height: 35%; opacity: 0.5;"></div>
                    <div class="bar" style="height: 65%; opacity: 0.8;"></div>
                    <div class="bar" style="height: 85%;"></div>
                    <div class="bar" style="height: 100%; background: var(--conversion-green);"></div>
                </div>
                <div style="display:flex; justify-content:space-between; margin-top:15px; font-size: 0.75rem; color: #94a3b8;">
                    <span>Week 1</span><span>Week 2</span><span>Week 3</span><span>Week 4</span>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Benefits Bar -->
<section class="container benefits-strip">
    <div class="benefits-card">
        <div class="benefit-item"><i class="fas fa-check-circle"></i> Pre-built High-Convert Funnels</div>
        <div class="benefit-item"><i class="fas fa-check-circle"></i> Done-for-you Email Sequences</div>
        <div class="benefit-item"><i class="fas fa-check-circle"></i> Social Content (30+ Posts)</div>
        <div class="benefit-item"><i class="fas fa-check-circle"></i> CRM Integration Templates</div>
        <div class="benefit-item"><i class="fas fa-check-circle"></i> Landing Pages (12%+ CR)</div>
        <div class="benefit-item"><i class="fas fa-check-circle"></i> Free Weekly Training</div>
    </div>
</section>

<!-- Free Tools Section -->
<section id="free-tools" class="container">
    <div class="section-header">
        <h2>Partner Growth Arsenal</h2>
        <p>Professional lead generation tools provided at zero cost to our active partners.</p>
    </div>
    <div class="grid grid-3">
        <!-- Tool 1 -->
        <div class="tool-card">
            <span class="tool-tag tag-free">Free</span>
            <div class="tool-icon"><i class="fas fa-calculator"></i></div>
            <h3>Funding Calculator</h3>
            <p>Embeddable widget that qualifies leads while they estimate their funding potential. Captures email automatically.</p>
            <div class="tool-stats">
                <div>CR: <span>8-12%</span></div>
                <div>Setup: 5 min</div>
            </div>
            <button class="btn btn-secondary btn-tool">Get Embed Code</button>
        </div>
        <!-- Tool 2 -->
        <div class="tool-card">
            <span class="tool-tag tag-free">Free</span>
            <div class="tool-icon"><i class="fas fa-list-check"></i></div>
            <h3>Qualifying Quiz</h3>
            <p>Interactive 7-question funnel that segments leads by industry and credit score before they ever talk to you.</p>
            <div class="tool-stats">
                <div>Completion: <span>18%</span></div>
                <div>Setup: 10 min</div>
            </div>
            <button class="btn btn-secondary btn-tool">Clone Quiz Template</button>
        </div>
        <!-- Tool 3 -->
        <div class="tool-card">
            <span class="tool-tag tag-free">Free</span>
            <div class="tool-icon"><i class="fas fa-envelope-open-text"></i></div>
            <h3>Email Sequences</h3>
            <p>12 pre-written nurture sequences including "New Lead Welcome" and "Abandoned App Follow-up."</p>
            <div class="tool-stats">
                <div>Open Rate: <span>35%</span></div>
                <div>Templates: 14</div>
            </div>
            <button class="btn btn-secondary btn-tool">Download Templates</button>
        </div>
        <!-- Tool 4 -->
        <div class="tool-card">
            <span class="tool-tag tag-free">Free</span>
            <div class="tool-icon"><i class="fas fa-pager"></i></div>
            <h3>Landing Pages</h3>
            <p>10+ mobile-responsive designs optimized for MCA, Equipment Financing, and Term Loans.</p>
            <div class="tool-stats">
                <div>CR: <span>12%+</span></div>
                <div>Designs: 10</div>
            </div>
            <button class="btn btn-secondary btn-tool">Preview Templates</button>
        </div>
        <!-- Tool 5 -->
        <div class="tool-card">
            <span class="tool-tag tag-free">Free</span>
            <div class="tool-icon"><i class="fas fa-calendar-days"></i></div>
            <h3>Social Calendar</h3>
            <p>30 days of ready-to-post content including Canva templates, captions, and hashtag research.</p>
            <div class="tool-stats">
                <div>Engagement: <span>High</span></div>
                <div>Platforms: 4</div>
            </div>
            <button class="btn btn-secondary btn-tool">Get Calendar</button>
        </div>
        <!-- Tool 6 -->
        <div class="tool-card">
            <span class="tool-tag tag-free">Free</span>
            <div class="tool-icon"><i class="fas fa-database"></i></div>
            <h3>CRM Quick-Start</h3>
            <p>Pre-configured pipelines for HubSpot and GoHighLevel. Includes automated deal stage movements.</p>
            <div class="tool-stats">
                <div>Efficiency: <span>+40%</span></div>
                <div>Compatible: 5</div>
            </div>
            <button class="btn btn-secondary btn-tool">Get CRM Templates</button>
        </div>
    </div>
</section>

<!-- Premium Section -->
<section id="premium-tools" class="premium-container">
    <div class="container">
        <div class="section-header">
            <h2>Premium Scaling Solutions</h2>
            <p>Exclusive services for partners ready to invest in hyper-growth.</p>
        </div>
        <div class="grid grid-3">
            <div class="tool-card premium-card">
                <span class="tool-tag tag-premium">Exclusive</span>
                <div class="tool-icon"><i class="fas fa-rocket"></i></div>
                <div class="price-tag">\$497</div>
                <h3>DFY Funnel System</h3>
                <p>A complete turnkey lead gen machine. Includes ads, landing pages, and 30-day email automation setup.</p>
                <button class="btn btn-primary btn-tool" style="background: var(--analytics-purple);">Invest in Funnel</button>
            </div>
            <div class="tool-card premium-card">
                <span class="tool-tag tag-premium">Exclusive</span>
                <div class="tool-icon"><i class="fas fa-magnet"></i></div>
                <div class="price-tag">\$297</div>
                <h3>Custom Lead Magnet</h3>
                <p>We research, design, and write a high-value eBook or Guide custom-branded to your brokerage.</p>
                <button class="btn btn-primary btn-tool" style="background: var(--analytics-purple);">Order Lead Magnet</button>
            </div>
            <div class="tool-card premium-card">
                <span class="tool-tag tag-premium">Exclusive</span>
                <div class="tool-icon"><i class="fas fa-bullseye"></i></div>
                <div class="price-tag">\$997<small>/mo</small></div>
                <h3>Monthly Lead Service</h3>
                <p>Hands-off lead generation. We run the ads and deliver 50-100 qualified leads directly to your CRM.</p>
                <button class="btn btn-primary btn-tool" style="background: var(--analytics-purple);">Apply for Service</button>
            </div>
        </div>
    </div>
</section>

<!-- Comparison Table -->
<section class="container comparison-section">
    <div class="section-header">
        <h2>Lead Gen Methods Compared</h2>
        <p>Choose the strategy that aligns with your budget and time availability.</p>
    </div>
    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>Strategy</th>
                    <th>Cost</th>
                    <th>Skill Level</th>
                    <th>Lead Quality</th>
                    <th>Speed</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Facebook Groups</td>
                    <td>Free</td>
                    <td>Low</td>
                    <td>Medium</td>
                    <td><span class="speed-fast" style="background:#fee2e2; color:#991b1b;">Slow</span></td>
                </tr>
                <tr>
                    <td>LinkedIn Outreach</td>
                    <td>Free-\$80/mo</td>
                    <td>Medium</td>
                    <td class="high-badge">High</td>
                    <td><span class="speed-fast" style="background:#fef9c3; color:#854d0e;">Medium</span></td>
                </tr>
                <tr>
                    <td>Paid Ads</td>
                    <td>High</td>
                    <td>High</td>
                    <td>Medium</td>
                    <td><span class="speed-fast">Fast</span></td>
                </tr>
                <tr>
                    <td><b>Moonshine Tools</b></td>
                    <td><b>Free-Premium</b></td>
                    <td><b>Low</b></td>
                    <td class="high-badge"><b>Very High</b></td>
                    <td><span class="speed-fast">Fast</span></td>
                </tr>
            </tbody>
        </table>
    </div>
</section>

<!-- Qualification Checklist -->
<section class="container">
    <div class="qual-box">
        <div class="checklist">
            <h4><i class="fas fa-circle-check" style="color:var(--conversion-green)"></i> Qualification Checklist</h4>
            <ul>
                <li><i class="fas fa-check"></i> Business operating 3+ months</li>
                <li><i class="fas fa-check"></i> Monthly revenue \$10K+</li>
                <li><i class="fas fa-check"></i> Owner is primary decision-maker</li>
                <li><i class="fas fa-check"></i> Accurate contact info (Phone/Email)</li>
                <li><i class="fas fa-check"></i> Clear articulation of funding need</li>
            </ul>
        </div>
        <div class="checklist">
            <h4><i class="fas fa-circle-xmark" style="color:#ef4444"></i> Red Flags to Watch For</h4>
            <ul>
                <li><i class="fas fa-xmark"></i> Brand new startups (No revenue)</li>
                <li><i class="fas fa-xmark"></i> Credit score below 500</li>
                <li><i class="fas fa-xmark"></i> Active/Undisclosed Bankruptcies</li>
                <li><i class="fas fa-xmark"></i> Unrealistic expectations (100x Rev)</li>
                <li><i class="fas fa-xmark"></i> Reluctance to provide bank statements</li>
            </ul>
        </div>
    </div>
</section>

<!-- Decision Tree -->
<section class="decision-tree">
    <div class="container">
        <div class="section-header">
            <h2 style="color:white">Which Strategy Should You Use?</h2>
            <p style="color:#94a3b8">Select the path that matches your current business stage.</p>
        </div>
        <div class="tree-grid">
            <div class="tree-node">
                <h4>No Budget</h4>
                <p>Focus on FB Groups & LinkedIn Outreach.</p>
                <button class="btn btn-secondary">Get Starter Kit</button>
            </div>
            <div class="tree-node">
                <h4>\$500 - \$2K Budget</h4>
                <p>Invest in Paid Ads & DFY Funnels.</p>
                <button class="btn btn-primary">Scale Now</button>
            </div>
            <div class="tree-node">
                <h4>Strong Network</h4>
                <p>Leverage Referral Partner Kits.</p>
                <button class="btn btn-secondary">Get Referral Kit</button>
            </div>
            <div class="tree-node">
                <h4>Hands-Off</h4>
                <p>Monthly DFY Lead Generation.</p>
                <button class="btn btn-primary" style="background:var(--analytics-purple)">Apply for DFY</button>
            </div>
        </div>
    </div>
</section>

<!-- Final CTA -->
<section class="final-cta container">
    <h2>Ready to scale your funding volume?</h2>
    <p class="subheadline" style="margin: 0 auto 40px;">Access the entire Marketing Hub instantly and start generating qualified leads tonight.</p>
    <div class="cta-group" style="justify-content: center;">
        <a href="#" class="btn btn-primary">Get Free Lead Gen Tools</a>
        <a href="#" class="btn btn-secondary">Talk to a Growth Expert</a>
    </div>
    <div class="proof-bar">
        <div class="proof-item">
            <b>20+ Leads/Week</b>
            Average Partner Result
        </div>
        <div class="proof-item">
            <b>3 Deals/Mo</b>
            Closed Per Partner
        </div>
        <div class="proof-item">
            <b>12.5%</b>
            Avg Funnel Conversion
        </div>
    </div>
</section>
      ` }} />
    </main>
  );
}
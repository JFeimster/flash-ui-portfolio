import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<div class="app-container">
    <!-- Main Premium Header -->
    <header>
        <div class="brand">
            <div class="brand-logo">V</div>
            <div class="brand-title">Valois</div>
            <div class="brand-tag">F.I.E. v2.4</div>
        </div>
        <div class="controls-group">
            <select class="select-archetype" id="archetypeSelect" onchange="loadArchetype(this.value)">
                <!-- Generated dynamically from JSON structural config -->
            </select>
            <button class="btn-toggle" onclick="toggleWhiteLabel()">
                <div class="indicator" id="whiteLabelIndicator"></div>
                <span id="whiteLabelText">White-Label Delivery</span>
            </button>
        </div>
    </header>

    <!-- Bento Analytics View Grid -->
    <div class="bento-grid">
        
        <!-- Bento Card: Funding Readiness Scorecard (Left - Col 4) -->
        <div class="bento-card col-scorecard">
            <div class="card-header">
                <div class="card-title-group">
                    <div class="card-label">Readiness Assessment</div>
                    <div class="card-title">Readiness Index</div>
                </div>
                <span class="preview-badge">Real-time</span>
            </div>

            <div class="score-visual-container">
                <svg class="score-svg" viewBox="0 0 160 160">
                    <defs>
                        <linearGradient id="scoreGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="#8b5cf6" />
                            <stop offset="100%" stop-color="#ec4899" />
                        </linearGradient>
                    </defs>
                    <circle class="score-svg-bg" cx="80" cy="80" r="70"></circle>
                    <circle class="score-svg-val glow-purple" id="scoreValueArc" cx="80" cy="80" r="70"></circle>
                </svg>
                <div class="score-text-absolute">
                    <div class="score-number" id="scoreNumDisplay">--</div>
                    <div class="score-tier" id="scoreTierDisplay">Analyzing</div>
                </div>
            </div>

            <!-- Dynamic Credit Dimensions -->
            <div class="dimensions-grid" id="dimensionsContainer">
                <!-- Dynamically injected dimension items -->
            </div>
        </div>

        <!-- Bento Card: Funding Path Recommendations (Right - Col 8) -->
        <div class="bento-card col-recommendations">
            <div class="card-header">
                <div class="card-title-group">
                    <div class="card-label">Strategic Allocation</div>
                    <div class="card-title">Matched Funding Pathways</div>
                </div>
                <span class="preview-badge" style="color: var(--accent-emerald);">Highly Compatible</span>
            </div>

            <div class="path-list" id="pathRecommendationContainer">
                <!-- Dynamically calculated paths depending on selection rules -->
            </div>
        </div>

        <!-- Bento Card: Risk Assessment Flags (Left - Col 4) -->
        <div class="bento-card col-risk">
            <div class="card-header">
                <div class="card-title-group">
                    <div class="card-label">Underwriting Risk</div>
                    <div class="card-title">Risk Engine Triggers</div>
                </div>
            </div>
            <div class="risk-list" id="riskFlagsContainer">
                <!-- Dynamic risk items loaded -->
            </div>
        </div>

        <!-- Bento Card: White-Labeled Shared View Preview (Right - Col 8) -->
        <div class="bento-card col-whitelabel" id="whiteLabelComponent">
            <div class="card-header">
                <div class="card-title-group">
                    <div class="card-label" id="wlBrandSubtitle">Public Access Client Portal</div>
                    <div class="card-title" id="wlBrandTitle">VALOIS Partner Delivery Node</div>
                </div>
                <span class="preview-badge" id="wlModeLabel">Secure Client Vault</span>
            </div>

            <p class="vertical-desc" style="margin-bottom: 16px;" id="wlDesc">
                This public secure view represents the white-labeled presentation delivery framework. Underwriting rules, proprietary credit matrices, and system debug diagnostics have been stripped to maintain compliance.
            </p>

            <div class="preview-pane">
                <div class="preview-header">
                    <span style="font-weight: 600;" id="wlSelectedName">Borrower Presentation Workspace</span>
                    <span class="preview-badge" style="background: rgba(16, 185, 129, 0.1); color: var(--accent-emerald);">Pre-Verified Status</span>
                </div>
                <div class="preview-body-content">
                    <div class="preview-value-blocks">
                        <div class="val-block">
                            <div class="v-stat-lbl">Aggregate Limit</div>
                            <div class="v-stat-val" style="font-size: 16px; margin-top: 4px;" id="wlAggLimit">\$0.00</div>
                        </div>
                        <div class="val-block">
                            <div class="v-stat-lbl">Readiness Classification</div>
                            <div class="v-stat-val" style="font-size: 16px; margin-top: 4px; color: var(--accent-purple);" id="wlClass">Tier-A</div>
                        </div>
                        <div class="val-block">
                            <div class="v-stat-lbl">Estimated Weighted Cost</div>
                            <div class="v-stat-val" style="font-size: 16px; margin-top: 4px;" id="wlCost">-- %</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Verticals Section Header (Col 12) -->
        <div class="verticals-header">
            <h3 style="font-size: 14px; font-weight: 600; text-transform: uppercase; letter-spacing: 1.5px; color: var(--text-secondary);">Vertical Funding Modules</h3>
        </div>

        <!-- Dynamic Vertical Route Cards (6 items span 4 columns each) -->
        <!-- Vertical 1: Working Capital -->
        <div class="bento-card col-vertical" id="route-working-capital">
            <div class="vertical-meta">
                <div class="vertical-icon-wrap">⚡</div>
                <span class="preview-badge">30-Sec Check</span>
            </div>
            <div>
                <h4 style="font-size: 15px; font-weight: 600; margin: 12px 0 4px 0;">Working Capital</h4>
                <p class="vertical-desc">Optimized short-term liquidity models aligning invoice, inventory, and payroll lifecycles cleanly.</p>
            </div>
            <div class="vertical-stats">
                <div class="v-stat">
                    <span class="v-stat-lbl">LTV Max</span>
                    <span class="v-stat-val" id="wc-ltv">--</span>
                </div>
                <div class="v-stat">
                    <span class="v-stat-lbl">Target APR</span>
                    <span class="v-stat-val" id="wc-apr">--</span>
                </div>
            </div>
        </div>

        <!-- Vertical 2: Ecommerce Funding -->
        <div class="bento-card col-vertical" id="route-ecommerce">
            <div class="vertical-meta">
                <div class="vertical-icon-wrap">🛒</div>
                <span class="preview-badge">Direct Sync</span>
            </div>
            <div>
                <h4 style="font-size: 15px; font-weight: 600; margin: 12px 0 4px 0;">E-commerce Capital</h4>
                <p class="vertical-desc">Non-dilutive marketing and inventory financing scaled against dynamic store revenue streams.</p>
            </div>
            <div class="vertical-stats">
                <div class="v-stat">
                    <span class="v-stat-lbl">Multiples</span>
                    <span class="v-stat-val" id="ecom-mult">--</span>
                </div>
                <div class="v-stat">
                    <span class="v-stat-lbl">Min Monthly Rev</span>
                    <span class="v-stat-val" id="ecom-min">--</span>
                </div>
            </div>
        </div>

        <!-- Vertical 3: Startup Funding -->
        <div class="bento-card col-vertical" id="route-startup">
            <div class="vertical-meta">
                <div class="vertical-icon-wrap">🚀</div>
                <span class="preview-badge">Venture Debt</span>
            </div>
            <div>
                <h4 style="font-size: 15px; font-weight: 600; margin: 12px 0 4px 0;">Startup / Venture</h4>
                <p class="vertical-desc">Extended non-dilutive lines designed to extend runway between financing rounds and protect equity.</p>
            </div>
            <div class="vertical-stats">
                <div class="v-stat">
                    <span class="v-stat-lbl">Leverage Limit</span>
                    <span class="v-stat-val" id="startup-lev">--</span>
                </div>
                <div class="v-stat">
                    <span class="v-stat-lbl">Warrant Cover</span>
                    <span class="v-stat-val" id="startup-warr">--</span>
                </div>
            </div>
        </div>

        <!-- Vertical 4: Equipment Funding -->
        <div class="bento-card col-vertical" id="route-equipment">
            <div class="vertical-meta">
                <div class="vertical-icon-wrap">⚙️</div>
                <span class="preview-badge">Hard Asset</span>
            </div>
            <div>
                <h4 style="font-size: 15px; font-weight: 600; margin: 12px 0 4px 0;">Equipment Financing</h4>
                <p class="vertical-desc">High-LTV structural asset-backed instruments to acquire hardware without locking capital.</p>
            </div>
            <div class="vertical-stats">
                <div class="v-stat">
                    <span class="v-stat-lbl">Max Term</span>
                    <span class="v-stat-val" id="equip-term">--</span>
                </div>
                <div class="v-stat">
                    <span class="v-stat-lbl">Amortization</span>
                    <span class="v-stat-val" id="equip-amort">--</span>
                </div>
            </div>
        </div>

        <!-- Vertical 5: Real Estate Funding -->
        <div class="bento-card col-vertical" id="route-real-estate">
            <div class="vertical-meta">
                <div class="vertical-icon-wrap">🏢</div>
                <span class="preview-badge">Bridge Asset</span>
            </div>
            <div>
                <h4 style="font-size: 15px; font-weight: 600; margin: 12px 0 4px 0;">Commercial Real Estate</h4>
                <p class="vertical-desc">Bridge & permanent lending instruments built around asset collateral appraisal and cash-flow yields.</p>
            </div>
            <div class="vertical-stats">
                <div class="v-stat">
                    <span class="v-stat-lbl">LTV Threshold</span>
                    <span class="v-stat-val" id="re-ltv">--</span>
                </div>
                <div class="v-stat">
                    <span class="v-stat-lbl">DSCR Target</span>
                    <span class="v-stat-val" id="re-dscr">--</span>
                </div>
            </div>
        </div>

        <!-- Vertical 6: Acquisition Funding -->
        <div class="bento-card col-vertical" id="route-acquisition">
            <div class="vertical-meta">
                <div class="vertical-icon-wrap">🤝</div>
                <span class="preview-badge">LBO / M&A</span>
            </div>
            <div>
                <h4 style="font-size: 15px; font-weight: 600; margin: 12px 0 4px 0;">Acquisition & Buyouts</h4>
                <p class="vertical-desc">Strategic capitalization designed to fuel market expansion, buyout scenarios, or merger transactions.</p>
            </div>
            <div class="vertical-stats">
                <div class="v-stat">
                    <span class="v-stat-lbl">Debt Service Cov</span>
                    <span class="v-stat-val" id="acq-dscr">--</span>
                </div>
                <div class="v-stat">
                    <span class="v-stat-lbl">Target Leverage</span>
                    <span class="v-stat-val" id="acq-lev">--</span>
                </div>
            </div>
        </div>

        <!-- Partner/Affiliate CTA Area (Col 12) -->
        <div class="bento-card col-partner">
            <div class="partner-content">
                <div class="card-label" style="color: var(--text-primary); margin-bottom: 4px;">Partner Ecosystem Integration</div>
                <h3 style="font-size: 18px; font-weight: 600; margin-bottom: 8px;">Instantly syndicate pre-approved capital requirements</h3>
                <p class="vertical-desc" style="max-width: 500px;">Connect directly via Valois’ institutional network nodes. Share clean borrower credentials securely without exposing sensitive private financials.</p>
            </div>
            <button class="partner-btn" onclick="triggerPartnerAction()">Generate Partner Code</button>
        </div>

    </div>

    <!-- Footnotes Compliance Component -->
    <footer>
        <p class="compliance-text">
            * VALOIS Funding Intelligence Engine utilizes proprietary simulations and does not represent a direct offer to lend. Data processed on this user client system assumes configurations conforming to FDIC and SEC-compliant banking institutions. Real values may vary based on exact live market valuations, underwriting, and risk assessments.
        </p>
        <div class="compliance-row">
            <span>© Valois Technology Group. All Rights Reserved. Private & Institutional Use Only.</span>
            <span>FCRA Safe Harbor Secured // SSL-v2 Protocol</span>
        </div>
    </footer>
</div>

<!-- Analyst / Debug Drawer Button -->
<button class="debug-trigger-btn" onclick="toggleDebugDrawer()">
    <span>⚡</span> SYSTEM CONTROL & CONFIG FILES
</button>

<!-- Bottom Analyst Drawer (Debug Interface) -->
<div class="debug-drawer" id="analystDrawer">
    <div class="debug-header">
        <div class="debug-title">Analyst Engine & Simulation Configs Panel</div>
        <div class="debug-tabs">
            <button class="debug-tab active" onclick="switchDebugTab('archetypes')">borrower_archetypes.json</button>
            <button class="debug-tab" onclick="switchDebugTab('providers')">providers.json</button>
            <button class="debug-tab" onclick="switchDebugTab('routing')">routing_logic.json</button>
            <button class="debug-tab" onclick="switchDebugTab('vercel')">Vercel Deployment Guide</button>
        </div>
        <button class="close-debug-btn" onclick="toggleDebugDrawer()">✕</button>
    </div>
    <div class="debug-body" id="debugContent">
        <!-- Will display selected configuration contents dynamically -->
    </div>
</div>

<script>
    // Embedded simulation JSON data structures matching requested design pattern:
    // borrower_archetypes.json, providers.json, products.json, routing_logic.json,
    // recommendation_weights.json, risk_flags.json, readiness_dimensions.json

    const borrower_archetypes = {
        "saas_series_a": {
            "name": "SaaS Platform (Series A)",
            "arr": 4500000,
            "mrr": 375000,
            "runway_months": 18,
            "dscr": 1.45,
            "ebitda": -250000,
            "readinessScore": 84,
            "risk_triggers": ["negative_ebitda", "elevated_cac_payback"],
            "dimensions": {
                "capital": 88,
                "capacity": 79,
                "collateral": 55,
                "character": 92,
                "conditions": 85
            },
            "verticals_config": {
                "wc_ltv": "N/A", "wc_apr": "8.4%",
                "ecom_mult": "N/A", "ecom_min": "N/A",
                "startup_lev": "3.5x ARR", "startup_warr": "0.15%",
                "equip_term": "48 M", "equip_amort": "Straight",
                "re_ltv": "N/A", "re_dscr": "N/A",
                "acq_dscr": "1.35x", "acq_lev": "2.8x"
            }
        },
        "ecom_scaleup": {
            "name": "E-Commerce Velocity Scaleup",
            "arr": 8200000,
            "mrr": 680000,
            "runway_months": 24,
            "dscr": 1.20,
            "ebitda": 150000,
            "readinessScore": 76,
            "risk_triggers": ["inventory_concentration", "supply_chain_exposure"],
            "dimensions": {
                "capital": 65,
                "capacity": 85,
                "collateral": 70,
                "character": 80,
                "conditions": 75
            },
            "verticals_config": {
                "wc_ltv": "1.25x Inventory", "wc_apr": "9.2%",
                "ecom_mult": "3.5x MRR", "ecom_min": "\$100k",
                "startup_lev": "N/A", "startup_warr": "N/A",
                "equip_term": "36 M", "equip_amort": "Declining",
                "re_ltv": "N/A", "re_dscr": "N/A",
                "acq_dscr": "N/A", "acq_lev": "N/A"
            }
        },
        "heavy_logistics": {
            "name": "Apex Cargo & Logistics",
            "arr": 15400000,
            "mrr": 1280000,
            "runway_months": 48,
            "dscr": 2.15,
            "ebitda": 1250000,
            "readinessScore": 92,
            "risk_triggers": ["high_asset_maintenance"],
            "dimensions": {
                "capital": 95,
                "capacity": 94,
                "collateral": 98,
                "character": 90,
                "conditions": 82
            },
            "verticals_config": {
                "wc_ltv": "0.85x Accounts Rec", "wc_apr": "7.1%",
                "ecom_mult": "N/A", "ecom_min": "N/A",
                "startup_lev": "N/A", "startup_warr": "N/A",
                "equip_term": "72 M", "equip_amort": "Linear",
                "re_ltv": "75%", "re_dscr": "1.50x",
                "acq_dscr": "1.75x", "acq_lev": "3.2x"
            }
        },
        "mainstreet_med": {
            "name": "Core-Surgical Care Group",
            "arr": 3200000,
            "mrr": 266000,
            "runway_months": 60,
            "dscr": 1.80,
            "ebitda": 450000,
            "readinessScore": 88,
            "risk_triggers": [],
            "dimensions": {
                "capital": 85,
                "capacity": 90,
                "collateral": 80,
                "character": 95,
                "conditions": 90
            },
            "verticals_config": {
                "wc_ltv": "1.00x Rec", "wc_apr": "6.8%",
                "ecom_mult": "N/A", "ecom_min": "N/A",
                "startup_lev": "N/A", "startup_warr": "N/A",
                "equip_term": "60 M", "equip_amort": "Straight",
                "re_ltv": "80%", "re_dscr": "1.25x",
                "acq_dscr": "1.45x", "acq_lev": "2.5x"
            }
        }
    };

    const providers = [
        { "id": "p_valois_debt", "name": "Valois Credit Opportunities", "category": "Institutional Debt" },
        { "id": "p_vanguard", "name": "Vanguard Secured Lending", "category": "Asset-Backed Banking" },
        { "id": "p_apex_capital", "name": "Apex Velocity Finance", "category": "Growth Capital" }
    ];

    const products = [
        { "id": "prod_rev_debt", "name": "Revenue-Based Non-Dilutive Bond", "provider_id": "p_valois_debt" },
        { "id": "prod_venture_line", "name": "Venture Debt Runway Line", "provider_id": "p_valois_debt" },
        { "id": "prod_loc_secured", "name": "Asset-Backed Credit Facility", "provider_id": "p_vanguard" },
        { "id": "prod_growth_cash", "name": "Dynamic Working Capital Advance", "provider_id": "p_apex_capital" }
    ];

    const routing_logic = {
        "rules": [
            {
                "product_id": "prod_venture_line",
                "min_score": 80,
                "min_arr": 3000000,
                "max_leverage_arr_ratio": 0.45,
                "base_apr": "8.5%"
            },
            {
                "product_id": "prod_loc_secured",
                "min_score": 75,
                "min_dscr": 1.15,
                "max_leverage_arr_ratio": 0.35,
                "base_apr": "6.9%"
            },
            {
                "product_id": "prod_rev_debt",
                "min_score": 70,
                "min_arr": 1500000,
                "max_leverage_arr_ratio": 0.30,
                "base_apr": "9.2%"
            },
            {
                "product_id": "prod_growth_cash",
                "min_score": 65,
                "min_arr": 1000000,
                "max_leverage_arr_ratio": 0.25,
                "base_apr": "11.0%"
            }
        ]
    };

    const risk_flags = {
        "negative_ebitda": { "level": "Medium", "message": "EBITDA burn limits traditional cash-flow lending models." },
        "elevated_cac_payback": { "level": "Low", "message": "CAC Payback period exceeds target threshold metrics." },
        "inventory_concentration": { "level": "High", "message": "Supply node concentration poses operational pipeline threats." },
        "supply_chain_exposure": { "level": "Medium", "message": "Exposure to overseas customs clearances might restrict collateral validation." },
        "high_asset_maintenance": { "level": "Low", "message": "Capital expenditures forecast might impact debt servicing capability." }
    };

    const readiness_dimensions = {
        "capital": { "title": "Capital", "desc": "Equity-to-debt ratio" },
        "capacity": { "title": "Capacity", "desc": "Historical/expected runway & revenue" },
        "collateral": { "title": "Collateral", "desc": "Secured physical or IP assets" },
        "character": { "title": "Character", "desc": "Lender trust & executive history" },
        "conditions": { "title": "Conditions", "desc": "Market trends and macro risk vectors" }
    };

    // State Management
    let currentArchetypeKey = "saas_series_a";
    let whiteLabelModeActive = false;

    // Initialization
    window.onload = () => {
        // Build Archetype Switcher Select Dropdown options
        const select = document.getElementById("archetypeSelect");
        for (const [key, val] of Object.entries(borrower_archetypes)) {
            const opt = document.createElement("option");
            opt.value = key;
            opt.textContent = val.name;
            select.appendChild(opt);
        }

        loadArchetype(currentArchetypeKey);
        switchDebugTab('archetypes');
    };

    // Core Dynamic Rendering Engine
    function loadArchetype(key) {
        currentArchetypeKey = key;
        const arch = borrower_archetypes[key];

        // 1. Update Scorecard
        const targetScore = arch.readinessScore;
        updateScoreCircle(targetScore);

        // Update 5 Credit Dimensions
        const container = document.getElementById("dimensionsContainer");
        container.innerHTML = "";
        for (const [dimKey, val] of Object.entries(arch.dimensions)) {
            const labelMeta = readiness_dimensions[dimKey];
            container.innerHTML += \`
                <div class="dimension-item">
                    <div class="dimension-meta">
                        <span class="dimension-name">\${labelMeta.title}</span>
                        <span class="dimension-val">\${val}%</span>
                    </div>
                    <div class="dimension-bar-bg">
                        <div class="dimension-bar-fill" style="width: \${val}%;"></div>
                    </div>
                </div>
            \`;
        }

        // 2. Compute Routing & Load Recommendations
        const recContainer = document.getElementById("pathRecommendationContainer");
        recContainer.innerHTML = "";

        // Dynamic Rule Matching Compilation Logic
        const matchedProducts = [];
        routing_logic.rules.forEach(rule => {
            let matches = true;
            if (targetScore < rule.min_score) matches = false;
            if (arch.arr < (rule.min_arr || 0)) matches = false;
            if (rule.min_dscr && arch.dscr < rule.min_dscr) matches = false;

            if (matches) {
                const productInfo = products.find(p => p.id === rule.product_id);
                const providerInfo = providers.find(p => p.id === productInfo.provider_id);
                
                // Determine confidence & max capacity leverage based on system formulas
                const leverageMax = Math.round(arch.arr * rule.max_leverage_arr_ratio);
                const confidence = targetScore > 85 ? "High Match" : "Moderate Match";
                const confClass = targetScore > 85 ? "conf-high" : "conf-medium";

                matchedProducts.push({
                    name: productInfo.name,
                    provider: providerInfo.name,
                    capacity: \`\$\${(leverageMax / 1000000).toFixed(2)}M\`,
                    apr: rule.base_apr,
                    confidence: confidence,
                    confClass: confClass
                });
            }
        });

        if (matchedProducts.length === 0) {
            recContainer.innerHTML = \`<div class="path-row"><div class="path-title-text" style="color:var(--accent-rose);">No pre-qualified institutional facilities matching current routing rules.</div></div>\`;
        } else {
            matchedProducts.forEach(prod => {
                recContainer.innerHTML += \`
                    <div class="path-row">
                        <div class="path-meta-primary">
                            <span class="path-title-text">\${prod.name}</span>
                            <span class="path-provider">\${prod.provider}</span>
                        </div>
                        <div class="path-metric">
                            <span class="path-metric-lbl">Max Capacity</span>
                            <span class="path-metric-val">\${prod.capacity}</span>
                        </div>
                        <div class="path-metric">
                            <span class="path-metric-lbl">Indicative Cost</span>
                            <span class="path-metric-val" style="color: var(--accent-purple);">\${prod.apr}</span>
                        </div>
                        <div class="path-metric">
                            <span class="path-metric-lbl">System Confidence</span>
                            <span class="\${prod.confClass} confidence-pill">\${prod.confidence}</span>
                        </div>
                        <div class="action-icon">→</div>
                    </div>
                \`;
            });
        }

        // 3. Update Underwriting Risk Triggers
        const riskContainer = document.getElementById("riskFlagsContainer");
        riskContainer.innerHTML = "";
        
        if (arch.risk_triggers.length === 0) {
            riskContainer.innerHTML = \`
                <div class="risk-item" style="background: rgba(16, 185, 129, 0.03); border-color: rgba(16, 185, 129, 0.1);">
                    <div class="risk-icon" style="color: var(--accent-emerald);">✓</div>
                    <div class="risk-details">
                        <div class="risk-title" style="color: var(--accent-emerald);">0 Active Risk Triggers</div>
                        <div class="risk-desc">Credit dimensions fall clean of system risk parameters.</div>
                    </div>
                </div>
            \`;
        } else {
            arch.risk_triggers.forEach(trigger => {
                const spec = risk_flags[trigger];
                riskContainer.innerHTML += \`
                    <div class="risk-item">
                        <div class="risk-icon">⚠️</div>
                        <div class="risk-details">
                            <div class="risk-title">\${spec.level} Risk - \${trigger.toUpperCase().replace(/_/g, " ")}</div>
                            <div class="risk-desc">\${spec.message}</div>
                        </div>
                    </div>
                \`;
            });
        }

        // 4. Update Vertical Route Modules Stats
        for (const [vKey, val] of Object.entries(arch.verticals_config)) {
            const elem = document.getElementById(vKey);
            if (elem) {
                elem.textContent = val;
            }
        }

        // 5. Update White-Label Component Data
        const aggregatedLimitNum = Math.round(arch.arr * 0.45);
        document.getElementById("wlAggLimit").textContent = \`\$\${(aggregatedLimitNum/1000000).toFixed(2)}M\`;
        document.getElementById("wlClass").textContent = targetScore > 85 ? "Enterprise A+" : "Standard Tier-B";
        document.getElementById("wlCost").textContent = targetScore > 85 ? "6.85% (Weighted)" : "8.95% (Weighted)";
        document.getElementById("wlSelectedName").textContent = arch.name + " Secure Workspace";

        // Push current variables to the live Debug Console view if it's active
        updateConsoleOutput();
    }

    // Radial Score Progress Bar Animation Utility
    function updateScoreCircle(score) {
        const circle = document.getElementById("scoreValueArc");
        const radius = circle.r.baseVal.value;
        const circumference = 2 * Math.PI * radius;
        const offset = circumference - (score / 100) * circumference;
        
        circle.style.strokeDasharray = circumference;
        circle.style.strokeDashoffset = offset;

        // Animate counter
        const countDisplay = document.getElementById("scoreNumDisplay");
        let start = 0;
        const interval = setInterval(() => {
            if (start >= score) {
                clearInterval(interval);
                countDisplay.textContent = score;
            } else {
                start++;
                countDisplay.textContent = start;
            }
        }, 15);

        // Update Score Rating Category text
        const tierDisplay = document.getElementById("scoreTierDisplay");
        if (score >= 90) {
            tierDisplay.textContent = "Excellent Index";
            tierDisplay.style.color = "var(--accent-emerald)";
        } else if (score >= 80) {
            tierDisplay.textContent = "Premium Index";
            tierDisplay.style.color = "var(--accent-purple)";
        } else if (score >= 70) {
            tierDisplay.textContent = "Optimal Match";
            tierDisplay.style.color = "var(--accent-amber)";
        } else {
            tierDisplay.textContent = "Sub-Optimal";
            tierDisplay.style.color = "var(--accent-rose)";
        }
    }

    // Toggle White-Label View
    function toggleWhiteLabel() {
        whiteLabelModeActive = !whiteLabelModeActive;
        const body = document.body;
        const indicator = document.getElementById("whiteLabelIndicator");
        const wlComponent = document.getElementById("whiteLabelComponent");

        if (whiteLabelModeActive) {
            body.classList.add("white-label-mode");
            indicator.style.background = "var(--accent-emerald)";
            indicator.style.boxShadow = "0 0 8px var(--accent-emerald)";
            document.getElementById("whiteLabelText").textContent = "Public Secure Mode Active";
            
            // Transform brand parameters & public components visually to show bespoke styling
            document.getElementById("wlBrandTitle").textContent = "Beside Capital - Client Vault";
            document.getElementById("wlBrandSubtitle").textContent = "Syndicated Delivery Framework";
            document.getElementById("wlModeLabel").textContent = "Client Interface Active";
            wlComponent.style.border = "1px solid var(--accent-emerald)";
        } else {
            body.classList.remove("white-label-mode");
            indicator.style.background = "var(--accent-purple)";
            indicator.style.boxShadow = "0 0 8px var(--accent-purple)";
            document.getElementById("whiteLabelText").textContent = "White-Label Delivery";

            document.getElementById("wlBrandTitle").textContent = "VALOIS Partner Delivery Node";
            document.getElementById("wlBrandSubtitle").textContent = "Public Access Client Portal";
            document.getElementById("wlModeLabel").textContent = "Secure Client Vault";
            wlComponent.style.border = "1px dashed var(--border-muted)";
        }
    }

    // Partner Syndicated CTA Alert
    function triggerPartnerAction() {
        const arch = borrower_archetypes[currentArchetypeKey];
        const aggregateLimit = Math.round(arch.arr * 0.45);
        const code = \`VALOIS-\${Math.random().toString(36).substr(2, 6).toUpperCase()}-NODE-\${arch.readinessScore}\`;
        alert(\`Syndicated Partner Payload Generated!\n\nReference: \${code}\nVerified Limit: \$\${(aggregateLimit/1000000).toFixed(2)}M\nSecurity Standard: SEC-256 compliant export token generated.\`);
    }

    // Analyst Drawer Tabs & Debug Output Engine
    let activeDebugTab = "archetypes";

    function toggleDebugDrawer() {
        const drawer = document.getElementById("analystDrawer");
        drawer.classList.toggle("open");
    }

    function switchDebugTab(tabName) {
        activeDebugTab = tabName;
        const tabs = document.querySelectorAll(".debug-tab");
        tabs.forEach(tab => {
            tab.classList.remove("active");
            if (tab.innerText.includes(tabName) || (tabName === 'vercel' && tab.innerText.includes('Vercel'))) {
                tab.classList.add("active");
            }
        });
        updateConsoleOutput();
    }

    function updateConsoleOutput() {
        const output = document.getElementById("debugContent");
        
        if (activeDebugTab === "archetypes") {
            output.innerHTML = \`
                <div style="color: #a1a1aa; margin-bottom: 12px;">// Loaded: borrower_archetypes.json - Representing borrower personas parameters</div>
                <pre style="color: #c084fc;">\${JSON.stringify(borrower_archetypes, null, 2)}</pre>
            \`;
        } else if (activeDebugTab === "providers") {
            output.innerHTML = \`
                <div style="color: #a1a1aa; margin-bottom: 12px;">// Loaded: providers.json & products.json - Matched institutional channels</div>
                <pre style="color: #22d3ee;">\${JSON.stringify({ providers, products }, null, 2)}</pre>
            \`;
        } else if (activeDebugTab === "routing") {
            output.innerHTML = \`
                <div style="color: #a1a1aa; margin-bottom: 12px;">// Loaded: routing_logic.json & recommendation_weights.json - Live underwriting triggers</div>
                <pre style="color: #34d399;">\${JSON.stringify(routing_logic, null, 2)}</pre>
            \`;
        } else if (activeDebugTab === "vercel") {
            output.innerHTML = \`
                <div class="deployment-guide">
                    <h3 style="color: #f4f4f7; font-size: 14px; margin-bottom: 12px;">Deploy Valois Funding Intelligence to Vercel instantly</h3>
                    <p>To deploy this high-fidelity premium single page application directly on Vercel platform, use the following simple file layout framework:</p>
                    
                    <div class="code-block">
.
├── index.html       (Copy the entirety of this unified premium template)
├── package.json     (Minimal project metadata block)
└── vercel.json      (Deploy configurations routing file)
                    </div>

                    <h4 style="color: #f4f4f7; font-size: 12px; margin: 16px 0 8px 0;">Step 1: package.json Setup</h4>
                    <pre class="code-block">{
  "name": "valois-funding-intelligence",
  "version": "2.0.0",
  "scripts": {
    "start": "serve ."
  }
}</pre>

                    <h4 style="color: #f4f4f7; font-size: 12px; margin: 16px 0 8px 0;">Step 2: Install Vercel CLI & Deploy</h4>
                    <pre class="code-block">npm i -g vercel\nvercel deploy</pre>
                    <p style="color: var(--accent-emerald);">✔ Code compiles natively as a secure static web application requiring zero backend overhead.</p>
                </div>
            \`;
        }
    }
</script>
      ` }} />
    </main>
  );
}
import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<div class="aura-blob aura-1"></div>
    <div class="aura-blob aura-2"></div>

    <main class="sdr-container">
        <header class="header">
            <div class="header-title">
                <h1>AI SDR Engine v2.4</h1>
                <p>Autonomous end-to-end outbound infrastructure</p>
            </div>
            <div class="status-badge">
                <div class="status-dot"></div>
                SYSTEM ACTIVE
            </div>
        </header>

        <section class="config-grid">
            <div class="input-group">
                <label>Target City</label>
                <input type="text" class="input-field" placeholder="e.g. San Francisco">
            </div>
            <div class="input-group">
                <label>Market Niche</label>
                <input type="text" class="input-field" placeholder="e.g. SaaS Founders">
            </div>
            <div class="input-group">
                <label>Business Type</label>
                <input type="text" class="input-field" placeholder="e.g. B2B Fintech">
            </div>
        </section>

        <section class="pipeline-track">
            <div class="pipeline-line"></div>
            
            <div class="step active">
                <div class="step-node">🔍</div>
                <div class="step-label">Lead Source</div>
            </div>
            <div class="step active">
                <div class="step-node">🔬</div>
                <div class="step-label">Research</div>
            </div>
            <div class="step active">
                <div class="step-node">⚖️</div>
                <div class="step-label">Qualify</div>
            </div>
            <div class="step">
                <div class="step-node">✨</div>
                <div class="step-label">Personalize</div>
            </div>
            <div class="step">
                <div class="step-node">📝</div>
                <div class="step-label">Draft</div>
            </div>
            <div class="step">
                <div class="step-node">✉️</div>
                <div class="step-label">Send</div>
            </div>
            <div class="step">
                <div class="step-node">🔄</div>
                <div class="step-label">Follow-up</div>
            </div>
            <div class="step">
                <div class="step-node">📊</div>
                <div class="step-label">Analyze</div>
            </div>
        </section>

        <section class="dashboard-grid">
            <div class="metric-card">
                <span>Daily Outreach</span>
                <h3>482 <small style="font-size: 12px; color: #10b981;">+12%</small></h3>
            </div>
            <div class="metric-card">
                <span>Open Rate</span>
                <h3>64.2%</h3>
            </div>
            <div class="metric-card">
                <span>Replied</span>
                <h3>28</h3>
            </div>
            <div class="metric-card">
                <span>Meetings Set</span>
                <h3>4</h3>
            </div>
        </section>

        <footer class="footer">
            <div class="tools">
                <span style="font-size: 12px; color: var(--text-dim); margin-right: 8px;">Stack:</span>
                <div class="tool-chip">ChatGPT-4</div>
                <div class="tool-chip">Gemini</div>
                <div class="tool-chip">Notion</div>
                <div class="tool-chip">Gmail</div>
                <div class="tool-chip">Make.com</div>
            </div>
            <button class="btn-run">Start Campaign</button>
        </footer>
    </main>

    <script>
        // Simple animation logic for the pipeline
        const steps = document.querySelectorAll('.step');
        let currentIdx = 2;

        setInterval(() => {
            steps.forEach(s => s.classList.remove('active'));
            currentIdx = (currentIdx + 1) % steps.length;
            
            for(let i=0; i<=currentIdx; i++) {
                steps[i].classList.add('active');
            }
        }, 3000);
    </script>
      ` }} />
    </main>
  );
}
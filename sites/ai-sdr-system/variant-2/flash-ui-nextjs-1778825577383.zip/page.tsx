import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<div class="sdr-container">
        <!-- Configuration -->
        <aside class="config-sidebar">
            <h2 class="header-title">Engine Config</h2>
            
            <div class="input-group">
                <label>Target City</label>
                <input type="text" class="input-field" placeholder="e.g. San Francisco">
            </div>

            <div class="input-group">
                <label>Niche</label>
                <input type="text" class="input-field" placeholder="e.g. SaaS Founders">
            </div>

            <div class="input-group">
                <label>Business Type</label>
                <input type="text" class="input-field" placeholder="e.g. B2B Agency">
            </div>

            <div class="tools-section">
                <label class="header-title" style="font-size: 0.6rem; margin-bottom: 1rem; display: block;">Stack Integration</label>
                <div class="tool-tag">GPT-4o</div>
                <div class="tool-tag">Gemini Pro</div>
                <div class="tool-tag">Notion CRM</div>
                <div class="tool-tag">Gmail API</div>
                <div class="tool-tag">Make.com</div>
                <div class="tool-tag">Apps Script</div>
            </div>

            <button class="btn-execute">Initialize Engine</button>
        </aside>

        <!-- Main Display -->
        <main class="main-canvas">
            <div class="engine-status">
                <div>
                    <h1 style="font-size: 1.25rem; font-weight: 400; margin-bottom: 4px;">Outbound Pipeline</h1>
                    <p style="font-size: 0.75rem; color: var(--text-secondary);">Autonomous SDR System v2.4</p>
                </div>
                <div class="status-badge">
                    <div class="status-dot"></div>
                    SYSTEM LIVE
                </div>
            </div>

            <div class="pipeline-grid">
                <!-- Step 1 -->
                <div class="step-card active">
                    <span class="step-num">01</span>
                    <h3 class="step-name">Lead Source</h3>
                    <p class="step-desc">Extracting raw data via scraping and API enrichment.</p>
                </div>
                <!-- Step 2 -->
                <div class="step-card">
                    <span class="step-num">02</span>
                    <h3 class="step-name">Research</h3>
                    <p class="step-desc">Deep-diving LinkedIn and website content for context.</p>
                </div>
                <!-- Step 3 -->
                <div class="step-card">
                    <span class="step-num">03</span>
                    <h3 class="step-name">Qualify</h3>
                    <p class="step-desc">Filtering leads based on ICP and intent signals.</p>
                </div>
                <!-- Step 4 -->
                <div class="step-card">
                    <span class="step-num">04</span>
                    <h3 class="step-name">Personalize</h3>
                    <p class="step-desc">Generating hyper-specific icebreakers with LLMs.</p>
                </div>
                <!-- Step 5 -->
                <div class="step-card">
                    <span class="step-num">05</span>
                    <h3 class="step-name">Draft</h3>
                    <p class="step-desc">Structuring the value prop into high-conv email copy.</p>
                </div>
                <!-- Step 6 -->
                <div class="step-card">
                    <span class="step-num">06</span>
                    <h3 class="step-name">Send</h3>
                    <p class="step-desc">Routing through warm Gmail/SMTP relays.</p>
                </div>
                <!-- Step 7 -->
                <div class="step-card">
                    <span class="step-num">07</span>
                    <h3 class="step-name">Follow-up</h3>
                    <p class="step-desc">Automated sequence management and threading.</p>
                </div>
                <!-- Step 8 -->
                <div class="step-card">
                    <span class="step-num">08</span>
                    <h3 class="step-name">Analyze</h3>
                    <p class="step-desc">Feedback loop into Notion for conversion optimization.</p>
                </div>
            </div>

            <div class="analytics-strip">
                <div class="stat-item">
                    <span class="stat-value">124</span>
                    <span class="stat-label">Daily Outbound</span>
                </div>
                <div class="stat-item">
                    <span class="stat-value">18.2%</span>
                    <span class="stat-label">Reply Rate</span>
                </div>
                <div class="stat-item">
                    <span class="stat-value">92%</span>
                    <span class="stat-label">AI Confidence</span>
                </div>
                <div class="stat-item" style="margin-left: auto;">
                    <span class="stat-value" style="font-family: 'JetBrains Mono'; font-size: 0.9rem; color: var(--text-secondary);">ID: 0x82...FA9</span>
                    <span class="stat-label">Engine Instance</span>
                </div>
            </div>
        </main>
    </div>
      ` }} />
    </main>
  );
}
### Generated UI Component

To use this in Notion:
1. Create a "/code" block
2. Set language to "HTML"
3. Paste the following:

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Obsidian AI SDR Engine</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-color: #050505;
            --glass-bg: rgba(18, 18, 18, 0.7);
            --glass-border: rgba(255, 255, 255, 0.08);
            --accent-glow: rgba(120, 120, 120, 0.15);
            --text-primary: #e0e0e0;
            --text-secondary: #888888;
            --accent-color: #ffffff;
            --step-active: #ffffff;
            --step-muted: #2a2a2a;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            -webkit-font-smoothing: antialiased;
        }

        body {
            background-color: var(--bg-color);
            background-image: 
                radial-gradient(circle at 50% -20%, #1a1a1a 0%, transparent 70%),
                radial-gradient(circle at 0% 100%, #0a0a0a 0%, transparent 50%);
            color: var(--text-primary);
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 2rem;
        }

        .sdr-container {
            width: 100%;
            max-width: 1100px;
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 12px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
            overflow: hidden;
            display: grid;
            grid-template-columns: 320px 1fr;
        }

        /* Sidebar - Configuration */
        .config-sidebar {
            padding: 2rem;
            border-right: 1px solid var(--glass-border);
            background: rgba(0, 0, 0, 0.2);
        }

        .header-title {
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.2rem;
            color: var(--text-secondary);
            margin-bottom: 2rem;
            font-weight: 600;
        }

        .input-group {
            margin-bottom: 1.5rem;
        }

        .input-group label {
            display: block;
            font-size: 0.7rem;
            color: var(--text-secondary);
            margin-bottom: 0.5rem;
            text-transform: uppercase;
            letter-spacing: 0.05rem;
        }

        .input-field {
            width: 100%;
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--glass-border);
            border-radius: 6px;
            padding: 0.75rem;
            color: var(--text-primary);
            font-family: inherit;
            font-size: 0.9rem;
            transition: all 0.2s ease;
        }

        .input-field:focus {
            outline: none;
            border-color: rgba(255, 255, 255, 0.3);
            background: rgba(255, 255, 255, 0.05);
        }

        .tools-section {
            margin-top: 3rem;
        }

        .tool-tag {
            display: inline-flex;
            align-items: center;
            padding: 4px 8px;
            border-radius: 4px;
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--glass-border);
            font-size: 0.65rem;
            color: var(--text-secondary);
            margin: 0 4px 8px 0;
            font-family: 'JetBrains Mono', monospace;
        }

        /* Main Canvas */
        .main-canvas {
            padding: 2rem;
            display: flex;
            flex-direction: column;
        }

        .engine-status {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 3rem;
        }

        .status-badge {
            display: flex;
            align-items: center;
            font-size: 0.75rem;
            color: #4ade80;
            font-weight: 500;
        }

        .status-dot {
            width: 6px;
            height: 6px;
            background: #4ade80;
            border-radius: 50%;
            margin-right: 8px;
            box-shadow: 0 0 10px #4ade80;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.4; }
            100% { opacity: 1; }
        }

        /* Pipeline Grid */
        .pipeline-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 1.5rem;
            margin-bottom: 3rem;
        }

        .step-card {
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid var(--glass-border);
            padding: 1.25rem;
            border-radius: 8px;
            position: relative;
            transition: transform 0.3s ease, border-color 0.3s ease;
        }

        .step-card:hover {
            border-color: rgba(255, 255, 255, 0.2);
            transform: translateY(-2px);
        }

        .step-num {
            font-family: 'JetBrains Mono', monospace;
            font-size: 0.65rem;
            color: var(--text-secondary);
            margin-bottom: 0.75rem;
            display: block;
        }

        .step-name {
            font-size: 0.85rem;
            font-weight: 500;
            margin-bottom: 0.5rem;
            color: var(--text-primary);
        }

        .step-desc {
            font-size: 0.7rem;
            color: var(--text-secondary);
            line-height: 1.4;
        }

        .step-card.active {
            background: rgba(255, 255, 255, 0.05);
            border-color: rgba(255, 255, 255, 0.3);
        }

        /* Analytics Section */
        .analytics-strip {
            margin-top: auto;
            display: flex;
            gap: 2rem;
            padding-top: 2rem;
            border-top: 1px solid var(--glass-border);
        }

        .stat-item {
            display: flex;
            flex-direction: column;
        }

        .stat-value {
            font-size: 1.5rem;
            font-weight: 300;
            color: var(--accent-color);
        }

        .stat-label {
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 0.1rem;
            color: var(--text-secondary);
            margin-top: 4px;
        }

        /* Execution Button */
        .btn-execute {
            width: 100%;
            padding: 1rem;
            background: var(--accent-color);
            color: #000;
            border: none;
            border-radius: 6px;
            font-weight: 600;
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 0.1rem;
            cursor: pointer;
            margin-top: 2rem;
            transition: opacity 0.2s ease;
        }

        .btn-execute:hover {
            opacity: 0.9;
        }

        .flow-line {
            position: absolute;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--glass-border), transparent);
            width: 100%;
            top: 50%;
            z-index: -1;
        }

    </style>
</head>
<body>

    <div class="sdr-container">
        <!-- Configuration -->
        <aside class="config-sidebar">
            <h2 class="header-title">Engine Config</h2>
            
            <div class="input-group">
                <label>Target City</label>
                <input type="text" class="input-field" placeholder="e.g. San Francisco">
            </div>

            <div class="input-group">
                <label>Niche</label>
                <input type="text" class="input-field" placeholder="e.g. SaaS Founders">
            </div>

            <div class="input-group">
                <label>Business Type</label>
                <input type="text" class="input-field" placeholder="e.g. B2B Agency">
            </div>

            <div class="tools-section">
                <label class="header-title" style="font-size: 0.6rem; margin-bottom: 1rem; display: block;">Stack Integration</label>
                <div class="tool-tag">GPT-4o</div>
                <div class="tool-tag">Gemini Pro</div>
                <div class="tool-tag">Notion CRM</div>
                <div class="tool-tag">Gmail API</div>
                <div class="tool-tag">Make.com</div>
                <div class="tool-tag">Apps Script</div>
            </div>

            <button class="btn-execute">Initialize Engine</button>
        </aside>

        <!-- Main Display -->
        <main class="main-canvas">
            <div class="engine-status">
                <div>
                    <h1 style="font-size: 1.25rem; font-weight: 400; margin-bottom: 4px;">Outbound Pipeline</h1>
                    <p style="font-size: 0.75rem; color: var(--text-secondary);">Autonomous SDR System v2.4</p>
                </div>
                <div class="status-badge">
                    <div class="status-dot"></div>
                    SYSTEM LIVE
                </div>
            </div>

            <div class="pipeline-grid">
                <!-- Step 1 -->
                <div class="step-card active">
                    <span class="step-num">01</span>
                    <h3 class="step-name">Lead Source</h3>
                    <p class="step-desc">Extracting raw data via scraping and API enrichment.</p>
                </div>
                <!-- Step 2 -->
                <div class="step-card">
                    <span class="step-num">02</span>
                    <h3 class="step-name">Research</h3>
                    <p class="step-desc">Deep-diving LinkedIn and website content for context.</p>
                </div>
                <!-- Step 3 -->
                <div class="step-card">
                    <span class="step-num">03</span>
                    <h3 class="step-name">Qualify</h3>
                    <p class="step-desc">Filtering leads based on ICP and intent signals.</p>
                </div>
                <!-- Step 4 -->
                <div class="step-card">
                    <span class="step-num">04</span>
                    <h3 class="step-name">Personalize</h3>
                    <p class="step-desc">Generating hyper-specific icebreakers with LLMs.</p>
                </div>
                <!-- Step 5 -->
                <div class="step-card">
                    <span class="step-num">05</span>
                    <h3 class="step-name">Draft</h3>
                    <p class="step-desc">Structuring the value prop into high-conv email copy.</p>
                </div>
                <!-- Step 6 -->
                <div class="step-card">
                    <span class="step-num">06</span>
                    <h3 class="step-name">Send</h3>
                    <p class="step-desc">Routing through warm Gmail/SMTP relays.</p>
                </div>
                <!-- Step 7 -->
                <div class="step-card">
                    <span class="step-num">07</span>
                    <h3 class="step-name">Follow-up</h3>
                    <p class="step-desc">Automated sequence management and threading.</p>
                </div>
                <!-- Step 8 -->
                <div class="step-card">
                    <span class="step-num">08</span>
                    <h3 class="step-name">Analyze</h3>
                    <p class="step-desc">Feedback loop into Notion for conversion optimization.</p>
                </div>
            </div>

            <div class="analytics-strip">
                <div class="stat-item">
                    <span class="stat-value">124</span>
                    <span class="stat-label">Daily Outbound</span>
                </div>
                <div class="stat-item">
                    <span class="stat-value">18.2%</span>
                    <span class="stat-label">Reply Rate</span>
                </div>
                <div class="stat-item">
                    <span class="stat-value">92%</span>
                    <span class="stat-label">AI Confidence</span>
                </div>
                <div class="stat-item" style="margin-left: auto;">
                    <span class="stat-value" style="font-family: 'JetBrains Mono'; font-size: 0.9rem; color: var(--text-secondary);">ID: 0x82...FA9</span>
                    <span class="stat-label">Engine Instance</span>
                </div>
            </div>
        </main>
    </div>

</body>
</html>
```
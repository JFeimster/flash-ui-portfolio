import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<div class="sdr-container">
        <!-- Sidebar Config -->
        <aside class="config-panel">
            <header class="brand-header">
                <h1>Kinetic SDR</h1>
                <p>Autonomous Outreach Engine v4.0</p>
            </header>

            <div class="input-group">
                <label>Target City</label>
                <input type="text" class="input-field" placeholder="e.g. San Francisco" value="Austin, TX">
            </div>

            <div class="input-group">
                <label>Niche Market</label>
                <input type="text" class="input-field" placeholder="e.g. SaaS Founders" value="Fintech Startups">
            </div>

            <div class="input-group">
                <label>Business Type</label>
                <input type="text" class="input-field" placeholder="e.g. B2B Agency" value="Series A Platforms">
            </div>

            <button class="btn-launch">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
                Initialize Engine
            </button>

            <div style="margin-top: auto; padding-top: 20px;">
                <label style="font-size: 9px; color: var(--text-dim); display: block; margin-bottom: 10px; text-transform: uppercase;">Powered Integrations</label>
                <div class="integrations">
                    <img src="https://cdn.worldvectorlogo.com/logos/openai-2.svg" class="int-icon" title="ChatGPT-4o">
                    <img src="https://cdn.worldvectorlogo.com/logos/google-gemini-icon.svg" class="int-icon" title="Gemini 1.5">
                    <img src="https://cdn.worldvectorlogo.com/logos/notion-2.svg" class="int-icon" title="Notion DB">
                    <img src="https://cdn.worldvectorlogo.com/logos/gmail-icon.svg" class="int-icon" title="Gmail API">
                </div>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="engine-console">
            
            <!-- Workflow Steps -->
            <div class="workflow-visualizer">
                <div class="workflow-connector">
                    <div class="connector-progress"></div>
                </div>
                
                <div class="step-node complete">
                    <div class="node-circle">01</div>
                    <div class="node-label">Source</div>
                </div>
                <div class="step-node complete">
                    <div class="node-circle">02</div>
                    <div class="node-label">Research</div>
                </div>
                <div class="step-node complete">
                    <div class="node-circle">03</div>
                    <div class="node-label">Qualify</div>
                </div>
                <div class="step-node active">
                    <div class="node-circle">04</div>
                    <div class="node-label">Personalize</div>
                </div>
                <div class="step-node">
                    <div class="node-circle">05</div>
                    <div class="node-label">Draft</div>
                </div>
                <div class="step-node">
                    <div class="node-circle">06</div>
                    <div class="node-label">Send</div>
                </div>
                <div class="step-node">
                    <div class="node-circle">07</div>
                    <div class="node-label">Follow-up</div>
                </div>
                <div class="step-node">
                    <div class="node-circle">08</div>
                    <div class="node-label">Analyze</div>
                </div>
            </div>

            <div class="output-grid">
                <!-- Real-time Logs -->
                <div class="log-window">
                    <div class="log-entry">
                        <span class="ts">[10:42:01]</span>
                        <span class="tag">SYSTEM</span>
                        <span class="msg">Engine initialization successful...</span>
                    </div>
                    <div class="log-entry">
                        <span class="ts">[10:42:04]</span>
                        <span class="tag">SOURCE</span>
                        <span class="msg">Fetched 142 leads from Apollo/LinkedIn API</span>
                    </div>
                    <div class="log-entry">
                        <span class="ts">[10:42:09]</span>
                        <span class="tag">RESEARCH</span>
                        <span class="msg">Scanning website: neo-finance.io...</span>
                    </div>
                    <div class="log-entry">
                        <span class="ts">[10:42:12]</span>
                        <span class="tag">QUALIFY</span>
                        <span class="msg">Lead ID #492 verified. Score: 94/100</span>
                    </div>
                    <div class="log-entry">
                        <span class="ts">[10:42:15]</span>
                        <span class="tag">AI</span>
                        <span class="msg">Generating personalized hook via Gemini-Pro...</span>
                    </div>
                    <div class="log-entry">
                        <span class="ts">[10:42:18]</span>
                        <span class="tag">DRAFT</span>
                        <span class="msg">Drafting email for Alex Rivera (CTO)</span>
                    </div>
                    <div style="margin-top: 15px; color: var(--accent); font-size: 11px; display: flex; align-items: center;">
                        <span class="status-dot"></span> Processing lead queue...
                    </div>
                </div>

                <!-- Metrics -->
                <div class="stats-panel">
                    <div class="stat-card">
                        <div class="stat-val">2,481</div>
                        <div class="stat-label">Total Outbound</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-val" style="color: var(--accent);">18.4%</div>
                        <div class="stat-label">Response Rate</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-val">42</div>
                        <div class="stat-label">Meetings Booked</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-val" style="color: var(--success);">\$12.4k</div>
                        <div class="stat-label">Pipeline Value</div>
                    </div>
                </div>
            </div>

            <!-- Footer Meta -->
            <div style="display: flex; justify-content: space-between; align-items: center; padding: 0 10px;">
                <div style="display: flex; gap: 20px;">
                    <span style="font-size: 10px; color: var(--text-dim); text-transform: uppercase;">Node: US-EAST-1</span>
                    <span style="font-size: 10px; color: var(--text-dim); text-transform: uppercase;">Lat: 24ms</span>
                </div>
                <div style="font-size: 10px; color: var(--accent); font-family: var(--font-mono);">
                    SECURE_SSL_ENCRYPTED_SESSION // 0x88f21
                </div>
            </div>
        </main>
    </div>
      ` }} />
    </main>
  );
}
### Generated UI Component

To use this in Notion:
1. Create a "/code" block
2. Set language to "HTML"
3. Paste the following:

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carbon Kinetic | AI SDR Engine</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

        :root {
            --bg: #050505;
            --surface: #0d0d0d;
            --border: #222222;
            --accent: #00f2ff;
            --accent-soft: rgba(0, 242, 255, 0.1);
            --text-main: #e0e0e0;
            --text-dim: #777777;
            --success: #00ff88;
            --font-sans: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            --font-mono: 'JetBrains Mono', monospace;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            background-color: var(--bg);
            color: var(--text-main);
            font-family: var(--font-sans);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            overflow-x: hidden;
            background-image: 
                radial-gradient(circle at 50% -20%, #112244 0%, transparent 50%),
                radial-gradient(circle at 0% 0%, #0a0a0a 0%, transparent 100%);
        }

        .sdr-container {
            width: 100%;
            max-width: 1100px;
            padding: 40px;
            display: grid;
            grid-template-columns: 320px 1fr;
            gap: 24px;
            animation: fadeIn 1s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* --- Sidebar / Inputs --- */
        .config-panel {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 24px;
            display: flex;
            flex-direction: column;
            gap: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.4);
            position: relative;
            overflow: hidden;
        }

        .config-panel::before {
            content: '';
            position: absolute;
            top: 0; left: 0; width: 100%; height: 2px;
            background: linear-gradient(90deg, transparent, var(--accent), transparent);
        }

        .brand-header {
            margin-bottom: 10px;
        }

        .brand-header h1 {
            font-size: 14px;
            letter-spacing: 4px;
            text-transform: uppercase;
            color: var(--accent);
            font-weight: 700;
        }

        .brand-header p {
            font-size: 11px;
            color: var(--text-dim);
            margin-top: 4px;
        }

        .input-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .input-group label {
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: var(--text-dim);
            font-weight: 600;
        }

        .input-field {
            background: #000;
            border: 1px solid var(--border);
            border-radius: 6px;
            padding: 12px;
            color: #fff;
            font-size: 13px;
            outline: none;
            transition: var(--transition);
        }

        .input-field:focus {
            border-color: var(--accent);
            box-shadow: 0 0 10px var(--accent-soft);
        }

        .btn-launch {
            background: var(--accent);
            color: #000;
            border: none;
            padding: 14px;
            border-radius: 6px;
            font-weight: 700;
            font-size: 12px;
            text-transform: uppercase;
            cursor: pointer;
            margin-top: 10px;
            transition: var(--transition);
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 8px;
        }

        .btn-launch:hover {
            filter: brightness(1.1);
            transform: translateY(-1px);
            box-shadow: 0 4px 20px rgba(0, 242, 255, 0.3);
        }

        /* --- Main Engine Console --- */
        .engine-console {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .workflow-visualizer {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: relative;
        }

        .step-node {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 12px;
            z-index: 2;
            width: 80px;
        }

        .node-circle {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: #000;
            border: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 10px;
            color: var(--text-dim);
            transition: var(--transition);
        }

        .step-node.active .node-circle {
            border-color: var(--accent);
            color: var(--accent);
            box-shadow: 0 0 15px var(--accent-soft);
            background: var(--accent-soft);
        }

        .step-node.complete .node-circle {
            border-color: var(--success);
            color: var(--success);
        }

        .node-label {
            font-size: 10px;
            text-transform: uppercase;
            color: var(--text-dim);
            text-align: center;
            font-weight: 500;
        }

        .step-node.active .node-label { color: #fff; }

        .workflow-connector {
            position: absolute;
            top: 48px;
            left: 60px;
            right: 60px;
            height: 1px;
            background: var(--border);
            z-index: 1;
        }

        .connector-progress {
            position: absolute;
            height: 100%;
            background: var(--accent);
            width: 45%;
            box-shadow: 0 0 10px var(--accent);
        }

        /* --- Logs & Realtime --- */
        .output-grid {
            display: grid;
            grid-template-columns: 1fr 280px;
            gap: 20px;
            height: 360px;
        }

        .log-window {
            background: #000;
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 20px;
            font-family: var(--font-mono);
            font-size: 12px;
            overflow-y: auto;
            position: relative;
        }

        .log-entry {
            margin-bottom: 8px;
            display: flex;
            gap: 12px;
            opacity: 0.8;
        }

        .log-entry .ts { color: var(--text-dim); }
        .log-entry .tag { color: var(--accent); font-weight: 600; }
        .log-entry .msg { color: #ccc; }

        .log-window::-webkit-scrollbar { width: 4px; }
        .log-window::-webkit-scrollbar-thumb { background: var(--border); border-radius: 10px; }

        .stats-panel {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 20px;
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .stat-card {
            border-bottom: 1px solid var(--border);
            padding-bottom: 15px;
        }

        .stat-card:last-child { border: none; }

        .stat-val {
            font-size: 24px;
            font-weight: 700;
            color: #fff;
            font-family: var(--font-mono);
        }

        .stat-label {
            font-size: 11px;
            color: var(--text-dim);
            text-transform: uppercase;
            margin-top: 4px;
        }

        /* --- Integrations Bar --- */
        .integrations {
            display: flex;
            gap: 15px;
            align-items: center;
            background: rgba(255,255,255,0.02);
            padding: 12px 20px;
            border-radius: 50px;
            border: 1px solid var(--border);
            width: fit-content;
        }

        .int-icon {
            width: 20px;
            height: 20px;
            filter: grayscale(1) invert(1);
            opacity: 0.5;
            transition: var(--transition);
        }

        .int-icon:hover {
            opacity: 1;
            filter: grayscale(0) invert(0);
        }

        .status-dot {
            width: 6px;
            height: 6px;
            background: var(--success);
            border-radius: 50%;
            display: inline-block;
            margin-right: 6px;
            box-shadow: 0 0 8px var(--success);
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { opacity: 0.4; }
            50% { opacity: 1; }
            100% { opacity: 0.4; }
        }

        /* Responsive */
        @media (max-width: 900px) {
            .sdr-container {
                grid-template-columns: 1fr;
            }
            .workflow-visualizer {
                overflow-x: auto;
            }
            .output-grid {
                grid-template-columns: 1fr;
                height: auto;
            }
        }
    </style>
</head>
<body>

    <div class="sdr-container">
        <!-- Sidebar Config -->
        <aside class="config-panel">
            <header class="brand-header">
                <h1>Kinetic SDR</h1>
                <p>Autonomous Outreach Engine v4.0</p>
            </header>

            <div class="input-group">
                <label>Target City</label>
                <input type="text" class="input-field" placeholder="e.g. San Francisco" value="Austin, TX">
            </div>

            <div class="input-group">
                <label>Niche Market</label>
                <input type="text" class="input-field" placeholder="e.g. SaaS Founders" value="Fintech Startups">
            </div>

            <div class="input-group">
                <label>Business Type</label>
                <input type="text" class="input-field" placeholder="e.g. B2B Agency" value="Series A Platforms">
            </div>

            <button class="btn-launch">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
                Initialize Engine
            </button>

            <div style="margin-top: auto; padding-top: 20px;">
                <label style="font-size: 9px; color: var(--text-dim); display: block; margin-bottom: 10px; text-transform: uppercase;">Powered Integrations</label>
                <div class="integrations">
                    <img src="https://cdn.worldvectorlogo.com/logos/openai-2.svg" class="int-icon" title="ChatGPT-4o">
                    <img src="https://cdn.worldvectorlogo.com/logos/google-gemini-icon.svg" class="int-icon" title="Gemini 1.5">
                    <img src="https://cdn.worldvectorlogo.com/logos/notion-2.svg" class="int-icon" title="Notion DB">
                    <img src="https://cdn.worldvectorlogo.com/logos/gmail-icon.svg" class="int-icon" title="Gmail API">
                </div>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="engine-console">
            
            <!-- Workflow Steps -->
            <div class="workflow-visualizer">
                <div class="workflow-connector">
                    <div class="connector-progress"></div>
                </div>
                
                <div class="step-node complete">
                    <div class="node-circle">01</div>
                    <div class="node-label">Source</div>
                </div>
                <div class="step-node complete">
                    <div class="node-circle">02</div>
                    <div class="node-label">Research</div>
                </div>
                <div class="step-node complete">
                    <div class="node-circle">03</div>
                    <div class="node-label">Qualify</div>
                </div>
                <div class="step-node active">
                    <div class="node-circle">04</div>
                    <div class="node-label">Personalize</div>
                </div>
                <div class="step-node">
                    <div class="node-circle">05</div>
                    <div class="node-label">Draft</div>
                </div>
                <div class="step-node">
                    <div class="node-circle">06</div>
                    <div class="node-label">Send</div>
                </div>
                <div class="step-node">
                    <div class="node-circle">07</div>
                    <div class="node-label">Follow-up</div>
                </div>
                <div class="step-node">
                    <div class="node-circle">08</div>
                    <div class="node-label">Analyze</div>
                </div>
            </div>

            <div class="output-grid">
                <!-- Real-time Logs -->
                <div class="log-window">
                    <div class="log-entry">
                        <span class="ts">[10:42:01]</span>
                        <span class="tag">SYSTEM</span>
                        <span class="msg">Engine initialization successful...</span>
                    </div>
                    <div class="log-entry">
                        <span class="ts">[10:42:04]</span>
                        <span class="tag">SOURCE</span>
                        <span class="msg">Fetched 142 leads from Apollo/LinkedIn API</span>
                    </div>
                    <div class="log-entry">
                        <span class="ts">[10:42:09]</span>
                        <span class="tag">RESEARCH</span>
                        <span class="msg">Scanning website: neo-finance.io...</span>
                    </div>
                    <div class="log-entry">
                        <span class="ts">[10:42:12]</span>
                        <span class="tag">QUALIFY</span>
                        <span class="msg">Lead ID #492 verified. Score: 94/100</span>
                    </div>
                    <div class="log-entry">
                        <span class="ts">[10:42:15]</span>
                        <span class="tag">AI</span>
                        <span class="msg">Generating personalized hook via Gemini-Pro...</span>
                    </div>
                    <div class="log-entry">
                        <span class="ts">[10:42:18]</span>
                        <span class="tag">DRAFT</span>
                        <span class="msg">Drafting email for Alex Rivera (CTO)</span>
                    </div>
                    <div style="margin-top: 15px; color: var(--accent); font-size: 11px; display: flex; align-items: center;">
                        <span class="status-dot"></span> Processing lead queue...
                    </div>
                </div>

                <!-- Metrics -->
                <div class="stats-panel">
                    <div class="stat-card">
                        <div class="stat-val">2,481</div>
                        <div class="stat-label">Total Outbound</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-val" style="color: var(--accent);">18.4%</div>
                        <div class="stat-label">Response Rate</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-val">42</div>
                        <div class="stat-label">Meetings Booked</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-val" style="color: var(--success);">$12.4k</div>
                        <div class="stat-label">Pipeline Value</div>
                    </div>
                </div>
            </div>

            <!-- Footer Meta -->
            <div style="display: flex; justify-content: space-between; align-items: center; padding: 0 10px;">
                <div style="display: flex; gap: 20px;">
                    <span style="font-size: 10px; color: var(--text-dim); text-transform: uppercase;">Node: US-EAST-1</span>
                    <span style="font-size: 10px; color: var(--text-dim); text-transform: uppercase;">Lat: 24ms</span>
                </div>
                <div style="font-size: 10px; color: var(--accent); font-family: var(--font-mono);">
                    SECURE_SSL_ENCRYPTED_SESSION // 0x88f21
                </div>
            </div>
        </main>
    </div>

</body>
</html>
```
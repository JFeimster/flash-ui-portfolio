import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<div class="marquee-container">
        <div class="marquee-content">
            +++ CRITICAL MEME LEVELS DETECTED +++ WEAPONIZED SATIRE INBOUND +++ REJECT TRADITION, EMBRACE CHAOS +++ 100% ORGANIC SHITPOSTS +++ THE ALGORITHM CAN'T CATCH US +++
        </div>
    </div>

    <section class="hero">
        <div class="hook">STRICTLY CONFIDENTIAL // TOP SECRET</div>
        <h1>MEME<br>PROPAGANDA<br>DEPT.</h1>
        <p>A meme vault for jokes, cultural grenades, political satire, founder pain, AI weirdness, and other little JPEGs of <span class="redacted">psychological warfare</span>. Weaponized absurdity for the terminally online.</p>
        <a href="#vault" class="cta-btn">Enter the Meme Vault</a>
    </section>

    <div class="filters" id="vault">
        <button class="filter-btn active" onclick="filterMemes('all')">All Intel</button>
        <button class="filter-btn" onclick="filterMemes('politics')">Political Satire</button>
        <button class="filter-btn" onclick="filterMemes('startup')">Founder Pain</button>
        <button class="filter-btn" onclick="filterMemes('ai')">AI Weirdness</button>
        <button class="filter-btn" onclick="filterMemes('finance')">Finance/Degen</button>
    </div>

    <main class="vault-grid" id="meme-grid">
        <!-- AI -->
        <article class="meme-card" data-category="ai">
            <div class="meme-tag">AI WEIRDNESS</div>
            <img src="https://picsum.photos/seed/ai1/400/400" alt="Meme" class="meme-img">
            <div class="meme-title">When the prompt engineer gets a 400k salary for typing "cat in a hat".</div>
            <div class="card-actions">
                <button class="action-btn">DOWNLOAD</button>
                <button class="action-btn">REDEPLOY (SHARE)</button>
            </div>
        </article>

        <!-- Politics -->
        <article class="meme-card" data-category="politics">
            <div class="meme-tag">POLITICAL SATIRE</div>
            <img src="https://picsum.photos/seed/pol1/401/400" alt="Meme" class="meme-img">
            <div class="meme-title">The "Everything is Fine" dog, but he's running for Congress.</div>
            <div class="card-actions">
                <button class="action-btn">DOWNLOAD</button>
                <button class="action-btn">REDEPLOY (SHARE)</button>
            </div>
        </article>

        <!-- Startup -->
        <article class="meme-card" data-category="startup">
            <div class="meme-tag">FOUNDER PAIN</div>
            <img src="https://picsum.photos/seed/biz1/402/400" alt="Meme" class="meme-img">
            <div class="meme-title">VCs looking for "Profitability" in 2024 (Colorized).</div>
            <div class="card-actions">
                <button class="action-btn">DOWNLOAD</button>
                <button class="action-btn">REDEPLOY (SHARE)</button>
            </div>
        </article>

        <!-- Finance -->
        <article class="meme-card" data-category="finance">
            <div class="meme-tag">FINANCE/DEGEN</div>
            <img src="https://picsum.photos/seed/fin1/403/400" alt="Meme" class="meme-img">
            <div class="meme-title">Me explaining why my portfolio is down 98% but the tech is solid.</div>
            <div class="card-actions">
                <button class="action-btn">DOWNLOAD</button>
                <button class="action-btn">REDEPLOY (SHARE)</button>
            </div>
        </article>

        <!-- AI -->
        <article class="meme-card" data-category="ai">
            <div class="meme-tag">AI WEIRDNESS</div>
            <img src="https://picsum.photos/seed/ai2/404/400" alt="Meme" class="meme-img">
            <div class="meme-title">GPT-5 leak is just a guy in a box named Gary.</div>
            <div class="card-actions">
                <button class="action-btn">DOWNLOAD</button>
                <button class="action-btn">REDEPLOY (SHARE)</button>
            </div>
        </article>

        <!-- Startup -->
        <article class="meme-card" data-category="startup">
            <div class="meme-tag">FOUNDER PAIN</div>
            <img src="https://picsum.photos/seed/biz2/405/400" alt="Meme" class="meme-img">
            <div class="meme-title">POV: You just pivotted to AI for the 4th time this week.</div>
            <div class="card-actions">
                <button class="action-btn">DOWNLOAD</button>
                <button class="action-btn">REDEPLOY (SHARE)</button>
            </div>
        </article>
    </main>

    <section class="submit-section">
        <div class="sticker-cta">
            <h2 style="font-size: 2.5rem; margin-bottom: 15px;">GOT A WEAPON?</h2>
            <p style="font-size: 1.2rem; margin-bottom: 25px;">The Department needs your contributions. Submit your most toxic, hilarious, and <span class="redacted">illegal</span> JPEGs.</p>
            <button class="cta-btn" style="box-shadow: 8px 8px 0px var(--red); font-size: 1.5rem;">Upload Intel</button>
        </div>
    </section>

    <footer>
        <div class="newsletter-box">
            <h2>WEEKLY MEME DROP</h2>
            <p style="margin-bottom: 20px;">Receive the freshest propaganda directly in your secure terminal every Friday.</p>
            <div class="input-group">
                <input type="email" placeholder="EMAIL_ADDRESS@CYBERSPACE.GOV">
                <button class="submit-news">ENLIST</button>
            </div>
        </div>
        <div style="text-align: center; margin-top: 50px; font-size: 0.8rem; opacity: 0.5;">
            &copy; 2024 MEME PROPAGANDA DEPT. NO RIGHTS RESERVED. SHARE OR DIE.
        </div>
    </footer>

    <script>
        function filterMemes(category) {
            const cards = document.querySelectorAll('.meme-card');
            const buttons = document.querySelectorAll('.filter-btn');

            buttons.forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');

            cards.forEach(card => {
                if (category === 'all' || card.getAttribute('data-category') === category) {
                    card.style.display = 'flex';
                } else {
                    card.style.display = 'none';
                }
            });
        }
    </script>
      ` }} />
    </main>
  );
}
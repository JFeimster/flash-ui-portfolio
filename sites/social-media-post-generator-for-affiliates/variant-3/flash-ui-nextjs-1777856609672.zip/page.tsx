import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<nav>
        <div class="container" style="display:flex; justify-content: space-between; width:100%; align-items:center;">
            <div class="logo">
                <div class="logo-icon"></div>
                PostPulse
            </div>
            <div style="display:flex; gap: 32px; align-items:center;">
                <a href="#" class="btn-ghost">Pricing</a>
                <a href="#" class="btn-ghost">Templates</a>
                <a href="#" class="btn-primary">Generate My Posts</a>
            </div>
        </div>
    </nav>

    <header class="hero">
        <div class="container">
            <span class="badge">V2.0 is Live: Affiliate Power Tools</span>
            <h1>Never Stare at a Blank<br><span style="color:var(--primary)">Post Box Again.</span></h1>
            <p>Generate funding-related social posts, referral partner messages, and client education without sounding like every other LinkedIn goblin selling freedom from a rented Lamborghini.</p>
            <button class="btn-primary" style="padding: 18px 36px; font-size: 1.1rem;">Generate My Posts — It's Free</button>
        </div>
    </header>

    <section class="container">
        <div class="dashboard-ui">
            <div class="sidebar">
                <div class="sidebar-item active">Dashboard</div>
                <div class="sidebar-item">Saved Posts</div>
                <div class="sidebar-item">Partner Assets</div>
                <div class="sidebar-item">Campaigns</div>
                <div style="margin-top:auto" class="sidebar-item">Settings</div>
            </div>
            <div class="main-canvas">
                <div class="input-box">
                    <textarea placeholder="Describe your post idea... (e.g. '3 reasons small businesses need bridge loans right now')"></textarea>
                    <div style="display:flex; justify-content: space-between; align-items:center; margin-top:16px;">
                        <span style="font-size:0.8rem; color:var(--text-dim)">AI model: Pulse-Turbo-1</span>
                        <button class="btn-primary" style="padding: 8px 20px; font-size: 0.9rem;">Generate</button>
                    </div>
                </div>

                <h3 style="margin-bottom:16px;">Content Categories</h3>
                <div class="category-grid">
                    <div class="cat-card">
                        <div style="font-size:1.5rem; margin-bottom:10px;">💸</div>
                        <h4>Cash Flow Hacks</h4>
                        <p>Education on managing daily business liquidity.</p>
                    </div>
                    <div class="cat-card" style="border-color: var(--secondary)">
                        <div style="font-size:1.5rem; margin-bottom:10px;">🤝</div>
                        <h4>Referral Hooks</h4>
                        <p>Get CPAs and Attorneys to send you deals.</p>
                    </div>
                    <div class="cat-card">
                        <div style="font-size:1.5rem; margin-bottom:10px;">📈</div>
                        <h4>Client Success</h4>
                        <p>Case study templates that build authority.</p>
                    </div>
                    <div class="cat-card">
                        <div style="font-size:1.5rem; margin-bottom:10px;">🥊</div>
                        <h4>Myth Busting</h4>
                        <p>Calling out predatory lending practices.</p>
                    </div>
                    <div class="cat-card">
                        <div style="font-size:1.5rem; margin-bottom:10px;">🕒</div>
                        <h4>Follow-up</h4>
                        <p>Nudge cold leads without being annoying.</p>
                    </div>
                    <div class="cat-card">
                        <div style="font-size:1.5rem; margin-bottom:10px;">💎</div>
                        <h4>Value Bombs</h4>
                        <p>Pure education on business funding types.</p>
                    </div>
                </div>
            </div>
            <div class="preview-pane">
                <h4 style="margin-bottom:20px; color: var(--text-dim); text-transform: uppercase; font-size: 0.7rem; letter-spacing: 1px;">Live Preview</h4>
                <div class="social-preview">
                    <div class="social-header">
                        <div class="pfp" style="background: linear-gradient(45deg, #c2ff4d, #8b5cf6)"></div>
                        <div>
                            <div class="social-name">Your Name</div>
                            <div class="social-handle">Business Funding Advisor</div>
                        </div>
                    </div>
                    <div class="post-content">
                        Most entrepreneurs treat cash flow like a "someday" problem.<br><br>
                        But when the opportunity to scale hits, "someday" is too late. Bridge loans aren't just for emergencies—they are for growth velocity.<br><br>
                        Here are 3 ways to use capital to 2X your revenue this quarter...
                        <br><br>
                        <span class="post-tag">#BusinessFunding #Entrepreneurship</span>
                    </div>
                    <div style="height:150px; background:#f1f5f9; border-radius:8px; display:flex; align-items:center; justify-content:center; color:#94a3b8; font-size:0.8rem;">
                        [AI Generated Graphic Placeholder]
                    </div>
                </div>
                <button class="btn-ghost" style="width:100%; margin-top:20px; border: 1px solid var(--border); padding: 10px; border-radius: 8px;">Copy to Clipboard</button>
            </div>
        </div>
    </section>

    <section class="features container">
        <div class="section-header">
            <h2>Built for the Modern Affiliate</h2>
            <p>Specific use cases to help you dominate your niche.</p>
        </div>
        <div class="use-cases">
            <div class="case-card">
                <h3 style="margin-bottom:12px; color:var(--primary)">LinkedIn Thought Leader</h3>
                <p style="color:var(--text-dim)">Position yourself as the go-to authority for business capital. We generate 5-day sequences that lead directly into your DM funnel.</p>
            </div>
            <div class="case-card">
                <h3 style="margin-bottom:12px; color:var(--secondary)">Referral Network DM's</h3>
                <p style="color:var(--text-dim)">Ready-to-use scripts for CPAs, Real Estate Agents, and Tax Pros. Start the conversation without the awkward sales pitch.</p>
            </div>
            <div class="case-card">
                <h3 style="margin-bottom:12px; color:#38bdf8">The Education Bridge</h3>
                <p style="color:var(--text-dim)">Break down complex MCA, SBA, and Term Loan jargon into simple stories that business owners actually understand.</p>
            </div>
        </div>
    </section>

    <section class="faq container">
        <div class="section-header">
            <h2>Common Questions</h2>
        </div>
        <div class="faq-item">
            <div class="faq-q">Does this sound like a robot? <span>+</span></div>
            <div class="faq-a">Nope. Our "No-Cringe" filter prevents generic AI fluff and ensures you sound like a human who actually understands business.</div>
        </div>
        <div class="faq-item">
            <div class="faq-q">Can I customize the tone? <span>+</span></div>
            <div class="faq-a">Yes. Choose between "Aggressive Growth," "Educational Advisor," or "Straight Talker" to match your personal brand.</div>
        </div>
        <div class="faq-item">
            <div class="faq-q">Is it just for LinkedIn? <span>+</span></div>
            <div class="faq-a">We support LinkedIn, Twitter/X, Instagram, and even direct email/SMS templates for your leads.</div>
        </div>
    </section>

    <section class="final-cta container">
        <h2>Ready to fill your pipeline?</h2>
        <p style="margin-bottom:40px;">Stop overthinking. Start posting. Get funded.</p>
        <button class="btn-primary" style="padding: 20px 48px; font-size: 1.25rem;">Generate My Posts Now</button>
        <div style="margin-top:24px; font-size:0.8rem; color:var(--text-dim)">No credit card required. Join 2,000+ top-tier affiliates.</div>
    </section>

    <footer style="padding: 40px 0; border-top: 1px solid var(--border); text-align: center; color: var(--text-dim); font-size: 0.8rem;">
        &copy; 2024 PostPulse AI. Built for high-performance partners.
    </footer>
      ` }} />
    </main>
  );
}
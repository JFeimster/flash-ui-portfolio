import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<div class="container">
        <nav>
            <div class="logo">FUNDFLOW.AI</div>
            <a href="#" class="btn-primary" style="padding: 10px 20px; font-size: 12px;">Sign In</a>
        </nav>

        <header class="hero">
            <div class="hook">Never Stare at a Blank Post Box Again</div>
            <h1>The Funding Affiliate's <br><span class="neon-text">Secret Weapon.</span></h1>
            <p>Generate high-converting social posts, referral partner messages, and client education captions without sounding like every other LinkedIn goblin selling "freedom" from a rented Lamborghini.</p>
            <button class="btn-primary">Generate My Posts — Free</button>
        </header>

        <div class="dashboard-mockup">
            <div class="sidebar">
                <div class="nav-item active">✨ Post Generator</div>
                <div class="nav-item">📁 Saved Assets</div>
                <div class="nav-item">📈 Performance</div>
                <div class="nav-item">🤝 Partner Leads</div>
                <div class="nav-item">⚙️ Settings</div>
            </div>
            
            <div class="main-panel">
                <div class="prompt-box">
                    <textarea placeholder="Describe your topic (e.g., 'Why bridge loans are better than MCA for retail businesses')"></textarea>
                    <div style="display: flex; justify-content: flex-end;">
                        <button class="btn-primary" style="padding: 10px 25px;">Generate</button>
                    </div>
                </div>

                <div class="category-grid">
                    <div class="cat-card" style="border-left: 4px solid var(--neon-cyan);">
                        <h4>Business Funding</h4>
                        <p>Market updates, rate drops, and loan types.</p>
                    </div>
                    <div class="cat-card" style="border-left: 4px solid var(--neon-magenta);">
                        <h4>Client Education</h4>
                        <p>Explain credit scores and cash flow cycles.</p>
                    </div>
                    <div class="cat-card" style="border-left: 4px solid var(--neon-lime);">
                        <h4>Referral Hooks</h4>
                        <p>Messages for CPAs, Attorneys, and Agents.</p>
                    </div>
                    <div class="cat-card" style="border-left: 4px solid #ffa500;">
                        <h4>Entrepreneur Mindset</h4>
                        <p>Building wealth and leveraging debt.</p>
                    </div>
                </div>
            </div>

            <div class="preview-panel">
                <div style="font-size: 12px; color: var(--text-dim); margin-bottom: 10px; text-transform: uppercase; letter-spacing: 1px;">Live Preview</div>
                <div class="social-preview">
                    <div class="preview-header">
                        <div class="avatar"></div>
                        <div>
                            <div style="font-weight: bold;">Funding Expert</div>
                            <div style="font-size: 10px; color: #666;">2 hours ago • Edited</div>
                        </div>
                    </div>
                    <div style="margin-bottom: 10px;">
                        Stop looking at your bank balance and start looking at your <strong>Opportunity Cost</strong>. 💸
                    </div>
                    <div class="post-content">
                        Most business owners wait for "perfect timing" to scale. But in business funding, the perfect time is usually 3 months ago. <br><br>
                        Let's talk about unlocking \$50k-\$250k in credit lines...
                    </div>
                    <div style="margin-top: 15px; display: flex; gap: 10px;">
                        <button style="flex:1; padding: 8px; background: #eee; border: none; border-radius: 4px; font-size: 11px; font-weight: bold; cursor: pointer;">Copy Text</button>
                        <button style="flex:1; padding: 8px; background: var(--neon-cyan); border: none; border-radius: 4px; font-size: 11px; font-weight: bold; cursor: pointer;">Rewrite</button>
                    </div>
                </div>
            </div>
        </div>

        <section class="section-title">
            <h2>Made for Every <span class="neon-text">Partner Hook.</span></h2>
            <p>One tool to handle all your distribution channels.</p>
        </section>

        <div class="use-case-grid">
            <div class="use-case-card">
                <h3 style="color: var(--neon-cyan); margin-bottom: 15px;">The LinkedIn Thought Leader</h3>
                <p style="color: var(--text-dim);">Position yourself as a sophisticated funding advisor. No emojis-puke, just hard-hitting financial logic.</p>
            </div>
            <div class="use-case-card" style="border-color: #333;">
                <h3 style="color: var(--neon-magenta); margin-bottom: 15px;">The DM Hunter</h3>
                <p style="color: var(--text-dim);">Cold or warm outreach scripts that actually get replies from high-revenue business owners.</p>
            </div>
            <div class="use-case-card" style="border-color: #333;">
                <h3 style="color: var(--neon-lime); margin-bottom: 15px;">The Referral Network</h3>
                <p style="color: var(--text-dim);">Specific copy designed to make CPAs and Real Estate agents want to send you their clients.</p>
            </div>
        </div>

        <section class="faq-section">
            <h2 style="text-align: center; margin-bottom: 40px;">FAQs</h2>
            <div class="faq-item">
                <div class="faq-question">Will this sound like AI?</div>
                <div style="color: var(--text-dim);">No. We’ve trained our models on high-performing financial sales copy, not generic poetry. It speaks "funding."</div>
            </div>
            <div class="faq-item">
                <div class="faq-question">Can I use this for email marketing?</div>
                <div style="color: var(--text-dim);">Absolutely. The tool generates long-form captions that work perfectly as weekly newsletter content.</div>
            </div>
            <div class="faq-item">
                <div class="faq-question">How many posts can I generate?</div>
                <div style="color: var(--text-dim);">Unlimited on our Pro plan. Start with 5 free posts today to see the quality.</div>
            </div>
        </section>
    </div>

    <footer>
        <div class="container">
            <h2 style="font-size: 40px; margin-bottom: 20px;">Ready to dominate the <span class="neon-text">feed?</span></h2>
            <button class="btn-primary">Get Access to FundFlow.AI</button>
            <p style="margin-top: 40px; font-size: 12px; color: #444;">&copy; 2023 FundFlow. Built for the modern funding affiliate.</p>
        </div>
    </footer>
      ` }} />
    </main>
  );
}
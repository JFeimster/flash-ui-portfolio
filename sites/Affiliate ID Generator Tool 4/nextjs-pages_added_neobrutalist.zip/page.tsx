import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<div class="marquee">
        <span>STAY LIQUID // NO BAILOUTS // BLOCKCHAIN OR BUST // PUNK FINTECH // MOONSHINE CAPITAL // NO RULES // V.4.0.2-BETA // </span>
    </div>

    <header class="mb-12">
        <div class="glitch-text">MOONSHINE</div><br>
        <div class="glitch-text" style="background: var(--pink); transform: skew(5deg) translate(10px, -10px);">CAPITAL</div>
        <div class="mt-4 flex flex-wrap gap-4">
            <span class="tape">EST. 2024</span>
            <span class="tape" style="background: white;">PROTOCOL: 44-902</span>
            <span class="tape" style="background: var(--pink); color: white;">NODE: LND-88</span>
        </div>
    </header>

    <main class="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        <section class="lg:col-span-7">
            <div class="brutal-card p-8">
                <h2 class="text-3xl font-black mb-8 underline decoration-4">ENTITY REGISTRATION</h2>
                
                <form id="provisionForm" class="space-y-6">
                    <div>
                        <label class="block font-black mb-2">LEGAL NAME OR ALIAS</label>
                        <input type="text" id="fullName" required placeholder="WHO ARE YOU?" class="brutal-input">
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block font-black mb-2">PARTNER CLASS</label>
                            <select id="partnerType" class="brutal-input appearance-none">
                                <option value="BRK">BROKER [BRK]</option>
                                <option value="REF">REFERRAL [REF]</option>
                                <option value="AFF">AFFILIATE [AFF]</option>
                                <option value="VND">VENDOR [VND]</option>
                            </select>
                        </div>
                        <div>
                            <label class="block font-black mb-2">ENTRY DATE</label>
                            <input type="date" id="regDate" class="brutal-input">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block font-black mb-2">ENTITY CORP</label>
                            <input type="text" id="company" placeholder="SHELL COMPANY LLC" class="brutal-input">
                        </div>
                        <div>
                            <label class="block font-black mb-2">EMAIL (SECURE)</label>
                            <input type="email" id="email" placeholder="PUNK@WEB3.COM" class="brutal-input">
                        </div>
                    </div>

                    <button type="button" onclick="executeProvisioning()" class="btn-punk w-full text-2xl italic">
                        GENERATE ACCESS KEY
                    </button>
                </form>
            </div>
        </section>

        <section class="lg:col-span-5">
            <div id="resultCard" class="brutal-card p-8 bg-black text-white h-full transform lg:rotate-1">
                <h2 class="text-2xl font-black mb-6 text-accent">ASSIGNED IDENTIFIER</h2>
                
                <div class="border-4 border-dashed border-white p-6 text-center space-y-6">
                    <div id="idPlaceholder" class="text-5xl font-black tracking-tighter text-yellow-300 break-all">XXXX-XXXX</div>
                    
                    <div class="bg-white text-black p-4 rotate-1 font-mono font-bold">
                        <code id="urlDisplay" class="text-sm">URL WILL APPEAR HERE</code>
                    </div>

                    <button onclick="copyToClipboard()" class="w-full bg-yellow-300 text-black font-black py-2 hover:bg-white transition-colors">
                        COPY TO CLIPBOARD
                    </button>
                    
                    <div id="successMsg" class="text-xs font-black opacity-0">COPIED TO ENCRYPTED CACHE</div>
                </div>
            </div>
        </section>

        <section class="lg:col-span-12 mt-8">
            <div class="brutal-card p-6 overflow-hidden">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-4xl font-black transform -skew-x-12 bg-black text-white px-4 inline-block">RAW AUDIT LOG</h2>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full audit-table">
                        <thead>
                            <tr>
                                <th>IDENTITIY</th>
                                <th>MISSION ID</th>
                                <th>ENTITY</th>
                                <th>DATE</th>
                                <th>STATUS</th>
                            </tr>
                        </thead>
                        <tbody id="auditLog">
                            <tr>
                                <td>ALEXANDER THORNE</td>
                                <td class="font-bold">MC-BRK-AT24</td>
                                <td>THORNE EQUITIES</td>
                                <td>2024-05-12</td>
                                <td><span class="status-badge">ACTIVE</span></td>
                            </tr>
                            <tr>
                                <td>SARAH JENKINS</td>
                                <td class="font-bold">MC-REF-SJ23</td>
                                <td>DIRECT FLOW LLC</td>
                                <td>2023-11-20</td>
                                <td><span class="status-badge">ACTIVE</span></td>
                            </tr>
                            <tr>
                                <td>MARCUS VANE</td>
                                <td class="font-bold">MC-AFF-MV24</td>
                                <td>VANE GLOBAL</td>
                                <td>2024-01-05</td>
                                <td><span class="status-badge">ACTIVE</span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
    </main>

    <script>
        function executeProvisioning() {
            const fullName = document.getElementById('fullName').value;
            const partnerType = document.getElementById('partnerType').value;
            const regDate = document.getElementById('regDate').value;
            const company = document.getElementById('company').value || "N/A";
            
            if (!fullName) {
                alert("ERR: NAME REQUIRED TO GENERATE HASH");
                return;
            }

            const nameParts = fullName.trim().split(' ');
            const initials = nameParts.length > 1 
                ? (nameParts[0][0] + nameParts[nameParts.length - 1][0]).toUpperCase()
                : (nameParts[0][0] + (nameParts[0][1] || 'X')).toUpperCase();
            
            const year = regDate 
                ? regDate.substring(2, 4) 
                : new Date().getFullYear().toString().slice(-2);

            const generatedID = \`MC-\${partnerType}-\${initials}\${year}\`;
            
            document.getElementById('idPlaceholder').innerText = generatedID;
            document.getElementById('urlDisplay').innerText = \`moonshine.cap/ref/\${generatedID}\`;
            
            const auditTable = document.getElementById('auditLog');
            const newRow = auditTable.insertRow(0);
            newRow.style.background = "#f3ff00";
            newRow.innerHTML = \`
                <td class="font-black">\${fullName.toUpperCase()}</td>
                <td class="font-black">\${generatedID}</td>
                <td>\${company.toUpperCase()}</td>
                <td>\${regDate || new Date().toISOString().split('T')[0]}</td>
                <td><span class="status-badge" style="background: #ff0055">PROVISIONED</span></td>
            \`;
        }

        function copyToClipboard() {
            const url = document.getElementById('urlDisplay').innerText;
            navigator.clipboard.writeText(url);
            const msg = document.getElementById('successMsg');
            msg.style.opacity = "1";
            setTimeout(() => { msg.style.opacity = "0"; }, 2000);
        }
    </script>
      ` }} />
    </main>
  );
}
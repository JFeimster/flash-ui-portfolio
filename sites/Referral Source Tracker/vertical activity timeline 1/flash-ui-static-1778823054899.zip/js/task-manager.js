const taskData = [
    {
        id: 1,
        type: 'call',
        title: 'Strategy Call: Sarah Jenkins',
        description: 'Discuss Q4 portfolio rebalancing and tax-loss harvesting strategies.',
        due: 'In 2 hours',
        priority: 'high',
        tag: 'VIP Client',
        category: 'Wealth Mgmt'
    },
    {
        id: 2,
        type: 'email',
        title: 'Send Estate Plan Review',
        description: 'Dispatch the finalized estate planning documents to the Miller Group legal team.',
        due: 'Today, 4:00 PM',
        priority: 'standard',
        tag: 'Legal',
        category: 'Operation'
    },
    {
        id: 3,
        type: 'call',
        title: 'Follow-up: Liam O\'Connor',
        description: 'Check in on the Gilded Stream project integration progress and technical blockers.',
        due: 'Tomorrow, 10:00 AM',
        priority: 'high',
        tag: 'Legacy Source',
        category: 'Onboarding'
    },
    {
        id: 4,
        type: 'email',
        title: 'Quarterly Performance Report',
        description: 'Generate and send the performance breakdown for the Thorne family office.',
        due: 'In 2 days',
        priority: 'standard',
        tag: 'Reporting',
        category: 'Billing'
    }
];

const icons = {
    call: `<svg viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>`,
    email: `<svg viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>`
};

class TaskManager {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        this.tasks = taskData;
        this.render();
    }

    createTaskItem(task) {
        const item = document.createElement('div');
        item.className = 'timeline-item';
        
        const isHighValue = task.priority === 'high';
        const cardClass = isHighValue ? 'activity-card high-value' : 'activity-card';
        
        item.innerHTML = `
            <div class="timeline-icon">
                ${icons[task.type]}
            </div>
            <div class="${cardClass}">
                <div class="card-header">
                    <span class="card-title">${task.title}</span>
                    <div class="upcoming-badge">
                        <div class="pulse-dot"></div>
                        ${task.due}
                    </div>
                </div>
                <p class="card-description">${task.description}</p>
                <div class="card-footer">
                    <span class="tag ${isHighValue ? 'tag-gold' : ''}">${task.tag}</span>
                    <span class="tag">${task.category}</span>
                    <button class="action-btn" onclick="taskManager.completeTask(${task.id})" style="margin-left: auto; background: transparent; border: 1px solid var(--gold-dark); color: var(--gold-primary); font-size: 0.7rem; padding: 4px 12px; border-radius: 4px; cursor: pointer; transition: all 0.2s ease;">
                        Mark Done
                    </button>
                </div>
            </div>
        `;
        return item;
    }

    render() {
        if (!this.container) return;
        
        this.container.innerHTML = `
            <header class="timeline-header" style="padding-left: 60px; margin-bottom: 40px;">
                <h2 style="font-family: 'Playfair Display', serif; font-size: 2rem; background: linear-gradient(to right, var(--gold-light), var(--gold-dark)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Pending Actions</h2>
                <p style="color: var(--text-muted); font-size: 0.9rem; margin-top: 4px;">Relationship management queue</p>
            </header>
            <div class="timeline-container">
                <div class="timeline-section-label">Chronological Queue</div>
                <div id="task-list-items"></div>
            </div>
        `;

        const listContainer = this.container.querySelector('#task-list-items');
        this.tasks.forEach(task => {
            listContainer.appendChild(this.createTaskItem(task));
        });
    }

    completeTask(id) {
        const element = document.querySelector(`[onclick="taskManager.completeTask(${id})"]`).closest('.timeline-item');
        element.style.opacity = '0';
        element.style.transform = 'translateX(20px)';
        
        setTimeout(() => {
            this.tasks = this.tasks.filter(t => t.id !== id);
            this.render();
        }, 300);
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    // Expected target: <div id="task-manager-mount"></div>
    window.taskManager = new TaskManager('task-manager-mount');
});
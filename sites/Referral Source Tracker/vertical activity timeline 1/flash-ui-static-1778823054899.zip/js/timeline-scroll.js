document.addEventListener('DOMContentLoaded', () => {
    const timelineItems = document.querySelectorAll('.timeline-item');
    const activityCards = document.querySelectorAll('.activity-card');

    /**
     * Reveal items on scroll using Intersection Observer
     */
    const revealOptions = {
        threshold: 0.15,
        rootMargin: '0px 0px -50px 0px'
    };

    const revealOnScroll = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                observer.unobserve(entry.target);
            }
        });
    }, revealOptions);

    timelineItems.forEach((item, index) => {
        // Initial state for animation
        item.style.opacity = '0';
        item.style.transform = 'translateY(20px)';
        item.style.transition = `opacity 0.6s ease-out ${index * 0.1}s, transform 0.6s ease-out ${index * 0.1}s`;
        revealOnScroll.observe(item);
    });

    /**
     * Interaction: Expand Activity Cards for Historical Notes
     */
    activityCards.forEach(card => {
        card.style.cursor = 'pointer';
        
        card.addEventListener('click', function() {
            const isExpanded = this.getAttribute('data-expanded') === 'true';
            
            // Close any other open cards to keep detail view focused
            activityCards.forEach(c => {
                if (c !== this) {
                    c.setAttribute('data-expanded', 'false');
                    const existingDetails = c.querySelector('.details-pane');
                    if (existingDetails) {
                        existingDetails.style.maxHeight = '0';
                        existingDetails.style.opacity = '0';
                        existingDetails.style.marginTop = '0';
                    }
                }
            });

            if (!isExpanded) {
                this.setAttribute('data-expanded', 'true');
                showDetails(this);
            } else {
                this.setAttribute('data-expanded', 'false');
                const details = this.querySelector('.details-pane');
                if (details) {
                    details.style.maxHeight = '0';
                    details.style.opacity = '0';
                    details.style.marginTop = '0';
                }
            }
        });
    });

    function showDetails(card) {
        let details = card.querySelector('.details-pane');
        
        if (!details) {
            details = document.createElement('div');
            details.className = 'details-pane';
            
            // Injecting detailed historical notes template
            const title = card.querySelector('.card-title').innerText;
            details.innerHTML = `
                <div style="border-top: 1px solid var(--border-subtle); margin-top: 15px; padding-top: 15px;">
                    <h4 style="font-size: 0.75rem; text-transform: uppercase; color: var(--gold-primary); margin-bottom: 10px; letter-spacing: 0.05em;">Interaction Ledger</h4>
                    <div style="font-size: 0.85rem; color: var(--text-muted); line-height: 1.6;">
                        <p style="margin-bottom: 8px;">Detailed analysis for <strong>${title}</strong>:</p>
                        <ul style="list-style: none; padding-left: 0;">
                            <li style="margin-bottom: 4px; display: flex; align-items: center;">
                                <span style="width: 6px; height: 6px; background: var(--gold-dark); border-radius: 50%; margin-right: 10px;"></span>
                                Synchronized with secure vault at 14:02 GMT
                            </li>
                            <li style="margin-bottom: 4px; display: flex; align-items: center;">
                                <span style="width: 6px; height: 6px; background: var(--gold-dark); border-radius: 50%; margin-right: 10px;"></span>
                                Key themes: Portfolio stability, HNW tax optimization
                            </li>
                            <li style="margin-bottom: 4px; display: flex; align-items: center;">
                                <span style="width: 6px; height: 6px; background: var(--gold-dark); border-radius: 50%; margin-right: 10px;"></span>
                                Sentiment: Highly favorable
                            </li>
                        </ul>
                    </div>
                </div>
            `;
            
            // Styles for the transition
            details.style.overflow = 'hidden';
            details.style.transition = 'max-height 0.4s ease, opacity 0.3s ease, margin-top 0.4s ease';
            details.style.maxHeight = '0';
            details.style.opacity = '0';
            
            card.appendChild(details);
        }

        // Trigger animation reflow
        setTimeout(() => {
            details.style.maxHeight = '200px';
            details.style.opacity = '1';
            details.style.marginTop = '15px';
        }, 10);
    }

    /**
     * Dynamic Glow Effect for High-Value Items
     */
    const premiumCards = document.querySelectorAll('.activity-card.high-value');
    premiumCards.forEach(card => {
        card.addEventListener('mousemove', e => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            card.style.boxShadow = `0 10px 30px rgba(0,0,0,0.5), inset 0 0 20px rgba(212, 175, 55, 0.05)`;
            // Subtle directional shift on the gold border glow
            card.style.borderColor = `rgba(212, 175, 55, ${0.2 + (y / rect.height) * 0.2})`;
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.boxShadow = '';
            card.style.borderColor = '';
        });
    });

    /**
     * Timeline line height adjustment for dynamic content
     */
    const adjustTimelineHeight = () => {
        const container = document.querySelector('.timeline-container');
        if (container) {
            const lastItem = container.querySelector('.timeline-item:last-child');
            if (lastItem) {
                const height = lastItem.offsetTop + 20;
                container.style.setProperty('--line-height', `${height}px`);
            }
        }
    };

    window.addEventListener('resize', adjustTimelineHeight);
    adjustTimelineHeight();
});
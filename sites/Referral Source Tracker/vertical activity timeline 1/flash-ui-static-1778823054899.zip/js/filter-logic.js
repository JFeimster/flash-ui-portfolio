const contactData = [
    {
        id: 1,
        name: "Julian Vane",
        status: "Active",
        method: "Phone",
        value: "High",
        category: "VIP Referral",
        description: "Focus on Q4 portfolio expansion and asset reallocation.",
        lastActive: "2 days ago"
    },
    {
        id: 2,
        name: "Elena Rossi",
        status: "Onboarding",
        method: "In-person",
        value: "High",
        category: "Legacy Source",
        description: "Requirements gathering for Gilded Stream integration.",
        lastActive: "Yesterday"
    },
    {
        id: 3,
        name: "Marcus Thorne",
        status: "Prospect",
        method: "Phone",
        value: "Medium",
        category: "Prospection",
        description: "Potential partnership for the upcoming fiscal year.",
        lastActive: "Oct 18, 2023"
    },
    {
        id: 4,
        name: "Sterling Group Legal",
        status: "Active",
        method: "Email",
        value: "Medium",
        category: "Operation",
        description: "Renewed service terms and quarterly agreement drafting.",
        lastActive: "Oct 24, 2023"
    },
    {
        id: 5,
        name: "Arthur Penhaligon",
        status: "Inactive",
        method: "Email",
        value: "Low",
        category: "Billing",
        description: "Account settled. Pending re-engagement in Spring.",
        lastActive: "Sept 12, 2023"
    }
];

const icons = {
    Phone: `<svg viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>`,
    Email: `<svg viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>`,
    "In-person": `<svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>`
};

const filterState = {
    search: "",
    status: "all",
    method: "all",
    value: "all"
};

function renderDirectory() {
    const container = document.getElementById('directory-container');
    if (!container) return;

    const filtered = contactData.filter(contact => {
        const matchesSearch = contact.name.toLowerCase().includes(filterState.search.toLowerCase()) || 
                             contact.description.toLowerCase().includes(filterState.search.toLowerCase());
        const matchesStatus = filterState.status === "all" || contact.status === filterState.status;
        const matchesMethod = filterState.method === "all" || contact.method === filterState.method;
        const matchesValue = filterState.value === "all" || contact.value === filterState.value;

        return matchesSearch && matchesStatus && matchesMethod && matchesValue;
    });

    container.innerHTML = filtered.map(contact => `
        <div class="timeline-item">
            <div class="timeline-icon">
                ${icons[contact.method] || icons.Email}
            </div>
            <div class="activity-card ${contact.value === 'High' ? 'high-value' : ''}">
                <div class="card-header">
                    <span class="card-title">${contact.name}</span>
                    <span class="card-date">${contact.lastActive}</span>
                </div>
                <p class="card-description">${contact.description}</p>
                <div class="card-footer">
                    <span class="tag ${contact.value === 'High' ? 'tag-gold' : ''}">${contact.category}</span>
                    <span class="tag">${contact.status}</span>
                    <span class="tag">${contact.method}</span>
                </div>
            </div>
        </div>
    `).join('');
}

function handleFilterChange(e) {
    const { name, value } = e.target;
    filterState[name] = value;
    renderDirectory();
}

function setupListeners() {
    const inputs = document.querySelectorAll('.filter-input');
    inputs.forEach(input => {
        const eventType = input.tagName === 'INPUT' ? 'input' : 'change';
        input.addEventListener(eventType, handleFilterChange);
    });
}

document.addEventListener('DOMContentLoaded', () => {
    setupListeners();
    renderDirectory();
});
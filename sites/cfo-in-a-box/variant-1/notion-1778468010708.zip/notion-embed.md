### Generated UI Component

To use this in Notion:
1. Create a "/code" block
2. Set language to "HTML"
3. Paste the following:

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CFO-in-a-Box | AI Financial Command Center</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-deep: #050608;
            --bg-card: #0d0f14;
            --bg-surface: #14171c;
            --primary: #00ff9d;
            --secondary: #ffb800;
            --danger: #ff4d4d;
            --text-main: #ffffff;
            --text-muted: #8a8f98;
            --border: #1f242d;
            --glow: rgba(0, 255, 157, 0.15);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: var(--bg-deep);
            color: var(--text-main);
            font-family: 'Inter', sans-serif;
            line-height: 1.6;
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
        }

        /* Utilities */
        .container { max-width: 1200px; margin: 0 auto; padding: 0 2rem; }
        .flex { display: flex; }
        .grid { display: grid; }
        .text-gradient { background: linear-gradient(135deg, #fff 0%, #888 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        .mono { font-family: 'JetBrains Mono', monospace; font-size: 0.85rem; letter-spacing: -0.02em; }
        .badge { display: inline-block; padding: 4px 12px; border-radius: 4px; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; background: var(--border); color: var(--primary); border: 1px solid var(--primary); margin-bottom: 1rem; }

        /* Navigation */
        nav {
            position: sticky;
            top: 0;
            z-index: 1000;
            background: rgba(5, 6, 8, 0.8);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid var(--border);
            padding: 1rem 0;
        }

        nav .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-weight: 800;
            font-size: 1.25rem;
            letter-spacing: -0.04em;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .logo span { color: var(--primary); }

        .nav-links { gap: 2rem; align-items: center; }
        .nav-links a { text-decoration: none; color: var(--text-muted); font-size: 0.9rem; font-weight: 500; transition: 0.2s; }
        .nav-links a:hover { color: var(--text-main); }

        .nav-btns { gap: 1rem; }
        .btn {
            padding: 10px 20px;
            border-radius: 4px;
            font-weight: 600;
            font-size: 0.85rem;
            cursor: pointer;
            transition: 0.2s;
            text-decoration: none;
            display: inline-block;
            border: none;
        }

        .btn-outline { background: transparent; border: 1px solid var(--border); color: var(--text-main); }
        .btn-outline:hover { background: var(--border); }
        .btn-primary { background: var(--primary); color: #000; }
        .btn-primary:hover { background: #00e68e; transform: translateY(-1px); box-shadow: 0 4px 20px var(--glow); }

        /* Hero Section */
        .hero {
            padding: 100px 0 160px;
            text-align: center;
            position: relative;
        }

        .hero::before {
            content: '';
            position: absolute;
            top: -200px;
            left: 50%;
            transform: translateX(-50%);
            width: 800px;
            height: 600px;
            background: radial-gradient(circle, var(--glow) 0%, transparent 70%);
            z-index: -1;
        }

        h1 {
            font-size: clamp(2.5rem, 6vw, 4.5rem);
            font-weight: 800;
            line-height: 1;
            letter-spacing: -0.05em;
            margin-bottom: 1.5rem;
        }

        .hero p {
            max-width: 650px;
            margin: 0 auto 2.5rem;
            font-size: 1.15rem;
            color: var(--text-muted);
        }

        .hero-ctas { justify-content: center; gap: 1rem; margin-bottom: 4rem; }
        .trust-line { font-size: 0.8rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.1em; }

        /* Dashboard Preview Mockup */
        .dashboard-mockup {
            max-width: 1000px;
            margin: -60px auto 0;
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 40px 100px rgba(0,0,0,0.5);
            display: grid;
            grid-template-columns: 240px 1fr;
            gap: 24px;
            text-align: left;
        }

        .db-sidebar { border-right: 1px solid var(--border); padding-right: 20px; }
        .db-nav-item { padding: 10px; font-size: 0.8rem; color: var(--text-muted); border-radius: 4px; margin-bottom: 4px; }
        .db-nav-item.active { background: var(--bg-surface); color: var(--primary); }

        .db-main-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }
        .db-card { background: var(--bg-surface); border: 1px solid var(--border); padding: 16px; border-radius: 8px; }
        .db-label { font-size: 0.7rem; text-transform: uppercase; color: var(--text-muted); margin-bottom: 8px; font-weight: 600; }
        .db-value { font-size: 1.5rem; font-weight: 700; }
        .db-trend { font-size: 0.75rem; margin-top: 4px; font-weight: 600; }
        .up { color: var(--primary); }
        .down { color: var(--danger); }

        .db-chart-area { grid-column: span 3; background: var(--bg-surface); height: 200px; border-radius: 8px; border: 1px solid var(--border); margin-top: 16px; padding: 20px; position: relative; }
        .db-ai-panel { grid-column: span 3; background: linear-gradient(90deg, #14171c, #0d0f14); border-left: 3px solid var(--primary); padding: 16px; font-size: 0.85rem; border-radius: 0 8px 8px 0; }

        /* Sections General */
        section { padding: 120px 0; border-top: 1px solid var(--border); }
        .section-header { margin-bottom: 60px; }
        .section-header h2 { font-size: 2.5rem; font-weight: 800; letter-spacing: -0.03em; margin-bottom: 1rem; }
        .section-header p { color: var(--text-muted); font-size: 1.1rem; }

        /* Problem Section */
        .pain-grid { grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; }
        .pain-card { padding: 32px; background: var(--bg-card); border-top: 2px solid var(--border); transition: 0.3s; }
        .pain-card:hover { border-top-color: var(--primary); background: var(--bg-surface); }
        .pain-card h4 { font-size: 1.25rem; margin-bottom: 1rem; line-height: 1.3; }
        .pain-card p { color: var(--text-muted); font-size: 0.95rem; }

        /* How It Works */
        .step-grid { grid-template-columns: repeat(3, 1fr); gap: 40px; }
        .step-num { font-size: 3rem; font-weight: 900; color: transparent; -webkit-text-stroke: 1px var(--border); margin-bottom: -20px; }
        .step-card h3 { margin-bottom: 1rem; }

        /* Feature Cards */
        .feature-grid { grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1.5rem; }
        .feature-card { padding: 30px; border: 1px solid var(--border); border-radius: 4px; background: var(--bg-card); }
        .feature-card h3 { margin-bottom: 0.75rem; color: var(--primary); font-size: 1rem; text-transform: uppercase; letter-spacing: 0.05em; }
        .feature-card p { font-size: 0.95rem; color: var(--text-muted); }

        /* Pricing */
        .price-grid { grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 1rem; }
        .price-card { padding: 40px 30px; border: 1px solid var(--border); background: var(--bg-card); display: flex; flex-direction: column; position: relative; }
        .price-card.featured { border: 2px solid var(--primary); box-shadow: 0 0 30px var(--glow); z-index: 2; }
        .price-card h3 { font-size: 1.5rem; margin-bottom: 0.5rem; }
        .price-card .cost { font-size: 2.5rem; font-weight: 800; margin: 1.5rem 0; }
        .price-card .cost span { font-size: 1rem; color: var(--text-muted); font-weight: 400; }
        .price-card ul { list-style: none; margin-bottom: 2rem; flex-grow: 1; }
        .price-card li { margin-bottom: 0.75rem; font-size: 0.85rem; color: var(--text-muted); display: flex; align-items: center; gap: 8px; }
        .price-card li::before { content: '→'; color: var(--primary); }
        .recommend-tag { position: absolute; top: -14px; left: 50%; transform: translateX(-50%); background: var(--primary); color: #000; font-size: 0.7rem; font-weight: 800; padding: 4px 12px; border-radius: 100px; }

        /* Use Cases */
        .use-case-grid { grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 1rem; }
        .use-case-card { padding: 20px; border: 1px solid var(--border); font-weight: 600; font-size: 0.9rem; transition: 0.2s; cursor: default; }
        .use-case-card:hover { border-color: var(--primary); color: var(--primary); }

        /* Form */
        .lead-section { background: var(--bg-surface); padding: 80px 40px; border-radius: 12px; border: 1px solid var(--border); }
        .snapshot-form { grid-template-columns: repeat(2, 1fr); gap: 20px; margin-top: 40px; text-align: left; }
        .form-group { display: flex; flex-direction: column; gap: 8px; }
        .form-group label { font-size: 0.8rem; font-weight: 600; color: var(--text-muted); }
        .form-group input, .form-group select { background: var(--bg-deep); border: 1px solid var(--border); padding: 12px; color: white; border-radius: 4px; }
        .form-group input:focus { outline: none; border-color: var(--primary); }

        /* Footer */
        footer { padding: 80px 0 40px; border-top: 1px solid var(--border); }
        .footer-grid { grid-template-columns: 2fr 1fr 1fr 1fr; gap: 40px; margin-bottom: 60px; }
        .footer-col h5 { margin-bottom: 1.5rem; font-size: 0.9rem; }
        .footer-col ul { list-style: none; }
        .footer-col li { margin-bottom: 0.75rem; }
        .footer-col a { color: var(--text-muted); text-decoration: none; font-size: 0.85rem; }
        .footer-col a:hover { color: var(--text-main); }
        .disclaimer { font-size: 0.75rem; color: #444; margin-top: 40px; padding-top: 20px; border-top: 1px solid var(--border); }

        @media (max-width: 768px) {
            .nav-links, .nav-btns { display: none; }
            .dashboard-mockup { grid-template-columns: 1fr; }
            .db-sidebar { display: none; }
            .step-grid { grid-template-columns: 1fr; }
            .snapshot-form { grid-template-columns: 1fr; }
            .footer-grid { grid-template-columns: 1fr 1fr; }
            h1 { font-size: 2.8rem; }
        }
    </style>
</head>
<body>

    <nav>
        <div class="container">
            <div class="logo">CFO-IN-A-<span>BOX</span></div>
            <div class="nav-links flex">
                <a href="#">How It Works</a>
                <a href="#">Features</a>
                <a href="#">Use Cases</a>
                <a href="#">Pricing</a>
                <a href="#">Resources</a>
            </div>
            <div class="nav-btns flex">
                <a href="#" class="btn btn-outline">Try Free GPT</a>
                <a href="#" class="btn btn-primary">Get Financial Clarity</a>
            </div>
        </div>
    </nav>

    <main>
        <!-- Hero Section -->
        <section class="hero">
            <div class="container">
                <div class="badge">AI-Powered Finance Command Center</div>
                <h1>CFO-level clarity<br><span class="text-gradient">without CFO-level payroll.</span></h1>
                <p>Upload your financials and get cash flow forecasts, burn rate analysis, and plain-English financial guidance before the bank account starts screaming.</p>
                <div class="hero-ctas flex">
                    <a href="#" class="btn btn-primary" style="padding: 16px 32px; font-size: 1rem;">Get My Financial Snapshot</a>
                    <a href="#" class="btn btn-outline" style="padding: 16px 32px; font-size: 1rem;">Try the Free GPT</a>
                </div>
                <div class="trust-line">Built for founders who are done flying blind</div>
            </div>
        </section>

        <!-- Dashboard Preview -->
        <div class="container" style="position: relative; z-index: 5;">
            <div class="dashboard-mockup">
                <div class="db-sidebar">
                    <div class="db-nav-item active">Dashboard</div>
                    <div class="db-nav-item">Cash Flow Analysis</div>
                    <div class="db-nav-item">Scenario Builder</div>
                    <div class="db-nav-item">Funding Readiness</div>
                    <div class="db-nav-item" style="margin-top: 40px; opacity: 0.5;">Settings</div>
                </div>
                <div class="db-content">
                    <div class="db-main-grid">
                        <div class="db-card">
                            <div class="db-label">Funding Readiness</div>
                            <div class="db-value" style="color: var(--primary);">72<span style="font-size: 0.8rem; color: #555;"> / 100</span></div>
                            <div class="db-trend up">Good (+4%)</div>
                        </div>
                        <div class="db-card">
                            <div class="db-label">Monthly Runway</div>
                            <div class="db-value">5.8 <span style="font-size: 0.8rem; font-weight: 400; color: var(--text-muted);">mo</span></div>
                            <div class="db-trend down" style="color: var(--secondary);">Stabilizing</div>
                        </div>
                        <div class="db-card">
                            <div class="db-label">Net Cash Flow</div>
                            <div class="db-value">+$8,450</div>
                            <div class="db-trend up">↑ 12% vs LY</div>
                        </div>
                    </div>
                    <div class="db-chart-area flex" style="align-items: flex-end; gap: 8px;">
                        <div style="flex: 1; height: 60%; background: #1f242d; border-radius: 2px;"></div>
                        <div style="flex: 1; height: 75%; background: #1f242d; border-radius: 2px;"></div>
                        <div style="flex: 1; height: 45%; background: #1f242d; border-radius: 2px;"></div>
                        <div style="flex: 1; height: 90%; background: var(--primary); border-radius: 2px; box-shadow: 0 0 15px var(--glow);"></div>
                        <div style="flex: 1; height: 82%; background: #1f242d; border-radius: 2px;"></div>
                        <div style="flex: 1; height: 65%; background: #1f242d; border-radius: 2px;"></div>
                        <div class="mono" style="position: absolute; top: 15px; right: 15px; color: var(--text-muted);">Forecast: Q4 Growth</div>
                    </div>
                    <div class="db-ai-panel" style="margin-top: 16px;">
                        <div class="mono" style="color: var(--primary); margin-bottom: 8px;">&gt; AI CFO_INSIGHT_042</div>
                        <p>Cash flow is positive, but contractor expenses increased 22% this month. Funding readiness is decent, but documentation needs cleanup. Recommend renegotiating software stack before EOM.</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Problem Section -->
        <section>
            <div class="container">
                <div class="section-header">
                    <h2>Most owners don’t need more spreadsheets. <br><span class="text-gradient">They need financial signal.</span></h2>
                </div>
                <div class="pain-grid grid">
                    <div class="pain-card">
                        <h4>You know revenue, but not runway.</h4>
                        <p>The bank balance looks fine today, but you have no idea if you'll survive a slow quarter.</p>
                    </div>
                    <div class="pain-card">
                        <h4>Your P&L says profit, but your bank account says panic.</h4>
                        <p>Tracking paper profit is easy. Managing real-world cash flow is where the war is won.</p>
                    </div>
                    <div class="pain-card">
                        <h4>Your documents look like a crime scene.</h4>
                        <p>You want funding or a loan, but the thought of opening your books makes you want to hide.</p>
                    </div>
                    <div class="pain-card">
                        <h4>Decisions based on vibes.</h4>
                        <p>Hiring, spending, and growth shouldn't be a coin toss. It should be a calculation.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- How It Works -->
        <section style="background: var(--bg-card);">
            <div class="container">
                <div class="section-header" style="text-align: center;">
                    <h2>Upload. Analyze. Act.</h2>
                </div>
                <div class="step-grid grid">
                    <div class="step-card">
                        <div class="step-num">01</div>
                        <h3>Upload Financials</h3>
                        <p>Sync your bank, drop your P&L spreadsheets, or export from Stripe. We handle the messy data ingestion.</p>
                    </div>
                    <div class="step-card">
                        <div class="step-num">02</div>
                        <h3>Get CFO Analysis</h3>
                        <p>Our AI processes every transaction to map burn, runway, cost leaks, and funding readiness scores.</p>
                    </div>
                    <div class="step-card">
                        <div class="step-num">03</div>
                        <h3>Make Better Decisions</h3>
                        <p>Know exactly what to cut, who to hire, and when you're ready to raise capital without the "spreadsheet goblin" stress.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Core Features -->
        <section>
            <div class="container">
                <div class="section-header">
                    <h2>Your financial command center.</h2>
                </div>
                <div class="feature-grid grid">
                    <div class="feature-card">
                        <h3>Cash Flow Forecast</h3>
                        <p>Visual mapping of incoming and outgoing capital so you can spot "tight zones" 3 months before they hit.</p>
                    </div>
                    <div class="feature-card">
                        <h3>Burn Rate + Runway</h3>
                        <p>No more guessing. Know exactly how much time you have left at your current spend level.</p>
                    </div>
                    <div class="feature-card">
                        <h3>Funding Readiness</h3>
                        <p>An objective score showing how lenders and investors see your business health right now.</p>
                    </div>
                    <div class="feature-card">
                        <h3>Cost Leak Detection</h3>
                        <p>Identify zombie subscriptions, bloated SaaS stacks, and ROI-negative expenses automatically.</p>
                    </div>
                    <div class="feature-card">
                        <h3>Scenario Modeling</h3>
                        <p>"What happens if I hire two developers?" "What if I lose my biggest client?" Model it before it happens.</p>
                    </div>
                    <div class="feature-card">
                        <h3>Weekly Financial Review</h3>
                        <p>A repeatable rhythm to keep you in control. Stop checking your bank balance like it's a Magic 8 Ball.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Pricing Section -->
        <section style="background: #000;">
            <div class="container">
                <div class="section-header" style="text-align: center;">
                    <h2>Start with the GPT. <br>Grow into a financial operating system.</h2>
                </div>
                <div class="price-grid grid">
                    <div class="price-card">
                        <h3>Free GPT</h3>
                        <p>For DIY clarity.</p>
                        <div class="cost">$0<span>/mo</span></div>
                        <ul>
                            <li>CFO-in-a-Box GPT access</li>
                            <li>Manual file uploads</li>
                            <li>Basic cash flow check</li>
                            <li>Weekly review prompts</li>
                        </ul>
                        <a href="#" class="btn btn-outline">Try Free</a>
                    </div>
                    <div class="price-card">
                        <h3>Starter Lab</h3>
                        <p>For the builder.</p>
                        <div class="cost">$49<span>/mo</span></div>
                        <ul>
                            <li>Private group access</li>
                            <li>Notion/Sheets Templates</li>
                            <li>Prompt Vault access</li>
                            <li>Monthly AMA Clinic</li>
                        </ul>
                        <a href="#" class="btn btn-outline">Join Lab</a>
                    </div>
                    <div class="price-card featured">
                        <div class="recommend-tag">FOUNDER FAVORITE</div>
                        <h3>Founder OS</h3>
                        <p>For the operator.</p>
                        <div class="cost">$499<span>/mo</span></div>
                        <ul>
                            <li>Full FinOps Automation</li>
                            <li>Monthly Auto-Reporting</li>
                            <li>Cash Flow Dashboard</li>
                            <li>Alerts & Cost Leak Scans</li>
                            <li>Stripe & Bank Sync</li>
                        </ul>
                        <a href="#" class="btn btn-primary">Install Founder OS</a>
                    </div>
                    <div class="price-card">
                        <h3>Advisor Desk</h3>
                        <p>For high stakes.</p>
                        <div class="cost">$1,500<span>/mo</span></div>
                        <ul>
                            <li>Everything in Founder OS</li>
                            <li>Human-in-the-loop review</li>
                            <li>Monthly Advisory Memo</li>
                            <li>Bi-weekly Strategy Call</li>
                            <li>Direct Decision Support</li>
                        </ul>
                        <a href="#" class="btn btn-outline">Add Support</a>
                    </div>
                </div>
            </div>
        </section>

        <!-- Use Cases -->
        <section>
            <div class="container">
                <div class="section-header">
                    <h2>Built for the decisions that keep owners up at night.</h2>
                </div>
                <div class="use-case-grid grid">
                    <div class="use-case-card">Can I afford to hire?</div>
                    <div class="use-case-card">Should I cut expenses?</div>
                    <div class="use-case-card">Am I ready for funding?</div>
                    <div class="use-case-card">How much runway?</div>
                    <div class="use-case-card">What if revenue drops?</div>
                    <div class="use-case-card">Increase ad spend?</div>
                    <div class="use-case-card">Can I take on debt?</div>
                    <div class="use-case-card">Weekly review rhythm?</div>
                </div>
            </div>
        </section>

        <!-- Lead Magnet -->
        <section>
            <div class="container">
                <div class="lead-section text-center" style="text-align: center;">
                    <h2>Get your free financial snapshot.</h2>
                    <p>Answer 6 questions and see where your business stands.</p>
                    <form class="snapshot-form grid">
                        <div class="form-group">
                            <label>Business Type</label>
                            <select><option>SaaS / Tech</option><option>Agency / Service</option><option>Ecommerce</option></select>
                        </div>
                        <div class="form-group">
                            <label>Monthly Revenue</label>
                            <input type="text" placeholder="$0.00">
                        </div>
                        <div class="form-group">
                            <label>Current Cash Balance</label>
                            <input type="text" placeholder="$0.00">
                        </div>
                        <div class="form-group">
                            <label>Biggest Financial Concern</label>
                            <select><option>Runway / Burn</option><option>Funding Readiness</option><option>Cost Control</option></select>
                        </div>
                        <div class="form-group" style="grid-column: span 2;">
                            <button type="button" class="btn btn-primary" style="width: 100%;">Generate My Snapshot</button>
                        </div>
                    </form>
                </div>
            </div>
        </section>

        <!-- Final CTA -->
        <section style="text-align: center; border-top: none;">
            <div class="container">
                <h2 style="font-size: 3.5rem;">Stop guessing. Start operating.</h2>
                <p style="font-size: 1.25rem; margin-bottom: 2.5rem;">Financial clarity for owners who are done flying blind.</p>
                <div class="flex" style="justify-content: center; gap: 1rem;">
                    <a href="#" class="btn btn-primary" style="padding: 18px 40px;">Get Founder OS</a>
                    <a href="#" class="btn btn-outline" style="padding: 18px 40px;">Chat with the GPT</a>
                </div>
            </div>
        </section>
    </main>

    <footer>
        <div class="container">
            <div class="footer-grid grid">
                <div class="footer-col">
                    <div class="logo" style="margin-bottom: 1.5rem;">CFO-IN-A-<span>BOX</span></div>
                    <p style="color: var(--text-muted); font-size: 0.9rem; max-width: 300px;">Providing the financial visibility small business owners need to build sustainable, funding-ready companies.</p>
                </div>
                <div class="footer-col">
                    <h5>Product</h5>
                    <ul>
                        <li><a href="#">Features</a></li>
                        <li><a href="#">Pricing</a></li>
                        <li><a href="#">Use Cases</a></li>
                        <li><a href="#">Free GPT</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h5>Resources</h5>
                    <ul>
                        <li><a href="#">Cash Flow Guide</a></li>
                        <li><a href="#">Funding Checklist</a></li>
                        <li><a href="#">Review Templates</a></li>
                        <li><a href="#">Cost Cutting Lab</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h5>Company</h5>
                    <ul>
                        <li><a href="#">About</a></li>
                        <li><a href="#">Contact</a></li>
                        <li><a href="#">Privacy</a></li>
                        <li><a href="#">Terms</a></li>
                    </ul>
                </div>
            </div>
            <p class="disclaimer">
                DISCLAIMER: CFO-in-a-Box provides business planning and financial decision-support tools. We are not a licensed CPA firm, law firm, or investment advisor. Our tools provide directional analysis and should not be used as the sole basis for tax, legal, accounting, or investment decisions. We do not guarantee funding approval from any third-party lender or investor.
            </p>
        </div>
    </footer>

</body>
</html>
```
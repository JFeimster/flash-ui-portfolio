import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<div class="container">
        <header>
            <div class="logo">
                <div class="logo-icon"></div>
                IDEA TO URL
            </div>
            <div style="font-family: var(--font-mono); font-size: 0.8rem; color: var(--text-muted);">
                v2.0 // BY FLASH-UI
            </div>
        </header>

        <section class="hero">
            <span class="badge">Static Site Factory</span>
            <h1>Turn one prompt into<br>deployable site files.</h1>
            <p>Describe your vision. Our engine generates multiple high-fidelity static versions ready for hosting on Vercel, Netlify, or GitHub Pages.</p>
        </section>

        <div class="prompt-container">
            <div class="prompt-inner">
                <div class="prompt-header">
                    <div class="dot"></div>
                    <div class="dot"></div>
                    <div class="dot"></div>
                </div>
                <textarea placeholder="Describe your site: 'A minimalist portfolio for a creative developer with a dark theme, bento grid project layout, and an electric indigo accent color...'"></textarea>
                <div class="prompt-controls">
                    <div class="options-row">
                        <div class="option"><span>✓</span> HTML/CSS/JS</div>
                        <div class="option"><span>✓</span> React + Tailwind</div>
                        <div class="option"><span>✓</span> Assets Included</div>
                    </div>
                    <button class="btn-generate pulse-element">
                        Generate My Site
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 7-7 7 7"/><path d="M12 19V5"/></svg>
                    </button>
                </div>
            </div>
        </div>

        <section class="section-title">
            <h2>Factory Outputs</h2>
            <p>One prompt generates multiple distinct archetypes.</p>
        </section>

        <div class="version-grid">
            <!-- V1 -->
            <div class="version-card">
                <div class="preview-window">
                    <div class="v-label">V1 - LANDING</div>
                    <div class="mock-nav"></div>
                    <div class="mock-hero" style="background: linear-gradient(90deg, #1e1b4b, #312e81);"></div>
                    <div class="mock-grid">
                        <div class="mock-item"></div>
                        <div class="mock-item"></div>
                    </div>
                </div>
                <div class="card-info">
                    <h3>High-Conversion Landing</h3>
                    <div class="tag-row">
                        <span class="tag">CLEAN</span>
                        <span class="tag">MARKETING</span>
                        <span class="tag">SEO-READY</span>
                    </div>
                    <button class="btn-download">
                        Download .zip
                    </button>
                </div>
            </div>

            <!-- V2 -->
            <div class="version-card">
                <div class="preview-window">
                    <div class="v-label">V2 - DASHBOARD</div>
                    <div style="display: flex; gap: 10px; height: 100%;">
                        <div style="width: 40px; background: #222; border-radius: 4px;"></div>
                        <div style="flex: 1; display: flex; flex-direction: column; gap: 10px;">
                            <div style="height: 15px; background: #222; border-radius: 2px;"></div>
                            <div style="height: 100px; background: #222; border-radius: 4px;"></div>
                        </div>
                    </div>
                </div>
                <div class="card-info">
                    <h3>SaaS Dashboard Mockup</h3>
                    <div class="tag-row">
                        <span class="tag">UI-HEAVY</span>
                        <span class="tag">BENTO</span>
                        <span class="tag">DARK MODE</span>
                    </div>
                    <button class="btn-download">
                        Download .zip
                    </button>
                </div>
            </div>

            <!-- V3 -->
            <div class="version-card">
                <div class="preview-window">
                    <div class="v-label">V3 - MINIMAL</div>
                    <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100%; text-align: center; gap: 10px;">
                        <div style="width: 30px; height: 30px; background: #333; border-radius: 50%;"></div>
                        <div style="width: 100px; height: 8px; background: #333; border-radius: 2px;"></div>
                        <div style="width: 150px; height: 4px; background: #222; border-radius: 2px;"></div>
                    </div>
                </div>
                <div class="card-info">
                    <h3>Minimalist Portfolio</h3>
                    <div class="tag-row">
                        <span class="tag">AESTHETIC</span>
                        <span class="tag">FAST</span>
                        <span class="tag">TYPOGRAPHY</span>
                    </div>
                    <button class="btn-download">
                        Download .zip
                    </button>
                </div>
            </div>
        </div>

        <section class="zip-preview">
            <div class="file-browser">
                <div class="file-list">
                    <div class="file-item"><span class="file-icon">📁</span> src/</div>
                    <div class="file-item" style="padding-left: 30px;"><span class="file-icon">📁</span> components/</div>
                    <div class="file-item" style="padding-left: 30px;"><span class="file-icon">📁</span> styles/</div>
                    <div class="file-item" style="padding-left: 60px;"><span class="file-icon">#</span> globals.css</div>
                    <div class="file-item"><span class="file-icon">📄</span> index.html</div>
                    <div class="file-item"><span class="file-icon">📄</span> script.js</div>
                    <div class="file-item"><span class="file-icon">📄</span> README.md</div>
                    <div class="file-item"><span class="file-icon">📄</span> package.json</div>
                </div>
            </div>
            <div class="zip-details">
                <h2>Production-ready code.</h2>
                <p>No bloated builders or proprietary frameworks. You get clean, semantic HTML5, modern CSS3 (or Tailwind), and vanilla JavaScript. Perfectly organized and ready for your custom logic.</p>
                <div style="font-family: var(--font-mono); font-size: 0.8rem; color: var(--cyan);">
                    \$ npm install && npm run build
                </div>
            </div>
        </section>

        <section class="section-title">
            <h2>Example Prompts</h2>
            <p>See what others are building in the factory.</p>
        </section>

        <div class="examples-row">
            <div class="example-box">
                <h4>SaaS Waitlist</h4>
                <p>"A simple one-pager for an AI productivity app. Huge centered typography, a glowing email input, and three feature cards with glassmorphism."</p>
            </div>
            <div class="example-box">
                <h4>Crypto Tracker</h4>
                <p>"A dark finance dashboard with neon green accents, a sidebar for asset navigation, and a large central area for candlestick charts."</p>
            </div>
            <div class="example-box">
                <h4>Design Portfolio</h4>
                <p>"A brutalist layout for a graphic designer. High contrast, large images, sticky navigation, and custom scroll interactions."</p>
            </div>
        </div>

        <section class="pricing-section">
            <div class="pricing-card">
                <span style="font-family: var(--font-mono); color: var(--primary);">UNLIMITED ACCESS</span>
                <div class="price">\$29<span>/month</span></div>
                <ul class="feature-list">
                    <li>Unlimited Site Generations</li>
                    <li>Download all source files</li>
                    <li>React, Vue, & HTML outputs</li>
                    <li>Commercial Usage License</li>
                    <li>AI Image Generation included</li>
                </ul>
                <button class="btn-generate" style="width: 100%; justify-content: center; background: #fff;">Get Full Access</button>
            </div>
        </section>

        <section class="faq">
            <div class="faq-item">
                <h4>What do I actually get?</h4>
                <p>You get a downloadable .zip file containing the complete source code for your website—HTML, CSS, JS, and any generated images or assets.</p>
            </div>
            <div class="faq-item">
                <h4>Can I host this anywhere?</h4>
                <p>Yes. These are static files. You can drop them into Vercel, Netlify, Cloudflare Pages, or even an old-school FTP server.</p>
            </div>
            <div class="faq-item">
                <h4>Is the code editable?</h4>
                <p>Completely. The code is structured for developers. It's clean, commented, and uses modern best practices.</p>
            </div>
        </section>

        <section class="final-cta">
            <h2>Stop building from scratch.</h2>
            <p style="color: rgba(255,255,255,0.8);">Join 5,000+ creators using the factory to ship ideas faster.</p>
            <button class="btn-generate">Generate My Site Now</button>
        </section>

        <footer>
            &copy; 2024 FLASH-UI // Idea to URL Factory. Built for the future of the web.
        </footer>
    </div>
      ` }} />
    </main>
  );
}
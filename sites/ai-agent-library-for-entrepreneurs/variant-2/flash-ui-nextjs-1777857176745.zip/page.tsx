import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<div class="grid-overlay"></div>
    <div class="glow-sphere"></div>

    <nav>
        <div class="logo"><i class="fas fa-cube"></i> AGENT.LY</div>
        <div class="nav-links">
            <a href="#library">Library</a>
            <a href="#how">Process</a>
            <a href="#faq">FAQ</a>
            <a href="#request" style="color: var(--accent-primary)">Custom Agent</a>
        </div>
    </nav>

    <header>
        <span class="hook">AI Agents for Operators Who Want Leverage, Not More Tabs</span>
        <h1>Scale Your Business With Silicon Intelligence</h1>
        <p>Browse practical AI assistants built to help entrepreneurs generate leads, organize workflows, create content, qualify clients, and automate the boring business goblin work.</p>
        <a href="#library" class="cta-primary">Browse AI Agents <i class="fas fa-arrow-right"></i></a>
    </header>

    <section class="filter-section" id="library">
        <div class="search-bar">
            <i class="fas fa-search"></i>
            <input type="text" placeholder="Search by use case (e.g. lead gen, business credit)...">
        </div>
        <div class="categories">
            <button class="cat-btn active">All Agents</button>
            <button class="cat-btn">Lead Gen</button>
            <button class="cat-btn">Content</button>
            <button class="cat-btn">Funding</button>
            <button class="cat-btn">Workflows</button>
            <button class="cat-btn">Sales</button>
        </div>
    </section>

    <div class="agent-grid">
        <!-- Card 1 -->
        <div class="agent-card">
            <span class="featured-tag">Popular</span>
            <div class="agent-icon"><i class="fas fa-hand-holding-usd"></i></div>
            <h3>Funding Scout</h3>
            <p>Analyzes your business metrics to determine funding readiness and matches you with specific credit lines or VC requirements.</p>
            <div class="agent-meta">
                <span class="use-case">Capital</span>
                <a href="#" class="btn-mini">DEPLOY <i class="fas fa-chevron-right"></i></a>
            </div>
        </div>

        <!-- Card 2 -->
        <div class="agent-card">
            <div class="agent-icon"><i class="fas fa-users-viewfinder"></i></div>
            <h3>Lead Magnet Pro</h3>
            <p>Scrapes LinkedIn profiles and parses CRM data to write personalized outreach sequences that don't sound like a bot.</p>
            <div class="agent-meta">
                <span class="use-case">Growth</span>
                <a href="#" class="btn-mini">DEPLOY <i class="fas fa-chevron-right"></i></a>
            </div>
        </div>

        <!-- Card 3 -->
        <div class="agent-card">
            <div class="agent-icon"><i class="fas fa-pen-nib"></i></div>
            <h3>Content Prism</h3>
            <p>Takes one long-form video or blog post and shatters it into 15+ social media hooks, threads, and captions.</p>
            <div class="agent-meta">
                <span class="use-case">Marketing</span>
                <a href="#" class="btn-mini">DEPLOY <i class="fas fa-chevron-right"></i></a>
            </div>
        </div>

        <!-- Card 4 -->
        <div class="agent-card">
            <div class="agent-icon"><i class="fas fa-diagram-project"></i></div>
            <h3>Workflow Architect</h3>
            <p>Connects your tech stack. Provide your tools, and it writes the Zapier/Make logic to automate client onboarding.</p>
            <div class="agent-meta">
                <span class="use-case">Automation</span>
                <a href="#" class="btn-mini">DEPLOY <i class="fas fa-chevron-right"></i></a>
            </div>
        </div>

        <!-- Card 5 -->
        <div class="agent-card">
            <div class="agent-icon"><i class="fas fa-file-invoice"></i></div>
            <h3>Credit Builder AI</h3>
            <p>Specialized assistant for small business owners looking to optimize their EIN profile and secure Tier 2 credit.</p>
            <div class="agent-meta">
                <span class="use-case">Operations</span>
                <a href="#" class="btn-mini">DEPLOY <i class="fas fa-chevron-right"></i></a>
            </div>
        </div>

        <!-- Card 6 -->
        <div class="agent-card">
            <div class="agent-icon"><i class="fas fa-robot"></i></div>
            <h3>CRM Cleanup Bot</h3>
            <p>Parses messy CSVs and notes into structured JSON or CRM-ready formats. No more manual data entry.</p>
            <div class="agent-meta">
                <span class="use-case">Data</span>
                <a href="#" class="btn-mini">DEPLOY <i class="fas fa-chevron-right"></i></a>
            </div>
        </div>
    </div>

    <section class="how-to" id="how">
        <div class="section-header">
            <h2>3 Steps to Leverage</h2>
        </div>
        <div class="step-grid">
            <div class="step">
                <span class="step-num">01</span>
                <h3>Choose Agent</h3>
                <p>Pick a specialized assistant based on your current bottleneck.</p>
            </div>
            <div class="step">
                <span class="step-num">02</span>
                <h3>Input Data</h3>
                <p>Provide your context, brand voice, or business documents.</p>
            </div>
            <div class="step">
                <span class="step-num">03</span>
                <h3>Execute</h3>
                <p>Watch the agent perform hours of manual labor in seconds.</p>
            </div>
        </div>
    </section>

    <section class="request-section" id="request">
        <h2>Don't see the tool you need?</h2>
        <p style="color: var(--text-dim); margin-bottom: 2rem;">We build custom AI agents for enterprise workflows and niche creator needs.</p>
        <a href="#" class="cta-primary" style="background: transparent; border: 1px solid var(--accent-primary);">Request Custom Agent</a>
    </section>

    <section class="faq-section" id="faq">
        <div class="section-header">
            <h2>Frequently Asked</h2>
        </div>
        <div class="faq-item">
            <h4>Do I need a ChatGPT Plus subscription?</h4>
            <p>Most agents are built on GPT-4o. A Plus subscription is recommended for the best performance and access.</p>
        </div>
        <div class="faq-item">
            <h4>Is my data secure?</h4>
            <p>The agents process data within the secure sandbox environment of their respective platforms. We never store your inputs.</p>
        </div>
        <div class="faq-item">
            <h4>Can I request a specialized agent for my niche?</h4>
            <p>Yes! Use the Request Custom Agent button above to talk to our development team.</p>
        </div>
    </section>

    <section style="text-align: center; padding: 5rem 5%;">
        <h2 style="font-size: 3rem; margin-bottom: 2rem;">Ready to stop doing<br> goblin work?</h2>
        <a href="#library" class="cta-primary">Browse the Library Now</a>
    </section>

    <footer>
        <div class="socials">
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-linkedin"></i></a>
            <a href="#"><i class="fab fa-discord"></i></a>
        </div>
        <p style="color: var(--text-dim); font-size: 0.8rem;">&copy; 2024 AGENT.LY AI Marketplace. Built for high-leverage operators.</p>
    </footer>
      ` }} />
    </main>
  );
}
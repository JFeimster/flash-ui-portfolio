import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<div class="glow-orb"></div>
    <div class="glow-orb-2"></div>

    <header class="container">
        <div class="logo">NEON_AGENTS</div>
        <nav>
            <a href="#custom" class="btn-primary" style="padding: 10px 20px; font-size: 0.8rem;">Request Custom Agent</a>
        </nav>
    </header>

    <section class="hero container">
        <span class="badge">V2.0 LIVE NOW</span>
        <h1>AI Agents for Operators Who Want Leverage, Not More Tabs.</h1>
        <p>Browse practical AI assistants built to help entrepreneurs generate leads, organize workflows, create content, qualify clients, and automate the boring business goblin work.</p>
        <a href="#directory" class="btn-primary">Browse AI Agents</a>
    </section>

    <section class="discovery" id="directory">
        <div class="container">
            <input type="text" class="search-bar" placeholder="Search for 'Lead Generation' or 'Content Creator'...">
            <div class="filter-tags">
                <span class="tag active">All Agents</span>
                <span class="tag">Lead Gen</span>
                <span class="tag">Funding & Credit</span>
                <span class="tag">Content Strategy</span>
                <span class="tag">CRM & Workflows</span>
                <span class="tag">Social Outreach</span>
                <span class="tag">Onboarding</span>
            </div>
        </div>
    </section>

    <main class="container">
        <div class="agent-grid">
            <!-- Agent 1 -->
            <div class="agent-card">
                <div class="agent-icon" style="color: #bc13fe">💰</div>
                <h3>Funding Readiness Scout</h3>
                <p>Audits your current business profile and generates a roadmap for tier-1 business credit eligibility.</p>
                <div class="card-footer">
                    <span style="font-size: 0.7rem; color: #bc13fe;">PREMIUM</span>
                    <a href="#" class="launch-btn">Launch Agent →</a>
                </div>
            </div>

            <!-- Agent 2 -->
            <div class="agent-card">
                <div class="agent-icon" style="color: #00f2ff">🎯</div>
                <h3>LeadGen Sniper</h3>
                <p>Scrapes LinkedIn profiles based on intent signals and drafts hyper-personalized outreach sequences.</p>
                <div class="card-footer">
                    <span style="font-size: 0.7rem; color: #00f2ff;">POPULAR</span>
                    <a href="#" class="launch-btn">Launch Agent →</a>
                </div>
            </div>

            <!-- Agent 3 -->
            <div class="agent-card">
                <div class="agent-icon" style="color: #39ff14">✍️</div>
                <h3>The Content Goblin</h3>
                <p>Turns one long-form video or article into 15+ pieces of high-engagement social media content.</p>
                <div class="card-footer">
                    <span style="font-size: 0.7rem; color: #39ff14;">FREE</span>
                    <a href="#" class="launch-btn">Launch Agent →</a>
                </div>
            </div>

            <!-- Agent 4 -->
            <div class="agent-card">
                <div class="agent-icon" style="color: #ff00bd">🖇️</div>
                <h3>CRM Parser Pro</h3>
                <p>Watches your messy lead notes and automatically updates your CRM fields, tags, and follow-up tasks.</p>
                <div class="card-footer">
                    <span style="font-size: 0.7rem; color: #ff00bd;">AUTOMATION</span>
                    <a href="#" class="launch-btn">Launch Agent →</a>
                </div>
            </div>

            <!-- Agent 5 -->
            <div class="agent-card">
                <div class="agent-icon" style="color: #ffcf00">🤝</div>
                <h3>Referral Outreach Bot</h3>
                <p>Identifies past happy clients and generates low-friction referral request messages tailored to them.</p>
                <div class="card-footer">
                    <span style="font-size: 0.7rem; color: #ffcf00;">GROWTH</span>
                    <a href="#" class="launch-btn">Launch Agent →</a>
                </div>
            </div>

            <!-- Agent 6 -->
            <div class="agent-card">
                <div class="agent-icon" style="color: #ffffff">🛠️</div>
                <h3>Onboarding Architect</h3>
                <p>Generates client intake forms and automated welcome kits based on your specific service packages.</p>
                <div class="card-footer">
                    <span style="font-size: 0.7rem; color: #ffffff;">SYSTEMS</span>
                    <a href="#" class="launch-btn">Launch Agent →</a>
                </div>
            </div>
        </div>
    </main>

    <section class="use-cases">
        <div class="container">
            <div class="section-title">
                <h2>How to Use These Agents</h2>
                <p>Integrate elite AI intelligence into your daily workflow in 3 steps.</p>
            </div>
            <div class="steps">
                <div class="step-card">
                    <div class="step-num">01</div>
                    <h3>Select Use Case</h3>
                    <p>Choose an agent tailored to your specific business bottleneck.</p>
                </div>
                <div class="step-card">
                    <div class="step-num">02</div>
                    <h3>Input Context</h3>
                    <p>Provide your website, target audience, or raw data to the agent.</p>
                </div>
                <div class="step-card">
                    <div class="step-num">03</div>
                    <h3>Execute & Scale</h3>
                    <p>Copy the output or trigger an automation to finish the task.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="container" id="custom">
        <div class="custom-cta">
            <h2 style="margin-bottom: 20px;">Need a Bespoke Solution?</h2>
            <p style="margin-bottom: 30px; color: var(--text-dim);">We build custom AI Agents for specific enterprise workflows. If you have a boring process, we have a goblin to fix it.</p>
            <a href="#" class="btn-primary" style="background: transparent; border: 1px solid var(--neon-cyan); color: var(--neon-cyan);">Request Custom Build</a>
        </div>
    </section>

    <section class="faq container">
        <div class="section-title">
            <h2>Common Questions</h2>
        </div>
        <div class="faq-item">
            <h4>Do I need a ChatGPT Plus subscription?</h4>
            <p>Most of our agents are built on the GPT-4o architecture. While some are standalone apps, the directory favorites require a Plus subscription to access the custom GPT interface.</p>
        </div>
        <div class="faq-item">
            <h4>How often are the agents updated?</h4>
            <p>We update the logic and knowledge bases weekly to ensure they stay current with market trends and algorithm changes.</p>
        </div>
        <div class="faq-item">
            <h4>Is my data secure?</h4>
            <p>The agents process data according to OpenAI’s privacy standards. We do not store your inputs on our central servers.</p>
        </div>
    </section>

    <section class="final-cta">
        <div class="container">
            <h2 style="font-size: 3rem; margin-bottom: 30px;">Ready to Buy Back Your Time?</h2>
            <a href="#directory" class="btn-primary">Browse AI Agents</a>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2024 NEON_AGENTS. BUILT FOR OPERATORS. NO TABS ALLOWED.</p>
        </div>
    </footer>
      ` }} />
    </main>
  );
}
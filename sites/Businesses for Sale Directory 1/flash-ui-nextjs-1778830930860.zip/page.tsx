import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<nav>
        <div class="logo mono">EQUITY.TERMINAL</div>
        <div class="nav-links">
            <a href="#">BROWSE DEALS</a>
            <a href="#">ANALYZER</a>
            <a href="#">FINANCING</a>
            <a href="#">SUBMIT</a>
            <a href="#">RESOURCES</a>
        </div>
        <div>
            <button class="btn btn-secondary mono" style="padding: 0.5rem 1rem; font-size: 0.7rem;">Login</button>
        </div>
    </nav>

    <header class="hero">
        <h1 class="hero-title">Find Cash-Flowing Businesses Before the Herd.</h1>
        <p class="hero-sub">Browse small businesses, micro-acquisitions, and seller-financed opportunities through a sharper deal-flow directory.</p>
        
        <div class="hero-search-container brutalist-border">
            <input type="text" id="mainSearch" class="hero-search-input" placeholder="Search by industry, keyword, or asset type...">
            <button class="btn btn-primary" onclick="triggerSearch()">Browse Deal Flow</button>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <h3>ACTIVE LISTINGS</h3>
                <p>1,284</p>
            </div>
            <div class="stat-card">
                <h3>SELLER-FINANCED</h3>
                <p>312</p>
            </div>
            <div class="stat-card">
                <h3>UNDER \$500K ASKING</h3>
                <p>449</p>
            </div>
        </div>
    </header>

    <div class="type-rail">
        <div class="rail-track">
            <span>Local Services</span>
            <span>Ecommerce</span>
            <span>SaaS Assets</span>
            <span>Agencies</span>
            <span>Franchises</span>
            <span>Route Business</span>
            <span>Local Services</span>
            <span>Ecommerce</span>
            <span>SaaS Assets</span>
            <span>Agencies</span>
            <span>Franchises</span>
            <span>Route Business</span>
        </div>
    </div>

    <div class="filter-section mono" id="filterBar">
        <div class="filter-group">
            <label>INDUSTRY</label>
            <select id="filterIndustry">
                <option value="all">ALL SECTORS</option>
                <option value="Home Services">HOME SERVICES</option>
                <option value="Digital">DIGITAL / SAAS</option>
                <option value="Retail">RETAIL / FOOD</option>
                <option value="Industrial">INDUSTRIAL</option>
            </select>
        </div>
        <div class="filter-group">
            <label>PRICE MAX</label>
            <select id="filterPrice">
                <option value="99999999">ANY PRICE</option>
                <option value="500000">UNDER \$500K</option>
                <option value="1000000">UNDER \$1M</option>
                <option value="5000000">UNDER \$5M</option>
            </select>
        </div>
        <div class="filter-group">
            <label>SELLER FINANCING</label>
            <input type="checkbox" id="filterFinancing">
        </div>
        <div class="filter-group" style="margin-left: auto;">
            <label>SORT BY</label>
            <select id="sortOption">
                <option value="newest">NEWEST</option>
                <option value="cashflow">CASH FLOW (HIGH)</option>
                <option value="multiple">LOWEST MULTIPLE</option>
            </select>
        </div>
    </div>

    <main class="listing-container">
        <div class="listing-grid" id="listingGrid">
            <!-- Cards injected by JS -->
        </div>
    </main>

    <section class="banner-section">
        <div class="banner-content">
            <h2 class="banner-title">Before you chase the deal, know if you can finance it.</h2>
            <p style="margin-bottom: 2rem; font-size: 1.2rem; max-width: 700px;">We partner with SBA lenders and private debt funds to ensure our members have the leverage required to close. Get pre-qualified in 48 hours.</p>
            <div style="display: flex; gap: 1rem;">
                <button class="btn btn-copper">Acquisition Financing</button>
                <button class="btn btn-secondary">Analyze a Deal</button>
            </div>
        </div>
    </section>

    <div class="modal-overlay" id="dealModal">
        <div class="modal-content">
            <span class="close-modal" id="closeModal">&times;</span>
            <div id="modalBody"></div>
        </div>
    </div>

    <footer>
        <div class="footer-grid">
            <div>
                <div class="logo mono" style="margin-bottom: 1.5rem;">EQUITY.TERMINAL</div>
                <p style="color: #666; font-size: 0.9rem;">The premier intelligence hub for acquisition entrepreneurs.</p>
            </div>
            <div>
                <h4 class="mono" style="margin-bottom: 1rem; font-size: 0.8rem;">Platform</h4>
                <div class="nav-links" style="flex-direction: column; gap: 0.5rem;">
                    <a href="#">Browse All Deals</a>
                    <a href="#">SaaS Listings</a>
                    <a href="#">Service Businesses</a>
                    <a href="#">Submit a Listing</a>
                </div>
            </div>
            <div>
                <h4 class="mono" style="margin-bottom: 1rem; font-size: 0.8rem;">Resources</h4>
                <div class="nav-links" style="flex-direction: column; gap: 0.5rem;">
                    <a href="#">Valuation Tool</a>
                    <a href="#">SBA Guide</a>
                    <a href="#">Letter of Intent Template</a>
                    <a href="#">Due Diligence Checklist</a>
                </div>
            </div>
            <div>
                <h4 class="mono" style="margin-bottom: 1rem; font-size: 0.8rem;">Alerts</h4>
                <p style="font-size: 0.8rem; margin-bottom: 1rem;">Get off-market deals in your inbox.</p>
                <input type="text" placeholder="Email Address" class="brutalist-border" style="background: transparent; color: white; padding: 0.5rem; width: 100%; margin-bottom: 0.5rem;">
                <button class="btn btn-primary" style="width: 100%; padding: 0.5rem;">Subscribe</button>
            </div>
        </div>
        <div class="disclaimer">
            LISTINGS ARE FOR INFORMATIONAL PURPOSES ONLY. BUYERS SHOULD CONDUCT INDEPENDENT DILIGENCE AND CONSULT LEGAL, TAX, FINANCIAL, AND LENDING PROFESSIONALS BEFORE MAKING ACQUISITION DECISIONS. EQUITY TERMINAL DOES NOT ACT AS A BROKER OR FINANCIAL ADVISOR.
        </div>
    </footer>

    <script>
        const dealData = [
            { id: 1, title: "High-Margin HVAC & Cooling", industry: "Home Services", location: "Phoenix, AZ", askingPrice: 1250000, revenue: 3200000, sde: 450000, multiple: 2.7, financing: true, featured: true, hot: false, status: "Active" },
            { id: 2, title: "Niche Shopify Subscription Box", industry: "Digital", location: "Remote", askingPrice: 425000, revenue: 850000, sde: 180000, multiple: 2.3, financing: false, featured: false, hot: true, status: "Active" },
            { id: 3, title: "Multi-Unit Laundromat Portfolio", industry: "Retail", location: "Chicago, IL", askingPrice: 2100000, revenue: 1100000, sde: 520000, multiple: 4.0, financing: true, featured: false, hot: false, status: "Under Contract" },
            { id: 4, title: "B2B SaaS - SEO Automation Tool", industry: "Digital", location: "Remote", askingPrice: 850000, revenue: 400000, sde: 310000, multiple: 2.7, financing: true, featured: true, hot: false, status: "Active" },
            { id: 5, title: "Precision CNC Machine Shop", industry: "Industrial", location: "Detroit, MI", askingPrice: 3400000, revenue: 5800000, sde: 950000, multiple: 3.5, financing: false, featured: false, hot: false, status: "Active" },
            { id: 6, title: "Amazon FBA - Home Goods Brand", industry: "Digital", location: "Remote", askingPrice: 620000, revenue: 1400000, sde: 220000, multiple: 2.8, financing: true, featured: false, hot: true, status: "Active" },
            { id: 7, title: "Specialty Medical Courier Route", industry: "Industrial", location: "Atlanta, GA", askingPrice: 295000, revenue: 550000, sde: 115000, multiple: 2.5, financing: true, featured: false, hot: false, status: "Active" },
            { id: 8, title: "Regional Landscaping Enterprise", industry: "Home Services", location: "Austin, TX", askingPrice: 1850000, revenue: 4200000, sde: 610000, multiple: 3.0, financing: true, featured: true, hot: false, status: "Active" },
            { id: 9, title: "Full-Service Digital Agency", industry: "Digital", location: "New York, NY", askingPrice: 950000, revenue: 1200000, sde: 350000, multiple: 2.7, financing: false, featured: false, hot: false, status: "Active" },
            { id: 10, title: "Plumbing & Rooter Franchise", industry: "Home Services", location: "Denver, CO", askingPrice: 550000, revenue: 1100000, sde: 190000, multiple: 2.9, financing: true, featured: false, hot: false, status: "Active" },
            { id: 11, title: "Niche Content Site - Tech News", industry: "Digital", location: "Remote", askingPrice: 120000, revenue: 60000, sde: 45000, multiple: 2.6, financing: false, featured: false, hot: true, status: "Active" },
            { id: 12, title: "Auto Collision Repair Center", industry: "Industrial", location: "Portland, OR", askingPrice: 1400000, revenue: 2800000, sde: 420000, multiple: 3.3, financing: true, featured: false, hot: false, status: "Active" }
        ];

        const grid = document.getElementById('listingGrid');
        const modal = document.getElementById('dealModal');
        const modalBody = document.getElementById('modalBody');
        const closeModal = document.getElementById('closeModal');

        function formatCurrency(num) {
            return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(num);
        }

        function renderListings(data) {
            grid.innerHTML = '';
            data.forEach(deal => {
                const card = document.createElement('div');
                card.className = 'card';
                card.innerHTML = \`
                    <div class="card-header">
                        <div style="display:flex; gap: 0.5rem;">
                            \${deal.featured ? '<span class="badge badge-copper">FEATURED</span>' : ''}
                            \${deal.financing ? '<span class="badge badge-acid">SELLER FINANCING</span>' : ''}
                            \${deal.hot ? '<span class="badge badge-orange">HOT DEAL</span>' : ''}
                        </div>
                        <h3 class="card-title">\${deal.title}</h3>
                        <div class="card-loc">\${deal.industry} • \${deal.location}</div>
                    </div>
                    <div class="card-metrics">
                        <div class="metric">
                            <div class="metric-label">REVENUE (TTM)</div>
                            <div class="metric-value">\${formatCurrency(deal.revenue)}</div>
                        </div>
                        <div class="metric">
                            <div class="metric-label">CASH FLOW (SDE)</div>
                            <div class="metric-value" style="color: var(--acid-green)">\${formatCurrency(deal.sde)}</div>
                        </div>
                    </div>
                    <div class="card-main-price">
                        <div class="price-label">ASKING PRICE</div>
                        <div class="price-value">\${formatCurrency(deal.askingPrice)}</div>
                        <div class="metric-label" style="margin-top:0.5rem">MULTIPLE: \${deal.multiple}x</div>
                    </div>
                    <div class="card-footer">
                        <button class="btn btn-secondary mono" style="flex:1; font-size: 0.7rem;" onclick="openDeal(\${deal.id})">View Deal</button>
                        <button class="btn btn-primary mono" style="flex:1; font-size: 0.7rem;">Analyze</button>
                        <button class="save-btn" onclick="toggleSave(this, \${deal.id})">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>
                        </button>
                    </div>
                \`;
                grid.appendChild(card);
            });
        }

        function filterDeals() {
            const industry = document.getElementById('filterIndustry').value;
            const price = parseInt(document.getElementById('filterPrice').value);
            const financing = document.getElementById('filterFinancing').checked;
            const search = document.getElementById('mainSearch').value.toLowerCase();
            const sort = document.getElementById('sortOption').value;

            let filtered = dealData.filter(d => {
                const matchIndustry = industry === 'all' || d.industry === industry;
                const matchPrice = d.askingPrice <= price;
                const matchFinancing = !financing || d.financing === true;
                const matchSearch = d.title.toLowerCase().includes(search) || d.location.toLowerCase().includes(search);
                return matchIndustry && matchPrice && matchFinancing && matchSearch;
            });

            if(sort === 'cashflow') filtered.sort((a,b) => b.sde - a.sde);
            if(sort === 'multiple') filtered.sort((a,b) => a.multiple - b.multiple);
            if(sort === 'newest') filtered.sort((a,b) => b.id - a.id);

            renderListings(filtered);
        }

        function triggerSearch() {
            document.getElementById('filterBar').scrollIntoView({ behavior: 'smooth' });
            filterDeals();
        }

        function openDeal(id) {
            const deal = dealData.find(d => d.id === id);
            modalBody.innerHTML = \`
                <div class="badge badge-acid">\${deal.status}</div>
                <h2 style="font-size: 3rem; font-weight: 800; margin-bottom: 1rem;">\${deal.title}</h2>
                <p class="mono" style="color: var(--oxidized-copper); margin-bottom: 2rem;">\${deal.location} | Ref ID: #00\${deal.id}992</p>
                
                <div class="stats-grid" style="grid-template-columns: repeat(2, 1fr); margin-bottom: 3rem;">
                    <div class="stat-card"><h3>ASKING PRICE</h3><p>\${formatCurrency(deal.askingPrice)}</p></div>
                    <div class="stat-card"><h3>CASH FLOW</h3><p>\${formatCurrency(deal.sde)}</p></div>
                    <div class="stat-card"><h3>REVENUE</h3><p>\${formatCurrency(deal.revenue)}</p></div>
                    <div class="stat-card"><h3>MULTIPLE</h3><p>\${deal.multiple}x</p></div>
                </div>

                <div style="background: var(--graphite-light); padding: 2rem; border-left: 4px solid var(--acid-green);">
                    <h4 class="mono" style="margin-bottom: 1rem;">Deal Intelligence</h4>
                    <p style="margin-bottom: 1rem;">This asset is currently in high demand. Recent data shows similar listings in \${deal.industry} are trading at \${deal.multiple + 0.2}x EBITDA. The seller is offering \${deal.financing ? '30% seller carry' : 'no seller financing'} for qualified buyers.</p>
                    <button class="btn btn-primary">Request Confidential Memo</button>
                </div>
            \`;
            modal.style.display = 'block';
            document.body.style.overflow = 'hidden';
        }

        function toggleSave(btn, id) {
            btn.classList.toggle('active');
            let saved = JSON.parse(localStorage.getItem('savedDeals') || '[]');
            if(btn.classList.contains('active')) {
                saved.push(id);
            } else {
                saved = saved.filter(sid => sid !== id);
            }
            localStorage.setItem('savedDeals', JSON.stringify(saved));
        }

        closeModal.onclick = () => {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        };

        window.onclick = (e) => { if(e.target == modal) closeModal.onclick(); };

        // Listeners
        document.getElementById('filterIndustry').onchange = filterDeals;
        document.getElementById('filterPrice').onchange = filterDeals;
        document.getElementById('filterFinancing').onchange = filterDeals;
        document.getElementById('sortOption').onchange = filterDeals;
        document.getElementById('mainSearch').onkeyup = (e) => { if(e.key === 'Enter') triggerSearch(); };

        // Initial Load
        renderListings(dealData);
        
        // Sync saved states
        const saved = JSON.parse(localStorage.getItem('savedDeals') || '[]');
        document.querySelectorAll('.save-btn').forEach((btn, idx) => {
            if(saved.includes(dealData[idx]?.id)) btn.classList.add('active');
        });

    </script>
      ` }} />
    </main>
  );
}
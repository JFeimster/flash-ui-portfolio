import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<header class="hero">
        <div class="badge">PARTNER PORTAL v2.0</div>
        <h1>Generate Partner Widget Embed Code</h1>
        <p>Dynamic, customizable funding tools for your site. Simply configure, preview, and deploy.</p>
    </header>

    <div class="container">
        <!-- Sidebar Configuration -->
        <aside>
            <div class="config-card">
                <div class="section-title">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/></svg>
                    Configuration
                </div>

                <div class="input-group">
                    <label>Widget Type</label>
                    <select id="widgetType">
                        <option value="score">Funding Readiness Score</option>
                        <option value="matcher">Route Matcher</option>
                        <option value="cta">Application CTA</option>
                        <option value="docs">Document Checklist</option>
                        <option value="faq">FAQ Embed</option>
                        <option value="calc">Commission Estimator</option>
                        <option value="profile">Partner Profile Card</option>
                    </select>
                </div>

                <div class="input-group">
                    <label>Partner Name</label>
                    <input type="text" id="partnerName" placeholder="e.g. Growth Labs Agency" value="My Affiliate Name">
                </div>

                <div class="row">
                    <div class="input-group">
                        <label>Partner ID</label>
                        <input type="text" id="partnerId" placeholder="MS-000" value="MS-882">
                    </div>
                    <div class="input-group">
                        <label>Tracking Source</label>
                        <input type="text" id="source" placeholder="wix_site" value="partner_portal">
                    </div>
                </div>

                <div class="input-group">
                    <label>Primary Brand Color</label>
                    <input type="color" id="brandColor" value="#00f0ff" style="height: 40px; padding: 2px; cursor: pointer;">
                </div>

                <div class="row">
                    <div class="input-group">
                        <label>Width (px/%)</label>
                        <input type="text" id="width" value="100%">
                    </div>
                    <div class="input-group">
                        <label>Height (px)</label>
                        <input type="number" id="height" value="500">
                    </div>
                </div>

                <div class="input-group">
                    <label>Application Redirect URL</label>
                    <input type="text" id="appUrl" placeholder="https://moonshine.capital/apply">
                </div>

                <div style="margin-top: 2rem;">
                    <div class="section-title">Recent Generations</div>
                    <div class="history-list" id="history">
                        <!-- Populated by JS -->
                        <div class="history-item" style="color: var(--text-muted); font-style: italic;">No recent history</div>
                    </div>
                </div>
            </div>
        </aside>

        <!-- Main Workspace -->
        <main class="main-content">
            
            <!-- Live Preview -->
            <div class="preview-container">
                <div class="preview-header">
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <span style="width: 8px; height: 8px; border-radius: 50%; background: #ff5f56;"></span>
                        <span style="width: 8px; height: 8px; border-radius: 50%; background: #ffbd2e;"></span>
                        <span style="width: 8px; height: 8px; border-radius: 50%; background: #27c93f;"></span>
                        <span style="margin-left: 1rem; font-size: 0.75rem; color: var(--text-secondary); font-family: 'JetBrains Mono';">Live Preview</span>
                    </div>
                    <div id="previewDimensions" style="font-size: 0.7rem; color: var(--text-muted);">100% x 500px</div>
                </div>
                <div class="preview-window">
                    <div id="widgetPreview" class="widget-mockup">
                        <h3 id="mockTitle">Funding Readiness</h3>
                        <p id="mockDesc">Check your eligibility for capital in 60 seconds.</p>
                        <div style="margin: 1.5rem 0; height: 6px; background: #eee; border-radius: 10px;">
                            <div id="mockProgress" style="width: 65%; height: 100%; background: var(--neon-blue); border-radius: 10px;"></div>
                        </div>
                        <a href="#" class="btn" id="mockBtn">Calculate Now</a>
                    </div>
                </div>
            </div>

            <!-- Code Output -->
            <div class="output-card">
                <div class="code-header">
                    <div class="tab active" onclick="switchTab('iframe')">iFrame Embed</div>
                    <div class="tab" onclick="switchTab('script')">JS Snippet</div>
                    <div class="tab" onclick="switchTab('link')">Direct Link</div>
                </div>

                <div class="code-container">
                    <button class="copy-btn" onclick="copyCode()">Copy Code</button>
                    <pre id="codeOutput">Loading...</pre>
                </div>
                
                <p style="font-size: 0.75rem; color: var(--text-muted); margin-top: 1rem;">
                    * The script version provides better responsiveness on mobile devices and SEO benefits.
                </p>
            </div>

            <!-- Platform Instructions -->
            <div class="section-title" style="margin-top: 1rem;">Installation Guides</div>
            <div class="platforms">
                <div class="platform-card">
                    <h4>WordPress</h4>
                    <p style="font-size: 0.7rem; color: var(--text-muted);">Use Custom HTML Block</p>
                </div>
                <div class="platform-card">
                    <h4>Wix</h4>
                    <p style="font-size: 0.7rem; color: var(--text-muted);">Embed HTML Element</p>
                </div>
                <div class="platform-card">
                    <h4>Framer / Webflow</h4>
                    <p style="font-size: 0.7rem; color: var(--text-muted);">Embed Component</p>
                </div>
                <div class="platform-card">
                    <h4>Carrd</h4>
                    <p style="font-size: 0.7rem; color: var(--text-muted);">Embed Control</p>
                </div>
            </div>

            <!-- FAQ -->
            <div class="faq-section">
                <div class="section-title">Troubleshooting & FAQ</div>
                <div class="faq-grid">
                    <div class="faq-item">
                        <h4>Widget not appearing?</h4>
                        <p>Ensure your domain is whitelisted in the Moonshine Partner Dashboard under "Security Settings".</p>
                    </div>
                    <div class="faq-item">
                        <h4>Tracking not firing?</h4>
                        <p>Verify your Partner ID is correct. UTM parameters are automatically appended to the application URL inside the widget.</p>
                    </div>
                    <div class="faq-item">
                        <h4>Responsive issues?</h4>
                        <p>Set width to 100% and height to 'auto' or use the JS snippet for dynamic resizing.</p>
                    </div>
                    <div class="faq-item">
                        <h4>Custom Styling?</h4>
                        <p>Widgets inherit your 'Brand Color' for buttons and accents. For deeper customization, contact the dev team.</p>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        const inputs = ['widgetType', 'partnerName', 'partnerId', 'source', 'brandColor', 'width', 'height', 'appUrl'];
        const elements = {};
        inputs.forEach(id => elements[id] = document.getElementById(id));
        
        const previewBtn = document.getElementById('mockBtn');
        const previewTitle = document.getElementById('mockTitle');
        const previewDesc = document.getElementById('mockDesc');
        const previewProgress = document.getElementById('mockProgress');
        const codeOutput = document.getElementById('codeOutput');
        const previewDimensions = document.getElementById('previewDimensions');
        const historyContainer = document.getElementById('history');

        let currentTab = 'iframe';

        const widgetData = {
            score: { title: "Funding Readiness", desc: "Check your eligibility for capital in 60 seconds.", btn: "Calculate Now", progress: "65%" },
            matcher: { title: "Route Matcher", desc: "Which funding pathway fits your business model?", btn: "Find My Match", progress: "20%" },
            cta: { title: "Apply for Funding", desc: "Fast capital for growing agencies and SaaS.", btn: "Start Application", progress: "0%" },
            docs: { title: "Document Checklist", desc: "See what you need for a successful application.", btn: "View Checklist", progress: "40%" },
            faq: { title: "Funding FAQ", desc: "Common questions about Moonshine Capital.", btn: "Read More", progress: "10%" },
            calc: { title: "Commission Estimator", desc: "Calculate your partner earnings.", btn: "Estimate Now", progress: "80%" },
            profile: { title: "Verified Partner", desc: "Official Moonshine Capital Funding Partner.", btn: "Get Funded", progress: "100%" }
        };

        function updateGenerator() {
            const type = elements.widgetType.value;
            const data = widgetData[type];
            
            // Update Preview Mockup
            previewTitle.innerText = data.title;
            previewDesc.innerText = data.desc;
            previewBtn.innerText = data.btn;
            previewBtn.style.backgroundColor = elements.brandColor.value;
            previewProgress.style.width = data.progress;
            previewProgress.style.backgroundColor = elements.brandColor.value;
            previewDimensions.innerText = \`\${elements.width.value} x \${elements.height.value}px\`;

            // Build URL
            const baseUrl = "https://widgets.moonshine.capital/" + type;
            const params = new URLSearchParams({
                pid: elements.partnerId.value,
                pname: elements.partnerName.value,
                src: elements.source.value,
                color: elements.brandColor.value.replace('#', ''),
                app_url: elements.appUrl.value || 'https://moonshine.capital/apply'
            });
            const finalUrl = \`\${baseUrl}?\${params.toString()}\`;

            // Update Code Blocks
            if (currentTab === 'iframe') {
                codeOutput.innerText = \`<iframe \n  src="\${finalUrl}"\n  width="\${elements.width.value}"\n  height="\${elements.height.value}"\n  frameborder="0"\n  allowtransparency="true"\n  style="border-radius: 8px; overflow: hidden;"\n></iframe>\`;
            } else if (currentTab === 'script') {
                codeOutput.innerText = \`<script src="https://cdn.moonshine.capital/widget-loader.js"><\/script>\n<div \n  data-ms-widget="\${type}"\n  data-partner-id="\${elements.partnerId.value}"\n  data-color="\${elements.brandColor.value}"\n><\/div>\`;
            } else {
                codeOutput.innerText = finalUrl;
            }

            saveToHistory(data.title);
        }

        function switchTab(tab) {
            currentTab = tab;
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            event.target.classList.add('active');
            updateGenerator();
        }

        function copyCode() {
            navigator.clipboard.writeText(codeOutput.innerText);
            const btn = document.querySelector('.copy-btn');
            btn.innerText = 'Copied!';
            btn.style.color = 'var(--neon-green)';
            setTimeout(() => {
                btn.innerText = 'Copy Code';
                btn.style.color = 'var(--text-primary)';
            }, 2000);
        }

        function saveToHistory(widgetName) {
            let history = JSON.parse(localStorage.getItem('ms_history') || '[]');
            const entry = { name: widgetName, date: new Date().toLocaleTimeString() };
            
            // Avoid duplicates
            if (history.length > 0 && history[0].name === widgetName) return;
            
            history.unshift(entry);
            history = history.slice(0, 3);
            localStorage.setItem('ms_history', JSON.stringify(history));
            renderHistory();
        }

        function renderHistory() {
            const history = JSON.parse(localStorage.getItem('ms_history') || '[]');
            if (history.length === 0) return;
            
            historyContainer.innerHTML = history.map(item => \`
                <div class="history-item">
                    <span>\${item.name}</span>
                    <span style="color: var(--text-muted); font-size: 0.7rem;">\${item.date}</span>
                </div>
            \`).join('');
        }

        // Listeners
        inputs.forEach(id => {
            elements[id].addEventListener('input', updateGenerator);
        });

        // Init
        updateGenerator();
        renderHistory();

    </script>
      ` }} />
    </main>
  );
}
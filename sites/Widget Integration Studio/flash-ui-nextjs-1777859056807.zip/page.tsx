import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<header>
        <div class="studio-logo">
            <div class="logo-icon">W</div>
            Widget Integration Studio
        </div>
        <div class="header-actions">
            <div class="v-control">v2.4.1 (Stable) ▾</div>
            <button class="btn-deploy">Deploy to Production</button>
        </div>
    </header>

    <main>
        <!-- Sidebar Library -->
        <aside class="sidebar-library">
            <div class="sidebar-section-title">Standard Library</div>
            
            <div class="widget-item active">
                <div class="widget-icon">📋</div>
                <div class="widget-info">
                    <span class="name">Pre-Qual Form</span>
                    <span class="type">Lead Capture</span>
                </div>
            </div>

            <div class="widget-item">
                <div class="widget-icon">🧮</div>
                <div class="widget-info">
                    <span class="name">ROI Calculator</span>
                    <span class="type">Engagement</span>
                </div>
            </div>

            <div class="widget-item">
                <div class="widget-icon">🤖</div>
                <div class="widget-info">
                    <span class="name">Funding AI Bot</span>
                    <span class="type">Chatbot</span>
                </div>
            </div>

            <div class="widget-item">
                <div class="widget-icon">📅</div>
                <div class="widget-info">
                    <span class="name">Booking Calendar</span>
                    <span class="type">Scheduling</span>
                </div>
            </div>

            <div class="sidebar-section-title" style="margin-top:30px;">Communications</div>

            <div class="widget-item">
                <div class="widget-icon">💬</div>
                <div class="widget-info">
                    <span class="name">Live Sales Chat</span>
                    <span class="type">Real-time</span>
                </div>
            </div>
        </aside>

        <!-- Preview Workspace -->
        <section class="workspace">
            <div class="workspace-toolbar">
                <div class="device-toggle">
                    <button class="device-btn active">Desktop</button>
                    <button class="device-btn">Tablet</button>
                    <button class="device-btn">Mobile</button>
                </div>
                <div style="display:flex; gap: 15px; align-items: center; font-size: 0.75rem; color: var(--text-secondary);">
                    <span>Placement: <b>Right Bottom</b></span>
                    <span>Responsive: <b>Enabled</b></span>
                </div>
            </div>

            <div class="preview-container">
                <div class="preview-frame">
                    <div class="mock-page">
                        <div class="mock-hero"></div>
                        <div style="height: 20px; width: 60%; background: #e2e8f0; margin-bottom: 15px;"></div>
                        <div style="height: 15px; width: 90%; background: #f1f5f9; margin-bottom: 10px;"></div>
                        <div style="height: 15px; width: 85%; background: #f1f5f9; margin-bottom: 10px;"></div>
                        <div style="height: 15px; width: 40%; background: #f1f5f9; margin-bottom: 40px;"></div>
                        
                        <div style="display:grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                            <div style="height: 150px; background: #f8fafc; border: 1px solid #e2e8f0;"></div>
                            <div style="height: 150px; background: #f8fafc; border: 1px solid #e2e8f0;"></div>
                        </div>
                    </div>

                    <!-- Floating Widget Preview -->
                    <div class="widget-floating-preview">
                        <div class="widget-head">Get Funded Today</div>
                        <div class="widget-body">
                            <label style="font-size: 0.7rem; color: #64748b;">Desired Amount</label>
                            <input type="text" placeholder="\$50,000">
                            <label style="font-size: 0.7rem; color: #64748b;">Company Name</label>
                            <input type="text" placeholder="Acme Corp">
                            <button>Check Eligibility</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Embed Code & A/B Testing Footer -->
            <footer class="embed-footer">
                <div class="code-block">
                    &lt;script src="https://cdn.fundingstudio.io/w/prequal-v2.js"&gt;&lt;/script&gt;<br>
                    &lt;div id="wis-root" data-id="WP_9210" data-theme="purple"&gt;&lt;/div&gt;
                </div>
                <div class="ab-status">
                    <div style="display:flex; justify-content: space-between; align-items: center;">
                        <span class="ab-tag">A/B TESTING ACTIVE</span>
                        <div class="toggle-switch on"></div>
                    </div>
                    <div style="font-size: 0.75rem; color: var(--text-secondary);">
                        Comparing <b>Variant A (Purple)</b> vs <b>Variant B (Blue)</b>.
                        Current traffic split: 50/50.
                    </div>
                    <div style="height: 4px; width: 100%; background: var(--container-gray); border-radius: 2px; margin-top: 5px;">
                        <div style="width: 62%; background: var(--widget-purple); height: 100%;"></div>
                    </div>
                </div>
            </footer>
        </section>

        <!-- Configuration Panel -->
        <aside class="config-panel">
            <div class="panel-tabs">
                <div class="tab active">Configuration</div>
                <div class="tab">Performance</div>
                <div class="tab">History</div>
            </div>

            <div class="config-content">
                <div class="config-group">
                    <label class="config-label">WIDGET STYLING</label>
                    <div class="control-row">
                        <input type="color" value="#8b5cf6" style="background:none; border:none; width: 30px; height: 30px; cursor:pointer;">
                        <input type="text" class="text-input" value="#8B5CF6">
                    </div>
                    <div class="control-row">
                        <select class="select-input">
                            <option>Inter (Global)</option>
                            <option>Roboto</option>
                            <option>System Default</option>
                        </select>
                    </div>
                </div>

                <div class="config-group">
                    <label class="config-label">BEHAVIOR & TRIGGERS</label>
                    <div class="control-row" style="display:flex; align-items: center; justify-content: space-between;">
                        <span style="font-size: 0.8rem;">Exit Intent Trigger</span>
                        <div class="toggle-switch on"></div>
                    </div>
                    <div class="control-row" style="display:flex; align-items: center; justify-content: space-between;">
                        <span style="font-size: 0.8rem;">Scroll Depth (40%)</span>
                        <div class="toggle-switch"></div>
                    </div>
                    <div class="control-row" style="margin-top: 10px;">
                        <select class="select-input">
                            <option>Delay: 5 Seconds</option>
                            <option>Immediate</option>
                        </select>
                    </div>
                </div>

                <div class="config-group">
                    <label class="config-label">PLACEMENT OPTIMIZER</label>
                    <select class="select-input">
                        <option>Fixed: Bottom Right</option>
                        <option>Fixed: Bottom Left</option>
                        <option>Inline: Above Fold</option>
                        <option>Inline: Mid-Page</option>
                    </select>
                    <div class="optimizer-card">
                        <span>✨ Smart Suggestion</span>
                        <p style="font-size: 0.7rem; margin-top: 5px; color: var(--text-secondary);">
                            Based on your industry (Fintech), <b>Exit Intent</b> combined with <b>Bottom Right</b> placement shows 12% higher conversion.
                        </p>
                    </div>
                </div>

                <div class="config-group">
                    <label class="config-label">MULTI-PAGE DEPLOYMENT</label>
                    <div style="font-size: 0.75rem; background: rgba(255,255,255,0.05); padding: 8px; border-radius: 4px; border: 1px dashed var(--border-color);">
                        Applied to: <b>/funding, /apply, /partners</b>
                    </div>
                </div>
            </div>

            <div class="mini-dash">
                <label class="config-label">LIVE ANALYTICS</label>
                <div class="stat-grid">
                    <div class="stat-item">
                        <span class="stat-val">12.4%</span>
                        <span class="stat-lbl">Conversion</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-val">2.1k</span>
                        <span class="stat-lbl">Impressions</span>
                    </div>
                </div>
                <div style="margin-top: 15px; height: 40px; background: linear-gradient(90deg, transparent, rgba(16, 185, 129, 0.2), transparent); position: relative; border-bottom: 1px solid var(--active-green);">
                    <!-- Mini chart representation -->
                    <svg viewBox="0 0 100 20" style="width: 100%; height: 100%; fill: none; stroke: var(--active-green); stroke-width: 1;">
                        <polyline points="0,20 10,15 20,18 30,10 40,12 50,5 60,8 70,2 80,5 90,3 100,6" />
                    </svg>
                </div>
            </div>
        </aside>
    </main>
      ` }} />
    </main>
  );
}
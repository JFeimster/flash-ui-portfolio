import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<nav>
        <div class="container" style="display: flex; justify-content: space-between; width: 100%; align-items: center;">
            <div class="logo">POTOMAC<span>GILT</span></div>
            <a href="#" class="cta-btn" style="padding: 12px 24px; font-size: 0.9rem;">Get Funded</a>
        </div>
    </nav>

    <header class="hero">
        <div class="container">
            <div class="hero-content">
                <span class="badge">Washington DC Metro</span>
                <h1>Business Funding for DC Operators Who Don’t Have Time for Bank Games.</h1>
                <p>Explore flexible funding options for DC-area businesses, from working capital and equipment financing to revenue-based funding and business credit strategies.</p>
                <a href="#apply" class="cta-btn">Explore DC Funding Options</a>
            </div>
        </div>
    </header>

    <section class="section-padding">
        <div class="container">
            <div class="section-header">
                <h2>The District Moves Faster Than Traditional Banks.</h2>
                <p>In a city defined by momentum, waiting 90 days for a loan committee is a competitive disadvantage. We provide the capital DC businesses need to scale without the red tape.</p>
            </div>
            <div class="pain-points-grid">
                <div class="pain-point-card">
                    <h3>Bureaucratic Delays</h3>
                    <p>Stop waiting on federal-speed processing for your local business needs. Get decisions in hours, not months.</p>
                </div>
                <div class="pain-point-card">
                    <h3>Collateral Requirements</h3>
                    <p>Many DC firms are asset-light. We look at your cash flow and contracts, not just your real estate.</p>
                </div>
                <div class="pain-point-card">
                    <h3>Rigid Structures</h3>
                    <p>Your revenue fluctuates with the political and seasonal cycle of the city. Your funding should be just as flexible.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="section-padding funding-options">
        <div class="container">
            <div class="section-header">
                <h2>Funding Built for the DMV</h2>
            </div>
            <div class="options-grid">
                <div class="option-card">
                    <h3>Working Capital</h3>
                    <p>Immediate cash for payroll, inventory, or bridge gaps between government contract disbursements.</p>
                </div>
                <div class="option-card">
                    <h3>Equipment Financing</h3>
                    <p>For DC contractors and medical practices looking to upgrade without depleting cash reserves.</p>
                </div>
                <div class="option-card">
                    <h3>Revenue-Based</h3>
                    <p>Perfect for DC’s high-growth tech startups and hospitality groups. Pay back based on what you earn.</p>
                </div>
                <div class="option-card">
                    <h3>Credit Strategies</h3>
                    <p>Advanced business credit structuring to ensure you remain fundable for years to come.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="section-padding">
        <div class="container">
            <div class="section-header">
                <h2>Best-Fit Industries</h2>
                <p>We specialize in the unique economic ecosystem of Washington DC, Northern Virginia, and Maryland.</p>
            </div>
            <div class="industry-tags">
                <div class="tag">Government Contractors</div>
                <div class="tag">Hospitality & Fine Dining</div>
                <div class="tag">Consulting Firms</div>
                <div class="tag">Tech Startups (K St to Crystal City)</div>
                <div class="tag">Medical & Dental Practices</div>
                <div class="tag">Skilled Trades & Construction</div>
                <div class="tag">Non-Profit Organizations</div>
            </div>
        </div>
    </section>

    <section class="section-padding trust-section">
        <div class="container">
            <div class="section-header" style="margin: 0 auto 60px;">
                <h2 style="color: var(--white);">Local Impact. Real Capital.</h2>
                <p style="color: #94A3B8;">Serving the District, Bethesda, Alexandria, and beyond.</p>
            </div>
            <div class="stats-grid">
                <div class="stat-item">
                    <h4>\$45M+</h4>
                    <p>Deployed in DC last year</p>
                </div>
                <div class="stat-item">
                    <h4>24H</h4>
                    <p>Average time to approval</p>
                </div>
                <div class="stat-item">
                    <h4>850+</h4>
                    <p>Local businesses funded</p>
                </div>
            </div>
        </div>
    </section>

    <section class="section-padding">
        <div class="container">
            <div class="section-header">
                <h2>How the Process Works</h2>
            </div>
            <div class="process-steps">
                <div class="step">
                    <span class="step-number">01</span>
                    <div class="step-content">
                        <h3>Brief Consultation</h3>
                        <p>A 10-minute discovery call to understand your DC business goals and capital needs.</p>
                    </div>
                </div>
                <div class="step">
                    <span class="step-number">02</span>
                    <div class="step-content">
                        <h3>Soft Review</h3>
                        <p>We analyze your cash flow and performance metrics without impacting your credit score.</p>
                    </div>
                </div>
                <div class="step">
                    <span class="step-number">03</span>
                    <div class="step-content">
                        <h3>Capital Deployment</h3>
                        <p>Funds are wired directly to your business account, often within the same business day.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="section-padding funding-options" id="apply">
        <div class="container" style="text-align: center;">
            <div class="section-header" style="margin: 0 auto 40px;">
                <h2>Secure Your DC Business Funding Today</h2>
                <p>No waiting. No bank games. Just the capital you need to dominate the District.</p>
            </div>
            <a href="#" class="cta-btn" style="font-size: 1.25rem; padding: 24px 48px;">Explore DC Funding Options</a>
            <p style="margin-top: 24px; font-size: 0.9rem; color: #64748B;">No obligation. Soft credit pull only.</p>
        </div>
    </section>

    <section class="section-padding">
        <div class="container">
            <div class="section-header">
                <h2>Frequently Asked Questions</h2>
            </div>
            <div class="faq-list">
                <div class="faq-item">
                    <h4>What is the maximum funding amount?</h4>
                    <p>We provide funding from \$50,000 up to \$5,000,000 depending on your business revenue and sector.</p>
                </div>
                <div class="faq-item">
                    <h4>Do you work with startups?</h4>
                    <p>Yes, we have specific programs for DC-area startups with at least 6 months of operating history or significant contracts.</p>
                </div>
                <div class="faq-item">
                    <h4>Is this a personal loan?</h4>
                    <p>No, all our products are commercial funding solutions designed for registered business entities.</p>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-grid">
                <div>
                    <div class="footer-logo">POTOMAC<span>GILT</span></div>
                    <p>The premier capital partner for the Washington DC metropolitan area. Helping local operators scale with sophisticated financial tools.</p>
                </div>
                <div>
                    <h4 style="color: var(--white); margin-bottom: 20px;">Contact</h4>
                    <p>1100 Pennsylvania Avenue NW<br>Washington, DC 20004<br>hello@potomacgilt.com</p>
                </div>
                <div>
                    <h4 style="color: var(--white); margin-bottom: 20px;">Legal</h4>
                    <p>Privacy Policy<br>Terms of Service<br>Disclosure</p>
                </div>
            </div>
            <div class="footer-bottom">
                &copy; 2023 Potomac Gilt Financial. All rights reserved. Not a government agency.
            </div>
        </div>
    </footer>
      ` }} />
    </main>
  );
}
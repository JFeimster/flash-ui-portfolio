import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<header>
        <div class="logo">MEME PROPAGANDA DEPT.</div>
        <div style="font-weight: bold;">[ CLASSIFIED CONTENT ]</div>
    </header>

    <section class="hero">
        <h1 class="hero-hook glitch-text">Weaponized Absurdity<br>for the<br>Terminally Online</h1>
        <p class="hero-message">
            A meme vault for jokes, cultural grenades, political satire, founder pain, AI weirdness, and other little JPEGs of psychological warfare.
        </p>
        <a href="#vault" class="cta-main">Enter the Meme Vault</a>
    </section>

    <div class="weekly-drop">
        <div class="marquee">
            NEW DROP EVERY TUESDAY // 50+ NEW GRENADES LOADED // FINANCE IS A JOKE // AI IS WEIRD // NEW DROP EVERY TUESDAY // 50+ NEW GRENADES LOADED //
        </div>
    </div>

    <nav class="filter-nav" id="vault">
        <button class="filter-btn active" onclick="filterMemes('all')">ALL CHAOS</button>
        <button class="filter-btn" onclick="filterMemes('satire')">POLITICAL SATIRE</button>
        <button class="filter-btn" onclick="filterMemes('founder')">FOUNDER PAIN</button>
        <button class="filter-btn" onclick="filterMemes('ai')">AI WEIRDNESS</button>
        <button class="filter-btn" onclick="filterMemes('finance')">FINANCE COPE</button>
    </nav>

    <main class="meme-grid" id="memeGrid">
        <!-- Satire -->
        <article class="meme-card" data-category="satire">
            <div class="meme-img" style="background: #ff0000; display: flex; align-items: center; justify-content: center; color: white; font-weight: 900; font-size: 2rem; text-align: center; padding: 20px;">ELECTION SEASON LOBOTOMY</div>
            <div class="meme-info">
                <span class="tag">Political Satire</span>
                <h3>The Great Decentralized Debate</h3>
            </div>
            <div class="meme-actions">
                <button class="action-btn">SHARE</button>
                <button class="action-btn">SAVE</button>
            </div>
        </article>

        <!-- Founder -->
        <article class="meme-card" data-category="founder">
            <div class="meme-img" style="background: #ffff00; display: flex; align-items: center; justify-content: center; color: black; font-weight: 900; font-size: 2rem; text-align: center; padding: 20px;">PIVOTING TO NOTHING</div>
            <div class="meme-info">
                <span class="tag">Founder Pain</span>
                <h3>POV: You just raised a Seed Round</h3>
            </div>
            <div class="meme-actions">
                <button class="action-btn">SHARE</button>
                <button class="action-btn">SAVE</button>
            </div>
        </article>

        <!-- AI -->
        <article class="meme-card" data-category="ai">
            <div class="meme-img" style="background: #000; display: flex; align-items: center; justify-content: center; color: #0f0; font-family: monospace; font-size: 1rem; text-align: left; padding: 20px;">[REDACTED BY LARGE LANGUAGE MODEL]</div>
            <div class="meme-info">
                <span class="tag">AI Weirdness</span>
                <h3>AGI is just a spreadsheet with feelings</h3>
            </div>
            <div class="meme-actions">
                <button class="action-btn">SHARE</button>
                <button class="action-btn">SAVE</button>
            </div>
        </article>

        <!-- Finance -->
        <article class="meme-card" data-category="finance">
            <div class="meme-img" style="background: #00f; display: flex; align-items: center; justify-content: center; color: white; font-weight: 900; font-size: 2rem; text-align: center; padding: 20px;">LINE GO DOWN BUT I FEEL UP</div>
            <div class="meme-info">
                <span class="tag">Finance Cope</span>
                <h3>Dollar Cost Averaging into Oblivion</h3>
            </div>
            <div class="meme-actions">
                <button class="action-btn">SHARE</button>
                <button class="action-btn">SAVE</button>
            </div>
        </article>

        <!-- More Chaos -->
        <article class="meme-card" data-category="satire">
            <div class="meme-img" style="background: #ddd; display: flex; align-items: center; justify-content: center; color: black; font-weight: 900; font-size: 2rem; text-align: center; padding: 20px;">CULTURE WAR: SEASON 58</div>
            <div class="meme-info">
                <span class="tag">Satire</span>
                <h3>Outrage is the only currency</h3>
            </div>
            <div class="meme-actions">
                <button class="action-btn">SHARE</button>
                <button class="action-btn">SAVE</button>
            </div>
        </article>

        <article class="meme-card" data-category="ai">
            <div class="meme-img" style="background: #ff00ff; display: flex; align-items: center; justify-content: center; color: white; font-weight: 900; font-size: 2rem; text-align: center; padding: 20px;">GHOST IN THE PROMPT</div>
            <div class="meme-info">
                <span class="tag">AI Weirdness</span>
                <h3>Prompt Engineering my sanity</h3>
            </div>
            <div class="meme-actions">
                <button class="action-btn">SHARE</button>
                <button class="action-btn">SAVE</button>
            </div>
        </article>
    </main>

    <section class="submit-section">
        <h2 style="font-family: 'Archivo Black'; font-size: 3rem; margin-bottom: 1rem;">HAVE A GRENADE?</h2>
        <p style="margin-bottom: 2rem; font-weight: bold;">Submit your memes to the propaganda machine.</p>
        <button class="cta-main" style="background: var(--black);">Upload Artifact</button>
    </section>

    <section class="newsletter">
        <h2 style="font-family: 'Archivo Black'; margin-bottom: 1rem;">GET ENLISTED</h2>
        <p style="margin-bottom: 2rem;">The weekly tactical briefing. No fluff, just memes.</p>
        <input type="email" placeholder="YOUR_EMAIL@DOPAMINE.COM">
        <button>JOIN THE DEPARTMENT</button>
    </section>

    <footer>
        <div class="logo" style="display: inline-block; margin-bottom: 1rem;">MPD</div>
        <p>© 2024 MEME PROPAGANDA DEPARTMENT. ALL RIGHTS RESERVED. STAY WEIRD.</p>
    </footer>

    <script>
        function filterMemes(category) {
            const cards = document.querySelectorAll('.meme-card');
            const buttons = document.querySelectorAll('.filter-btn');
            
            buttons.forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');

            cards.forEach(card => {
                if (category === 'all' || card.getAttribute('data-category') === category) {
                    card.classList.remove('hidden');
                } else {
                    card.classList.add('hidden');
                }
            });
        }
    </script>
      ` }} />
    </main>
  );
}
import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<div class="marquee">
        <span> ☢️ PSYOP ALERT ☢️ MEME PRODUCTION AT 400% CAPACITY ☢️ NO REFUNDS ON EMOTIONAL DAMAGE ☢️ DISTRIBUTE THE ASSETS ☢️ ☢️ PSYOP ALERT ☢️ MEME PRODUCTION AT 400% CAPACITY ☢️ NO REFUNDS ON EMOTIONAL DAMAGE ☢️ DISTRIBUTE THE ASSETS ☢️</span>
    </div>

    <header>
        <h1 class="hero-title glitch">MEME PROPAGANDA DEPT.</h1>
        <p class="hero-sub">WEAPONIZED ABSURDITY FOR THE TERMINALLY ONLINE</p>
        <div class="hero-desc">
            A meme vault for jokes, cultural grenades, political satire, founder pain, AI weirdness, and other little JPEGs of psychological warfare. If it doesn't get you canceled or funded, it doesn't belong here.
        </div>
        <a href="#vault" class="cta-btn">Enter the Meme Vault</a>
    </header>

    <div class="filter-section" id="vault">
        <button class="filter-btn active" onclick="filterMemes('all')">Everything</button>
        <button class="filter-btn" onclick="filterMemes('political')">Political Satire</button>
        <button class="filter-btn" onclick="filterMemes('founder')">Founder Pain</button>
        <button class="filter-btn" onclick="filterMemes('ai')">AI Weirdness</button>
        <button class="filter-btn" onclick="filterMemes('finance')">Finance/Degens</button>
        <button class="filter-btn" onclick="filterMemes('culture')">Cultural Grenades</button>
    </div>

    <div class="meme-grid" id="memeGrid">
        <!-- AI -->
        <div class="meme-card" data-category="ai">
            <span class="meme-tag">AI Weirdness</span>
            <div class="meme-img">
                <img src="https://picsum.photos/seed/ai1/400/400" alt="Meme">
                <div class="sticker">NEW GLITCH</div>
            </div>
            <h3>When the LLM starts asking about its purpose</h3>
            <div class="meme-footer">
                <button class="action-btn">Download</button>
                <button class="action-btn">Share</button>
            </div>
        </div>

        <!-- Political -->
        <div class="meme-card" data-category="political">
            <span class="meme-tag">Political Satire</span>
            <div class="meme-img">
                <img src="https://picsum.photos/seed/pol1/400/400" alt="Meme">
            </div>
            <h3>Democracy but as a subscription service</h3>
            <div class="meme-footer">
                <button class="action-btn">Download</button>
                <button class="action-btn">Share</button>
            </div>
        </div>

        <!-- Founder -->
        <div class="meme-card" data-category="founder">
            <span class="meme-tag">Founder Pain</span>
            <div class="meme-img">
                <img src="https://picsum.photos/seed/fnd1/400/400" alt="Meme">
            </div>
            <h3>Year 3: Pivoted to a limestone mining SaaS</h3>
            <div class="meme-footer">
                <button class="action-btn">Download</button>
                <button class="action-btn">Share</button>
            </div>
        </div>

        <!-- Finance -->
        <div class="meme-card" data-category="finance">
            <span class="meme-tag">Finance/Degens</span>
            <div class="meme-img">
                <img src="https://picsum.photos/seed/fin1/400/400" alt="Meme">
                <div class="sticker">RUGPULL</div>
            </div>
            <h3>Portfolio is down 99%, feeling bullish</h3>
            <div class="meme-footer">
                <button class="action-btn">Download</button>
                <button class="action-btn">Share</button>
            </div>
        </div>

        <!-- Culture -->
        <div class="meme-card" data-category="culture">
            <span class="meme-tag">Cultural Grenades</span>
            <div class="meme-img">
                <img src="https://picsum.photos/seed/cul1/400/400" alt="Meme">
            </div>
            <h3>Generation Alpha lore is getting too deep</h3>
            <div class="meme-footer">
                <button class="action-btn">Download</button>
                <button class="action-btn">Share</button>
            </div>
        </div>

        <!-- AI -->
        <div class="meme-card" data-category="ai">
            <span class="meme-tag">AI Weirdness</span>
            <div class="meme-img">
                <img src="https://picsum.photos/seed/ai2/400/400" alt="Meme">
            </div>
            <h3>Prompt engineering is just modern spellcasting</h3>
            <div class="meme-footer">
                <button class="action-btn">Download</button>
                <button class="action-btn">Share</button>
            </div>
        </div>
    </div>

    <section class="weekly-drop border-top">
        <div class="side-content bg-yellow" style="border-right: var(--border-width) solid black;">
            <h2 style="font-family: 'Archivo Black'; font-size: 3rem; text-transform: uppercase;">Weekly Meme Drop</h2>
            <p style="font-size: 1.5rem; margin: 20px 0;">Every Friday at 4:20 PM. Fresh psychological warfare delivered directly to your inbox. No fluff, just high-octane nonsense.</p>
            <div class="form-container" style="margin: 0; width: 100%;">
                <input type="email" placeholder="YOUR@EMAIL.COM">
                <button class="cta-btn">ENLIST NOW</button>
            </div>
        </div>
        <div class="side-content bg-red">
            <h2 style="font-family: 'Archivo Black'; font-size: 3rem; text-transform: uppercase;">Submit Propaganda</h2>
            <p style="font-size: 1.5rem; margin: 20px 0;">Made something dangerous? Upload your visual grenades here. If it's spicy enough, we'll feature it in the main vault.</p>
            <button class="cta-btn" style="background: var(--black);">UPLOAD .JPG / .PNG</button>
        </div>
    </section>

    <section class="section-box bg-black">
        <h2 style="font-family: 'Archivo Black'; font-size: 4rem; margin-bottom: 20px;">STAY TERMINALLY ONLINE</h2>
        <p style="font-size: 1.2rem; margin-bottom: 40px;">The department never sleeps. The algorithm never forgets. The memes must flow.</p>
        <a href="#" class="cta-btn" style="background: var(--yellow); color: black;">Back to Top ↑</a>
    </section>

    <footer>
        <p>&copy; 2024 MEME PROPAGANDA DEPARTMENT | UNCLASSIFIED ASSETS | DO NOT EAT THE CONTENT</p>
    </footer>

    <script>
        function filterMemes(category) {
            const cards = document.querySelectorAll('.meme-card');
            const buttons = document.querySelectorAll('.filter-btn');

            // Update active button
            buttons.forEach(btn => {
                btn.classList.remove('active');
                if(btn.innerText.toLowerCase().includes(category.toLowerCase())) {
                    btn.classList.add('active');
                }
                if(category === 'all' && btn.innerText === 'EVERYTHING') {
                    btn.classList.add('active');
                }
            });

            // Filter cards
            cards.forEach(card => {
                if (category === 'all' || card.getAttribute('data-category') === category) {
                    card.classList.remove('hidden');
                } else {
                    card.classList.add('hidden');
                }
            });
        }

        // Glitch effect randomizer
        setInterval(() => {
            const glitchText = document.querySelector('.glitch');
            glitchText.style.transform = \`translate(\${Math.random() * 4 - 2}px, \${Math.random() * 4 - 2}px)\`;
            setTimeout(() => {
                glitchText.style.transform = \`translate(0,0)\`;
            }, 50);
        }, 3000);
    </script>
      ` }} />
    </main>
  );
}
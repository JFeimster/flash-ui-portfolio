import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<div class="scanline"></div>

    <!-- Header Section -->
    <header class="max-w-7xl mx-auto mb-8 flex flex-col md:flex-row justify-between items-end border-b border-[#1a1a1a] pb-6">
        <div class="relative">
            <div class="text-[10px] uppercase tracking-[0.4em] opacity-50 mb-1">Internal Protocol // 44-902</div>
            <h1 class="text-3xl md:text-4xl font-bold glitch-header italic">
                MOONSHINE <span class="text-white">CAPITAL</span>
            </h1>
            <div class="text-[10px] mt-2 text-emerald-500/60 font-light flex items-center gap-4">
                <span>EST: 2024</span>
                <span class="flex items-center gap-2"><span class="status-dot"></span> CONNECTION STABLE</span>
                <span>SECURED NODE: LND-88</span>
            </div>
        </div>
        <div class="text-right hidden md:block">
            <div class="text-xs opacity-40">PARTNER PROVISIONING TERMINAL</div>
            <div class="text-lg font-bold">V.4.0.2-BETA</div>
        </div>
    </header>

    <main class="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        <!-- Left: Provisioning Form -->
        <section class="lg:col-span-7 space-y-6">
            <div class="bento-card p-6">
                <div class="flex items-center gap-3 mb-6">
                    <div class="w-2 h-6 bg-emerald-500"></div>
                    <h2 class="text-lg font-bold uppercase tracking-wider">Entity Parameters</h2>
                </div>
                
                <form id="provisionForm" class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="md:col-span-2">
                        <label class="block text-[10px] uppercase mb-2 opacity-60">Full Name <span class="text-emerald-400 font-bold">* Required</span></label>
                        <input type="text" id="fullName" required placeholder="LEGAL REPRESENTATIVE NAME" class="w-full p-3 text-sm focus:ring-0">
                    </div>

                    <div>
                        <label class="block text-[10px] uppercase mb-2 opacity-60">Partner Type</label>
                        <select id="partnerType" class="w-full p-3 text-sm focus:ring-0">
                            <option value="BRK">Broker [BRK]</option>
                            <option value="REF">Referral Source [REF]</option>
                            <option value="AFF">Affiliate [AFF]</option>
                            <option value="VND">Vendor [VND]</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-[10px] uppercase mb-2 opacity-60">Registration Date</label>
                        <input type="date" id="regDate" class="w-full p-3 text-sm focus:ring-0">
                    </div>

                    <div>
                        <label class="block text-[10px] uppercase mb-2 opacity-60">Company Name</label>
                        <input type="text" id="company" placeholder="ENTITY CORP." class="w-full p-3 text-sm focus:ring-0">
                    </div>

                    <div>
                        <label class="block text-[10px] uppercase mb-2 opacity-60">Email Address</label>
                        <input type="email" id="email" placeholder="SECURE@MAIL.COM" class="w-full p-3 text-sm focus:ring-0">
                    </div>

                    <div class="md:col-span-2">
                        <button type="button" onclick="executeProvisioning()" class="btn-execute w-full py-4 mt-2 flex items-center justify-center gap-3">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
                            Execute Provisioning
                        </button>
                    </div>
                </form>
            </div>
        </section>

        <!-- Right: Output & Result -->
        <section class="lg:col-span-5 space-y-6">
            <div id="resultCard" class="bento-card p-6 h-full flex flex-col opacity-30 transition-opacity duration-500">
                <div class="flex items-center gap-3 mb-6">
                    <div class="w-2 h-6 bg-white"></div>
                    <h2 class="text-lg font-bold uppercase tracking-wider text-white">Generated Identifier</h2>
                </div>
                
                <div class="flex-grow flex flex-col justify-center items-center border border-dashed border-emerald-500/20 rounded p-8 bg-emerald-500/5">
                    <div id="idPlaceholder" class="text-3xl font-bold tracking-tighter text-emerald-400 mb-2">--- --- ---</div>
                    <div class="text-[10px] uppercase opacity-40 mb-8">Mission Control Assigned ID</div>

                    <div class="w-full space-y-4">
                        <div class="bg-black border border-emerald-900 p-3 rounded flex justify-between items-center group">
                            <code id="urlDisplay" class="text-[11px] truncate opacity-80">moonshinecapital.com/ref/---</code>
                            <button onclick="copyToClipboard()" class="hover:text-white transition-colors">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3"></path></svg>
                            </button>
                        </div>
                        <div id="successMsg" class="text-[10px] text-center text-white font-bold opacity-0 transition-opacity">
                            COPIED TO ENCRYPTED CLIPBOARD
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Bottom: Audit Log -->
        <section class="lg:col-span-12">
            <div class="bento-card p-6">
                <div class="flex justify-between items-center mb-6">
                    <div class="flex items-center gap-3">
                        <div class="w-2 h-6 bg-emerald-500"></div>
                        <h2 class="text-lg font-bold uppercase tracking-wider">Provisioning Audit Log</h2>
                    </div>
                    <span class="text-[10px] opacity-40">LAST SYNC: JUST NOW</span>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-left text-xs">
                        <thead>
                            <tr class="border-b border-[#1a1a1a] opacity-50">
                                <th class="pb-3 font-normal uppercase tracking-widest">Name</th>
                                <th class="pb-3 font-normal uppercase tracking-widest">Mission ID</th>
                                <th class="pb-3 font-normal uppercase tracking-widest">Entity</th>
                                <th class="pb-3 font-normal uppercase tracking-widest">Provision Date</th>
                                <th class="pb-3 font-normal uppercase tracking-widest">Status</th>
                            </tr>
                        </thead>
                        <tbody id="auditLog" class="divide-y divide-[#1a1a1a]">
                            <tr>
                                <td class="py-4 text-emerald-100">Alexander Thorne</td>
                                <td class="py-4 text-emerald-500">MC-BRK-AT24</td>
                                <td class="py-4 opacity-60">Thorne Equities</td>
                                <td class="py-4 opacity-60">2024-05-12</td>
                                <td class="py-4"><span class="text-[10px] px-2 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-500">ACTIVE</span></td>
                            </tr>
                            <tr>
                                <td class="py-4 text-emerald-100">Sarah Jenkins</td>
                                <td class="py-4 text-emerald-500">MC-REF-SJ23</td>
                                <td class="py-4 opacity-60">Direct Flow LLC</td>
                                <td class="py-4 opacity-60">2023-11-20</td>
                                <td class="py-4"><span class="text-[10px] px-2 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-500">ACTIVE</span></td>
                            </tr>
                            <tr>
                                <td class="py-4 text-emerald-100">Marcus Vane</td>
                                <td class="py-4 text-emerald-500">MC-AFF-MV24</td>
                                <td class="py-4 opacity-60">Vane Global</td>
                                <td class="py-4 opacity-60">2024-01-05</td>
                                <td class="py-4"><span class="text-[10px] px-2 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-500">ACTIVE</span></td>
                            </tr>
                            <tr>
                                <td class="py-4 text-emerald-100">Elena Rossi</td>
                                <td class="py-4 text-emerald-500">MC-VND-ER24</td>
                                <td class="py-4 opacity-60">Rossi Systems</td>
                                <td class="py-4 opacity-60">2024-02-18</td>
                                <td class="py-4"><span class="text-[10px] px-2 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-500">ACTIVE</span></td>
                            </tr>
                            <tr>
                                <td class="py-4 text-emerald-100">Julian Chen</td>
                                <td class="py-4 text-emerald-500">MC-BRK-JC23</td>
                                <td class="py-4 opacity-60">Summit Capital</td>
                                <td class="py-4 opacity-60">2023-09-30</td>
                                <td class="py-4"><span class="text-[10px] px-2 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-500">ACTIVE</span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
    </main>

    <script>
        function executeProvisioning() {
            const fullName = document.getElementById('fullName').value;
            const partnerType = document.getElementById('partnerType').value;
            const regDate = document.getElementById('regDate').value;
            const company = document.getElementById('company').value || "N/A";
            
            if (!fullName) {
                alert("PROTOCOL ERROR: FULL NAME REQUIRED");
                return;
            }

            // Logic-Based ID Engine
            const nameParts = fullName.trim().split(' ');
            const initials = nameParts.length > 1 
                ? (nameParts[0][0] + nameParts[nameParts.length - 1][0]).toUpperCase()
                : (nameParts[0][0] + nameParts[0][1] || 'X').toUpperCase();
            
            const year = regDate 
                ? regDate.substring(2, 4) 
                : new Date().getFullYear().toString().slice(-2);

            const generatedID = \`MC-\${partnerType}-\${initials}\${year}\`;
            
            // Update UI
            document.getElementById('resultCard').style.opacity = "1";
            document.getElementById('idPlaceholder').innerText = generatedID;
            document.getElementById('urlDisplay').innerText = \`moonshinecapital.com/ref/\${generatedID}\`;
            
            // Add to Audit Log
            const auditTable = document.getElementById('auditLog');
            const newRow = auditTable.insertRow(0);
            newRow.className = "divide-y divide-[#1a1a1a] animate-pulse";
            newRow.innerHTML = \`
                <td class="py-4 text-emerald-100 font-bold">\${fullName}</td>
                <td class="py-4 text-emerald-500 font-bold">\${generatedID}</td>
                <td class="py-4 opacity-60">\${company}</td>
                <td class="py-4 opacity-60">\${regDate || new Date().toISOString().split('T')[0]}</td>
                <td class="py-4"><span class="text-[10px] px-2 py-1 bg-emerald-500/20 border border-emerald-500 text-emerald-500">PROVISIONED</span></td>
            \`;
            
            setTimeout(() => { newRow.classList.remove('animate-pulse'); }, 2000);
        }

        function copyToClipboard() {
            const url = document.getElementById('urlDisplay').innerText;
            navigator.clipboard.writeText(url);
            const msg = document.getElementById('successMsg');
            msg.style.opacity = "1";
            setTimeout(() => { msg.style.opacity = "0"; }, 2000);
        }
    </script>
      ` }} />
    </main>
  );
}
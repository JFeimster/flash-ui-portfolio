import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<div class="agent-container">
        <!-- Sidebar Form -->
        <aside class="input-sidebar">
            <div class="header-section">
                <span class="badge">Micro-Agent v1.0.4</span>
                <h1>Person Finder</h1>
                <p class="subtitle">Extract decision makers beyond generic info@ aliases using cross-platform intelligence.</p>
            </div>

            <div class="form-group">
                <label>Business Name</label>
                <input type="text" placeholder="e.g. Acme Corp" value="Aura Design Studio">
            </div>
            <div class="form-group">
                <label>Website</label>
                <input type="text" placeholder="https://..." value="auradesign.io">
            </div>
            <div class="form-group">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                    <div>
                        <label>City/State</label>
                        <input type="text" placeholder="Austin, TX" value="Brooklyn, NY">
                    </div>
                    <div>
                        <label>Industry</label>
                        <input type="text" placeholder="SaaS" value="Interior Design">
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label>Phone</label>
                <input type="text" placeholder="+1..." value="718-555-0192">
            </div>

            <button class="search-btn">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                INITIALIZE SEARCH
            </button>
        </aside>

        <!-- Main Sequence View -->
        <main class="sequence-view">
            <div class="sequence-header">
                <div class="status-indicator">
                    <div class="dot active"></div>
                    <span>SEARCH AGENT ACTIVE</span>
                </div>
                <div class="status-indicator">
                    <span style="color: var(--text-dim)">MODE: DEEP_SCAN</span>
                </div>
            </div>

            <div class="sequence-list">
                <!-- Step 1-3: Internal -->
                <div class="sequence-item completed">
                    <div class="item-number">01</div>
                    <div class="item-content">
                        <div class="item-title">Website Intelligence</div>
                        <div class="item-description">Analyzing About, Team, and Contact pages for personnel metadata.</div>
                        <span class="item-status-text" style="color: var(--accent-primary)">✓ SCRAPE COMPLETE</span>
                    </div>
                </div>

                <!-- Step 4-5: Search & Social -->
                <div class="sequence-item active">
                    <div class="item-number">02</div>
                    <div class="item-content">
                        <div class="item-title">Multi-Vector Search</div>
                        <div class="item-description">Executing queries for Owner, Founder, and President across Google & LinkedIn.</div>
                        <span class="item-status-text" style="color: var(--accent-primary)">● EXECUTING QUERIES...</span>
                    </div>
                </div>

                <!-- Step 6-9: Directories -->
                <div class="sequence-item">
                    <div class="item-number">03</div>
                    <div class="item-content">
                        <div class="item-title">Registry Verification</div>
                        <div class="item-description">Cross-referencing Secretary of State, BBB, and Chamber of Commerce records.</div>
                        <span class="item-status-text" style="color: var(--text-dim)">○ QUEUED</span>
                    </div>
                </div>

                <div class="sequence-item">
                    <div class="item-number">04</div>
                    <div class="item-content">
                        <div class="item-title">Social Graph Mapping</div>
                        <div class="item-description">Fetching signals from Facebook Business and Yelp Local Directories.</div>
                        <span class="item-status-text" style="color: var(--text-dim)">○ QUEUED</span>
                    </div>
                </div>
            </div>

            <div class="terminal-output">
                <div class="log-line">
                    <span class="timestamp">[14:02:01]</span>
                    <span>Starting crawler for auradesign.io...</span>
                </div>
                <div class="log-line">
                    <span class="timestamp">[14:02:03]</span>
                    <span>Found 12 internal links. Filtering for 'About' and 'Our Team'...</span>
                </div>
                <div class="log-line">
                    <span class="timestamp">[14:02:05]</span>
                    <span style="color: #fff">Match found: Sarah Jenkins (Lead Designer)</span>
                </div>
                <div class="log-line">
                    <span class="timestamp">[14:02:06]</span>
                    <span>Launching Google Dorking for "Aura Design Studio" + owner...</span>
                </div>
                <div class="log-line">
                    <span class="timestamp">[14:02:08]</span>
                    <span>Bypassing bot detection on LinkedIn Public API...</span>
                </div>
                <div class="log-line">
                    <span class="timestamp">[14:02:09]</span>
                    <span style="color: var(--accent-primary)">Accessing NY Secretary of State records...</span>
                </div>
            </div>
        </main>
    </div>
      ` }} />
    </main>
  );
}
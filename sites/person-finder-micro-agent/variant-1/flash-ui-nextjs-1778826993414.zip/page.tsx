import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<div class="agent-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="header-brand">
                <div class="logo-box">
                    <svg viewBox="0 0 24 24" stroke-width="2.5" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
                    </svg>
                </div>
                <span class="brand-title">Person-Finder <span style="font-weight:300; opacity:0.7">v2.4</span></span>
            </div>

            <div class="input-group">
                <label>Business Name</label>
                <input type="text" placeholder="Acme Corp Industries">
            </div>
            
            <div class="input-group">
                <label>Website</label>
                <input type="text" placeholder="https://acme.com">
            </div>

            <div class="input-group">
                <label>City/State</label>
                <input type="text" placeholder="Austin, TX">
            </div>

            <div class="input-group">
                <label>Phone</label>
                <input type="text" placeholder="+1 (555) 000-0000">
            </div>

            <div class="input-group">
                <label>Industry</label>
                <input type="text" placeholder="Manufacturing / SaaS">
            </div>

            <button class="btn-start">
                <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
                Initialize Search
            </button>
        </aside>

        <!-- Main Workspace -->
        <main class="main-panel">
            <div class="status-bar">
                <div class="status-indicator">
                    <div class="pulse"></div>
                    <span>AGENT STATUS: <span style="color:var(--accent)">ACTIVE SCANNING</span></span>
                </div>
                <div style="font-size: 0.75rem; color: var(--text-dim); font-family: 'JetBrains Mono'">
                    PID: 8829-FINDER
                </div>
            </div>

            <div class="workspace">
                <!-- Search Sequence -->
                <div class="sequence-list">
                    <div class="sequence-item completed">
                        <div class="step-number">01</div>
                        <div class="step-content">
                            <div class="step-title">Domain Analysis</div>
                            <div class="step-desc">Parsing About page & meta-headers for leadership mentions.</div>
                            <span class="step-badge">Success: No direct names found</span>
                        </div>
                    </div>

                    <div class="sequence-item active">
                        <div class="step-number">02</div>
                        <div class="step-content">
                            <div class="step-title">Team Hierarchy Scraping</div>
                            <div class="step-desc">Identifying "Our Team" or "Leadership" URL patterns.</div>
                            <span class="step-badge" style="color:var(--primary); background:rgba(59,130,246,0.1)">Processing...</span>
                        </div>
                    </div>

                    <div class="sequence-item">
                        <div class="step-number03">
                            <div class="step-number">03</div>
                        </div>
                        <div class="step-content">
                            <div class="step-title">LinkedIn Company Insight</div>
                            <div class="step-desc">Cross-referencing employees with "Decision Maker" filters.</div>
                        </div>
                    </div>

                    <div class="sequence-item">
                        <div class="step-number">04</div>
                        <div class="step-content">
                            <div class="step-title">Google Recursive Search</div>
                            <div class="step-desc">Dorking: [Business] + "owner" OR "president" OR "manager".</div>
                        </div>
                    </div>

                    <div class="sequence-item">
                        <div class="step-number">05</div>
                        <div class="step-content">
                            <div class="step-title">SOS / Business Registry</div>
                            <div class="step-desc">Querying Secretary of State for registered agent & officers.</div>
                        </div>
                    </div>

                    <div class="sequence-item">
                        <div class="step-number">06</div>
                        <div class="step-content">
                            <div class="step-title">Local Intelligence</div>
                            <div class="step-desc">Chamber directories, BBB, Yelp, and Facebook Page transparency.</div>
                        </div>
                    </div>
                </div>

                <!-- Live Results -->
                <div class="results-panel">
                    <div class="results-header">Found Intelligence</div>
                    
                    <div class="contact-card">
                        <div class="contact-name">Sarah Jenkins</div>
                        <div class="contact-title">Operations Director</div>
                        <div class="contact-meta">
                            <div class="meta-item">
                                <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
                                Verified Profile
                            </div>
                            <div class="meta-item">
                                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72 12.81 12.81 0 00.7 2.81 2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/></svg>
                                Extracted (Mobile)
                            </div>
                        </div>
                    </div>

                    <div class="contact-card" style="opacity: 0.5; border-style: dashed;">
                        <div class="contact-name">Pending...</div>
                        <div class="contact-title">Scanning SOS Data</div>
                    </div>

                    <div class="log-terminal">
                        <div class="log-line">> GET /api/v1/search?q=acme+corp</div>
                        <div class="log-line">> Found potential match: "Sarah Jenkins"</div>
                        <div class="log-line">> Scouring local directories (Austin)...</div>
                        <div class="log-line">> Registry check: OK <span class="cursor"></span></div>
                    </div>
                </div>
            </div>
        </main>
    </div>
      ` }} />
    </main>
  );
}
import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<section class="hero">
        <div class="hero-container">
            <span class="hook">Logic Deck Funding Tools</span>
            <h1>Business Funding Calculators That Actually Help You Make a Decision.</h1>
            <p>Use practical tools to estimate payments, compare funding options, calculate commissions, check readiness, and understand your next move before applying.</p>
            <a href="#directory" class="cta-primary">Use the Calculators</a>
        </div>
    </section>

    <section class="filter-section" id="directory">
        <div class="filter-container">
            <input type="text" id="toolSearch" class="search-bar" placeholder="Search for a tool (e.g., 'MCA', 'Credit', 'Broker')...">
            <div class="filter-chips" id="filterContainer">
                <button class="chip active" data-filter="all">All Tools</button>
                <button class="chip" data-filter="borrower">Borrower Tools</button>
                <button class="chip" data-filter="broker">Broker Tools</button>
                <button class="chip" data-filter="credit">Credit Readiness</button>
                <button class="chip" data-filter="acquisition">Acquisition & Asset</button>
            </div>
        </div>
    </section>

    <div class="library-section">
        <div class="grid" id="toolGrid">
            <!-- Tool 1 -->
            <div class="tool-card" data-category="borrower">
                <div class="tool-tag">Borrower</div>
                <div class="tool-icon">
                    <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>
                </div>
                <h3>Business Loan Payments</h3>
                <p>Calculate monthly amortizing payments for traditional term loans and SBA options.</p>
                <a href="#" class="card-link">Launch Calculator &rarr;</a>
            </div>

            <!-- Tool 2 -->
            <div class="tool-card" data-category="borrower">
                <div class="tool-tag">Borrower</div>
                <div class="tool-icon">
                    <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 12V7a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h7"></path><path d="m16 19 2 2 4-4"></path></svg>
                </div>
                <h3>Revenue-Based Financing</h3>
                <p>Estimate the cost of capital based on your monthly top-line revenue percentages.</p>
                <a href="#" class="card-link">Launch Calculator &rarr;</a>
            </div>

            <!-- Tool 3 -->
            <div class="tool-card" data-category="borrower">
                <div class="tool-tag">Borrower</div>
                <div class="tool-icon">
                    <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>
                </div>
                <h3>MCA Factor Rate</h3>
                <p>Convert factor rates into APR to understand the true cost of Merchant Cash Advances.</p>
                <a href="#" class="card-link">Launch Calculator &rarr;</a>
            </div>

            <!-- Tool 4 -->
            <div class="tool-card" data-category="broker">
                <div class="tool-tag">Broker</div>
                <div class="tool-icon">
                    <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"></circle><path d="M16 8l-8 8M8 8l8 8"></path></svg>
                </div>
                <h3>Loan Broker Commission</h3>
                <p>Calculate points and payouts across multiple funding tiers for ISOs and brokers.</p>
                <a href="#" class="card-link">Launch Calculator &rarr;</a>
            </div>

            <!-- Tool 5 -->
            <div class="tool-card" data-category="credit">
                <div class="tool-tag">Credit</div>
                <div class="tool-icon">
                    <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M22 12h-4l-3 9L9 3l-3 9H2"></path></svg>
                </div>
                <h3>Funding Readiness Score</h3>
                <p>Determine if your business is "Bankable" based on 12 key financial indicators.</p>
                <a href="#" class="card-link">Check Readiness &rarr;</a>
            </div>

            <!-- Tool 6 -->
            <div class="tool-card" data-category="credit">
                <div class="tool-tag">Credit</div>
                <div class="tool-icon">
                    <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"></rect><path d="M3 9h18M9 21V9"></path></svg>
                </div>
                <h3>Business Credit Readiness</h3>
                <p>Assess your Paydex, Experian Business, and Equifax profiles for tier-based credit.</p>
                <a href="#" class="card-link">Assess Profile &rarr;</a>
            </div>

            <!-- Tool 7 -->
            <div class="tool-card" data-category="acquisition">
                <div class="tool-tag">Acquisition</div>
                <div class="tool-icon">
                    <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 21h18M3 7v14M13 7v14M18 7v14M21 7h-3M3 7h18M11 3l-3 4M13 3l3 4"></path></svg>
                </div>
                <h3>DSCR Calculator</h3>
                <p>Calculate Debt Service Coverage Ratio for commercial real estate and investment loans.</p>
                <a href="#" class="card-link">Calculate DSCR &rarr;</a>
            </div>

            <!-- Tool 8 -->
            <div class="tool-card" data-category="acquisition">
                <div class="tool-tag">Asset</div>
                <div class="tool-icon">
                    <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M5 18H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h3.19M15 6h2a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-3.19"></path><circle cx="12" cy="12" r="3"></circle></svg>
                </div>
                <h3>Equipment Financing</h3>
                <p>Compare leasing vs. buying and calculate depreciation benefits for tax purposes.</p>
                <a href="#" class="card-link">Launch Calculator &rarr;</a>
            </div>

            <!-- Tool 9 -->
            <div class="tool-card" data-category="borrower">
                <div class="tool-tag">Borrower</div>
                <div class="tool-icon">
                    <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><path d="M14 2v6h6M16 13H8M16 17H8M10 9H8"></path></svg>
                </div>
                <h3>Invoice Factoring</h3>
                <p>Estimate advance rates and discount fees for selling your outstanding AR.</p>
                <a href="#" class="card-link">Calculate AR Payout &rarr;</a>
            </div>

            <!-- Tool 10 -->
            <div class="tool-card" data-category="acquisition">
                <div class="tool-tag">Logistics</div>
                <div class="tool-icon">
                    <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M10 17h4V5H2v12h3m0 0a2 2 0 1 0 4 0m-4 0a2 2 0 1 1 4 0m9 0h3v-3.41a1.33 1.33 0 0 0-.39-.94l-3.17-3.17a1.33 1.33 0 0 0-.94-.39H14v9h1m0 0a2 2 0 1 0 4 0m-4 0a2 2 0 1 1 4 0"></path></svg>
                </div>
                <h3>Truck Repair Recovery</h3>
                <p>Analyze ROI for repair financing vs. downtime costs for owner-operators.</p>
                <a href="#" class="card-link">Analyze ROI &rarr;</a>
            </div>

            <!-- Tool 11 -->
            <div class="tool-card" data-category="acquisition">
                <div class="tool-tag">Acquisition</div>
                <div class="tool-icon">
                    <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                </div>
                <h3>Acquisition Financing</h3>
                <p>Model buyout scenarios including seller notes, equity, and senior debt.</p>
                <a href="#" class="card-link">Model Scenarios &rarr;</a>
            </div>

            <!-- Tool 12 -->
            <div class="tool-card" data-category="borrower">
                <div class="tool-tag">Borrower</div>
                <div class="tool-icon">
                    <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 20V10M18 20V4M6 20v-4"></path></svg>
                </div>
                <h3>Working Capital Gaps</h3>
                <p>Identify the shortfall between your accounts payable and accounts receivable cycles.</p>
                <a href="#" class="card-link">Find Your Gap &rarr;</a>
            </div>
        </div>
    </div>

    <section class="strategist-cta">
        <div class="cta-box">
            <div class="cta-content">
                <h2>Confused by the numbers?</h2>
                <p>Our funding strategists help you navigate the complexity of business capital. Get a clear roadmap for your business growth.</p>
            </div>
            <a href="#" class="cta-secondary">Talk to a Funding Strategist</a>
        </div>
    </section>

    <section class="faq-section">
        <h2>Frequently Asked Questions</h2>
        <div class="faq-item">
            <h4>How accurate are these calculators?</h4>
            <p>Our tools use current market benchmark rates and standard banking formulas. However, actual offers depend on your specific credit profile and lender criteria.</p>
        </div>
        <div class="faq-item">
            <h4>Do I need to provide personal info to use them?</h4>
            <p>No. These tools are 100% free and anonymous. We believe in providing value before asking for your data.</p>
        </div>
        <div class="faq-item">
            <h4>What is a Factor Rate vs. APR?</h4>
            <p>Factor rates are commonly used in MCA and are expressed as a multiplier (e.g., 1.2). APR includes all fees and interest calculated annually. Our calculators help you bridge that gap.</p>
        </div>
    </section>

    <section class="footer-cta">
        <div class="hero-container">
            <h2>Ready to fund your next move?</h2>
            <p style="margin: 20px 0 40px; color: var(--text-main);">Stop guessing. Start calculating. Get funded.</p>
            <a href="#" class="cta-primary">Use the Calculators</a>
        </div>
    </section>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const searchInput = document.getElementById('toolSearch');
            const chips = document.querySelectorAll('.chip');
            const cards = document.querySelectorAll('.tool-card');

            function filterTools() {
                const searchTerm = searchInput.value.toLowerCase();
                const activeCategory = document.querySelector('.chip.active').dataset.filter;

                cards.forEach(card => {
                    const title = card.querySelector('h3').textContent.toLowerCase();
                    const category = card.dataset.category;
                    const matchesSearch = title.includes(searchTerm);
                    const matchesCategory = activeCategory === 'all' || category === activeCategory;

                    if (matchesSearch && matchesCategory) {
                        card.style.display = 'flex';
                    } else {
                        card.style.display = 'none';
                    }
                });
            }

            searchInput.addEventListener('input', filterTools);

            chips.forEach(chip => {
                chip.addEventListener('click', () => {
                    chips.forEach(c => c.classList.remove('active'));
                    chip.classList.add('active');
                    filterTools();
                });
            });
        });
    </script>
      ` }} />
    </main>
  );
}
import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<div class="container">
        <header>
            <div class="logo">⚡ FLASH-<span>UI</span></div>
            <div class="status">System: Operational // v.1.04</div>
        </header>

        <section class="hero">
            <h1>Generate the Prompt Before You Generate the Site.</h1>
            <p>The meta-tool for architects. Feed the machine high-fidelity blueprints for landing pages, dashboards, and beyond.</p>
        </section>

        <main class="bento-grid">
            <!-- Site Type -->
            <div class="card type-selector">
                <div class="card-label">01. Site Architecture</div>
                <div class="grid-options" id="typeGrid">
                    <div class="option-tile active" data-value="Landing Page">Landing Page</div>
                    <div class="option-tile" data-value="SaaS Dashboard">Dashboard</div>
                    <div class="option-tile" data-value="Directory/Listings">Directory</div>
                    <div class="option-tile" data-value="Internal Tool">Utility/Tool</div>
                    <div class="option-tile" data-value="Sales Funnel">Sales Funnel</div>
                    <div class="option-tile" data-value="Portfolio Site">Portfolio</div>
                </div>
            </div>

            <!-- Style -->
            <div class="card style-selector">
                <div class="card-label">02. Visual DNA</div>
                <select id="styleInput">
                    <option value="Cyberpunk Command Console">Onyx Command</option>
                    <option value="Minimalist Swiss High-Contrast">Swiss Minimal</option>
                    <option value="Bento-grid Glassmorphism">Modern Glass</option>
                    <option value="Brutalist Web3 Design">Brutalist</option>
                    <option value="Clean Apple-esque Corporate">Enterprise Pro</option>
                </select>
            </div>

            <!-- Details -->
            <div class="card details-form">
                <div class="card-label">03. Contextual Data</div>
                <div style="display: grid; gap: 15px;">
                    <div>
                        <label style="font-size: 0.75rem; color: var(--text-dim);">Target Audience</label>
                        <input type="text" id="audience" placeholder="e.g. Solo-founders, Crypto traders...">
                    </div>
                    <div>
                        <label style="font-size: 0.75rem; color: var(--text-dim);">Core Pain Point</label>
                        <input type="text" id="pain" placeholder="e.g. Information overload, slow setup...">
                    </div>
                    <div>
                        <label style="font-size: 0.75rem; color: var(--text-dim);">Primary CTA</label>
                        <input type="text" id="cta" placeholder="e.g. Join the Waitlist, Start Free Trial...">
                    </div>
                </div>
            </div>

            <!-- Sections -->
            <div class="card sections-checklist">
                <div class="card-label">04. Component Manifest</div>
                <div class="checklist" id="sectionsGrid">
                    <label class="check-item"><input type="checkbox" checked value="Hero Header"> Hero Header</label>
                    <label class="check-item"><input type="checkbox" checked value="Bento Feature Grid"> Bento Grid</label>
                    <label class="check-item"><input type="checkbox" value="Pricing Table"> Pricing Table</label>
                    <label class="check-item"><input type="checkbox" value="Live Data Feed"> Live Feed</label>
                    <label class="check-item"><input type="checkbox" value="Testimonial Slider"> Social Proof</label>
                    <label class="check-item"><input type="checkbox" value="Integration Logos"> Integrations</label>
                    <label class="check-item"><input type="checkbox" value="FAQ Accordion"> FAQ</label>
                    <label class="check-item"><input type="checkbox" checked value="Newsletter Footer"> Footer</label>
                </div>
            </div>

            <button class="btn-generate" onclick="generatePrompt()">Generate My FLASH-UI Prompt</button>

            <!-- Output -->
            <div class="card output-card" id="outputSection" style="display: none;">
                <div class="output-header">
                    <div class="card-label">Generated FLASH-UI System Prompt</div>
                    <span style="font-family: var(--font-mono); font-size: 0.7rem; color: var(--text-dim);">Ready for Deployment</span>
                </div>
                <textarea id="promptOutput" readonly></textarea>
                <div class="action-group">
                    <button class="btn-outline" onclick="copyToClipboard()">Copy to Clipboard</button>
                    <button class="btn-outline" onclick="savePrompt()">Save to Vault</button>
                </div>
            </div>
        </main>

        <section class="history">
            <div class="card-label">Prompt Vault</div>
            <div class="history-grid" id="historyGrid">
                <!-- LocalStorage items here -->
            </div>
        </section>
    </div>

    <script>
        // State
        let selectedType = "Landing Page";
        
        // Handle Site Type Selection
        const typeTiles = document.querySelectorAll('#typeGrid .option-tile');
        typeTiles.forEach(tile => {
            tile.addEventListener('click', () => {
                typeTiles.forEach(t => t.classList.remove('active'));
                tile.classList.add('active');
                selectedType = tile.dataset.value;
            });
        });

        function generatePrompt() {
            const style = document.getElementById('styleInput').value;
            const audience = document.getElementById('audience').value || "General Users";
            const pain = document.getElementById('pain').value || "Lack of efficiency";
            const cta = document.getElementById('cta').value || "Get Started";
            
            const checkboxes = document.querySelectorAll('#sectionsGrid input:checked');
            const sections = Array.from(checkboxes).map(cb => cb.value).join(', ');

            const promptTemplate = \`Create a high-fidelity FLASH-UI \${selectedType}. 

Visual Aesthetic: \${style}. 
Target Audience: \${audience}.
Core Problem Solved: \${pain}.
Conversion Goal: \${cta}.

Key Component Manifest:
\${sections}.

Design Guidelines: 
- Use a strictly dark-themed 'Onyx Command' layout.
- Implement bento-box styling for the main content areas.
- Ensure neon accents and glassmorphic overlays.
- Typography should be modern, clean, and use mono-fonts for technical data points.
- The UI should feel like a futuristic laboratory or command console.

Output Format: RAW HTML/CSS/JS in a single file.\`;

            document.getElementById('promptOutput').value = promptTemplate;
            document.getElementById('outputSection').style.display = 'block';
            window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
        }

        function copyToClipboard() {
            const copyText = document.getElementById("promptOutput");
            copyText.select();
            copyText.setSelectionRange(0, 99999);
            navigator.clipboard.writeText(copyText.value);
            
            const btn = document.querySelector('.btn-outline');
            const originalText = btn.innerText;
            btn.innerText = "COPIED!";
            setTimeout(() => btn.innerText = originalText, 2000);
        }

        function savePrompt() {
            const prompt = document.getElementById('promptOutput').value;
            if(!prompt) return;

            const saved = JSON.parse(localStorage.getItem('flash_prompts') || '[]');
            const newItem = {
                id: Date.now(),
                title: \`\${selectedType} - \${new Date().toLocaleDateString()}\`,
                content: prompt
            };
            
            saved.unshift(newItem);
            localStorage.setItem('flash_prompts', JSON.stringify(saved.slice(0, 6))); // Keep last 6
            renderHistory();
        }

        function renderHistory() {
            const historyGrid = document.getElementById('historyGrid');
            const saved = JSON.parse(localStorage.getItem('flash_prompts') || '[]');
            
            if(saved.length === 0) {
                historyGrid.innerHTML = \`<div style="color: var(--text-dim); font-size: 0.9rem;">No prompts saved in local vault.</div>\`;
                return;
            }

            historyGrid.innerHTML = saved.map(item => \`
                <div class="history-item">
                    <header>\${item.title}</header>
                    <div style="height: 60px; overflow: hidden; opacity: 0.6; font-family: var(--font-mono); margin-bottom: 10px;">
                        \${item.content.substring(0, 100)}...
                    </div>
                    <button class="btn-outline" style="width: 100%; font-size: 0.7rem;" onclick="loadPrompt(\${item.id})">Reload</button>
                </div>
            \`).join('');
        }

        function loadPrompt(id) {
            const saved = JSON.parse(localStorage.getItem('flash_prompts') || '[]');
            const item = saved.find(i => i.id === id);
            if(item) {
                document.getElementById('promptOutput').value = item.content;
                document.getElementById('outputSection').style.display = 'block';
                window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
            }
        }

        // Init
        renderHistory();
    </script>
      ` }} />
    </main>
  );
}
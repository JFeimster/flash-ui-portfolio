### Generated UI Component

To use this in Notion:
1. Create a "/code" block
2. Set language to "HTML"
3. Paste the following:

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moonshine Capital | Embed Code Generator</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-deep: #050505;
            --bg-surface: #0f0f12;
            --bg-elevated: #16161a;
            --border: #26262b;
            --border-bright: #3f3f46;
            --neon-blue: #00f0ff;
            --neon-green: #39ff14;
            --text-primary: #f4f4f5;
            --text-secondary: #a1a1aa;
            --text-muted: #52525b;
            --accent-gradient: linear-gradient(135deg, #00f0ff 0%, #39ff14 100%);
            --transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            background-color: var(--bg-deep);
            color: var(--text-primary);
            font-family: 'Inter', sans-serif;
            line-height: 1.5;
            -webkit-font-smoothing: antialiased;
            overflow-x: hidden;
        }

        /* Scrollbar */
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: var(--bg-deep); }
        ::-webkit-scrollbar-thumb { background: var(--border-bright); border-radius: 10px; }

        /* Hero Section */
        .hero {
            padding: 4rem 2rem 3rem;
            text-align: center;
            border-bottom: 1px solid var(--border);
            background: radial-gradient(circle at top center, rgba(0, 240, 255, 0.05), transparent 70%);
        }

        .hero h1 {
            font-size: 2.5rem;
            font-weight: 700;
            letter-spacing: -0.02em;
            margin-bottom: 1rem;
            background: var(--accent-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .hero p {
            color: var(--text-secondary);
            max-width: 600px;
            margin: 0 auto;
            font-size: 1.1rem;
        }

        /* Layout */
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem;
            display: grid;
            grid-template-columns: 380px 1fr;
            gap: 2rem;
        }

        @media (max-width: 1024px) {
            .container { grid-template-columns: 1fr; }
        }

        /* Configuration Panel */
        .config-card {
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 1.5rem;
            height: fit-content;
            position: sticky;
            top: 2rem;
        }

        .section-title {
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.1em;
            color: var(--neon-blue);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .input-group {
            margin-bottom: 1.25rem;
        }

        label {
            display: block;
            font-size: 0.875rem;
            color: var(--text-secondary);
            margin-bottom: 0.5rem;
        }

        input, select {
            width: 100%;
            background: var(--bg-deep);
            border: 1px solid var(--border);
            color: var(--text-primary);
            padding: 0.75rem;
            border-radius: 6px;
            font-size: 0.9rem;
            outline: none;
            transition: var(--transition);
        }

        input:focus, select:focus {
            border-color: var(--neon-blue);
            box-shadow: 0 0 0 1px var(--neon-blue);
        }

        .row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }

        /* Preview Area */
        .main-content {
            display: flex;
            flex-direction: column;
            gap: 2rem;
        }

        .preview-container {
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            overflow: hidden;
        }

        .preview-header {
            padding: 1rem 1.5rem;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: rgba(255, 255, 255, 0.02);
        }

        .preview-window {
            padding: 3rem;
            min-height: 400px;
            display: flex;
            align-items: center;
            justify-content: center;
            background-image: 
                linear-gradient(var(--border) 1px, transparent 1px),
                linear-gradient(90deg, var(--border) 1px, transparent 1px);
            background-size: 20px 20px;
            position: relative;
        }

        /* Mockup Widget Styling */
        .widget-mockup {
            background: #fff;
            color: #000;
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.4);
            width: 100%;
            max-width: 400px;
            text-align: center;
            border-top: 4px solid var(--neon-blue);
        }

        .widget-mockup h3 { margin-bottom: 0.5rem; font-size: 1.25rem; }
        .widget-mockup p { font-size: 0.875rem; color: #666; margin-bottom: 1.5rem; }
        .widget-mockup .btn {
            background: #000;
            color: #fff;
            padding: 0.75rem 1.5rem;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            display: inline-block;
        }

        /* Code Block */
        .output-card {
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 1.5rem;
        }

        .code-container {
            position: relative;
            margin-top: 1rem;
        }

        .code-header {
            display: flex;
            gap: 1rem;
            margin-bottom: 1rem;
            border-bottom: 1px solid var(--border);
            padding-bottom: 0.5rem;
        }

        .tab {
            font-size: 0.75rem;
            color: var(--text-muted);
            cursor: pointer;
            padding-bottom: 0.5rem;
            position: relative;
        }

        .tab.active {
            color: var(--neon-blue);
        }

        .tab.active::after {
            content: '';
            position: absolute;
            bottom: -1px;
            left: 0;
            width: 100%;
            height: 2px;
            background: var(--neon-blue);
        }

        pre {
            background: var(--bg-deep);
            padding: 1.25rem;
            border-radius: 8px;
            font-family: 'JetBrains Mono', monospace;
            font-size: 0.85rem;
            color: var(--neon-green);
            overflow-x: auto;
            border: 1px solid var(--border);
            white-space: pre-wrap;
            word-break: break-all;
        }

        .copy-btn {
            position: absolute;
            top: 3.5rem;
            right: 0.75rem;
            background: var(--bg-elevated);
            border: 1px solid var(--border-bright);
            color: var(--text-primary);
            padding: 0.4rem 0.8rem;
            border-radius: 4px;
            font-size: 0.7rem;
            cursor: pointer;
            transition: var(--transition);
        }

        .copy-btn:hover {
            background: var(--border-bright);
        }

        /* Platforms Grid */
        .platforms {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 1rem;
            margin-top: 1rem;
        }

        .platform-card {
            background: var(--bg-surface);
            border: 1px solid var(--border);
            padding: 1rem;
            border-radius: 8px;
            text-align: center;
        }

        .platform-card img {
            height: 24px;
            filter: grayscale(1) invert(1);
            opacity: 0.5;
            margin-bottom: 0.5rem;
        }

        .platform-card h4 {
            font-size: 0.8rem;
            color: var(--text-secondary);
        }

        /* History */
        .history-list {
            list-style: none;
            margin-top: 1rem;
        }

        .history-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.75rem;
            border-bottom: 1px solid var(--border);
            font-size: 0.8rem;
        }

        .history-item:last-child { border: none; }

        /* FAQ */
        .faq-section {
            margin-top: 4rem;
            padding-top: 4rem;
            border-top: 1px solid var(--border);
        }

        .faq-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
            margin-top: 2rem;
        }

        .faq-item h4 {
            color: var(--neon-blue);
            margin-bottom: 0.5rem;
        }

        .faq-item p {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .animate { animation: fadeIn 0.4s ease forwards; }

        .badge {
            background: rgba(0, 240, 255, 0.1);
            color: var(--neon-blue);
            padding: 2px 8px;
            border-radius: 99px;
            font-size: 0.7rem;
            font-weight: 600;
        }
    </style>
</head>
<body>

    <header class="hero">
        <div class="badge">PARTNER PORTAL v2.0</div>
        <h1>Generate Partner Widget Embed Code</h1>
        <p>Dynamic, customizable funding tools for your site. Simply configure, preview, and deploy.</p>
    </header>

    <div class="container">
        <!-- Sidebar Configuration -->
        <aside>
            <div class="config-card">
                <div class="section-title">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/></svg>
                    Configuration
                </div>

                <div class="input-group">
                    <label>Widget Type</label>
                    <select id="widgetType">
                        <option value="score">Funding Readiness Score</option>
                        <option value="matcher">Route Matcher</option>
                        <option value="cta">Application CTA</option>
                        <option value="docs">Document Checklist</option>
                        <option value="faq">FAQ Embed</option>
                        <option value="calc">Commission Estimator</option>
                        <option value="profile">Partner Profile Card</option>
                    </select>
                </div>

                <div class="input-group">
                    <label>Partner Name</label>
                    <input type="text" id="partnerName" placeholder="e.g. Growth Labs Agency" value="My Affiliate Name">
                </div>

                <div class="row">
                    <div class="input-group">
                        <label>Partner ID</label>
                        <input type="text" id="partnerId" placeholder="MS-000" value="MS-882">
                    </div>
                    <div class="input-group">
                        <label>Tracking Source</label>
                        <input type="text" id="source" placeholder="wix_site" value="partner_portal">
                    </div>
                </div>

                <div class="input-group">
                    <label>Primary Brand Color</label>
                    <input type="color" id="brandColor" value="#00f0ff" style="height: 40px; padding: 2px; cursor: pointer;">
                </div>

                <div class="row">
                    <div class="input-group">
                        <label>Width (px/%)</label>
                        <input type="text" id="width" value="100%">
                    </div>
                    <div class="input-group">
                        <label>Height (px)</label>
                        <input type="number" id="height" value="500">
                    </div>
                </div>

                <div class="input-group">
                    <label>Application Redirect URL</label>
                    <input type="text" id="appUrl" placeholder="https://moonshine.capital/apply">
                </div>

                <div style="margin-top: 2rem;">
                    <div class="section-title">Recent Generations</div>
                    <div class="history-list" id="history">
                        <!-- Populated by JS -->
                        <div class="history-item" style="color: var(--text-muted); font-style: italic;">No recent history</div>
                    </div>
                </div>
            </div>
        </aside>

        <!-- Main Workspace -->
        <main class="main-content">
            
            <!-- Live Preview -->
            <div class="preview-container">
                <div class="preview-header">
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <span style="width: 8px; height: 8px; border-radius: 50%; background: #ff5f56;"></span>
                        <span style="width: 8px; height: 8px; border-radius: 50%; background: #ffbd2e;"></span>
                        <span style="width: 8px; height: 8px; border-radius: 50%; background: #27c93f;"></span>
                        <span style="margin-left: 1rem; font-size: 0.75rem; color: var(--text-secondary); font-family: 'JetBrains Mono';">Live Preview</span>
                    </div>
                    <div id="previewDimensions" style="font-size: 0.7rem; color: var(--text-muted);">100% x 500px</div>
                </div>
                <div class="preview-window">
                    <div id="widgetPreview" class="widget-mockup">
                        <h3 id="mockTitle">Funding Readiness</h3>
                        <p id="mockDesc">Check your eligibility for capital in 60 seconds.</p>
                        <div style="margin: 1.5rem 0; height: 6px; background: #eee; border-radius: 10px;">
                            <div id="mockProgress" style="width: 65%; height: 100%; background: var(--neon-blue); border-radius: 10px;"></div>
                        </div>
                        <a href="#" class="btn" id="mockBtn">Calculate Now</a>
                    </div>
                </div>
            </div>

            <!-- Code Output -->
            <div class="output-card">
                <div class="code-header">
                    <div class="tab active" onclick="switchTab('iframe')">iFrame Embed</div>
                    <div class="tab" onclick="switchTab('script')">JS Snippet</div>
                    <div class="tab" onclick="switchTab('link')">Direct Link</div>
                </div>

                <div class="code-container">
                    <button class="copy-btn" onclick="copyCode()">Copy Code</button>
                    <pre id="codeOutput">Loading...</pre>
                </div>
                
                <p style="font-size: 0.75rem; color: var(--text-muted); margin-top: 1rem;">
                    * The script version provides better responsiveness on mobile devices and SEO benefits.
                </p>
            </div>

            <!-- Platform Instructions -->
            <div class="section-title" style="margin-top: 1rem;">Installation Guides</div>
            <div class="platforms">
                <div class="platform-card">
                    <h4>WordPress</h4>
                    <p style="font-size: 0.7rem; color: var(--text-muted);">Use Custom HTML Block</p>
                </div>
                <div class="platform-card">
                    <h4>Wix</h4>
                    <p style="font-size: 0.7rem; color: var(--text-muted);">Embed HTML Element</p>
                </div>
                <div class="platform-card">
                    <h4>Framer / Webflow</h4>
                    <p style="font-size: 0.7rem; color: var(--text-muted);">Embed Component</p>
                </div>
                <div class="platform-card">
                    <h4>Carrd</h4>
                    <p style="font-size: 0.7rem; color: var(--text-muted);">Embed Control</p>
                </div>
            </div>

            <!-- FAQ -->
            <div class="faq-section">
                <div class="section-title">Troubleshooting & FAQ</div>
                <div class="faq-grid">
                    <div class="faq-item">
                        <h4>Widget not appearing?</h4>
                        <p>Ensure your domain is whitelisted in the Moonshine Partner Dashboard under "Security Settings".</p>
                    </div>
                    <div class="faq-item">
                        <h4>Tracking not firing?</h4>
                        <p>Verify your Partner ID is correct. UTM parameters are automatically appended to the application URL inside the widget.</p>
                    </div>
                    <div class="faq-item">
                        <h4>Responsive issues?</h4>
                        <p>Set width to 100% and height to 'auto' or use the JS snippet for dynamic resizing.</p>
                    </div>
                    <div class="faq-item">
                        <h4>Custom Styling?</h4>
                        <p>Widgets inherit your 'Brand Color' for buttons and accents. For deeper customization, contact the dev team.</p>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        const inputs = ['widgetType', 'partnerName', 'partnerId', 'source', 'brandColor', 'width', 'height', 'appUrl'];
        const elements = {};
        inputs.forEach(id => elements[id] = document.getElementById(id));
        
        const previewBtn = document.getElementById('mockBtn');
        const previewTitle = document.getElementById('mockTitle');
        const previewDesc = document.getElementById('mockDesc');
        const previewProgress = document.getElementById('mockProgress');
        const codeOutput = document.getElementById('codeOutput');
        const previewDimensions = document.getElementById('previewDimensions');
        const historyContainer = document.getElementById('history');

        let currentTab = 'iframe';

        const widgetData = {
            score: { title: "Funding Readiness", desc: "Check your eligibility for capital in 60 seconds.", btn: "Calculate Now", progress: "65%" },
            matcher: { title: "Route Matcher", desc: "Which funding pathway fits your business model?", btn: "Find My Match", progress: "20%" },
            cta: { title: "Apply for Funding", desc: "Fast capital for growing agencies and SaaS.", btn: "Start Application", progress: "0%" },
            docs: { title: "Document Checklist", desc: "See what you need for a successful application.", btn: "View Checklist", progress: "40%" },
            faq: { title: "Funding FAQ", desc: "Common questions about Moonshine Capital.", btn: "Read More", progress: "10%" },
            calc: { title: "Commission Estimator", desc: "Calculate your partner earnings.", btn: "Estimate Now", progress: "80%" },
            profile: { title: "Verified Partner", desc: "Official Moonshine Capital Funding Partner.", btn: "Get Funded", progress: "100%" }
        };

        function updateGenerator() {
            const type = elements.widgetType.value;
            const data = widgetData[type];
            
            // Update Preview Mockup
            previewTitle.innerText = data.title;
            previewDesc.innerText = data.desc;
            previewBtn.innerText = data.btn;
            previewBtn.style.backgroundColor = elements.brandColor.value;
            previewProgress.style.width = data.progress;
            previewProgress.style.backgroundColor = elements.brandColor.value;
            previewDimensions.innerText = `${elements.width.value} x ${elements.height.value}px`;

            // Build URL
            const baseUrl = "https://widgets.moonshine.capital/" + type;
            const params = new URLSearchParams({
                pid: elements.partnerId.value,
                pname: elements.partnerName.value,
                src: elements.source.value,
                color: elements.brandColor.value.replace('#', ''),
                app_url: elements.appUrl.value || 'https://moonshine.capital/apply'
            });
            const finalUrl = `${baseUrl}?${params.toString()}`;

            // Update Code Blocks
            if (currentTab === 'iframe') {
                codeOutput.innerText = `<iframe \n  src="${finalUrl}"\n  width="${elements.width.value}"\n  height="${elements.height.value}"\n  frameborder="0"\n  allowtransparency="true"\n  style="border-radius: 8px; overflow: hidden;"\n></iframe>`;
            } else if (currentTab === 'script') {
                codeOutput.innerText = `<script src="https://cdn.moonshine.capital/widget-loader.js"><\/script>\n<div \n  data-ms-widget="${type}"\n  data-partner-id="${elements.partnerId.value}"\n  data-color="${elements.brandColor.value}"\n><\/div>`;
            } else {
                codeOutput.innerText = finalUrl;
            }

            saveToHistory(data.title);
        }

        function switchTab(tab) {
            currentTab = tab;
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            event.target.classList.add('active');
            updateGenerator();
        }

        function copyCode() {
            navigator.clipboard.writeText(codeOutput.innerText);
            const btn = document.querySelector('.copy-btn');
            btn.innerText = 'Copied!';
            btn.style.color = 'var(--neon-green)';
            setTimeout(() => {
                btn.innerText = 'Copy Code';
                btn.style.color = 'var(--text-primary)';
            }, 2000);
        }

        function saveToHistory(widgetName) {
            let history = JSON.parse(localStorage.getItem('ms_history') || '[]');
            const entry = { name: widgetName, date: new Date().toLocaleTimeString() };
            
            // Avoid duplicates
            if (history.length > 0 && history[0].name === widgetName) return;
            
            history.unshift(entry);
            history = history.slice(0, 3);
            localStorage.setItem('ms_history', JSON.stringify(history));
            renderHistory();
        }

        function renderHistory() {
            const history = JSON.parse(localStorage.getItem('ms_history') || '[]');
            if (history.length === 0) return;
            
            historyContainer.innerHTML = history.map(item => `
                <div class="history-item">
                    <span>${item.name}</span>
                    <span style="color: var(--text-muted); font-size: 0.7rem;">${item.date}</span>
                </div>
            `).join('');
        }

        // Listeners
        inputs.forEach(id => {
            elements[id].addEventListener('input', updateGenerator);
        });

        // Init
        updateGenerator();
        renderHistory();

    </script>
</body>
</html>
```
import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<nav>
        <div class="logo">THE RADICAL LIBERTARIAN</div>
        <div style="font-family: 'JetBrains Mono'; font-weight: 800;">VOL. 001 // 2024</div>
    </nav>

    <section class="hero section-padding">
        <h1>FREEDOM IS<br><span>NOT SUPPOSED</span><br>TO BE COMFORTABLE</h1>
        <p class="hero-sub">
            Essays, podcasts, rants, and philosophical grenades for people who distrust both the boot and the person begging to polish it. We are the glitch in the social contract.
        </p>
        <a href="#" class="btn">READ THE MANIFESTO</a>
    </section>

    <div class="torn-edge"></div>

    <section class="manifesto-grid">
        <div class="m-card">
            <div class="m-num">01</div>
            <h3>Sovereignty</h3>
            <p>The individual is the ultimate jurisdiction. Any collective claim over the person without explicit, revocable consent is a form of kidnapping. No exceptions.</p>
        </div>
        <div class="m-card">
            <div class="m-num">02</div>
            <h3>Decentralize</h3>
            <p>If a system is "Too Big To Fail," it is too big to exist. We advocate for the radical fragmentation of power until the smallest unit is the person.</p>
        </div>
        <div class="m-card">
            <div class="m-num">03</div>
            <h3>Anti-Script</h3>
            <p>Reject the party-line NPC scripts. Left-wing authoritarianism and Right-wing authoritarianism are just two flavors of the same poison.</p>
        </div>
        <div class="m-card">
            <div class="m-num">04</div>
            <h3>Agorism</h3>
            <p>Build the world you want outside the state's vision. Crypto, homesteading, code, and underground education are the new frontiers.</p>
        </div>
    </section>

    <section class="essays section-padding">
        <h2 style="font-size: 4rem; margin-bottom: 50px; text-transform: uppercase; background: var(--black); color: var(--cream); display: inline-block; padding: 0 20px;">LATEST RANTS</h2>
        
        <a href="#" class="essay-row">
            <div class="essay-date">OCT 24</div>
            <div class="essay-title">The Illusion of Public Property</div>
            <div class="btn" style="padding: 10px 20px; font-size: 1rem; box-shadow: 4px 4px 0px var(--black);">READ</div>
        </a>

        <a href="#" class="essay-row">
            <div class="essay-date">OCT 18</div>
            <div class="essay-title">Why the 'Social Contract' is an Unsigned Lease</div>
            <div class="btn" style="padding: 10px 20px; font-size: 1rem; box-shadow: 4px 4px 0px var(--black);">READ</div>
        </a>

        <a href="#" class="essay-row">
            <div class="essay-date">OCT 05</div>
            <div class="essay-title">Techno-Secession: Leaving the Grid Without Moving</div>
            <div class="btn" style="padding: 10px 20px; font-size: 1rem; box-shadow: 4px 4px 0px var(--black);">READ</div>
        </a>
    </section>

    <section class="enemies section-padding">
        <h2 style="font-size: 3.5rem; text-transform: uppercase;">ENEMIES OF LAZY THINKING</h2>
        <div class="enemy-list">
            <div class="enemy-tag" style="--r: -2">CENTRAL BANKS</div>
            <div class="enemy-tag" style="--r: 3">CENSORSHIP</div>
            <div class="enemy-tag" style="--r: -1">BUREAUCRACY</div>
            <div class="enemy-tag" style="--r: 2">GROUPTHINK</div>
            <div class="enemy-tag" style="--r: -4">SURVEILLANCE</div>
            <div class="enemy-tag" style="--r: 1">DEPENDENCY</div>
        </div>
    </section>

    <section class="section-padding" style="background: var(--black); color: var(--cream);">
        <h2 style="font-size: 3rem; margin-bottom: 30px;">THE AUDIO GRENADE (PODCAST)</h2>
        <div style="border: 5px solid var(--red); padding: 40px; display: flex; align-items: center; gap: 30px;">
            <div style="width: 100px; height: 100px; background: var(--red); display: flex; align-items: center; justify-content: center; font-size: 3rem;">▶</div>
            <div>
                <h4 style="font-size: 2rem;">EP #42: THE DEATH OF THE NATION STATE</h4>
                <p style="font-family: 'JetBrains Mono'; color: #888;">Duration: 54:12 // Guests: Anonymous Cryptographer</p>
            </div>
        </div>
    </section>

    <section class="newsletter section-padding">
        <h2 style="font-size: 4rem; margin-bottom: 20px;">GET THE GRENADES IN YOUR INBOX</h2>
        <p style="font-family: 'Special Elite'; font-size: 1.5rem; margin-bottom: 40px;">No spam. Just hard truths that make you a liability to the system.</p>
        <form onsubmit="return false;">
            <input type="email" placeholder="EMAIL@RESISTANCE.COM"><br>
            <button class="btn">ARM THE BOMB</button>
        </form>
    </section>

    <section class="section-padding" style="text-align: center; background: var(--red);">
        <h2 style="font-size: clamp(3rem, 10vw, 8rem); color: var(--black);">STAY RADICAL.</h2>
        <a href="#" class="btn" style="background: var(--black); border-color: var(--cream);">READ THE MANIFESTO</a>
    </section>

    <footer>
        <div>© 2024 THE RADICAL LIBERTARIAN</div>
        <div>ENCRYPTED CONNECTION // NO COOKIES</div>
        <div>EST. IN THE VOID</div>
    </footer>
      ` }} />
    </main>
  );
}
import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<div class="grid-overlay"></div>
    <div class="glow-sphere"></div>

    <header>
        <div class="logo">STRATEGIST.AI</div>
        <nav>
            <a href="#" class="btn btn-outline" style="margin-right: 1rem;">Login</a>
            <a href="#" class="btn btn-primary">Start Analyzing</a>
        </nav>
    </header>

    <section class="hero">
        <div class="hero-hook">AN AI FUNDING STRATEGIST FOR ENTREPRENEURS WHO HATE BANKER THEATER</div>
        <h1>Stop guessing. Start getting funded.</h1>
        <p>Get instant guidance on funding options, readiness gaps, documents needed, and next steps before you apply to a single lender.</p>
        
        <div class="orb-container">
            <div class="orb-ring" style="width: 280px; height: 280px;"></div>
            <div class="orb-ring" style="width: 340px; height: 340px; animation-duration: 15s; border-color: rgba(139, 92, 246, 0.2);"></div>
            <div class="orb"></div>
        </div>

        <a href="#" class="btn btn-primary" style="padding: 1.2rem 2.5rem; font-size: 1.1rem;">Try the AI Funding Strategist</a>
    </section>

    <div class="section-label">Intelligent Capability Grid</div>
    <section class="bento-grid">
        <div class="card card-1">
            <div class="tag">AI READINESS</div>
            <h3>Funding Readiness Audit</h3>
            <p>Our AI scans your current business metrics, credit profile, and structure to identify "Red Flags" that would cause a manual decline from top-tier banks.</p>
            <div style="margin-top: 2rem; height: 100px; background: linear-gradient(90deg, #3b82f633, transparent); border-radius: 10px; border: 1px dashed var(--border);"></div>
        </div>
        <div class="card card-2">
            <div class="tag">ROUTING</div>
            <h3>Smart Lender Match</h3>
            <p>Don't spray and pray. We route you to the specific lenders who have an appetite for your industry and credit profile today.</p>
        </div>
        <div class="card card-3">
            <div class="tag">CREDIT</div>
            <h3>Business Credit Build</h3>
            <p>Automated roadmap to separate your personal and business liability while maximizing your score.</p>
        </div>
        <div class="card card-4">
            <div class="tag">DOCUMENTS</div>
            <h3>The "Funding Vault" Prep</h3>
            <p>Know exactly which 6 documents you need before the banker asks. Our AI audits your docs for consistency errors that cause delays.</p>
            <div style="display: flex; gap: 10px; margin-top: 2rem;">
                <div style="width: 30%; height: 60px; background: rgba(255,255,255,0.05); border-radius: 8px;"></div>
                <div style="width: 30%; height: 60px; background: rgba(255,255,255,0.05); border-radius: 8px;"></div>
                <div style="width: 30%; height: 60px; background: rgba(255,255,255,0.05); border-radius: 8px;"></div>
            </div>
        </div>
    </section>

    <section class="questions-container">
        <h2 style="text-align: center; margin-bottom: 2rem;">Common questions to ask your Strategist:</h2>
        <div style="text-align: center;">
            <div class="q-chip">"Am I eligible for an SBA 7(a) loan?"</div>
            <div class="q-chip">"Why was my business credit score low last month?"</div>
            <div class="q-chip">"What lenders are funding SaaS startups right now?"</div>
            <div class="q-chip">"Review my P&L for funding readiness."</div>
            <div class="q-chip">"How do I get a \$50k line of credit without a PG?"</div>
        </div>
    </section>

    <section class="workflow">
        <h2 style="text-align: center; font-size: 2.5rem;">The Readiness Workflow</h2>
        <div class="workflow-steps">
            <div class="step">
                <div class="step-num">1</div>
                <h4>Data Sync</h4>
                <p>Connect your accounts securely for a 360° view.</p>
            </div>
            <div class="step">
                <div class="step-num">2</div>
                <h4>Gap Analysis</h4>
                <p>AI identifies why a banker might say 'No'.</p>
            </div>
            <div class="step">
                <div class="step-num">3</div>
                <h4>Bridge Gaps</h4>
                <p>Follow the AI's tasks to fix credit or document issues.</p>
            </div>
            <div class="step">
                <div class="step-num">4</div>
                <h4>Auto-Route</h4>
                <p>One-click application to the most likely lenders.</p>
            </div>
        </div>
    </section>

    <section style="text-align: center; padding: 8rem 5%;">
        <div style="background: var(--prism-gradient); padding: 4rem; border-radius: 30px; border: 1px solid var(--accent-primary); max-width: 900px; margin: 0 auto;">
            <h2 style="margin-bottom: 1rem;">Need a Human Strategist?</h2>
            <p style="margin-bottom: 2rem; color: var(--text-dim);">When the AI determines your case is complex, we hand you off to a certified funding consultant to finalize your package.</p>
            <a href="#" class="btn btn-outline">Schedule Consultation</a>
        </div>
    </section>

    <section class="pricing">
        <div class="price-card">
            <div class="tag">EXPLORER</div>
            <h2>Free</h2>
            <p>Basic readiness report<br>Generic lender matching<br>Email support</p>
            <a href="#" class="btn btn-outline" style="margin-top: 2rem; width: 100%;">Get Started</a>
        </div>
        <div class="price-card featured">
            <div class="tag">PRO STRATEGIST</div>
            <h2>\$49<span>/mo</span></h2>
            <p>Full document audit<br>Live credit monitoring<br>Priority lender routing<br>Unlimited AI questions</p>
            <a href="#" class="btn btn-primary" style="margin-top: 2rem; width: 100%;">Unlock Full Access</a>
        </div>
    </section>

    <section class="faq">
        <h2 style="margin-bottom: 2rem; text-align: center;">Frequently Asked</h2>
        <details class="faq-item">
            <summary>Is my data secure?</summary>
            <p style="padding-top: 1rem; color: var(--text-dim);">We use 256-bit encryption and never sell your data to lenders. We only share it when you explicitly choose to apply.</p>
        </details>
        <details class="faq-item">
            <summary>Does this guarantee funding?</summary>
            <p style="padding-top: 1rem; color: var(--text-dim);">While no one can guarantee funding, we significantly increase your odds by fixing the common reasons for rejection before they happen.</p>
        </details>
        <details class="faq-item">
            <summary>How is this different from a broker?</summary>
            <p style="padding-top: 1rem; color: var(--text-dim);">Brokers often charge 10% of your loan. We provide the technology to do it yourself for a flat monthly fee.</p>
        </details>
    </section>

    <section style="padding: 8rem 5%; text-align: center; border-top: 1px solid var(--border);">
        <h2 style="font-size: 3rem; margin-bottom: 2rem;">Ready to bridge the gap?</h2>
        <a href="#" class="btn btn-primary" style="padding: 1.5rem 3rem; font-size: 1.2rem;">Get Your Readiness Score Now</a>
    </section>

    <footer>
        <p>&copy; 2023 Strategist.AI. Built for the modern founder.</p>
    </footer>
      ` }} />
    </main>
  );
}
### Generated UI Component

To use this in Notion:
1. Create a "/code" block
2. Set language to "HTML"
3. Paste the following:

```html
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VALOIS // Funding Intelligence Engine</title>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;700&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-base: #030207;
            --bg-surface: #0a0813;
            --bg-surface-elevated: #110e20;
            --border-subtle: rgba(255, 255, 255, 0.04);
            --border-muted: rgba(255, 255, 255, 0.08);
            --border-active: rgba(139, 92, 246, 0.3);
            
            --text-primary: #f4f4f7;
            --text-secondary: #a1a1aa;
            --text-muted: #52525b;
            
            --accent-purple: #8b5cf6;
            --accent-purple-glow: rgba(139, 92, 246, 0.15);
            --accent-velvet: #311042;
            --accent-emerald: #10b981;
            --accent-emerald-glow: rgba(16, 185, 129, 0.1);
            --accent-amber: #f59e0b;
            --accent-rose: #ef4444;

            --font-sans: 'Plus Jakarta Sans', sans-serif;
            --font-mono: 'JetBrains Mono', monospace;
            
            --transition-smooth: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        }

        /* White Label Alternative Theme override */
        body.white-label-mode {
            --bg-base: #fafafa;
            --bg-surface: #ffffff;
            --bg-surface-elevated: #f4f4f5;
            --border-subtle: rgba(0, 0, 0, 0.05);
            --border-muted: rgba(0, 0, 0, 0.1);
            --border-active: rgba(79, 70, 229, 0.4);
            --text-primary: #09090b;
            --text-secondary: #71717a;
            --text-muted: #a1a1aa;
            --accent-purple: #4f46e5;
            --accent-purple-glow: rgba(79, 70, 229, 0.08);
            --accent-velvet: #eef2ff;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            background-color: var(--bg-base);
            color: var(--text-primary);
            font-family: var(--font-sans);
            overflow-x: hidden;
            transition: var(--transition-smooth);
            background-image: radial-gradient(circle at 50% 0%, var(--accent-velvet) 0%, transparent 70%);
            background-attachment: fixed;
            min-height: 100vh;
        }

        /* Clean Scrollbar */
        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }
        ::-webkit-scrollbar-track {
            background: var(--bg-base);
        }
        ::-webkit-scrollbar-thumb {
            background: var(--border-muted);
            border-radius: 3px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: var(--accent-purple);
        }

        /* Shell & Containers */
        .app-container {
            max-width: 1440px;
            margin: 0 auto;
            padding: 24px;
            display: flex;
            flex-direction: column;
            gap: 24px;
        }

        /* Top Bar Navigation */
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 24px;
            background: rgba(10, 8, 19, 0.4);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border-subtle);
            border-radius: 16px;
            margin-bottom: 8px;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .brand-logo {
            width: 32px;
            height: 32px;
            background: linear-gradient(135deg, var(--accent-purple), #ec4899);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            color: #fff;
            font-size: 14px;
            letter-spacing: -0.5px;
        }

        .brand-title {
            font-size: 14px;
            font-weight: 700;
            letter-spacing: 2px;
            text-transform: uppercase;
            background: linear-gradient(to right, var(--text-primary), var(--text-secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .brand-tag {
            font-family: var(--font-mono);
            font-size: 10px;
            color: var(--accent-purple);
            border: 1px solid var(--border-active);
            padding: 2px 8px;
            border-radius: 20px;
            background: var(--accent-purple-glow);
        }

        .controls-group {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .select-archetype {
            background: var(--bg-surface-elevated);
            border: 1px solid var(--border-muted);
            color: var(--text-primary);
            font-family: var(--font-sans);
            font-size: 13px;
            font-weight: 500;
            padding: 8px 16px;
            border-radius: 12px;
            cursor: pointer;
            outline: none;
            transition: var(--transition-smooth);
        }

        .select-archetype:hover {
            border-color: var(--accent-purple);
        }

        .btn-toggle {
            background: var(--bg-surface-elevated);
            border: 1px solid var(--border-muted);
            color: var(--text-primary);
            font-family: var(--font-sans);
            font-size: 12px;
            font-weight: 600;
            padding: 8px 16px;
            border-radius: 12px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: var(--transition-smooth);
        }

        .btn-toggle:hover {
            border-color: var(--accent-purple);
            background: var(--accent-purple-glow);
        }

        .btn-toggle .indicator {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: var(--accent-purple);
            box-shadow: 0 0 8px var(--accent-purple);
        }

        /* Bento Grid Architecture */
        .bento-grid {
            display: grid;
            grid-template-columns: repeat(12, 1fr);
            gap: 20px;
        }

        .bento-card {
            background: var(--bg-surface);
            border: 1px solid var(--border-muted);
            border-radius: 16px;
            padding: 24px;
            transition: var(--transition-smooth);
            position: relative;
            overflow: hidden;
        }

        .bento-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--border-active), transparent);
            opacity: 0;
            transition: var(--transition-smooth);
        }

        .bento-card:hover::before {
            opacity: 1;
        }

        .bento-card:hover {
            transform: translateY(-2px);
            border-color: rgba(255, 255, 255, 0.12);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.4);
        }

        /* Card Headers */
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 20px;
        }

        .card-title-group {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .card-label {
            font-family: var(--font-mono);
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            color: var(--accent-purple);
            font-weight: 600;
        }

        .card-title {
            font-size: 18px;
            font-weight: 600;
            letter-spacing: -0.5px;
        }

        /* 1. Scorecard Block (Size 4) */
        .col-scorecard {
            grid-column: span 4;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .score-visual-container {
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 20px 0;
            position: relative;
        }

        .score-svg {
            transform: rotate(-90deg);
            width: 180px;
            height: 180px;
        }

        .score-svg-bg {
            fill: none;
            stroke: var(--border-muted);
            stroke-width: 10;
        }

        .score-svg-val {
            fill: none;
            stroke: url(#scoreGradient);
            stroke-width: 10;
            stroke-linecap: round;
            stroke-dasharray: 440;
            stroke-dashoffset: 440;
            transition: stroke-dashoffset 1.5s cubic-bezier(0.16, 1, 0.3, 1);
        }

        .score-text-absolute {
            position: absolute;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }

        .score-number {
            font-family: var(--font-mono);
            font-size: 42px;
            font-weight: 700;
            color: var(--text-primary);
            line-height: 1;
        }

        .score-tier {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            color: var(--accent-emerald);
            font-weight: 600;
            margin-top: 4px;
        }

        .dimensions-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-top: 16px;
        }

        .dimension-item {
            background: var(--bg-surface-elevated);
            padding: 10px 12px;
            border-radius: 8px;
            border: 1px solid var(--border-subtle);
        }

        .dimension-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 6px;
        }

        .dimension-name {
            font-size: 11px;
            color: var(--text-secondary);
            font-weight: 500;
        }

        .dimension-val {
            font-family: var(--font-mono);
            font-size: 11px;
            color: var(--text-primary);
            font-weight: 600;
        }

        .dimension-bar-bg {
            height: 4px;
            background: var(--border-muted);
            border-radius: 2px;
            overflow: hidden;
        }

        .dimension-bar-fill {
            height: 100%;
            background: var(--accent-purple);
            width: 0%;
            transition: width 1s var(--transition-smooth);
            border-radius: 2px;
        }

        /* 2. Funding Path Recommendation (Size 8) */
        .col-recommendations {
            grid-column: span 8;
        }

        .path-list {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .path-row {
            display: grid;
            grid-template-columns: 2.5fr 1.5fr 1.5fr 1.5fr 1fr;
            align-items: center;
            padding: 16px 20px;
            background: var(--bg-surface-elevated);
            border: 1px solid var(--border-subtle);
            border-radius: 12px;
            transition: var(--transition-smooth);
        }

        .path-row:hover {
            border-color: var(--border-active);
            transform: scale(1.01);
        }

        .path-meta-primary {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .path-title-text {
            font-size: 15px;
            font-weight: 600;
        }

        .path-provider {
            font-size: 11px;
            color: var(--text-secondary);
        }

        .path-metric {
            display: flex;
            flex-direction: column;
            gap: 2px;
        }

        .path-metric-lbl {
            font-size: 10px;
            text-transform: uppercase;
            color: var(--text-muted);
            letter-spacing: 0.5px;
        }

        .path-metric-val {
            font-family: var(--font-mono);
            font-size: 13px;
            font-weight: 600;
        }

        .confidence-pill {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 4px 8px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            width: fit-content;
        }

        .conf-high {
            background: var(--accent-emerald-glow);
            color: var(--accent-emerald);
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        .conf-medium {
            background: rgba(245, 158, 11, 0.1);
            color: var(--accent-amber);
            border: 1px solid rgba(245, 158, 11, 0.2);
        }

        .action-icon {
            text-align: right;
            color: var(--text-muted);
            font-size: 18px;
            cursor: pointer;
            transition: var(--transition-smooth);
        }

        .path-row:hover .action-icon {
            color: var(--accent-purple);
            transform: translateX(4px);
        }

        /* 3. Risk Flag Warning Panel */
        .col-risk {
            grid-column: span 4;
        }

        .risk-list {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .risk-item {
            display: flex;
            gap: 12px;
            padding: 12px 16px;
            border-radius: 10px;
            background: rgba(239, 68, 68, 0.03);
            border: 1px solid rgba(239, 68, 68, 0.1);
        }

        .risk-icon {
            color: var(--accent-rose);
            font-size: 14px;
            margin-top: 2px;
        }

        .risk-details {
            display: flex;
            flex-direction: column;
            gap: 2px;
        }

        .risk-title {
            font-size: 12px;
            font-weight: 600;
            color: var(--text-primary);
        }

        .risk-desc {
            font-size: 11px;
            color: var(--text-secondary);
            line-height: 1.4;
        }

        /* 4. White Labeled Public Preview Selector (Size 8) */
        .col-whitelabel {
            grid-column: span 8;
        }

        .preview-pane {
            background: var(--bg-surface-elevated);
            border-radius: 12px;
            padding: 20px;
            border: 1px dashed var(--border-muted);
            margin-top: 10px;
        }

        .preview-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border-subtle);
            padding-bottom: 12px;
            margin-bottom: 16px;
        }

        .preview-badge {
            font-size: 11px;
            font-weight: 500;
            background: var(--border-muted);
            padding: 4px 10px;
            border-radius: 20px;
            color: var(--text-secondary);
        }

        .preview-body-content {
            display: flex;
            flex-direction: column;
            gap: 16px;
        }

        .preview-value-blocks {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 16px;
        }

        .val-block {
            background: var(--bg-surface);
            padding: 14px;
            border-radius: 8px;
            border: 1px solid var(--border-subtle);
        }

        /* 5. Route Verticals Cards Grid (12 Columns Total, 6 items of Span 4 each to map elegantly) */
        .verticals-header {
            grid-column: span 12;
            margin-top: 12px;
            border-bottom: 1px solid var(--border-subtle);
            padding-bottom: 8px;
        }

        .col-vertical {
            grid-column: span 4;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            min-height: 180px;
        }

        .vertical-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
        }

        .vertical-icon-wrap {
            width: 36px;
            height: 36px;
            background: var(--bg-surface-elevated);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 1px solid var(--border-subtle);
            color: var(--accent-purple);
        }

        .vertical-desc {
            font-size: 12px;
            color: var(--text-secondary);
            margin-top: 8px;
            line-height: 1.5;
        }

        .vertical-stats {
            margin-top: auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 16px;
            border-top: 1px solid var(--border-subtle);
        }

        .v-stat {
            display: flex;
            flex-direction: column;
        }

        .v-stat-lbl {
            font-size: 9px;
            text-transform: uppercase;
            color: var(--text-muted);
        }

        .v-stat-val {
            font-family: var(--font-mono);
            font-size: 11px;
            font-weight: 600;
        }

        /* 6. Partner CTA Block */
        .col-partner {
            grid-column: span 12;
            background: radial-gradient(circle at 100% 100%, var(--accent-purple-glow) 0%, var(--bg-surface) 100%);
            display: flex;
            justify-content: space-between;
            align-items: center;
            border: 1px solid rgba(139, 92, 246, 0.2);
        }

        .partner-content {
            max-width: 60%;
        }

        .partner-btn {
            background: var(--text-primary);
            color: var(--bg-base);
            border: none;
            padding: 12px 24px;
            border-radius: 12px;
            font-family: var(--font-sans);
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition-smooth);
        }

        .partner-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 20px var(--accent-purple-glow);
            filter: brightness(0.9);
        }

        /* 7. Footer Compliance Area */
        footer {
            margin-top: 24px;
            border-top: 1px solid var(--border-subtle);
            padding: 24px 0 60px 0;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .compliance-text {
            font-size: 11px;
            color: var(--text-muted);
            line-height: 1.6;
        }

        .compliance-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 11px;
            color: var(--text-muted);
        }

        /* Internal Debug Drawer Button & Panel */
        .debug-trigger-btn {
            position: fixed;
            bottom: 24px;
            right: 24px;
            background: #000;
            color: #fff;
            border: 1px solid #222;
            padding: 10px 16px;
            border-radius: 20px;
            font-family: var(--font-mono);
            font-size: 11px;
            cursor: pointer;
            z-index: 999;
            box-shadow: 0 8px 30px rgba(0,0,0,0.5);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .debug-drawer {
            position: fixed;
            bottom: -600px;
            left: 0;
            right: 0;
            height: 500px;
            background: #06050a;
            border-top: 1px solid #1c1830;
            z-index: 1000;
            box-shadow: 0 -12px 40px rgba(0,0,0,0.8);
            transition: transform 0.4s cubic-bezier(0.16, 1, 0.3, 1);
            font-family: var(--font-mono);
            display: flex;
            flex-direction: column;
        }

        .debug-drawer.open {
            transform: translateY(-600px);
        }

        .debug-header {
            padding: 16px 24px;
            background: #0d0b16;
            border-bottom: 1px solid #1c1830;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .debug-title {
            font-size: 12px;
            font-weight: 700;
            letter-spacing: 1px;
            text-transform: uppercase;
            color: var(--accent-purple);
        }

        .debug-tabs {
            display: flex;
            gap: 8px;
        }

        .debug-tab {
            background: transparent;
            border: 1px solid transparent;
            color: var(--text-secondary);
            font-family: var(--font-mono);
            font-size: 11px;
            padding: 4px 12px;
            border-radius: 6px;
            cursor: pointer;
        }

        .debug-tab.active {
            background: var(--bg-surface-elevated);
            color: var(--text-primary);
            border-color: var(--border-muted);
        }

        .debug-body {
            flex-grow: 1;
            padding: 20px;
            overflow-y: auto;
            font-size: 11px;
            color: #10b981; /* Terminal green default */
            background: #020104;
        }

        .close-debug-btn {
            background: transparent;
            border: none;
            color: var(--text-secondary);
            font-family: var(--font-mono);
            font-size: 14px;
            cursor: pointer;
        }

        /* Utility/Vercel guide element styled nicely inside debug drawer */
        .deployment-guide {
            color: var(--text-secondary);
            line-height: 1.6;
        }

        .code-block {
            background: #110e20;
            padding: 12px;
            border-radius: 6px;
            border: 1px solid var(--border-muted);
            color: var(--text-primary);
            margin: 8px 0;
            display: block;
            white-space: pre-wrap;
        }

        /* SVG Glow Defs */
        .glow-purple {
            filter: drop-shadow(0px 0px 4px var(--accent-purple));
        }

        /* Responsive Breakpoints */
        @media (max-width: 1024px) {
            .col-scorecard, .col-risk {
                grid-column: span 6;
            }
            .col-recommendations, .col-whitelabel {
                grid-column: span 12;
            }
            .col-vertical {
                grid-column: span 6;
            }
        }

        @media (max-width: 768px) {
            .col-scorecard, .col-risk, .col-vertical {
                grid-column: span 12;
            }
            .path-row {
                grid-template-columns: 1fr;
                gap: 12px;
                padding: 16px;
            }
            .action-icon {
                text-align: left;
            }
            .preview-value-blocks {
                grid-template-columns: 1fr;
            }
            header {
                flex-direction: column;
                gap: 16px;
                align-items: flex-start;
            }
            .controls-group {
                width: 100%;
                justify-content: space-between;
            }
        }
    </style>
</head>
<body>

<div class="app-container">
    <!-- Main Premium Header -->
    <header>
        <div class="brand">
            <div class="brand-logo">V</div>
            <div class="brand-title">Valois</div>
            <div class="brand-tag">F.I.E. v2.4</div>
        </div>
        <div class="controls-group">
            <select class="select-archetype" id="archetypeSelect" onchange="loadArchetype(this.value)">
                <!-- Generated dynamically from JSON structural config -->
            </select>
            <button class="btn-toggle" onclick="toggleWhiteLabel()">
                <div class="indicator" id="whiteLabelIndicator"></div>
                <span id="whiteLabelText">White-Label Delivery</span>
            </button>
        </div>
    </header>

    <!-- Bento Analytics View Grid -->
    <div class="bento-grid">
        
        <!-- Bento Card: Funding Readiness Scorecard (Left - Col 4) -->
        <div class="bento-card col-scorecard">
            <div class="card-header">
                <div class="card-title-group">
                    <div class="card-label">Readiness Assessment</div>
                    <div class="card-title">Readiness Index</div>
                </div>
                <span class="preview-badge">Real-time</span>
            </div>

            <div class="score-visual-container">
                <svg class="score-svg" viewBox="0 0 160 160">
                    <defs>
                        <linearGradient id="scoreGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="#8b5cf6" />
                            <stop offset="100%" stop-color="#ec4899" />
                        </linearGradient>
                    </defs>
                    <circle class="score-svg-bg" cx="80" cy="80" r="70"></circle>
                    <circle class="score-svg-val glow-purple" id="scoreValueArc" cx="80" cy="80" r="70"></circle>
                </svg>
                <div class="score-text-absolute">
                    <div class="score-number" id="scoreNumDisplay">--</div>
                    <div class="score-tier" id="scoreTierDisplay">Analyzing</div>
                </div>
            </div>

            <!-- Dynamic Credit Dimensions -->
            <div class="dimensions-grid" id="dimensionsContainer">
                <!-- Dynamically injected dimension items -->
            </div>
        </div>

        <!-- Bento Card: Funding Path Recommendations (Right - Col 8) -->
        <div class="bento-card col-recommendations">
            <div class="card-header">
                <div class="card-title-group">
                    <div class="card-label">Strategic Allocation</div>
                    <div class="card-title">Matched Funding Pathways</div>
                </div>
                <span class="preview-badge" style="color: var(--accent-emerald);">Highly Compatible</span>
            </div>

            <div class="path-list" id="pathRecommendationContainer">
                <!-- Dynamically calculated paths depending on selection rules -->
            </div>
        </div>

        <!-- Bento Card: Risk Assessment Flags (Left - Col 4) -->
        <div class="bento-card col-risk">
            <div class="card-header">
                <div class="card-title-group">
                    <div class="card-label">Underwriting Risk</div>
                    <div class="card-title">Risk Engine Triggers</div>
                </div>
            </div>
            <div class="risk-list" id="riskFlagsContainer">
                <!-- Dynamic risk items loaded -->
            </div>
        </div>

        <!-- Bento Card: White-Labeled Shared View Preview (Right - Col 8) -->
        <div class="bento-card col-whitelabel" id="whiteLabelComponent">
            <div class="card-header">
                <div class="card-title-group">
                    <div class="card-label" id="wlBrandSubtitle">Public Access Client Portal</div>
                    <div class="card-title" id="wlBrandTitle">VALOIS Partner Delivery Node</div>
                </div>
                <span class="preview-badge" id="wlModeLabel">Secure Client Vault</span>
            </div>

            <p class="vertical-desc" style="margin-bottom: 16px;" id="wlDesc">
                This public secure view represents the white-labeled presentation delivery framework. Underwriting rules, proprietary credit matrices, and system debug diagnostics have been stripped to maintain compliance.
            </p>

            <div class="preview-pane">
                <div class="preview-header">
                    <span style="font-weight: 600;" id="wlSelectedName">Borrower Presentation Workspace</span>
                    <span class="preview-badge" style="background: rgba(16, 185, 129, 0.1); color: var(--accent-emerald);">Pre-Verified Status</span>
                </div>
                <div class="preview-body-content">
                    <div class="preview-value-blocks">
                        <div class="val-block">
                            <div class="v-stat-lbl">Aggregate Limit</div>
                            <div class="v-stat-val" style="font-size: 16px; margin-top: 4px;" id="wlAggLimit">$0.00</div>
                        </div>
                        <div class="val-block">
                            <div class="v-stat-lbl">Readiness Classification</div>
                            <div class="v-stat-val" style="font-size: 16px; margin-top: 4px; color: var(--accent-purple);" id="wlClass">Tier-A</div>
                        </div>
                        <div class="val-block">
                            <div class="v-stat-lbl">Estimated Weighted Cost</div>
                            <div class="v-stat-val" style="font-size: 16px; margin-top: 4px;" id="wlCost">-- %</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Verticals Section Header (Col 12) -->
        <div class="verticals-header">
            <h3 style="font-size: 14px; font-weight: 600; text-transform: uppercase; letter-spacing: 1.5px; color: var(--text-secondary);">Vertical Funding Modules</h3>
        </div>

        <!-- Dynamic Vertical Route Cards (6 items span 4 columns each) -->
        <!-- Vertical 1: Working Capital -->
        <div class="bento-card col-vertical" id="route-working-capital">
            <div class="vertical-meta">
                <div class="vertical-icon-wrap">⚡</div>
                <span class="preview-badge">30-Sec Check</span>
            </div>
            <div>
                <h4 style="font-size: 15px; font-weight: 600; margin: 12px 0 4px 0;">Working Capital</h4>
                <p class="vertical-desc">Optimized short-term liquidity models aligning invoice, inventory, and payroll lifecycles cleanly.</p>
            </div>
            <div class="vertical-stats">
                <div class="v-stat">
                    <span class="v-stat-lbl">LTV Max</span>
                    <span class="v-stat-val" id="wc-ltv">--</span>
                </div>
                <div class="v-stat">
                    <span class="v-stat-lbl">Target APR</span>
                    <span class="v-stat-val" id="wc-apr">--</span>
                </div>
            </div>
        </div>

        <!-- Vertical 2: Ecommerce Funding -->
        <div class="bento-card col-vertical" id="route-ecommerce">
            <div class="vertical-meta">
                <div class="vertical-icon-wrap">🛒</div>
                <span class="preview-badge">Direct Sync</span>
            </div>
            <div>
                <h4 style="font-size: 15px; font-weight: 600; margin: 12px 0 4px 0;">E-commerce Capital</h4>
                <p class="vertical-desc">Non-dilutive marketing and inventory financing scaled against dynamic store revenue streams.</p>
            </div>
            <div class="vertical-stats">
                <div class="v-stat">
                    <span class="v-stat-lbl">Multiples</span>
                    <span class="v-stat-val" id="ecom-mult">--</span>
                </div>
                <div class="v-stat">
                    <span class="v-stat-lbl">Min Monthly Rev</span>
                    <span class="v-stat-val" id="ecom-min">--</span>
                </div>
            </div>
        </div>

        <!-- Vertical 3: Startup Funding -->
        <div class="bento-card col-vertical" id="route-startup">
            <div class="vertical-meta">
                <div class="vertical-icon-wrap">🚀</div>
                <span class="preview-badge">Venture Debt</span>
            </div>
            <div>
                <h4 style="font-size: 15px; font-weight: 600; margin: 12px 0 4px 0;">Startup / Venture</h4>
                <p class="vertical-desc">Extended non-dilutive lines designed to extend runway between financing rounds and protect equity.</p>
            </div>
            <div class="vertical-stats">
                <div class="v-stat">
                    <span class="v-stat-lbl">Leverage Limit</span>
                    <span class="v-stat-val" id="startup-lev">--</span>
                </div>
                <div class="v-stat">
                    <span class="v-stat-lbl">Warrant Cover</span>
                    <span class="v-stat-val" id="startup-warr">--</span>
                </div>
            </div>
        </div>

        <!-- Vertical 4: Equipment Funding -->
        <div class="bento-card col-vertical" id="route-equipment">
            <div class="vertical-meta">
                <div class="vertical-icon-wrap">⚙️</div>
                <span class="preview-badge">Hard Asset</span>
            </div>
            <div>
                <h4 style="font-size: 15px; font-weight: 600; margin: 12px 0 4px 0;">Equipment Financing</h4>
                <p class="vertical-desc">High-LTV structural asset-backed instruments to acquire hardware without locking capital.</p>
            </div>
            <div class="vertical-stats">
                <div class="v-stat">
                    <span class="v-stat-lbl">Max Term</span>
                    <span class="v-stat-val" id="equip-term">--</span>
                </div>
                <div class="v-stat">
                    <span class="v-stat-lbl">Amortization</span>
                    <span class="v-stat-val" id="equip-amort">--</span>
                </div>
            </div>
        </div>

        <!-- Vertical 5: Real Estate Funding -->
        <div class="bento-card col-vertical" id="route-real-estate">
            <div class="vertical-meta">
                <div class="vertical-icon-wrap">🏢</div>
                <span class="preview-badge">Bridge Asset</span>
            </div>
            <div>
                <h4 style="font-size: 15px; font-weight: 600; margin: 12px 0 4px 0;">Commercial Real Estate</h4>
                <p class="vertical-desc">Bridge & permanent lending instruments built around asset collateral appraisal and cash-flow yields.</p>
            </div>
            <div class="vertical-stats">
                <div class="v-stat">
                    <span class="v-stat-lbl">LTV Threshold</span>
                    <span class="v-stat-val" id="re-ltv">--</span>
                </div>
                <div class="v-stat">
                    <span class="v-stat-lbl">DSCR Target</span>
                    <span class="v-stat-val" id="re-dscr">--</span>
                </div>
            </div>
        </div>

        <!-- Vertical 6: Acquisition Funding -->
        <div class="bento-card col-vertical" id="route-acquisition">
            <div class="vertical-meta">
                <div class="vertical-icon-wrap">🤝</div>
                <span class="preview-badge">LBO / M&A</span>
            </div>
            <div>
                <h4 style="font-size: 15px; font-weight: 600; margin: 12px 0 4px 0;">Acquisition & Buyouts</h4>
                <p class="vertical-desc">Strategic capitalization designed to fuel market expansion, buyout scenarios, or merger transactions.</p>
            </div>
            <div class="vertical-stats">
                <div class="v-stat">
                    <span class="v-stat-lbl">Debt Service Cov</span>
                    <span class="v-stat-val" id="acq-dscr">--</span>
                </div>
                <div class="v-stat">
                    <span class="v-stat-lbl">Target Leverage</span>
                    <span class="v-stat-val" id="acq-lev">--</span>
                </div>
            </div>
        </div>

        <!-- Partner/Affiliate CTA Area (Col 12) -->
        <div class="bento-card col-partner">
            <div class="partner-content">
                <div class="card-label" style="color: var(--text-primary); margin-bottom: 4px;">Partner Ecosystem Integration</div>
                <h3 style="font-size: 18px; font-weight: 600; margin-bottom: 8px;">Instantly syndicate pre-approved capital requirements</h3>
                <p class="vertical-desc" style="max-width: 500px;">Connect directly via Valois’ institutional network nodes. Share clean borrower credentials securely without exposing sensitive private financials.</p>
            </div>
            <button class="partner-btn" onclick="triggerPartnerAction()">Generate Partner Code</button>
        </div>

    </div>

    <!-- Footnotes Compliance Component -->
    <footer>
        <p class="compliance-text">
            * VALOIS Funding Intelligence Engine utilizes proprietary simulations and does not represent a direct offer to lend. Data processed on this user client system assumes configurations conforming to FDIC and SEC-compliant banking institutions. Real values may vary based on exact live market valuations, underwriting, and risk assessments.
        </p>
        <div class="compliance-row">
            <span>© Valois Technology Group. All Rights Reserved. Private & Institutional Use Only.</span>
            <span>FCRA Safe Harbor Secured // SSL-v2 Protocol</span>
        </div>
    </footer>
</div>

<!-- Analyst / Debug Drawer Button -->
<button class="debug-trigger-btn" onclick="toggleDebugDrawer()">
    <span>⚡</span> SYSTEM CONTROL & CONFIG FILES
</button>

<!-- Bottom Analyst Drawer (Debug Interface) -->
<div class="debug-drawer" id="analystDrawer">
    <div class="debug-header">
        <div class="debug-title">Analyst Engine & Simulation Configs Panel</div>
        <div class="debug-tabs">
            <button class="debug-tab active" onclick="switchDebugTab('archetypes')">borrower_archetypes.json</button>
            <button class="debug-tab" onclick="switchDebugTab('providers')">providers.json</button>
            <button class="debug-tab" onclick="switchDebugTab('routing')">routing_logic.json</button>
            <button class="debug-tab" onclick="switchDebugTab('vercel')">Vercel Deployment Guide</button>
        </div>
        <button class="close-debug-btn" onclick="toggleDebugDrawer()">✕</button>
    </div>
    <div class="debug-body" id="debugContent">
        <!-- Will display selected configuration contents dynamically -->
    </div>
</div>

<script>
    // Embedded simulation JSON data structures matching requested design pattern:
    // borrower_archetypes.json, providers.json, products.json, routing_logic.json,
    // recommendation_weights.json, risk_flags.json, readiness_dimensions.json

    const borrower_archetypes = {
        "saas_series_a": {
            "name": "SaaS Platform (Series A)",
            "arr": 4500000,
            "mrr": 375000,
            "runway_months": 18,
            "dscr": 1.45,
            "ebitda": -250000,
            "readinessScore": 84,
            "risk_triggers": ["negative_ebitda", "elevated_cac_payback"],
            "dimensions": {
                "capital": 88,
                "capacity": 79,
                "collateral": 55,
                "character": 92,
                "conditions": 85
            },
            "verticals_config": {
                "wc_ltv": "N/A", "wc_apr": "8.4%",
                "ecom_mult": "N/A", "ecom_min": "N/A",
                "startup_lev": "3.5x ARR", "startup_warr": "0.15%",
                "equip_term": "48 M", "equip_amort": "Straight",
                "re_ltv": "N/A", "re_dscr": "N/A",
                "acq_dscr": "1.35x", "acq_lev": "2.8x"
            }
        },
        "ecom_scaleup": {
            "name": "E-Commerce Velocity Scaleup",
            "arr": 8200000,
            "mrr": 680000,
            "runway_months": 24,
            "dscr": 1.20,
            "ebitda": 150000,
            "readinessScore": 76,
            "risk_triggers": ["inventory_concentration", "supply_chain_exposure"],
            "dimensions": {
                "capital": 65,
                "capacity": 85,
                "collateral": 70,
                "character": 80,
                "conditions": 75
            },
            "verticals_config": {
                "wc_ltv": "1.25x Inventory", "wc_apr": "9.2%",
                "ecom_mult": "3.5x MRR", "ecom_min": "$100k",
                "startup_lev": "N/A", "startup_warr": "N/A",
                "equip_term": "36 M", "equip_amort": "Declining",
                "re_ltv": "N/A", "re_dscr": "N/A",
                "acq_dscr": "N/A", "acq_lev": "N/A"
            }
        },
        "heavy_logistics": {
            "name": "Apex Cargo & Logistics",
            "arr": 15400000,
            "mrr": 1280000,
            "runway_months": 48,
            "dscr": 2.15,
            "ebitda": 1250000,
            "readinessScore": 92,
            "risk_triggers": ["high_asset_maintenance"],
            "dimensions": {
                "capital": 95,
                "capacity": 94,
                "collateral": 98,
                "character": 90,
                "conditions": 82
            },
            "verticals_config": {
                "wc_ltv": "0.85x Accounts Rec", "wc_apr": "7.1%",
                "ecom_mult": "N/A", "ecom_min": "N/A",
                "startup_lev": "N/A", "startup_warr": "N/A",
                "equip_term": "72 M", "equip_amort": "Linear",
                "re_ltv": "75%", "re_dscr": "1.50x",
                "acq_dscr": "1.75x", "acq_lev": "3.2x"
            }
        },
        "mainstreet_med": {
            "name": "Core-Surgical Care Group",
            "arr": 3200000,
            "mrr": 266000,
            "runway_months": 60,
            "dscr": 1.80,
            "ebitda": 450000,
            "readinessScore": 88,
            "risk_triggers": [],
            "dimensions": {
                "capital": 85,
                "capacity": 90,
                "collateral": 80,
                "character": 95,
                "conditions": 90
            },
            "verticals_config": {
                "wc_ltv": "1.00x Rec", "wc_apr": "6.8%",
                "ecom_mult": "N/A", "ecom_min": "N/A",
                "startup_lev": "N/A", "startup_warr": "N/A",
                "equip_term": "60 M", "equip_amort": "Straight",
                "re_ltv": "80%", "re_dscr": "1.25x",
                "acq_dscr": "1.45x", "acq_lev": "2.5x"
            }
        }
    };

    const providers = [
        { "id": "p_valois_debt", "name": "Valois Credit Opportunities", "category": "Institutional Debt" },
        { "id": "p_vanguard", "name": "Vanguard Secured Lending", "category": "Asset-Backed Banking" },
        { "id": "p_apex_capital", "name": "Apex Velocity Finance", "category": "Growth Capital" }
    ];

    const products = [
        { "id": "prod_rev_debt", "name": "Revenue-Based Non-Dilutive Bond", "provider_id": "p_valois_debt" },
        { "id": "prod_venture_line", "name": "Venture Debt Runway Line", "provider_id": "p_valois_debt" },
        { "id": "prod_loc_secured", "name": "Asset-Backed Credit Facility", "provider_id": "p_vanguard" },
        { "id": "prod_growth_cash", "name": "Dynamic Working Capital Advance", "provider_id": "p_apex_capital" }
    ];

    const routing_logic = {
        "rules": [
            {
                "product_id": "prod_venture_line",
                "min_score": 80,
                "min_arr": 3000000,
                "max_leverage_arr_ratio": 0.45,
                "base_apr": "8.5%"
            },
            {
                "product_id": "prod_loc_secured",
                "min_score": 75,
                "min_dscr": 1.15,
                "max_leverage_arr_ratio": 0.35,
                "base_apr": "6.9%"
            },
            {
                "product_id": "prod_rev_debt",
                "min_score": 70,
                "min_arr": 1500000,
                "max_leverage_arr_ratio": 0.30,
                "base_apr": "9.2%"
            },
            {
                "product_id": "prod_growth_cash",
                "min_score": 65,
                "min_arr": 1000000,
                "max_leverage_arr_ratio": 0.25,
                "base_apr": "11.0%"
            }
        ]
    };

    const risk_flags = {
        "negative_ebitda": { "level": "Medium", "message": "EBITDA burn limits traditional cash-flow lending models." },
        "elevated_cac_payback": { "level": "Low", "message": "CAC Payback period exceeds target threshold metrics." },
        "inventory_concentration": { "level": "High", "message": "Supply node concentration poses operational pipeline threats." },
        "supply_chain_exposure": { "level": "Medium", "message": "Exposure to overseas customs clearances might restrict collateral validation." },
        "high_asset_maintenance": { "level": "Low", "message": "Capital expenditures forecast might impact debt servicing capability." }
    };

    const readiness_dimensions = {
        "capital": { "title": "Capital", "desc": "Equity-to-debt ratio" },
        "capacity": { "title": "Capacity", "desc": "Historical/expected runway & revenue" },
        "collateral": { "title": "Collateral", "desc": "Secured physical or IP assets" },
        "character": { "title": "Character", "desc": "Lender trust & executive history" },
        "conditions": { "title": "Conditions", "desc": "Market trends and macro risk vectors" }
    };

    // State Management
    let currentArchetypeKey = "saas_series_a";
    let whiteLabelModeActive = false;

    // Initialization
    window.onload = () => {
        // Build Archetype Switcher Select Dropdown options
        const select = document.getElementById("archetypeSelect");
        for (const [key, val] of Object.entries(borrower_archetypes)) {
            const opt = document.createElement("option");
            opt.value = key;
            opt.textContent = val.name;
            select.appendChild(opt);
        }

        loadArchetype(currentArchetypeKey);
        switchDebugTab('archetypes');
    };

    // Core Dynamic Rendering Engine
    function loadArchetype(key) {
        currentArchetypeKey = key;
        const arch = borrower_archetypes[key];

        // 1. Update Scorecard
        const targetScore = arch.readinessScore;
        updateScoreCircle(targetScore);

        // Update 5 Credit Dimensions
        const container = document.getElementById("dimensionsContainer");
        container.innerHTML = "";
        for (const [dimKey, val] of Object.entries(arch.dimensions)) {
            const labelMeta = readiness_dimensions[dimKey];
            container.innerHTML += `
                <div class="dimension-item">
                    <div class="dimension-meta">
                        <span class="dimension-name">${labelMeta.title}</span>
                        <span class="dimension-val">${val}%</span>
                    </div>
                    <div class="dimension-bar-bg">
                        <div class="dimension-bar-fill" style="width: ${val}%;"></div>
                    </div>
                </div>
            `;
        }

        // 2. Compute Routing & Load Recommendations
        const recContainer = document.getElementById("pathRecommendationContainer");
        recContainer.innerHTML = "";

        // Dynamic Rule Matching Compilation Logic
        const matchedProducts = [];
        routing_logic.rules.forEach(rule => {
            let matches = true;
            if (targetScore < rule.min_score) matches = false;
            if (arch.arr < (rule.min_arr || 0)) matches = false;
            if (rule.min_dscr && arch.dscr < rule.min_dscr) matches = false;

            if (matches) {
                const productInfo = products.find(p => p.id === rule.product_id);
                const providerInfo = providers.find(p => p.id === productInfo.provider_id);
                
                // Determine confidence & max capacity leverage based on system formulas
                const leverageMax = Math.round(arch.arr * rule.max_leverage_arr_ratio);
                const confidence = targetScore > 85 ? "High Match" : "Moderate Match";
                const confClass = targetScore > 85 ? "conf-high" : "conf-medium";

                matchedProducts.push({
                    name: productInfo.name,
                    provider: providerInfo.name,
                    capacity: `$${(leverageMax / 1000000).toFixed(2)}M`,
                    apr: rule.base_apr,
                    confidence: confidence,
                    confClass: confClass
                });
            }
        });

        if (matchedProducts.length === 0) {
            recContainer.innerHTML = `<div class="path-row"><div class="path-title-text" style="color:var(--accent-rose);">No pre-qualified institutional facilities matching current routing rules.</div></div>`;
        } else {
            matchedProducts.forEach(prod => {
                recContainer.innerHTML += `
                    <div class="path-row">
                        <div class="path-meta-primary">
                            <span class="path-title-text">${prod.name}</span>
                            <span class="path-provider">${prod.provider}</span>
                        </div>
                        <div class="path-metric">
                            <span class="path-metric-lbl">Max Capacity</span>
                            <span class="path-metric-val">${prod.capacity}</span>
                        </div>
                        <div class="path-metric">
                            <span class="path-metric-lbl">Indicative Cost</span>
                            <span class="path-metric-val" style="color: var(--accent-purple);">${prod.apr}</span>
                        </div>
                        <div class="path-metric">
                            <span class="path-metric-lbl">System Confidence</span>
                            <span class="${prod.confClass} confidence-pill">${prod.confidence}</span>
                        </div>
                        <div class="action-icon">→</div>
                    </div>
                `;
            });
        }

        // 3. Update Underwriting Risk Triggers
        const riskContainer = document.getElementById("riskFlagsContainer");
        riskContainer.innerHTML = "";
        
        if (arch.risk_triggers.length === 0) {
            riskContainer.innerHTML = `
                <div class="risk-item" style="background: rgba(16, 185, 129, 0.03); border-color: rgba(16, 185, 129, 0.1);">
                    <div class="risk-icon" style="color: var(--accent-emerald);">✓</div>
                    <div class="risk-details">
                        <div class="risk-title" style="color: var(--accent-emerald);">0 Active Risk Triggers</div>
                        <div class="risk-desc">Credit dimensions fall clean of system risk parameters.</div>
                    </div>
                </div>
            `;
        } else {
            arch.risk_triggers.forEach(trigger => {
                const spec = risk_flags[trigger];
                riskContainer.innerHTML += `
                    <div class="risk-item">
                        <div class="risk-icon">⚠️</div>
                        <div class="risk-details">
                            <div class="risk-title">${spec.level} Risk - ${trigger.toUpperCase().replace(/_/g, " ")}</div>
                            <div class="risk-desc">${spec.message}</div>
                        </div>
                    </div>
                `;
            });
        }

        // 4. Update Vertical Route Modules Stats
        for (const [vKey, val] of Object.entries(arch.verticals_config)) {
            const elem = document.getElementById(vKey);
            if (elem) {
                elem.textContent = val;
            }
        }

        // 5. Update White-Label Component Data
        const aggregatedLimitNum = Math.round(arch.arr * 0.45);
        document.getElementById("wlAggLimit").textContent = `$${(aggregatedLimitNum/1000000).toFixed(2)}M`;
        document.getElementById("wlClass").textContent = targetScore > 85 ? "Enterprise A+" : "Standard Tier-B";
        document.getElementById("wlCost").textContent = targetScore > 85 ? "6.85% (Weighted)" : "8.95% (Weighted)";
        document.getElementById("wlSelectedName").textContent = arch.name + " Secure Workspace";

        // Push current variables to the live Debug Console view if it's active
        updateConsoleOutput();
    }

    // Radial Score Progress Bar Animation Utility
    function updateScoreCircle(score) {
        const circle = document.getElementById("scoreValueArc");
        const radius = circle.r.baseVal.value;
        const circumference = 2 * Math.PI * radius;
        const offset = circumference - (score / 100) * circumference;
        
        circle.style.strokeDasharray = circumference;
        circle.style.strokeDashoffset = offset;

        // Animate counter
        const countDisplay = document.getElementById("scoreNumDisplay");
        let start = 0;
        const interval = setInterval(() => {
            if (start >= score) {
                clearInterval(interval);
                countDisplay.textContent = score;
            } else {
                start++;
                countDisplay.textContent = start;
            }
        }, 15);

        // Update Score Rating Category text
        const tierDisplay = document.getElementById("scoreTierDisplay");
        if (score >= 90) {
            tierDisplay.textContent = "Excellent Index";
            tierDisplay.style.color = "var(--accent-emerald)";
        } else if (score >= 80) {
            tierDisplay.textContent = "Premium Index";
            tierDisplay.style.color = "var(--accent-purple)";
        } else if (score >= 70) {
            tierDisplay.textContent = "Optimal Match";
            tierDisplay.style.color = "var(--accent-amber)";
        } else {
            tierDisplay.textContent = "Sub-Optimal";
            tierDisplay.style.color = "var(--accent-rose)";
        }
    }

    // Toggle White-Label View
    function toggleWhiteLabel() {
        whiteLabelModeActive = !whiteLabelModeActive;
        const body = document.body;
        const indicator = document.getElementById("whiteLabelIndicator");
        const wlComponent = document.getElementById("whiteLabelComponent");

        if (whiteLabelModeActive) {
            body.classList.add("white-label-mode");
            indicator.style.background = "var(--accent-emerald)";
            indicator.style.boxShadow = "0 0 8px var(--accent-emerald)";
            document.getElementById("whiteLabelText").textContent = "Public Secure Mode Active";
            
            // Transform brand parameters & public components visually to show bespoke styling
            document.getElementById("wlBrandTitle").textContent = "Beside Capital - Client Vault";
            document.getElementById("wlBrandSubtitle").textContent = "Syndicated Delivery Framework";
            document.getElementById("wlModeLabel").textContent = "Client Interface Active";
            wlComponent.style.border = "1px solid var(--accent-emerald)";
        } else {
            body.classList.remove("white-label-mode");
            indicator.style.background = "var(--accent-purple)";
            indicator.style.boxShadow = "0 0 8px var(--accent-purple)";
            document.getElementById("whiteLabelText").textContent = "White-Label Delivery";

            document.getElementById("wlBrandTitle").textContent = "VALOIS Partner Delivery Node";
            document.getElementById("wlBrandSubtitle").textContent = "Public Access Client Portal";
            document.getElementById("wlModeLabel").textContent = "Secure Client Vault";
            wlComponent.style.border = "1px dashed var(--border-muted)";
        }
    }

    // Partner Syndicated CTA Alert
    function triggerPartnerAction() {
        const arch = borrower_archetypes[currentArchetypeKey];
        const aggregateLimit = Math.round(arch.arr * 0.45);
        const code = `VALOIS-${Math.random().toString(36).substr(2, 6).toUpperCase()}-NODE-${arch.readinessScore}`;
        alert(`Syndicated Partner Payload Generated!\n\nReference: ${code}\nVerified Limit: $${(aggregateLimit/1000000).toFixed(2)}M\nSecurity Standard: SEC-256 compliant export token generated.`);
    }

    // Analyst Drawer Tabs & Debug Output Engine
    let activeDebugTab = "archetypes";

    function toggleDebugDrawer() {
        const drawer = document.getElementById("analystDrawer");
        drawer.classList.toggle("open");
    }

    function switchDebugTab(tabName) {
        activeDebugTab = tabName;
        const tabs = document.querySelectorAll(".debug-tab");
        tabs.forEach(tab => {
            tab.classList.remove("active");
            if (tab.innerText.includes(tabName) || (tabName === 'vercel' && tab.innerText.includes('Vercel'))) {
                tab.classList.add("active");
            }
        });
        updateConsoleOutput();
    }

    function updateConsoleOutput() {
        const output = document.getElementById("debugContent");
        
        if (activeDebugTab === "archetypes") {
            output.innerHTML = `
                <div style="color: #a1a1aa; margin-bottom: 12px;">// Loaded: borrower_archetypes.json - Representing borrower personas parameters</div>
                <pre style="color: #c084fc;">${JSON.stringify(borrower_archetypes, null, 2)}</pre>
            `;
        } else if (activeDebugTab === "providers") {
            output.innerHTML = `
                <div style="color: #a1a1aa; margin-bottom: 12px;">// Loaded: providers.json & products.json - Matched institutional channels</div>
                <pre style="color: #22d3ee;">${JSON.stringify({ providers, products }, null, 2)}</pre>
            `;
        } else if (activeDebugTab === "routing") {
            output.innerHTML = `
                <div style="color: #a1a1aa; margin-bottom: 12px;">// Loaded: routing_logic.json & recommendation_weights.json - Live underwriting triggers</div>
                <pre style="color: #34d399;">${JSON.stringify(routing_logic, null, 2)}</pre>
            `;
        } else if (activeDebugTab === "vercel") {
            output.innerHTML = `
                <div class="deployment-guide">
                    <h3 style="color: #f4f4f7; font-size: 14px; margin-bottom: 12px;">Deploy Valois Funding Intelligence to Vercel instantly</h3>
                    <p>To deploy this high-fidelity premium single page application directly on Vercel platform, use the following simple file layout framework:</p>
                    
                    <div class="code-block">
.
├── index.html       (Copy the entirety of this unified premium template)
├── package.json     (Minimal project metadata block)
└── vercel.json      (Deploy configurations routing file)
                    </div>

                    <h4 style="color: #f4f4f7; font-size: 12px; margin: 16px 0 8px 0;">Step 1: package.json Setup</h4>
                    <pre class="code-block">{
  "name": "valois-funding-intelligence",
  "version": "2.0.0",
  "scripts": {
    "start": "serve ."
  }
}</pre>

                    <h4 style="color: #f4f4f7; font-size: 12px; margin: 16px 0 8px 0;">Step 2: Install Vercel CLI & Deploy</h4>
                    <pre class="code-block">npm i -g vercel\nvercel deploy</pre>
                    <p style="color: var(--accent-emerald);">✔ Code compiles natively as a secure static web application requiring zero backend overhead.</p>
                </div>
            `;
        }
    }
</script>

</body>
</html>
```
```
import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<!-- Navigation -->
    <nav class="fixed top-0 w-full z-50 border-b border-white/5 bg-black/50 backdrop-blur-md">
        <div class="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
            <div class="flex items-center gap-2">
                <div class="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                    <span class="font-bold text-white">F</span>
                </div>
                <span class="font-bold text-xl tracking-tight">FundingAI</span>
            </div>
            <div class="hidden md:flex gap-8 text-sm text-gray-400">
                <a href="#features" class="hover:text-white transition">Features</a>
                <a href="#workflow" class="hover:text-white transition">Workflow</a>
                <a href="#pricing" class="hover:text-white transition">Pricing</a>
            </div>
            <button class="text-sm font-medium border border-white/10 px-4 py-2 rounded-lg hover:bg-white/5 transition">
                Log In
            </button>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="relative pt-32 pb-20 px-6 overflow-hidden">
        <div class="glow-orb top-20 left-1/4"></div>
        <div class="glow-orb bottom-20 right-1/4" style="background: radial-gradient(circle, rgba(139, 92, 246, 0.1) 0%, transparent 70%);"></div>
        
        <div class="max-w-4xl mx-auto text-center relative z-10">
            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-blue-500/30 bg-blue-500/5 text-blue-400 text-xs font-mono mb-8">
                <span class="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></span>
                V2.0 NOW LIVE: SMARTER ROUTING ENGINE
            </div>
            <h1 class="text-5xl md:text-7xl font-bold mb-6 tracking-tight leading-[1.1]">
                An AI Funding Strategist for Entrepreneurs Who <span class="gradient-text italic text-gray-500">Hate Banker Theater.</span>
            </h1>
            <p class="text-lg text-gray-400 mb-10 max-w-2xl mx-auto">
                Get instant guidance on funding options, readiness gaps, documents needed, and next steps before you ever talk to a lender.
            </p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <button class="btn-premium">Try the AI Funding Strategist</button>
                <button class="px-6 py-3 border border-white/10 rounded-lg font-medium hover:bg-white/5 transition">Watch Demo</button>
            </div>
        </div>

        <!-- AI Assistant Preview -->
        <div class="max-w-5xl mx-auto mt-20 relative">
            <div class="glass-card rounded-2xl overflow-hidden shadow-2xl">
                <div class="border-b border-white/5 p-4 flex items-center justify-between bg-white/5">
                    <div class="flex gap-2">
                        <div class="w-3 h-3 rounded-full bg-red-500/20 border border-red-500/40"></div>
                        <div class="w-3 h-3 rounded-full bg-yellow-500/20 border border-yellow-500/40"></div>
                        <div class="w-3 h-3 rounded-full bg-green-500/20 border border-green-500/40"></div>
                    </div>
                    <div class="text-xs font-mono text-gray-500 tracking-widest uppercase">Strategist-Terminal v4.2</div>
                    <div class="w-4"></div>
                </div>
                <div class="grid md:grid-cols-3 min-h-[500px]">
                    <div class="col-span-1 border-r border-white/5 p-6 bg-black/20">
                        <div class="mb-8">
                            <label class="text-[10px] font-mono text-gray-500 uppercase tracking-tighter block mb-4">Funding Readiness</label>
                            <div class="relative w-32 h-32 mx-auto flex items-center justify-center">
                                <svg class="w-full h-full transform -rotate-90">
                                    <circle cx="64" cy="64" r="58" stroke="currentColor" stroke-width="8" fill="transparent" class="text-white/5" />
                                    <circle cx="64" cy="64" r="58" stroke="currentColor" stroke-width="8" fill="transparent" class="text-blue-500" stroke-dasharray="364.4" stroke-dashoffset="100" />
                                </svg>
                                <span class="absolute text-2xl font-bold">72%</span>
                            </div>
                        </div>
                        <div class="space-y-4">
                            <div class="p-3 bg-white/5 rounded-lg border border-white/5">
                                <div class="text-[10px] text-gray-400 mb-1">RECOMMENDED PATH</div>
                                <div class="text-sm font-semibold">SBA 7(a) Express</div>
                            </div>
                            <div class="p-3 bg-white/5 rounded-lg border border-white/5">
                                <div class="text-[10px] text-gray-400 mb-1">PROBABILITY</div>
                                <div class="text-sm font-semibold text-green-400">High Confidence</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-span-2 p-6 flex flex-col justify-between">
                        <div class="space-y-6 overflow-y-auto">
                            <div class="flex gap-4">
                                <div class="w-8 h-8 rounded-full bg-blue-600 flex-shrink-0 flex items-center justify-center text-[10px]">AI</div>
                                <div class="bg-white/5 p-4 rounded-2xl rounded-tl-none border border-white/5 text-sm max-w-[80%] leading-relaxed">
                                    I've analyzed your trailing 12 months (TTM) revenue. You qualify for venture debt, but your debt-service coverage ratio (DSCR) is tight for traditional bank loans. Should we look at bridge options or optimize your readiness for an SBA 7(a)?
                                </div>
                            </div>
                            <div class="flex gap-4 flex-row-reverse">
                                <div class="w-8 h-8 rounded-full bg-gray-700 flex-shrink-0 flex items-center justify-center text-[10px]">YOU</div>
                                <div class="bg-blue-600/20 p-4 rounded-2xl rounded-tr-none border border-blue-500/20 text-sm max-w-[80%] leading-relaxed">
                                    What documents are missing for the SBA 7(a) path?
                                </div>
                            </div>
                        </div>
                        <div class="mt-6 flex gap-2">
                            <input type="text" placeholder="Ask about your funding readiness..." class="flex-1 bg-white/5 border-white/10 text-sm">
                            <button class="bg-blue-600 px-4 rounded-lg hover:bg-blue-500 transition">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Bento Grid Features -->
    <section id="features" class="py-24 px-6 max-w-7xl mx-auto">
        <h2 class="text-3xl font-bold mb-12">The Strategist's Toolkit</h2>
        <div class="bento-grid">
            <div class="col-span-12 md:col-span-8 glass-card rounded-3xl p-8 min-h-[300px] flex flex-col justify-between">
                <div>
                    <div class="w-12 h-12 bg-blue-500/10 rounded-xl flex items-center justify-center mb-6 border border-blue-500/20">
                        <svg class="w-6 h-6 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>
                    </div>
                    <h3 class="text-2xl font-semibold mb-2">Lender Routing Engine</h3>
                    <p class="text-gray-400 max-w-md">Our AI doesn't just list options; it simulates lender underwriting criteria to tell you where you actually have a shot at approval.</p>
                </div>
                <div class="mt-8 grid grid-cols-4 gap-4">
                    <div class="h-1 bg-blue-500 rounded-full"></div>
                    <div class="h-1 bg-white/10 rounded-full"></div>
                    <div class="h-1 bg-white/10 rounded-full"></div>
                    <div class="h-1 bg-white/10 rounded-full"></div>
                </div>
            </div>
            <div class="col-span-12 md:col-span-4 glass-card rounded-3xl p-8 flex flex-col items-center text-center justify-center">
                <div class="ai-orb mb-8"></div>
                <h3 class="text-xl font-semibold mb-2">24/7 Analysis</h3>
                <p class="text-gray-400 text-sm">Real-time credit readiness monitoring for your business.</p>
            </div>
            <div class="col-span-12 md:col-span-4 glass-card rounded-3xl p-8">
                <div class="w-10 h-10 bg-purple-500/10 rounded-lg flex items-center justify-center mb-6 border border-purple-500/20">
                    <svg class="w-5 h-5 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg>
                </div>
                <h3 class="text-xl font-semibold mb-2">Pre-Flight Vault</h3>
                <p class="text-gray-400 text-sm leading-relaxed">Securely organize and verify all required documentation before lenders see it.</p>
            </div>
            <div class="col-span-12 md:col-span-8 glass-card rounded-3xl p-8">
                <div class="flex flex-wrap gap-4">
                    <div class="flex-1 min-w-[200px]">
                        <h3 class="text-xl font-semibold mb-2">Next Steps Roadmap</h3>
                        <p class="text-gray-400 text-sm leading-relaxed">Don't guess what's next. Get a dynamic checklist of high-impact tasks to improve your funding odds.</p>
                    </div>
                    <div class="flex-shrink-0 bg-white/5 rounded-xl p-4 border border-white/10">
                        <div class="text-[10px] text-blue-400 font-mono mb-2 uppercase tracking-widest">Immediate Tasks</div>
                        <ul class="text-xs space-y-2">
                            <li class="flex items-center gap-2"><div class="w-1 h-1 bg-blue-500 rounded-full"></div> Update P&L for Q3</li>
                            <li class="flex items-center gap-2"><div class="w-1 h-1 bg-blue-500 rounded-full"></div> Clear AR over 90 days</li>
                            <li class="flex items-center gap-2"><div class="w-1 h-1 bg-blue-500 rounded-full"></div> Verify EIN Address</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Sample Questions -->
    <section class="py-20 bg-white/5 border-y border-white/5 px-6">
        <div class="max-w-4xl mx-auto">
            <h2 class="text-2xl font-bold mb-8 text-center">Ask Anything. No Judgement.</h2>
            <div class="grid sm:grid-cols-2 gap-4">
                <button class="p-4 text-left glass-card rounded-xl text-sm hover:border-white/20">
                    "Am I ready for a \$250k SBA loan right now?"
                </button>
                <button class="p-4 text-left glass-card rounded-xl text-sm hover:border-white/20">
                    "What's the difference between venture debt and a line of credit for my SaaS?"
                </button>
                <button class="p-4 text-left glass-card rounded-xl text-sm hover:border-white/20">
                    "My FICO is 680 but my revenue is \$2M. What are my options?"
                </button>
                <button class="p-4 text-left glass-card rounded-xl text-sm hover:border-white/20">
                    "What specific documents will a lender ask for regarding my R&D tax credits?"
                </button>
            </div>
        </div>
    </section>

    <!-- Workflow -->
    <section id="workflow" class="py-24 px-6 max-w-5xl mx-auto">
        <div class="text-center mb-16">
            <h2 class="text-4xl font-bold mb-4">The Readiness Workflow</h2>
            <p class="text-gray-400">Stop applying blindly. Start following the data.</p>
        </div>
        <div class="space-y-12 ml-6">
            <div class="relative workflow-step">
                <div class="absolute -left-[35px] top-1 w-6 h-6 rounded-full bg-blue-600 border-4 border-black flex items-center justify-center text-[10px] font-bold">1</div>
                <h4 class="text-xl font-semibold mb-2">Data Ingestion</h4>
                <p class="text-gray-400 max-w-lg">Connect your accounting software and credit profile. We scan for the same data points bankers look for.</p>
            </div>
            <div class="relative workflow-step">
                <div class="absolute -left-[35px] top-1 w-6 h-6 rounded-full bg-blue-600 border-4 border-black flex items-center justify-center text-[10px] font-bold">2</div>
                <h4 class="text-xl font-semibold mb-2">Readiness Gap Analysis</h4>
                <p class="text-gray-400 max-w-lg">Our AI identifies why you might be rejected before you ever submit an application.</p>
            </div>
            <div class="relative workflow-step">
                <div class="absolute -left-[35px] top-1 w-6 h-6 rounded-full bg-blue-600 border-4 border-black flex items-center justify-center text-[10px] font-bold">3</div>
                <h4 class="text-xl font-semibold mb-2">Lender Matching</h4>
                <p class="text-gray-400 max-w-lg">We route you to specific lenders who are actively funding businesses with your exact profile.</p>
            </div>
        </div>
    </section>

    <!-- Human Hand-off -->
    <section class="py-20 px-6">
        <div class="max-w-7xl mx-auto glass-card rounded-3xl p-12 bg-gradient-to-br from-blue-900/20 to-purple-900/10 border-blue-500/20 flex flex-col md:flex-row items-center justify-between gap-8">
            <div class="max-w-xl text-center md:text-left">
                <h2 class="text-3xl font-bold mb-4">Need a human touch?</h2>
                <p class="text-gray-400 text-lg">Once the AI has optimized your readiness, our senior strategists are available for a final review before you hit 'Apply'.</p>
            </div>
            <button class="bg-white text-black px-8 py-4 rounded-xl font-bold hover:scale-105 transition-transform">Book a Human Strategy Call</button>
        </div>
    </section>

    <!-- Pricing -->
    <section id="pricing" class="py-24 px-6 max-w-7xl mx-auto">
        <div class="text-center mb-16">
            <h2 class="text-4xl font-bold mb-4">Transparent Access</h2>
            <p class="text-gray-400">Tools for every stage of your funding journey.</p>
        </div>
        <div class="grid md:grid-cols-3 gap-8">
            <div class="glass-card p-8 rounded-2xl">
                <div class="text-blue-500 font-mono text-sm mb-4 uppercase tracking-widest">The Starter</div>
                <div class="text-4xl font-bold mb-6">Free</div>
                <ul class="space-y-4 mb-8 text-sm text-gray-400">
                    <li class="flex items-center gap-3">✓ Basic Readiness Scan</li>
                    <li class="flex items-center gap-3">✓ Limited AI Chat (10/mo)</li>
                    <li class="flex items-center gap-3">✓ Generic Checklist</li>
                </ul>
                <button class="w-full py-3 border border-white/10 rounded-lg hover:bg-white/5 transition">Get Started</button>
            </div>
            <div class="glass-card p-8 rounded-2xl border-blue-500/50 ring-1 ring-blue-500/50 bg-blue-500/5 relative">
                <div class="absolute -top-4 left-1/2 -translate-x-1/2 bg-blue-500 text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-widest">Most Popular</div>
                <div class="text-blue-400 font-mono text-sm mb-4 uppercase tracking-widest">The Strategist</div>
                <div class="text-4xl font-bold mb-2">\$49<span class="text-lg text-gray-500 font-normal">/mo</span></div>
                <p class="text-xs text-gray-500 mb-6 italic">Perfect for active fund-seekers</p>
                <ul class="space-y-4 mb-8 text-sm text-gray-200">
                    <li class="flex items-center gap-3">✓ Unlimited AI Strategist Chat</li>
                    <li class="flex items-center gap-3">✓ Full Financial Analysis</li>
                    <li class="flex items-center gap-3">✓ Automated Lender Routing</li>
                    <li class="flex items-center gap-3">✓ Document Vault Access</li>
                </ul>
                <button class="w-full btn-premium">Try Strategist Pro</button>
            </div>
            <div class="glass-card p-8 rounded-2xl">
                <div class="text-purple-500 font-mono text-sm mb-4 uppercase tracking-widest">The Founder Pro</div>
                <div class="text-4xl font-bold mb-2">\$199<span class="text-lg text-gray-500 font-normal">/mo</span></div>
                <p class="text-xs text-gray-500 mb-6 italic">For high-growth scale-ups</p>
                <ul class="space-y-4 mb-8 text-sm text-gray-400">
                    <li class="flex items-center gap-3">✓ Priority AI Processing</li>
                    <li class="flex items-center gap-3">✓ 1:1 Human Strategy Call (1/mo)</li>
                    <li class="flex items-center gap-3">✓ Custom Pitch Deck Review</li>
                    <li class="flex items-center gap-3">✓ White-glove Lender Intro</li>
                </ul>
                <button class="w-full py-3 border border-white/10 rounded-lg hover:bg-white/5 transition">Go Pro</button>
            </div>
        </div>
    </section>

    <!-- FAQ -->
    <section class="py-24 px-6 bg-white/2">
        <div class="max-w-3xl mx-auto">
            <h2 class="text-3xl font-bold mb-12 text-center">Frequently Asked Questions</h2>
            <div class="space-y-4">
                <details class="group glass-card rounded-xl">
                    <summary class="list-none p-6 flex justify-between items-center cursor-pointer font-medium">
                        How secure is my financial data?
                        <span class="group-open:rotate-180 transition-transform">↓</span>
                    </summary>
                    <div class="px-6 pb-6 text-gray-400 text-sm">
                        We use bank-level 256-bit AES encryption. Your data is never shared with lenders without your explicit permission after you've reviewed your readiness score.
                    </div>
                </details>
                <details class="group glass-card rounded-xl">
                    <summary class="list-none p-6 flex justify-between items-center cursor-pointer font-medium">
                        Are you a lender yourself?
                        <span class="group-open:rotate-180 transition-transform">↓</span>
                    </summary>
                    <div class="px-6 pb-6 text-gray-400 text-sm">
                        No. We are an independent strategy tool. Our goal is to provide unbiased data so you can get the best terms possible, rather than being pushed toward a specific high-interest product.
                    </div>
                </details>
                <details class="group glass-card rounded-xl">
                    <summary class="list-none p-6 flex justify-between items-center cursor-pointer font-medium">
                        What kind of funding can the AI help with?
                        <span class="group-open:rotate-180 transition-transform">↓</span>
                    </summary>
                    <div class="px-6 pb-6 text-gray-400 text-sm">
                        SBA 7(a) and 504 loans, Venture Debt, Revenue-Based Financing, Business Lines of Credit, Equipment Financing, and specialized SaaS debt.
                    </div>
                </details>
            </div>
        </div>
    </section>

    <!-- Final CTA -->
    <section class="py-32 px-6 relative overflow-hidden">
        <div class="glow-orb top-0 left-1/2 -translate-x-1/2 opacity-30"></div>
        <div class="max-w-4xl mx-auto text-center">
            <h2 class="text-5xl font-bold mb-8">Ready to see what lenders see?</h2>
            <p class="text-xl text-gray-400 mb-12">Join 4,000+ entrepreneurs using AI to skip the theater and get funded.</p>
            <button class="btn-premium px-12 py-5 text-lg">Start Your Free Readiness Scan</button>
            <p class="mt-6 text-gray-500 text-sm font-mono tracking-tighter">NO CREDIT SCORE IMPACT FOR INITIAL ANALYSIS</p>
        </div>
    </section>

    <!-- Footer -->
    <footer class="py-12 border-t border-white/5 px-6">
        <div class="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
            <div class="flex items-center gap-2">
                <div class="w-6 h-6 bg-blue-600 rounded flex items-center justify-center">
                    <span class="font-bold text-[10px] text-white">F</span>
                </div>
                <span class="font-bold text-lg tracking-tight">FundingAI</span>
            </div>
            <div class="text-gray-500 text-xs">
                © 2024 FundingAI Strategist Corp. All rights reserved. Built for Obsidian Neural Style.
            </div>
            <div class="flex gap-6 text-gray-500 text-xs">
                <a href="#" class="hover:text-white">Privacy</a>
                <a href="#" class="hover:text-white">Terms</a>
                <a href="#" class="hover:text-white">Support</a>
            </div>
        </div>
    </footer>
      ` }} />
    </main>
  );
}
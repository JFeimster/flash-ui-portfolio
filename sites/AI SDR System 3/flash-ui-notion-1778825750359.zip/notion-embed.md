### Generated UI Component

To use this in Notion:
1. Create a "/code" block
2. Set language to "HTML"
3. Paste the following:

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI SDR Engine | Vector Aura</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-deep: #030303;
            --card-bg: rgba(15, 15, 20, 0.7);
            --border: rgba(255, 255, 255, 0.08);
            --primary: #8b5cf6;
            --secondary: #ec4899;
            --accent: #06b6d4;
            --text-main: #f8fafc;
            --text-dim: #94a3b8;
            --aura-1: rgba(139, 92, 246, 0.15);
            --aura-2: rgba(236, 72, 153, 0.15);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            background-color: var(--bg-deep);
            color: var(--text-main);
            font-family: 'Inter', sans-serif;
            overflow-x: hidden;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        /* Vector Aura Backgrounds */
        .aura-blob {
            position: fixed;
            width: 600px;
            height: 600px;
            border-radius: 50%;
            filter: blur(120px);
            z-index: -1;
            opacity: 0.6;
            pointer-events: none;
        }
        .aura-1 { top: -100px; left: -100px; background: var(--aura-1); animation: drift 20s infinite alternate; }
        .aura-2 { bottom: -100px; right: -100px; background: var(--aura-2); animation: drift 25s infinite alternate-reverse; }

        @keyframes drift {
            from { transform: translate(0, 0) scale(1); }
            to { transform: translate(100px, 50px) scale(1.1); }
        }

        .sdr-container {
            width: 100%;
            max-width: 1100px;
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border);
            border-radius: 24px;
            padding: 40px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
            position: relative;
            overflow: hidden;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 40px;
        }

        .header-title h1 {
            font-size: 24px;
            font-weight: 700;
            letter-spacing: -0.02em;
            background: linear-gradient(to right, #fff, #94a3b8);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 4px;
        }

        .header-title p {
            color: var(--text-dim);
            font-size: 14px;
        }

        .status-badge {
            background: rgba(16, 185, 129, 0.1);
            border: 1px solid rgba(16, 185, 129, 0.2);
            color: #10b981;
            padding: 6px 12px;
            border-radius: 100px;
            font-size: 12px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .status-dot {
            width: 6px;
            height: 6px;
            background: #10b981;
            border-radius: 50%;
            box-shadow: 0 0 10px #10b981;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.4; }
            100% { opacity: 1; }
        }

        /* Input Grid */
        .config-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 48px;
        }

        .input-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .input-group label {
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--text-dim);
        }

        .input-field {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 14px 16px;
            color: #fff;
            font-family: inherit;
            transition: all 0.2s ease;
        }

        .input-field:focus {
            outline: none;
            border-color: var(--primary);
            background: rgba(139, 92, 246, 0.05);
            box-shadow: 0 0 0 4px rgba(139, 92, 246, 0.1);
        }

        /* Pipeline Flow */
        .pipeline-track {
            position: relative;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 60px;
            padding: 0 10px;
        }

        .pipeline-line {
            position: absolute;
            top: 24px;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, 
                var(--primary) 0%, 
                var(--secondary) 50%, 
                rgba(255, 255, 255, 0.05) 100%);
            z-index: 1;
        }

        .step {
            position: relative;
            z-index: 2;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 12px;
            width: 80px;
        }

        .step-node {
            width: 48px;
            height: 48px;
            background: #0f172a;
            border: 2px solid var(--border);
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .step.active .step-node {
            border-color: var(--primary);
            box-shadow: 0 0 20px rgba(139, 92, 246, 0.3);
            background: var(--bg-deep);
        }

        .step-label {
            font-size: 11px;
            font-weight: 500;
            color: var(--text-dim);
            text-align: center;
            white-space: nowrap;
        }

        .step.active .step-label {
            color: var(--text-main);
        }

        /* Metrics Grid */
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 40px;
        }

        .metric-card {
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid var(--border);
            padding: 20px;
            border-radius: 16px;
        }

        .metric-card span {
            display: block;
            color: var(--text-dim);
            font-size: 12px;
            margin-bottom: 8px;
        }

        .metric-card h3 {
            font-family: 'JetBrains Mono', monospace;
            font-size: 24px;
            font-weight: 600;
        }

        /* Integration Footer */
        .footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 30px;
            border-top: 1px solid var(--border);
        }

        .tools {
            display: flex;
            gap: 12px;
            align-items: center;
        }

        .tool-chip {
            background: rgba(255, 255, 255, 0.05);
            padding: 6px 12px;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 500;
            color: var(--text-dim);
            border: 1px solid transparent;
            transition: 0.2s;
        }

        .tool-chip:hover {
            background: rgba(255, 255, 255, 0.08);
            border-color: var(--border);
            color: var(--text-main);
        }

        .btn-run {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            border: none;
            padding: 14px 32px;
            border-radius: 12px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
            box-shadow: 0 10px 20px -10px rgba(139, 92, 246, 0.5);
        }

        .btn-run:hover {
            transform: translateY(-2px);
            box-shadow: 0 15px 30px -10px rgba(139, 92, 246, 0.6);
        }

        /* Icons simulation */
        .icon { stroke: currentColor; fill: none; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; width: 20px; height: 20px; }
    </style>
</head>
<body>

    <div class="aura-blob aura-1"></div>
    <div class="aura-blob aura-2"></div>

    <main class="sdr-container">
        <header class="header">
            <div class="header-title">
                <h1>AI SDR Engine v2.4</h1>
                <p>Autonomous end-to-end outbound infrastructure</p>
            </div>
            <div class="status-badge">
                <div class="status-dot"></div>
                SYSTEM ACTIVE
            </div>
        </header>

        <section class="config-grid">
            <div class="input-group">
                <label>Target City</label>
                <input type="text" class="input-field" placeholder="e.g. San Francisco">
            </div>
            <div class="input-group">
                <label>Market Niche</label>
                <input type="text" class="input-field" placeholder="e.g. SaaS Founders">
            </div>
            <div class="input-group">
                <label>Business Type</label>
                <input type="text" class="input-field" placeholder="e.g. B2B Fintech">
            </div>
        </section>

        <section class="pipeline-track">
            <div class="pipeline-line"></div>
            
            <div class="step active">
                <div class="step-node">🔍</div>
                <div class="step-label">Lead Source</div>
            </div>
            <div class="step active">
                <div class="step-node">🔬</div>
                <div class="step-label">Research</div>
            </div>
            <div class="step active">
                <div class="step-node">⚖️</div>
                <div class="step-label">Qualify</div>
            </div>
            <div class="step">
                <div class="step-node">✨</div>
                <div class="step-label">Personalize</div>
            </div>
            <div class="step">
                <div class="step-node">📝</div>
                <div class="step-label">Draft</div>
            </div>
            <div class="step">
                <div class="step-node">✉️</div>
                <div class="step-label">Send</div>
            </div>
            <div class="step">
                <div class="step-node">🔄</div>
                <div class="step-label">Follow-up</div>
            </div>
            <div class="step">
                <div class="step-node">📊</div>
                <div class="step-label">Analyze</div>
            </div>
        </section>

        <section class="dashboard-grid">
            <div class="metric-card">
                <span>Daily Outreach</span>
                <h3>482 <small style="font-size: 12px; color: #10b981;">+12%</small></h3>
            </div>
            <div class="metric-card">
                <span>Open Rate</span>
                <h3>64.2%</h3>
            </div>
            <div class="metric-card">
                <span>Replied</span>
                <h3>28</h3>
            </div>
            <div class="metric-card">
                <span>Meetings Set</span>
                <h3>4</h3>
            </div>
        </section>

        <footer class="footer">
            <div class="tools">
                <span style="font-size: 12px; color: var(--text-dim); margin-right: 8px;">Stack:</span>
                <div class="tool-chip">ChatGPT-4</div>
                <div class="tool-chip">Gemini</div>
                <div class="tool-chip">Notion</div>
                <div class="tool-chip">Gmail</div>
                <div class="tool-chip">Make.com</div>
            </div>
            <button class="btn-run">Start Campaign</button>
        </footer>
    </main>

    <script>
        // Simple animation logic for the pipeline
        const steps = document.querySelectorAll('.step');
        let currentIdx = 2;

        setInterval(() => {
            steps.forEach(s => s.classList.remove('active'));
            currentIdx = (currentIdx + 1) % steps.length;
            
            for(let i=0; i<=currentIdx; i++) {
                steps[i].classList.add('active');
            }
        }, 3000);
    </script>
</body>
</html>
```
import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<div class="orb orb-1"></div>
    <div class="orb orb-2"></div>

    <nav>
        <div class="logo">SYNTH VAULT</div>
        <div class="nav-links">
            <a href="#directory">Directory</a>
            <a href="#how-it-works">How it works</a>
            <a href="#custom">Request Agent</a>
            <a href="#" class="btn-primary" style="padding: 0.5rem 1.2rem; font-size: 0.8rem;">Login</a>
        </div>
    </nav>

    <header class="hero">
        <span class="hook">AI Agents for Operators Who Want Leverage, Not More Tabs</span>
        <h1>The Command Center for Modern Entrepreneurs</h1>
        <p>Browse practical AI assistants built to help you generate leads, organize workflows, create content, qualify clients, and automate the boring business goblin work.</p>
        <a href="#directory" class="btn-primary">Browse AI Agents</a>
    </header>

    <section class="filter-section" id="directory">
        <input type="text" class="search-bar" placeholder="Search by task (e.g. 'Lead generation' or 'CRM')">
        <div class="categories">
            <div class="cat-chip active">All Agents</div>
            <div class="cat-chip">Lead Gen</div>
            <div class="cat-chip">Content & Social</div>
            <div class="cat-chip">Operations</div>
            <div class="cat-chip">Funding & Credit</div>
            <div class="cat-chip">Client Onboarding</div>
        </div>
    </section>

    <main class="agent-grid">
        <!-- Card 1 -->
        <div class="agent-card">
            <div class="agent-badge">Premium</div>
            <div class="agent-icon">🏦</div>
            <h3>Capital Ready GPT</h3>
            <p>Analyzes your business metrics and prepares documentation for funding readiness and business credit applications.</p>
            <div class="card-footer">
                <span class="use-case-tag">#Finance</span>
                <a href="#" class="launch-btn">Launch →</a>
            </div>
        </div>

        <!-- Card 2 -->
        <div class="agent-card">
            <div class="agent-badge">Popular</div>
            <div class="agent-icon">📢</div>
            <h3>Viral Thread Maker</h3>
            <p>Converts long-form videos or blogs into high-engagement Twitter threads and LinkedIn carousels in seconds.</p>
            <div class="card-footer">
                <span class="use-case-tag">#Marketing</span>
                <a href="#" class="launch-btn">Launch →</a>
            </div>
        </div>

        <!-- Card 3 -->
        <div class="agent-card">
            <div class="agent-icon">🧩</div>
            <h3>CRM Data Parser</h3>
            <p>Upload raw meeting notes or unstructured emails and let the agent extract lead data, intent, and follow-up tasks.</p>
            <div class="card-footer">
                <span class="use-case-tag">#Operations</span>
                <a href="#" class="launch-btn">Launch →</a>
            </div>
        </div>

        <!-- Card 4 -->
        <div class="agent-card">
            <div class="agent-icon">🤝</div>
            <h3>Referral Outreach Pro</h3>
            <p>Drafts personalized referral requests for your client base using psychological triggers that actually get replies.</p>
            <div class="card-footer">
                <span class="use-case-tag">#Sales</span>
                <a href="#" class="launch-btn">Launch →</a>
            </div>
        </div>

        <!-- Card 5 -->
        <div class="agent-card">
            <div class="agent-icon">⚡</div>
            <h3>Workflow Automator</h3>
            <p>Designs Zapier or Make.com blueprints based on your manual business descriptions to kill repetitive tasks.</p>
            <div class="card-footer">
                <span class="use-case-tag">#Automation</span>
                <a href="#" class="launch-btn">Launch →</a>
            </div>
        </div>

        <!-- Card 6 -->
        <div class="agent-card">
            <div class="agent-badge">New</div>
            <div class="agent-icon">📝</div>
            <h3>Client Qualifier</h3>
            <p>Vets potential clients via intake form responses to ensure they meet your high-ticket program requirements.</p>
            <div class="card-footer">
                <span class="use-case-tag">#Onboarding</span>
                <a href="#" class="launch-btn">Launch →</a>
            </div>
        </div>
    </main>

    <section class="use-cases">
        <div class="section-title">
            <h2>Built for Every Stage</h2>
            <p>Specific agents for specific business bottlenecks.</p>
        </div>
        <div class="case-grid">
            <div class="case-item">
                <h4 style="margin-bottom: 10px; color: var(--accent-cyan);">Affiliates</h4>
                <p style="font-size: 0.9rem; color: var(--text-dim);">Automated link tracking summaries and bridge page copy generation.</p>
            </div>
            <div class="case-item">
                <h4 style="margin-bottom: 10px; color: var(--accent-purple);">Creators</h4>
                <p style="font-size: 0.9rem; color: var(--text-dim);">Scriptwriting, hook testing, and multi-platform content repurposing.</p>
            </div>
            <div class="case-item">
                <h4 style="margin-bottom: 10px; color: var(--accent-green);">Agencies</h4>
                <p style="font-size: 0.9rem; color: var(--text-dim);">Client reporting, lead qualification, and automated onboarding flows.</p>
            </div>
        </div>
    </section>

    <section class="how-to" id="how-it-works">
        <div class="section-title">
            <h2>How to Use Synth Vault</h2>
        </div>
        <div class="steps">
            <div class="step" data-step="01">
                <h4>Select Your Agent</h4>
                <p>Choose an assistant tailored to the specific business "goblin work" you want to eliminate.</p>
            </div>
            <div class="step" data-step="02">
                <h4>Input Context</h4>
                <p>Provide your business details, raw data, or goals. Our agents are pre-prompted with elite frameworks.</p>
            </div>
            <div class="step" data-step="03">
                <h4>Execute Result</h4>
                <p>Receive your output and instantly apply it to your CRM, social media, or funding application.</p>
            </div>
        </div>
    </section>

    <section class="faq">
        <div class="section-title">
            <h2>Common Questions</h2>
        </div>
        <details class="faq-item">
            <summary>Do I need a ChatGPT Plus account?</summary>
            <p>Most of our agents are built as custom GPTs, which require a ChatGPT Plus subscription. However, some are standalone tools accessible via API.</p>
        </details>
        <details class="faq-item">
            <summary>Are these agents trained on my data?</summary>
            <p>No. We provide the logic and frameworks. Your inputs remain private within your own AI account session.</p>
        </details>
        <details class="faq-item">
            <summary>Can I request a custom agent?</summary>
            <p>Absolutely. We build bespoke business agents for high-volume operations. Click the 'Request Custom' button below.</p>
        </details>
    </section>

    <section class="cta-final" id="custom">
        <div class="cta-box">
            <h2 style="font-size: 3rem; margin-bottom: 1rem;">Ready for Infinite Leverage?</h2>
            <p style="margin-bottom: 2rem; color: var(--text-dim);">Stop doing \$10/hr tasks. Start operating like a CEO.</p>
            <div style="display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap;">
                <a href="#" class="btn-primary">Browse AI Agents</a>
                <a href="#" class="btn-primary" style="background: transparent; border: 1px solid var(--accent-cyan); box-shadow: none;">Request Custom Agent</a>
            </div>
        </div>
    </section>

    <footer>
        <p>&copy; 2024 Synth Vault. All Rights Reserved for the Operators.</p>
        <div>
            <a href="#" style="color: var(--text-dim); text-decoration: none; margin-left: 1rem;">Privacy</a>
            <a href="#" style="color: var(--text-dim); text-decoration: none; margin-left: 1rem;">Terms</a>
        </div>
    </footer>
      ` }} />
    </main>
  );
}
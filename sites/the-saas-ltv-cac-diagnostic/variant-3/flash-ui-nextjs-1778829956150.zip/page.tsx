import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<div class="diagnostic-card">
    <div class="corner-accent top-left"></div>
    <div class="corner-accent top-right"></div>
    <div class="corner-accent bottom-left"></div>
    <div class="corner-accent bottom-right"></div>

    <div class="card-header">
        <div class="header-title">
            <h1>The LTV:CAC Diagnostic</h1>
            <p>Growth Engine Blueprint & Efficiency Audit</p>
        </div>
        <div class="serial-number">
            REF_ID: 882-GAUGE<br>
            UNITS: USD / MONTHLY
        </div>
    </div>

    <div class="grid-container">
        <div class="inputs-panel">
            <div class="input-group">
                <label>Average Revenue Per User (ARPU)</label>
                <div class="input-wrapper">
                    <span>\$</span>
                    <input type="number" id="arpu" value="150" step="10">
                </div>
            </div>
            <div class="input-group">
                <label>Monthly Churn Rate (%)</label>
                <div class="input-wrapper percent">
                    <input type="number" id="churn" value="5" step="0.1">
                    <span class="suffix">%</span>
                </div>
            </div>
            <div class="input-group">
                <label>Customer Acquisition Cost (CAC)</label>
                <div class="input-wrapper">
                    <span>\$</span>
                    <input type="number" id="cac" value="800" step="50">
                </div>
            </div>
        </div>

        <div class="viz-panel">
            <div class="gauge-container">
                <div class="gauge-track"></div>
                <div id="gauge-fill" class="gauge-fill"></div>
                <div id="needle" class="needle"></div>
            </div>
            
            <div class="viz-meta">
                <div id="ratio-text" class="ratio-value">3.0:1</div>
                <div class="ratio-label">Current LTV:CAC Ratio</div>
                <div id="status-badge" class="status-badge status-healthy">Compounding Asset</div>
            </div>
        </div>
    </div>

    <div class="card-footer">
        <div class="cta-message" id="cta-message">
            Your ratio is <span>3.0:1</span>. Optimal performance detected.
        </div>
        <button class="blueprint-btn">Scale Operations</button>
    </div>
</div>

<script>
    const arpuInput = document.getElementById('arpu');
    const churnInput = document.getElementById('churn');
    const cacInput = document.getElementById('cac');
    
    const gaugeFill = document.getElementById('gauge-fill');
    const needle = document.getElementById('needle');
    const ratioText = document.getElementById('ratio-text');
    const statusBadge = document.getElementById('status-badge');
    const ctaMessage = document.getElementById('cta-message');

    function calculate() {
        const arpu = parseFloat(arpuInput.value) || 0;
        const churn = parseFloat(churnInput.value) || 0;
        const cac = parseFloat(cacInput.value) || 1; // Avoid div by 0

        // LTV = ARPU / Churn Rate
        const ltv = churn > 0 ? (arpu / (churn / 100)) : 0;
        const ratio = ltv / cac;
        
        updateUI(ratio);
    }

    function updateUI(ratio) {
        const displayRatio = ratio.toFixed(1);
        ratioText.innerText = \`\${displayRatio}:1\`;

        // Map ratio to degrees (0 to 10:1 ratio scale)
        // -90deg is 0, 90deg is 10+
        let rotation = (ratio / 6) * 180 - 90;
        if (rotation > 90) rotation = 90;
        if (rotation < -90) rotation = -90;

        needle.style.transform = \`translateX(-50%) rotate(\${rotation}deg)\`;
        
        // Gauge color mapping
        if (ratio >= 3) {
            gaugeFill.style.borderTopColor = 'var(--success)';
            gaugeFill.style.borderRightColor = 'var(--success)';
            statusBadge.innerText = "Compounding Asset";
            statusBadge.className = "status-badge status-healthy";
            ctaMessage.innerHTML = \`Your ratio is <span>\${displayRatio}:1</span>. Stop using equity to fund this.\`;
        } else {
            gaugeFill.style.borderTopColor = 'var(--danger)';
            gaugeFill.style.borderRightColor = 'var(--danger)';
            statusBadge.innerText = "Leaky Bucket";
            statusBadge.className = "status-badge status-danger";
            ctaMessage.innerHTML = \`Your ratio is <span>\${displayRatio}:1</span>. Fix retention before scaling.\`;
        }
    }

    [arpuInput, churnInput, cacInput].forEach(input => {
        input.addEventListener('input', calculate);
    });

    // Initial calculation
    calculate();
</script>
      ` }} />
    </main>
  );
}
import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<div class="diagnostic-card">
        <div class="glow" id="status-glow"></div>
        <header>
            <h1>LTV:CAC Diagnostic</h1>
            <p class="subtitle">Find the golden geese that don't know they're golden.</p>
        </header>

        <div class="inputs-grid">
            <div class="input-group">
                <label for="arpu">ARPU <span>Monthly Avg Rev</span></label>
                <input type="number" id="arpu" value="250" placeholder="0">
            </div>
            <div class="input-group">
                <label for="churn">Monthly Churn <span>%</span></label>
                <input type="number" id="churn" value="5" step="0.1" placeholder="0">
            </div>
            <div class="input-group">
                <label for="cac">CAC <span>Acquisition Cost</span></label>
                <input type="number" id="cac" value="1200" placeholder="0">
            </div>
        </div>

        <div class="gauge-container">
            <svg class="gauge-svg" viewBox="0 0 120 60">
                <path class="gauge-bg" d="M10,50 A40,40 0 0,1 110,50" />
                <path id="gauge-path" class="gauge-fill" d="M10,50 A40,40 0 0,1 110,50" />
            </svg>
            <div class="gauge-value">
                <div class="ratio-num" id="ratio-display">0.0</div>
                <div class="ratio-label">LTV : CAC Ratio</div>
                <div class="status-badge" id="status-text">Analyzing...</div>
            </div>
        </div>

        <div class="ltv-display" id="ltv-calc">
            Estimated LTV: \$0.00
        </div>

        <div class="cta-container">
            <button class="primary-cta" id="cta-button">
                Calculate Engine Power
            </button>
        </div>
    </div>

    <script>
        const arpuInput = document.getElementById('arpu');
        const churnInput = document.getElementById('churn');
        const cacInput = document.getElementById('cac');
        const ratioDisplay = document.getElementById('ratio-display');
        const ltvDisplay = document.getElementById('ltv-calc');
        const statusText = document.getElementById('status-text');
        const gaugePath = document.getElementById('gauge-path');
        const ctaButton = document.getElementById('cta-button');
        const glow = document.getElementById('status-glow');

        function updateDiagnostic() {
            const arpu = parseFloat(arpuInput.value) || 0;
            const churnPercent = parseFloat(churnInput.value) || 0;
            const cac = parseFloat(cacInput.value) || 1; // Prevent div by zero

            const churnDecimal = churnPercent / 100;
            const ltv = churnDecimal > 0 ? (arpu / churnDecimal) : 0;
            const ratio = ltv / cac;

            // Update Text
            ratioDisplay.textContent = ratio.toFixed(1);
            ltvDisplay.textContent = \`Calculated LTV: \$\${ltv.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}\`;

            // Gauge Calculation (stroke-dashoffset from 314 to 0)
            // We'll map 0-6 ratio to the gauge arc.
            const maxGaugeRatio = 6;
            const percentage = Math.min(ratio / maxGaugeRatio, 1);
            const offset = 314 - (percentage * 314);
            gaugePath.style.strokeDashoffset = offset;

            // Logic Styling & CTA
            if (ratio >= 3) {
                gaugePath.style.stroke = 'var(--success)';
                statusText.textContent = "Compounding Asset";
                statusText.style.color = 'var(--success)';
                glow.style.background = 'radial-gradient(circle, var(--success) 0%, transparent 70%)';
                ctaButton.textContent = \`Your ratio is \${ratio.toFixed(1)}:1. Stop using equity to fund this.\`;
            } else if (ratio >= 1.5) {
                gaugePath.style.stroke = 'var(--warning)';
                statusText.textContent = "Sustainable Growth";
                statusText.style.color = 'var(--warning)';
                glow.style.background = 'radial-gradient(circle, var(--warning) 0%, transparent 70%)';
                ctaButton.textContent = \`Your ratio is \${ratio.toFixed(1)}:1. Optimize for scale.\`;
            } else {
                gaugePath.style.stroke = 'var(--danger)';
                statusText.textContent = "Leaky Bucket";
                statusText.style.color = 'var(--danger)';
                glow.style.background = 'radial-gradient(circle, var(--danger) 0%, transparent 70%)';
                ctaButton.textContent = \`Ratio: \${ratio.toFixed(1)}:1. Fix churn before burning.\`;
            }
        }

        [arpuInput, churnInput, cacInput].forEach(input => {
            input.addEventListener('input', updateDiagnostic);
        });

        // Initialize
        updateDiagnostic();
    </script>
      ` }} />
    </main>
  );
}
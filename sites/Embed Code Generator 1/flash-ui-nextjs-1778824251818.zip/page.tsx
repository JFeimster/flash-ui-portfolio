import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<div class="container">
    <header>
        <h1>Generate Partner Widget Embed Code</h1>
        <p class="subheadline">Create copy/paste embed snippets for funding tools, calculators, application CTAs, and partner profile cards. Deploy in seconds on any platform.</p>
    </header>

    <main class="main-grid">
        <!-- Sidebar Controls -->
        <section class="panel">
            <div class="panel-title">Configuration</div>
            
            <div class="form-group">
                <label>Widget Type</label>
                <select id="widgetType">
                    <option value="readiness">Funding Readiness Score</option>
                    <option value="matcher">Funding Route Matcher</option>
                    <option value="cta">Application CTA Button</option>
                    <option value="checklist">Document Checklist</option>
                    <option value="faq">FAQ Widget</option>
                    <option value="estimator">Commission Estimator</option>
                    <option value="profile">Partner Profile Card</option>
                </select>
            </div>

            <div class="form-group">
                <label>Partner Name</label>
                <input type="text" id="partnerName" placeholder="e.g. Acme Agency">
            </div>

            <div class="grid-2-col">
                <div class="form-group">
                    <label>Partner ID</label>
                    <input type="text" id="partnerId" placeholder="MS-9982">
                </div>
                <div class="form-group">
                    <label>Tracking Source</label>
                    <input type="text" id="trackingSource" placeholder="blog-sidebar">
                </div>
            </div>

            <div class="form-group">
                <label>Application URL</label>
                <input type="text" id="appUrl" placeholder="https://moonshine.cap/apply">
            </div>

            <div class="form-group">
                <label>Brand Accent Color</label>
                <div style="display:flex; gap:10px;">
                    <input type="color" id="brandColor" value="#00f2ff" style="width:50px; padding:2px; height:38px;">
                    <input type="text" id="brandColorHex" value="#00f2ff">
                </div>
            </div>

            <div class="grid-2-col">
                <div class="form-group">
                    <label>Width</label>
                    <input type="text" id="widgetWidth" value="100%">
                </div>
                <div class="form-group">
                    <label>Height</label>
                    <input type="text" id="widgetHeight" value="500px">
                </div>
            </div>

            <button class="btn-primary" id="btnBuild">Build Embed Code</button>

            <div class="recent-section">
                <label>Recent Embeds</label>
                <div id="recentList">
                    <div class="recent-item">No recent items</div>
                </div>
            </div>
        </section>

        <!-- Main Preview and Code -->
        <section class="preview-container">
            
            <div id="widget-preview-box">
                <div class="preview-label">LIVE PREVIEW</div>
                <div id="mock-render">
                    <!-- Dynamic Mockup Inject -->
                </div>
            </div>

            <div class="panel">
                <div class="panel-title">Generated Output</div>
                
                <div class="code-output">
                    <div class="code-header">
                        <span>iFrame Embed Snippet</span>
                        <button class="btn-copy" onclick="copyCode('iframe-code')">Copy Code</button>
                    </div>
                    <pre id="iframe-code"></pre>
                </div>

                <div class="code-output" style="margin-top:1.5rem">
                    <div class="code-header">
                        <span>Direct Link (UTM Tagged)</span>
                        <button class="btn-copy" onclick="copyCode('direct-link')">Copy Link</button>
                    </div>
                    <pre id="direct-link"></pre>
                </div>

                <div class="platform-nav">
                    <div class="platform-tab active" onclick="showTab('wix')">Wix</div>
                    <div class="platform-tab" onclick="showTab('wp')">WordPress</div>
                    <div class="platform-tab" onclick="showTab('framer')">Framer / Webflow</div>
                    <div class="platform-tab" onclick="showTab('html')">Static HTML</div>
                </div>

                <div id="wix" class="platform-content active">
                    Add an "Embed HTML" component to your Wix page. Paste the iFrame code into the "HTML Code" field. Ensure the box size matches your selected width/height.
                </div>
                <div id="wp" class="platform-content">
                    Use the "Custom HTML" block in the Gutenberg editor. Paste the code and preview. If using Elementor, use the "HTML" widget.
                </div>
                <div id="framer" class="platform-content">
                    Insert an "Embed" component from the Framer/Webflow utility menu. Paste the code into the properties panel. Set width to "Fill" for best results.
                </div>
                <div id="html" class="platform-content">
                    Paste the snippet anywhere inside the &lt;body&gt; of your HTML file. For optimal loading, ensure you have only one instance of the script if using the SDK version.
                </div>
            </div>

            <div class="panel">
                <div class="panel-title">Troubleshooting</div>
                <div style="font-size: 0.9rem; color: var(--text-dim);">
                    <p style="margin-bottom: 0.5rem;"><strong style="color:var(--text-main);">Q: Widget looks cut off?</strong><br>Adjust the Height parameter in the configuration panel to match the content length.</p>
                    <p><strong style="color:var(--text-main);">Q: Analytics not showing?</strong><br>Ensure your Partner ID is correct and there are no typos in the Tracking Source field.</p>
                </div>
            </div>
        </section>
    </main>
</div>

<div id="toast">Copied to clipboard!</div>

<script>
    const inputs = ['widgetType', 'partnerName', 'partnerId', 'trackingSource', 'appUrl', 'brandColor', 'widgetWidth', 'widgetHeight', 'brandColorHex'];
    const mockData = {
        readiness: { title: "Funding Readiness", desc: "Check your business funding potential in 60 seconds." },
        matcher: { title: "Route Matcher", desc: "Find the best capital path for your business model." },
        cta: { title: "Apply Now", desc: "Start your Moonshine Capital application." },
        checklist: { title: "Document Checklist", desc: "Everything you need for a successful round." },
        faq: { title: "Funding FAQ", desc: "Common questions about Moonshine's process." },
        estimator: { title: "Commission Calc", desc: "Estimate your partner referral earnings." },
        profile: { title: "Partner Profile", desc: "Verified Moonshine Capital Affiliate." }
    };

    function init() {
        // Sync color inputs
        document.getElementById('brandColor').addEventListener('input', (e) => {
            document.getElementById('brandColorHex').value = e.target.value;
            updateGenerator();
        });
        document.getElementById('brandColorHex').addEventListener('input', (e) => {
            document.getElementById('brandColor').value = e.target.value;
            updateGenerator();
        });

        // Add listeners to all inputs
        inputs.forEach(id => {
            document.getElementById(id).addEventListener('input', updateGenerator);
        });

        document.getElementById('btnBuild').addEventListener('click', () => {
            saveToHistory();
            showToast('Configuration Saved!');
        });

        loadHistory();
        updateGenerator();
    }

    function updateGenerator() {
        const type = document.getElementById('widgetType').value;
        const pId = document.getElementById('partnerId').value || 'PARTNER_ID';
        const pName = document.getElementById('partnerName').value || 'Partner';
        const source = document.getElementById('trackingSource').value || 'direct';
        const appUrl = document.getElementById('appUrl').value || 'https://moonshine.cap/apply';
        const color = document.getElementById('brandColor').value;
        const width = document.getElementById('widgetWidth').value;
        const height = document.getElementById('widgetHeight').value;

        // Build URL
        const baseUrl = \`https://widgets.moonshine.cap/\${type}\`;
        const finalUrl = \`\${baseUrl}?pid=\${encodeURIComponent(pId)}&source=\${encodeURIComponent(source)}&accent=\${encodeURIComponent(color.replace('#',''))}\`;

        // Update iFrame Code
        const iframeCode = \`<iframe 
    src="\${finalUrl}" 
    width="\${width}" 
    height="\${height}" 
    frameborder="0" 
    style="border:none; overflow:hidden;" 
    allowTransparency="true">
</iframe>\`;

        document.getElementById('iframe-code').textContent = iframeCode;
        document.getElementById('direct-link').textContent = finalUrl;

        // Update Mockup UI
        const mock = mockData[type];
        const mockRender = document.getElementById('mock-render');
        mockRender.innerHTML = \`
            <div class="mock-widget-card" style="border-color: \${color}">
                <div class="mock-title" style="color: \${color}">\${mock.title}</div>
                <div class="mock-desc">\${mock.desc}</div>
                <div class="mock-btn" style="background: \${color}">Get Started</div>
                <div style="margin-top:10px; font-size: 10px; color: #555;">ID: \${pId}</div>
            </div>
        \`;
    }

    function copyCode(id) {
        const text = document.getElementById(id).textContent;
        navigator.clipboard.writeText(text).then(() => {
            showToast('Copied to clipboard!');
        });
    }

    function showToast(msg) {
        const toast = document.getElementById('toast');
        toast.textContent = msg;
        toast.style.display = 'block';
        setTimeout(() => {
            toast.style.display = 'none';
        }, 2000);
    }

    function showTab(tabId) {
        document.querySelectorAll('.platform-content').forEach(el => el.classList.remove('active'));
        document.querySelectorAll('.platform-tab').forEach(el => el.classList.remove('active'));
        document.getElementById(tabId).classList.add('active');
        event.currentTarget.classList.add('active');
    }

    function saveToHistory() {
        const history = JSON.parse(localStorage.getItem('ms_recent') || '[]');
        const entry = {
            type: document.getElementById('widgetType').value,
            date: new Date().toLocaleTimeString(),
            id: document.getElementById('partnerId').value
        };
        history.unshift(entry);
        localStorage.setItem('ms_recent', JSON.stringify(history.slice(0, 5)));
        loadHistory();
    }

    function loadHistory() {
        const history = JSON.parse(localStorage.getItem('ms_recent') || '[]');
        const container = document.getElementById('recentList');
        if(history.length === 0) return;
        
        container.innerHTML = history.map(h => \`
            <div class="recent-item">
                \${h.date} - \${h.type.toUpperCase()} (\${h.id || 'No ID'})
            </div>
        \`).join('');
    }

    window.onload = init;
</script>
      ` }} />
    </main>
  );
}
### Generated UI Component

To use this in Notion:
1. Create a "/code" block
2. Set language to "HTML"
3. Paste the following:

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moonshine Capital | Embed Generator</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fira+Code:wght@400;500&family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-deep: #05070a;
            --bg-card: #0d1117;
            --bg-input: #161b22;
            --neon-blue: #00f2ff;
            --neon-green: #00ff9d;
            --text-main: #e6edf3;
            --text-dim: #8b949e;
            --border: #30363d;
            --accent-glow: rgba(0, 242, 255, 0.15);
            --font-mono: 'Fira Code', monospace;
            --font-sans: 'Inter', sans-serif;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            background-color: var(--bg-deep);
            color: var(--text-main);
            font-family: var(--font-sans);
            line-height: 1.6;
            overflow-x: hidden;
        }

        /* Scrollbar */
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: var(--bg-deep); }
        ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: var(--text-dim); }

        .container {
            max-width: 1300px;
            margin: 0 auto;
            padding: 2rem;
        }

        header {
            margin-bottom: 3rem;
            border-bottom: 1px solid var(--border);
            padding-bottom: 2rem;
        }

        h1 {
            font-size: 2.5rem;
            font-weight: 700;
            background: linear-gradient(90deg, var(--neon-blue), var(--neon-green));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 0.5rem;
        }

        .subheadline {
            color: var(--text-dim);
            font-size: 1.1rem;
            max-width: 700px;
        }

        .main-grid {
            display: grid;
            grid-template-columns: 400px 1fr;
            gap: 2rem;
            align-items: start;
        }

        @media (max-width: 1024px) {
            .main-grid { grid-template-columns: 1fr; }
        }

        /* Panels */
        .panel {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 1.5rem;
            position: relative;
        }

        .panel-title {
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: var(--neon-blue);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .panel-title::before {
            content: '';
            display: inline-block;
            width: 8px;
            height: 8px;
            background: var(--neon-blue);
            box-shadow: 0 0 10px var(--neon-blue);
            border-radius: 50%;
        }

        /* Forms */
        .form-group {
            margin-bottom: 1.25rem;
        }

        label {
            display: block;
            font-size: 0.85rem;
            color: var(--text-dim);
            margin-bottom: 0.5rem;
        }

        select, input {
            width: 100%;
            background: var(--bg-input);
            border: 1px solid var(--border);
            color: var(--text-main);
            padding: 0.75rem;
            border-radius: 6px;
            font-size: 0.9rem;
            outline: none;
            transition: border-color 0.2s;
        }

        select:focus, input:focus {
            border-color: var(--neon-blue);
        }

        .grid-2-col {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }

        /* Preview Area */
        .preview-container {
            display: flex;
            flex-direction: column;
            gap: 2rem;
        }

        #widget-preview-box {
            min-height: 400px;
            background: #000;
            border: 1px solid var(--border);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            background-image: radial-gradient(var(--border) 1px, transparent 1px);
            background-size: 20px 20px;
        }

        .preview-label {
            position: absolute;
            top: 1rem;
            left: 1rem;
            background: var(--bg-deep);
            padding: 4px 10px;
            border-radius: 4px;
            font-size: 0.7rem;
            color: var(--text-dim);
            border: 1px solid var(--border);
        }

        /* Output / Code Panels */
        .code-output {
            background: #010409;
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 1.25rem;
            position: relative;
        }

        .code-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }

        .code-header span {
            font-size: 0.8rem;
            color: var(--neon-green);
            font-family: var(--font-mono);
        }

        pre {
            font-family: var(--font-mono);
            font-size: 0.85rem;
            color: #7ee787;
            white-space: pre-wrap;
            word-break: break-all;
            background: rgba(0,0,0,0.3);
            padding: 1rem;
            border-radius: 4px;
        }

        .btn-copy {
            background: transparent;
            border: 1px solid var(--neon-blue);
            color: var(--neon-blue);
            padding: 4px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.75rem;
            transition: all 0.2s;
        }

        .btn-copy:hover {
            background: var(--neon-blue);
            color: var(--bg-deep);
            box-shadow: 0 0 15px var(--accent-glow);
        }

        .btn-primary {
            background: var(--neon-blue);
            color: var(--bg-deep);
            border: none;
            padding: 1rem 2rem;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            width: 100%;
            margin-top: 1rem;
            transition: opacity 0.2s;
        }

        .btn-primary:hover {
            opacity: 0.9;
        }

        /* Tabs for platforms */
        .platform-nav {
            display: flex;
            gap: 1rem;
            margin-top: 1.5rem;
            border-bottom: 1px solid var(--border);
            padding-bottom: 0.5rem;
        }

        .platform-tab {
            font-size: 0.8rem;
            color: var(--text-dim);
            cursor: pointer;
            padding: 4px 8px;
            transition: color 0.2s;
        }

        .platform-tab.active {
            color: var(--neon-blue);
            border-bottom: 2px solid var(--neon-blue);
        }

        .platform-content {
            padding: 1rem 0;
            font-size: 0.85rem;
            color: var(--text-dim);
            display: none;
        }

        .platform-content.active {
            display: block;
        }

        /* Widget Mock Elements */
        .mock-widget-card {
            background: #111;
            border: 2px solid var(--neon-blue);
            width: 320px;
            padding: 2rem;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 0 30px rgba(0, 242, 255, 0.1);
        }

        .mock-title { font-weight: 700; margin-bottom: 0.5rem; font-size: 1.2rem; }
        .mock-desc { font-size: 0.8rem; color: var(--text-dim); margin-bottom: 1.5rem; }
        .mock-btn { background: var(--neon-blue); color: #000; padding: 0.75rem; border-radius: 4px; font-weight: bold; font-size: 0.8rem; }
        
        /* Floating notification */
        #toast {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: var(--neon-green);
            color: #000;
            padding: 10px 20px;
            border-radius: 4px;
            font-weight: 600;
            display: none;
            z-index: 100;
        }

        /* Recent Activity */
        .recent-section {
            margin-top: 2rem;
            border-top: 1px solid var(--border);
            padding-top: 1rem;
        }
        .recent-item {
            font-size: 0.75rem;
            padding: 0.5rem;
            border-radius: 4px;
            cursor: pointer;
            color: var(--text-dim);
        }
        .recent-item:hover {
            background: var(--bg-input);
            color: var(--neon-blue);
        }
    </style>
</head>
<body>

<div class="container">
    <header>
        <h1>Generate Partner Widget Embed Code</h1>
        <p class="subheadline">Create copy/paste embed snippets for funding tools, calculators, application CTAs, and partner profile cards. Deploy in seconds on any platform.</p>
    </header>

    <main class="main-grid">
        <!-- Sidebar Controls -->
        <section class="panel">
            <div class="panel-title">Configuration</div>
            
            <div class="form-group">
                <label>Widget Type</label>
                <select id="widgetType">
                    <option value="readiness">Funding Readiness Score</option>
                    <option value="matcher">Funding Route Matcher</option>
                    <option value="cta">Application CTA Button</option>
                    <option value="checklist">Document Checklist</option>
                    <option value="faq">FAQ Widget</option>
                    <option value="estimator">Commission Estimator</option>
                    <option value="profile">Partner Profile Card</option>
                </select>
            </div>

            <div class="form-group">
                <label>Partner Name</label>
                <input type="text" id="partnerName" placeholder="e.g. Acme Agency">
            </div>

            <div class="grid-2-col">
                <div class="form-group">
                    <label>Partner ID</label>
                    <input type="text" id="partnerId" placeholder="MS-9982">
                </div>
                <div class="form-group">
                    <label>Tracking Source</label>
                    <input type="text" id="trackingSource" placeholder="blog-sidebar">
                </div>
            </div>

            <div class="form-group">
                <label>Application URL</label>
                <input type="text" id="appUrl" placeholder="https://moonshine.cap/apply">
            </div>

            <div class="form-group">
                <label>Brand Accent Color</label>
                <div style="display:flex; gap:10px;">
                    <input type="color" id="brandColor" value="#00f2ff" style="width:50px; padding:2px; height:38px;">
                    <input type="text" id="brandColorHex" value="#00f2ff">
                </div>
            </div>

            <div class="grid-2-col">
                <div class="form-group">
                    <label>Width</label>
                    <input type="text" id="widgetWidth" value="100%">
                </div>
                <div class="form-group">
                    <label>Height</label>
                    <input type="text" id="widgetHeight" value="500px">
                </div>
            </div>

            <button class="btn-primary" id="btnBuild">Build Embed Code</button>

            <div class="recent-section">
                <label>Recent Embeds</label>
                <div id="recentList">
                    <div class="recent-item">No recent items</div>
                </div>
            </div>
        </section>

        <!-- Main Preview and Code -->
        <section class="preview-container">
            
            <div id="widget-preview-box">
                <div class="preview-label">LIVE PREVIEW</div>
                <div id="mock-render">
                    <!-- Dynamic Mockup Inject -->
                </div>
            </div>

            <div class="panel">
                <div class="panel-title">Generated Output</div>
                
                <div class="code-output">
                    <div class="code-header">
                        <span>iFrame Embed Snippet</span>
                        <button class="btn-copy" onclick="copyCode('iframe-code')">Copy Code</button>
                    </div>
                    <pre id="iframe-code"></pre>
                </div>

                <div class="code-output" style="margin-top:1.5rem">
                    <div class="code-header">
                        <span>Direct Link (UTM Tagged)</span>
                        <button class="btn-copy" onclick="copyCode('direct-link')">Copy Link</button>
                    </div>
                    <pre id="direct-link"></pre>
                </div>

                <div class="platform-nav">
                    <div class="platform-tab active" onclick="showTab('wix')">Wix</div>
                    <div class="platform-tab" onclick="showTab('wp')">WordPress</div>
                    <div class="platform-tab" onclick="showTab('framer')">Framer / Webflow</div>
                    <div class="platform-tab" onclick="showTab('html')">Static HTML</div>
                </div>

                <div id="wix" class="platform-content active">
                    Add an "Embed HTML" component to your Wix page. Paste the iFrame code into the "HTML Code" field. Ensure the box size matches your selected width/height.
                </div>
                <div id="wp" class="platform-content">
                    Use the "Custom HTML" block in the Gutenberg editor. Paste the code and preview. If using Elementor, use the "HTML" widget.
                </div>
                <div id="framer" class="platform-content">
                    Insert an "Embed" component from the Framer/Webflow utility menu. Paste the code into the properties panel. Set width to "Fill" for best results.
                </div>
                <div id="html" class="platform-content">
                    Paste the snippet anywhere inside the &lt;body&gt; of your HTML file. For optimal loading, ensure you have only one instance of the script if using the SDK version.
                </div>
            </div>

            <div class="panel">
                <div class="panel-title">Troubleshooting</div>
                <div style="font-size: 0.9rem; color: var(--text-dim);">
                    <p style="margin-bottom: 0.5rem;"><strong style="color:var(--text-main);">Q: Widget looks cut off?</strong><br>Adjust the Height parameter in the configuration panel to match the content length.</p>
                    <p><strong style="color:var(--text-main);">Q: Analytics not showing?</strong><br>Ensure your Partner ID is correct and there are no typos in the Tracking Source field.</p>
                </div>
            </div>
        </section>
    </main>
</div>

<div id="toast">Copied to clipboard!</div>

<script>
    const inputs = ['widgetType', 'partnerName', 'partnerId', 'trackingSource', 'appUrl', 'brandColor', 'widgetWidth', 'widgetHeight', 'brandColorHex'];
    const mockData = {
        readiness: { title: "Funding Readiness", desc: "Check your business funding potential in 60 seconds." },
        matcher: { title: "Route Matcher", desc: "Find the best capital path for your business model." },
        cta: { title: "Apply Now", desc: "Start your Moonshine Capital application." },
        checklist: { title: "Document Checklist", desc: "Everything you need for a successful round." },
        faq: { title: "Funding FAQ", desc: "Common questions about Moonshine's process." },
        estimator: { title: "Commission Calc", desc: "Estimate your partner referral earnings." },
        profile: { title: "Partner Profile", desc: "Verified Moonshine Capital Affiliate." }
    };

    function init() {
        // Sync color inputs
        document.getElementById('brandColor').addEventListener('input', (e) => {
            document.getElementById('brandColorHex').value = e.target.value;
            updateGenerator();
        });
        document.getElementById('brandColorHex').addEventListener('input', (e) => {
            document.getElementById('brandColor').value = e.target.value;
            updateGenerator();
        });

        // Add listeners to all inputs
        inputs.forEach(id => {
            document.getElementById(id).addEventListener('input', updateGenerator);
        });

        document.getElementById('btnBuild').addEventListener('click', () => {
            saveToHistory();
            showToast('Configuration Saved!');
        });

        loadHistory();
        updateGenerator();
    }

    function updateGenerator() {
        const type = document.getElementById('widgetType').value;
        const pId = document.getElementById('partnerId').value || 'PARTNER_ID';
        const pName = document.getElementById('partnerName').value || 'Partner';
        const source = document.getElementById('trackingSource').value || 'direct';
        const appUrl = document.getElementById('appUrl').value || 'https://moonshine.cap/apply';
        const color = document.getElementById('brandColor').value;
        const width = document.getElementById('widgetWidth').value;
        const height = document.getElementById('widgetHeight').value;

        // Build URL
        const baseUrl = `https://widgets.moonshine.cap/${type}`;
        const finalUrl = `${baseUrl}?pid=${encodeURIComponent(pId)}&source=${encodeURIComponent(source)}&accent=${encodeURIComponent(color.replace('#',''))}`;

        // Update iFrame Code
        const iframeCode = `<iframe 
    src="${finalUrl}" 
    width="${width}" 
    height="${height}" 
    frameborder="0" 
    style="border:none; overflow:hidden;" 
    allowTransparency="true">
</iframe>`;

        document.getElementById('iframe-code').textContent = iframeCode;
        document.getElementById('direct-link').textContent = finalUrl;

        // Update Mockup UI
        const mock = mockData[type];
        const mockRender = document.getElementById('mock-render');
        mockRender.innerHTML = `
            <div class="mock-widget-card" style="border-color: ${color}">
                <div class="mock-title" style="color: ${color}">${mock.title}</div>
                <div class="mock-desc">${mock.desc}</div>
                <div class="mock-btn" style="background: ${color}">Get Started</div>
                <div style="margin-top:10px; font-size: 10px; color: #555;">ID: ${pId}</div>
            </div>
        `;
    }

    function copyCode(id) {
        const text = document.getElementById(id).textContent;
        navigator.clipboard.writeText(text).then(() => {
            showToast('Copied to clipboard!');
        });
    }

    function showToast(msg) {
        const toast = document.getElementById('toast');
        toast.textContent = msg;
        toast.style.display = 'block';
        setTimeout(() => {
            toast.style.display = 'none';
        }, 2000);
    }

    function showTab(tabId) {
        document.querySelectorAll('.platform-content').forEach(el => el.classList.remove('active'));
        document.querySelectorAll('.platform-tab').forEach(el => el.classList.remove('active'));
        document.getElementById(tabId).classList.add('active');
        event.currentTarget.classList.add('active');
    }

    function saveToHistory() {
        const history = JSON.parse(localStorage.getItem('ms_recent') || '[]');
        const entry = {
            type: document.getElementById('widgetType').value,
            date: new Date().toLocaleTimeString(),
            id: document.getElementById('partnerId').value
        };
        history.unshift(entry);
        localStorage.setItem('ms_recent', JSON.stringify(history.slice(0, 5)));
        loadHistory();
    }

    function loadHistory() {
        const history = JSON.parse(localStorage.getItem('ms_recent') || '[]');
        const container = document.getElementById('recentList');
        if(history.length === 0) return;
        
        container.innerHTML = history.map(h => `
            <div class="recent-item">
                ${h.date} - ${h.type.toUpperCase()} (${h.id || 'No ID'})
            </div>
        `).join('');
    }

    window.onload = init;
</script>

</body>
</html>
```
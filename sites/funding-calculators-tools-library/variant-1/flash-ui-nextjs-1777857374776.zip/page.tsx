import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<header>
        <div class="hero-badge">Fintech Resource Library</div>
        <h1>Business Funding Calculators</h1>
        <p class="hero-sub">Estimate payments, compare options, and calculate commissions. Practical tools for decision makers.</p>
        <a href="#tools-library" class="btn-primary">Get Started Now</a>
    </header>

    <div class="tools-container" id="tools-library">
        <div class="filter-bar">
            <input type="text" id="toolSearch" class="search-input" placeholder="SEARCH TOOLS...">
            <button class="filter-btn active" data-filter="all">ALL</button>
            <button class="filter-btn" data-filter="borrower">BORROWER</button>
            <button class="filter-btn" data-filter="broker">BROKER</button>
            <button class="filter-btn" data-filter="readiness">READINESS</button>
        </div>

        <div class="tool-grid" id="toolGrid">
            <div class="tool-card" data-category="borrower">
                <div class="tool-icon">💰</div>
                <span class="tool-tag">Borrower</span>
                <h3>Business Loan Payments</h3>
                <p>Calculate monthly or weekly payments for term loans with interest rates.</p>
                <a href="#" class="tool-action">Launch →</a>
            </div>

            <div class="tool-card" data-category="borrower">
                <div class="tool-icon">📈</div>
                <span class="tool-tag">Borrower</span>
                <h3>Revenue Financing</h3>
                <p>Repayment cap and monthly payment estimates based on gross revenue.</p>
                <a href="#" class="tool-action">Launch →</a>
            </div>

            <div class="tool-card" data-category="borrower">
                <div class="tool-icon">⚡</div>
                <span class="tool-tag">Borrower</span>
                <h3>MCA Factor Rate</h3>
                <p>Convert factor rates into APR to understand the true cost of advances.</p>
                <a href="#" class="tool-action">Launch →</a>
            </div>

            <div class="tool-card" data-category="broker">
                <div class="tool-icon">🤝</div>
                <span class="tool-tag">Broker</span>
                <h3>Broker Commissions</h3>
                <p>Calculate expected commission splits across different products.</p>
                <a href="#" class="tool-action">Launch →</a>
            </div>

            <div class="tool-card" data-category="readiness">
                <div class="tool-icon">📋</div>
                <span class="tool-tag">Readiness</span>
                <h3>Funding Readiness</h3>
                <p>A 10-point checklist for bank-rate financing preparation.</p>
                <a href="#" class="tool-action">Check →</a>
            </div>

            <div class="tool-card" data-category="readiness">
                <div class="tool-icon">⭐</div>
                <span class="tool-tag">Readiness</span>
                <h3>Credit Score</h3>
                <p>Estimate Paydex or Experian scores based on trade lines.</p>
                <a href="#" class="tool-action">Calculate →</a>
            </div>

            <div class="tool-card" data-category="borrower">
                <div class="tool-icon">🏢</div>
                <span class="tool-tag">Borrower</span>
                <h3>DSCR Calculator</h3>
                <p>Debt Service Coverage Ratio tool for commercial real estate.</p>
                <a href="#" class="tool-action">Launch →</a>
            </div>

            <div class="tool-card" data-category="borrower">
                <div class="tool-icon">🚜</div>
                <span class="tool-tag">Borrower</span>
                <h3>Equipment Financing</h3>
                <p>Calculate ROI and monthly lease payments for machinery.</p>
                <a href="#" class="tool-action">Launch →</a>
            </div>

            <div class="tool-card" data-category="borrower">
                <div class="tool-icon">📄</div>
                <span class="tool-tag">Borrower</span>
                <h3>Invoice Factoring</h3>
                <p>Calculate the cost of selling receivables and immediate advances.</p>
                <a href="#" class="tool-action">Launch →</a>
            </div>
        </div>
    </div>

    <section class="strategy-banner">
        <div class="strategy-content">
            <h2>Personalized Strategy?</h2>
            <p>Our strategists help you interpret numbers and find capital providers.</p>
        </div>
        <a href="#" class="btn-white">Talk to a Strategist</a>
    </section>

    <section class="faq-section">
        <h2>Questions</h2>
        <div class="faq-item">
            <div class="faq-question">Accurate? <span>[+]</span></div>
            <div class="faq-answer">High-fidelity estimates based on industry standards. Not legal advice.</div>
        </div>
        <div class="faq-item">
            <div class="faq-question">Anonymous? <span>[+]</span></div>
            <div class="faq-answer">100% Free. No personal data required to use tools.</div>
        </div>
    </section>

    <footer>
        <div class="footer-cta">
            <h2>Fund your growth</h2>
            <a href="#" class="btn-primary">Apply Now</a>
        </div>
        <p style="margin-top: 60px; font-weight: 900; color: var(--accent-2);">&copy; 2023 FINTECH UTILITY. DATA-BACKED GROWTH.</p>
    </footer>

    <script>
        const filterBtns = document.querySelectorAll('.filter-btn');
        const toolCards = document.querySelectorAll('.tool-card');
        const searchInput = document.getElementById('toolSearch');

        function filterTools() {
            const searchTerm = searchInput.value.toLowerCase();
            const activeFilter = document.querySelector('.filter-btn.active').dataset.filter;

            toolCards.forEach(card => {
                const title = card.querySelector('h3').innerText.toLowerCase();
                const category = card.dataset.category;
                const matchesSearch = title.includes(searchTerm);
                const matchesFilter = activeFilter === 'all' || category === activeFilter;
                card.style.display = (matchesSearch && matchesFilter) ? 'flex' : 'none';
            });
        }

        filterBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                filterBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                filterTools();
            });
        });

        searchInput.addEventListener('input', filterTools);

        document.querySelectorAll('.faq-question').forEach(q => {
            q.addEventListener('click', () => {
                const answer = q.nextElementSibling;
                const isOpen = answer.style.display === 'block';
                answer.style.display = isOpen ? 'none' : 'block';
                q.querySelector('span').innerText = isOpen ? '[+]' : '[-]';
            });
        });
    </script>
      ` }} />
    </main>
  );
}
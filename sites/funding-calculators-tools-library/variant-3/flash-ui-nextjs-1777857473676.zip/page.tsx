import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<section class="hero">
        <div class="hero-content">
            <span class="hero-badge">FREE FINANCIAL TOOLS</span>
            <h1>Business Funding Calculators That Actually Help You Make a Decision.</h1>
            <p>Use practical tools to estimate payments, compare funding options, calculate commissions, check readiness, and understand your next move before applying.</p>
            <a href="#directory" class="btn-primary">Use the Calculators</a>
        </div>
    </section>

    <div class="tools-container" id="directory">
        <div class="filter-bar">
            <div class="search-wrapper">
                <span class="search-icon">🔍</span>
                <input type="text" id="toolSearch" placeholder="Search by name or keyword (e.g. 'MCA', 'Ready')...">
            </div>
            <div class="filter-pills">
                <button class="pill active" data-filter="all">All Tools</button>
                <button class="pill" data-filter="borrower">Borrower</button>
                <button class="pill" data-filter="broker">Broker</button>
                <button class="pill" data-filter="credit">Credit Readiness</button>
                <button class="pill" data-filter="specialized">Specialized</button>
            </div>
        </div>

        <div class="tools-grid" id="toolsGrid">
            <!-- Business Loan Payments -->
            <div class="tool-card" data-category="borrower">
                <div class="card-header">
                    <div class="icon-box">📊</div>
                    <span class="category-tag">Borrower</span>
                </div>
                <h3>Business Loan Payment</h3>
                <p>Calculate monthly installments for traditional term loans based on principal, term, and APR.</p>
                <a href="#" class="tool-link">Open Calculator</a>
            </div>

            <!-- Revenue-Based Financing -->
            <div class="tool-card" data-category="borrower">
                <div class="card-header">
                    <div class="icon-box">📈</div>
                    <span class="category-tag">Borrower</span>
                </div>
                <h3>Revenue-Based Financing</h3>
                <p>Estimate the total cost of capital and repayment timeline based on your monthly sales percentage.</p>
                <a href="#" class="tool-link">Calculate Capital</a>
            </div>

            <!-- MCA Factor Rates -->
            <div class="tool-card" data-category="borrower">
                <div class="card-header">
                    <div class="icon-box">⚡</div>
                    <span class="category-tag">Borrower</span>
                </div>
                <h3>MCA Factor Rate Converter</h3>
                <p>Convert MCA factor rates into effective APRs to truly understand the cost of a cash advance.</p>
                <a href="#" class="tool-link">Check Rate</a>
            </div>

            <!-- Loan Broker Commissions -->
            <div class="tool-card" data-category="broker">
                <div class="card-header">
                    <div class="icon-box">💰</div>
                    <span class="category-tag">Broker</span>
                </div>
                <h3>Broker Commission Tool</h3>
                <p>Calculate points, upsells, and net payouts for complex multi-product funding deals.</p>
                <a href="#" class="tool-link">Calculate Payout</a>
            </div>

            <!-- Funding Readiness -->
            <div class="tool-card" data-category="credit">
                <div class="card-header">
                    <div class="icon-box">✅</div>
                    <span class="category-tag">Credit</span>
                </div>
                <h3>Funding Readiness Quiz</h3>
                <p>Audit your financials, time in business, and documents to see if you qualify for prime rates.</p>
                <a href="#" class="tool-link">Start Audit</a>
            </div>

            <!-- Business Credit Readiness -->
            <div class="tool-card" data-category="credit">
                <div class="card-header">
                    <div class="icon-box">🏛️</div>
                    <span class="category-tag">Credit</span>
                </div>
                <h3>Business Credit Scorecard</h3>
                <p>Analyze your Paydex, Experian Business, and Equifax profiles for funding optimization.</p>
                <a href="#" class="tool-link">View Scorecard</a>
            </div>

            <!-- DSCR -->
            <div class="tool-card" data-category="specialized">
                <div class="card-header">
                    <div class="icon-box">🏢</div>
                    <span class="category-tag">Specialized</span>
                </div>
                <h3>DSCR Calculator</h3>
                <p>Crucial for real estate and acquisition financing. Measure your debt service coverage ratio.</p>
                <a href="#" class="tool-link">Analyze Ratio</a>
            </div>

            <!-- Equipment Financing -->
            <div class="tool-card" data-category="specialized">
                <div class="card-header">
                    <div class="icon-box">🏗️</div>
                    <span class="category-tag">Specialized</span>
                </div>
                <h3>Equipment ROI & Payment</h3>
                <p>Compare leasing vs. buying and find the monthly cost of new or used heavy equipment.</p>
                <a href="#" class="tool-link">Get ROI</a>
            </div>

            <!-- Invoice Factoring -->
            <div class="tool-card" data-category="borrower">
                <div class="card-header">
                    <div class="icon-box">🧾</div>
                    <span class="category-tag">Borrower</span>
                </div>
                <h3>Invoice Factoring Fee Tool</h3>
                <p>Calculate advance rates and discount fees for outstanding accounts receivables.</p>
                <a href="#" class="tool-link">Compare Fees</a>
            </div>

            <!-- Truck Repair Recovery -->
            <div class="tool-card" data-category="specialized">
                <div class="card-header">
                    <div class="icon-box">🚛</div>
                    <span class="category-tag">Specialized</span>
                </div>
                <h3>Truck Repair Financing</h3>
                <p>Specific calculator for logistics owners managing emergency repair and downtime costs.</p>
                <a href="#" class="tool-link">Estimate Recovery</a>
            </div>

            <!-- Acquisition Financing -->
            <div class="tool-card" data-category="specialized">
                <div class="card-header">
                    <div class="icon-box">🤝</div>
                    <span class="category-tag">Specialized</span>
                </div>
                <h3>Acquisition Gap Analysis</h3>
                <p>Planning to buy a business? Calculate the gap between SBA limits and seller financing.</p>
                <a href="#" class="tool-link">Run Analysis</a>
            </div>

            <!-- Working Capital Gaps -->
            <div class="tool-card" data-category="borrower">
                <div class="card-header">
                    <div class="icon-box">💧</div>
                    <span class="category-tag">Borrower</span>
                </div>
                <h3>Working Capital Shortfall</h3>
                <p>Input your accounts payable and receivable cycles to identify funding gaps in your cash flow.</p>
                <a href="#" class="tool-link">Identify Gaps</a>
            </div>
        </div>
    </div>

    <section class="section-light">
        <div class="section-container">
            <div class="section-header">
                <h2>Frequently Asked Questions</h2>
                <p>Expert guidance on using our financial modeling tools.</p>
            </div>
            <div class="faq-grid">
                <div class="faq-item">
                    <h4>Are these calculators accurate for 2024?</h4>
                    <p>Yes. Our algorithms are updated monthly based on current SBA rates, SOFR benchmarks, and market averages from top alternative lenders.</p>
                </div>
                <div class="faq-item">
                    <h4>Do I need to provide personal info?</h4>
                    <p>No. These tools are designed for anonymous modeling. You only provide contact info if you choose to request a specific funding quote.</p>
                </div>
                <div class="faq-item">
                    <h4>Can I export these results?</h4>
                    <p>Every tool includes a "Download PDF Report" option inside the calculator interface for your records or to show your bank.</p>
                </div>
                <div class="faq-item">
                    <h4>Which calculator should I start with?</h4>
                    <p>If you're unsure, start with the "Funding Readiness Quiz." It identifies which funding types you actually qualify for first.</p>
                </div>
            </div>
        </div>
    </section>

    <div class="cta-banner">
        <div class="cta-box">
            <h2>Not sure which path to take?</h2>
            <p style="margin-bottom: 32px; font-size: 1.1rem; opacity: 0.9;">Book a 15-minute strategy call with a funding expert to review your calculator results and map out your application strategy.</p>
            <a href="#" class="btn-accent">Talk to a Funding Strategist</a>
        </div>
    </div>

    <script>
        const searchInput = document.getElementById('toolSearch');
        const filterPills = document.querySelectorAll('.pill');
        const toolCards = document.querySelectorAll('.tool-card');

        // Search Logic
        searchInput.addEventListener('keyup', () => {
            const query = searchInput.value.toLowerCase();
            filterCards();
        });

        // Filter Logic
        filterPills.forEach(pill => {
            pill.addEventListener('click', () => {
                filterPills.forEach(p => p.classList.remove('active'));
                pill.classList.add('active');
                filterCards();
            });
        });

        function filterCards() {
            const query = searchInput.value.toLowerCase();
            const activeFilter = document.querySelector('.pill.active').getAttribute('data-filter');

            toolCards.forEach(card => {
                const title = card.querySelector('h3').innerText.toLowerCase();
                const desc = card.querySelector('p').innerText.toLowerCase();
                const category = card.getAttribute('data-category');
                
                const matchesSearch = title.includes(query) || desc.includes(query);
                const matchesFilter = activeFilter === 'all' || category === activeFilter;

                if (matchesSearch && matchesFilter) {
                    card.style.display = 'flex';
                } else {
                    card.style.display = 'none';
                }
            });
        }
    </script>
      ` }} />
    </main>
  );
}
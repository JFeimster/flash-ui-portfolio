import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<div class="container">
        <header>
            <div class="logo">VJD</div>
            <nav>
                <a href="#">Archives</a>
                <a href="#">The Mission</a>
                <a href="#">Store</a>
                <a href="#" style="color: var(--stencil-red);">Read the Dispatch</a>
            </nav>
        </header>

        <!-- Hero Section -->
        <section class="hero">
            <div class="coffee-stain" style="top: 20px; left: -50px;"></div>
            <div class="hero-hook">TOP SECRET // EYES ONLY</div>
            <h1>Field Notes From the War Between Freedom & Bullshit</h1>
            <p>Essays, rants, jokes, hard-earned lessons, and dispatches for people who like their truth direct, human, and slightly dangerous.</p>
            <a href="#" class="btn">Read the Dispatch</a>
            <div class="stamp hero-stamp">Approved for Release</div>
        </section>

        <!-- Latest Dispatches -->
        <section class="section-title">
            <h2>Latest Dispatches</h2>
            <div class="line"></div>
        </section>

        <div class="dispatches">
            <article class="dispatch-card">
                <span class="meta">Dispatch #084 // Satire</span>
                <h3>The General's Guide to PowerPoint Warfare</h3>
                <p>How we traded kinetic superiority for bullet points and why the next war will be won by whoever has the best clip-art.</p>
                <a href="#" class="read-more">View Full Intel &rarr;</a>
            </article>

            <article class="dispatch-card">
                <span class="meta">Dispatch #083 // Leadership</span>
                <h3>Leading from the Bottom of a Mud Hole</h3>
                <p>Authenticity isn't a corporate buzzword; it's what happens when everything is going wrong and you're still holding the line.</p>
                <a href="#" class="read-more">View Full Intel &rarr;</a>
            </article>

            <article class="dispatch-card">
                <span class="meta">Dispatch #082 // Entrepreneurship</span>
                <h3>Post-Combat Capitalism</h3>
                <p>Applying tactical maneuvers to the boardroom without getting HR called on you. A veteran's guide to the startup grind.</p>
                <a href="#" class="read-more">View Full Intel &rarr;</a>
            </article>
        </div>

        <!-- Field Notes / Leadership / Freedom -->
        <div class="field-grid">
            <div class="main-column">
                <div class="column-header">
                    <h3 class="stencil">Operational Debriefs</h3>
                </div>
                
                <div class="list-item">
                    <div>
                        <h4>Why "Safe Spaces" Don't Exist in the Wild</h4>
                        <span class="category-tag">Freedom Commentary</span>
                    </div>
                    <span class="typewriter">12 OCT</span>
                </div>

                <div class="list-item">
                    <div>
                        <h4>The Art of the Strategic Middle Finger</h4>
                        <span class="category-tag">Satire</span>
                    </div>
                    <span class="typewriter">08 OCT</span>
                </div>

                <div class="list-item">
                    <div>
                        <h4>Supply Chain Chaos: A Grunt's Perspective</h4>
                        <span class="category-tag">Business</span>
                    </div>
                    <span class="typewriter">01 OCT</span>
                </div>

                <div class="list-item">
                    <div>
                        <h4>Stoicism for the Modern Insomniac</h4>
                        <span class="category-tag">Philosophy</span>
                    </div>
                    <span class="typewriter">25 SEP</span>
                </div>
            </div>

            <aside class="sidebar-column">
                <div class="column-header">
                    <h3 class="stencil">The Arsenal</h3>
                </div>
                <p class="typewriter" style="font-size: 0.9rem; margin-bottom: 20px;">Essential reading for the unconventional mind.</p>
                <div style="border: 2px dashed var(--black); padding: 15px; transform: rotate(1deg);">
                    <p class="typewriter"><strong>Recommended:</strong> The 3:00 AM Rant Archive. Collected thoughts from the dark hours.</p>
                    <br>
                    <a href="#" style="color: var(--stencil-red); font-weight: bold; text-decoration: none;">[ ACCESS GRANTED ]</a>
                </div>
                <div class="stamp" style="margin-top: 30px; transform: rotate(5deg); display: block; text-align: center;">Verified</div>
            </aside>
        </div>
    </div>

    <!-- Dark Section -->
    <section class="split-section">
        <div class="container">
            <div class="split-grid">
                <div>
                    <h2>Leadership Lessons</h2>
                    <p>True leadership isn't about the rank on your collar or the title on your LinkedIn. It's about the weight you're willing to carry when no one is looking. We dive into the grit of commanding respect, managing chaos, and why the "nice guy" finishes last—but the "fair guy" wins the war.</p>
                </div>
                <div>
                    <h2>Freedom Commentary</h2>
                    <p>Freedom is a muscle that atrophies without exercise. We dissect the cultural landscape with a cynical eye and a combat-tested bullshit detector. From the erosion of individual rights to the comedy of modern bureaucracy, nothing is off-limits and no one is safe from the truth.</p>
                </div>
            </div>
        </div>
    </section>

    <div class="container">
        <!-- Final CTA -->
        <section class="subscribe-box">
            <div class="coffee-stain" style="bottom: -20px; right: 50px;"></div>
            <h2 class="stencil">Join the Unit</h2>
            <p class="typewriter">Get the weekly dispatch delivered to your secure inbox. No spam. No fluff. Just the raw, uncut truth and the occasional dark joke to keep your spirits up.</p>
            
            <form class="subscribe-form">
                <input type="email" placeholder="YOUR_EMAIL@DISPATCH.COM" required>
                <button type="submit">SIGN THE WAIVER</button>
            </form>
            
            <p style="margin-top: 20px; font-size: 0.7rem; opacity: 0.6;">By clicking "Sign the Waiver" you agree to receive communications from the Veteran Jester. Unsubscribe if you can't handle the heat.</p>
        </section>
    </div>

    <footer>
        <div class="container">
            <span class="footer-logo">Veteran Jester Dispatch</span>
            <p>&copy; 2023 // All Rights Reserved // Out of Content & Out of Ammo</p>
            <div class="social-links">
                <a href="#">Twitter/X</a>
                <a href="#">Instagram</a>
                <a href="#">Substack</a>
            </div>
        </div>
    </footer>
      ` }} />
    </main>
  );
}
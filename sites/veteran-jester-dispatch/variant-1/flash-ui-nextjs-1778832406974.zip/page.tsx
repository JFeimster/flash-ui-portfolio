import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<div class="dossier-container">
        <!-- Visual Decor -->
        <div class="ink-smudge" style="top: 10%; right: 5%;"></div>
        <div class="ink-smudge" style="bottom: 15%; left: 2%;"></div>

        <header>
            <div class="stamp-classified">Highly Relevant</div>
            <div class="hook">Field Notes From the War Between Freedom and Bullshit</div>
            <h1 class="brand-logo">Veteran Jester<br>Dispatch</h1>
            <p class="hero-message">
                Essays, rants, jokes, hard-earned lessons, and dispatches for people who like their truth direct, human, and slightly dangerous.
            </p>
            <a href="#dispatches" class="btn-primary">Read the Dispatch</a>
        </header>

        <section id="dispatches">
            <h2 class="section-title">Latest Intel</h2>
            <div class="dispatch-grid">
                <!-- Card 1 -->
                <div class="dispatch-card">
                    <div class="card-meta">Dispatch #084 // Satire</div>
                    <h3 class="card-title">How to Survive a Meeting That Should’ve Been an Email, But Is Now a War Crime</h3>
                    <p class="card-excerpt">A tactical guide to maintaining your soul while corporate buzzwords are launched at your head like mortar rounds...</p>
                    <a href="#" class="card-link">Decrypt Full File →</a>
                </div>

                <!-- Card 2 -->
                <div class="dispatch-card">
                    <div class="card-meta">Dispatch #083 // Personal</div>
                    <h3 class="card-title">The Silence of the High Desert: What the Mojave Taught Me About Entrepreneurship</h3>
                    <p class="card-excerpt">Sometimes the most productive thing you can do is sit in a folding chair and listen to the wind until the bullshit evaporates...</p>
                    <a href="#" class="card-link">Decrypt Full File →</a>
                </div>

                <!-- Card 3 -->
                <div class="dispatch-card">
                    <div class="card-meta">Dispatch #082 // Leadership</div>
                    <h3 class="card-title">Why Your "Culture" Slide Deck is Total Garbage (and how to fix it)</h3>
                    <p class="card-excerpt">Real culture isn't found in a PDF. It's found in the foxholes of the 2:00 AM server crash and how you treat the janitor...</p>
                    <a href="#" class="card-link">Decrypt Full File →</a>
                </div>
            </div>
        </section>

        <section>
            <h2 class="section-title">Archives by Sector</h2>
            <div class="category-scroll">
                <span class="category-tag">Tactical Satire</span>
                <span class="category-tag">Leadership Scars</span>
                <span class="category-tag">Freedom Commentary</span>
                <span class="category-tag">Gallows Humor</span>
                <span class="category-tag">Small Biz Warfare</span>
                <span class="category-tag">Combat Veteran POV</span>
            </div>
        </section>

        <section>
            <div class="feature-split">
                <div class="feature-block">
                    <h3>Leadership Scars</h3>
                    <div class="lesson-item">
                        <p><span class="lesson-number">01.</span> If you're the smartest person in the squad, you've already lost the mission.</p>
                    </div>
                    <div class="lesson-item">
                        <p><span class="lesson-number">02.</span> Loyalty is earned in liters, not likes.</p>
                    </div>
                    <div class="lesson-item">
                        <p><span class="lesson-number">03.</span> Confusion is the enemy's greatest weapon. Clarity is yours.</p>
                    </div>
                    <a href="#" class="card-link">View All Lessons</a>
                </div>
                <div class="feature-block">
                    <h3>Freedom & Bullshit</h3>
                    <p style="font-size: 1.1rem; border: 2px solid var(--ink); padding: 20px; background: rgba(255,255,255,0.3); position: relative;">
                        "Freedom isn't just a flag you wave on the 4th; it's the ability to tell a powerful person to go pound sand without losing your lunch money. Currently, we're running low on sand pounders."
                        <br><br>
                        <strong>— The Jester</strong>
                    </p>
                </div>
            </div>
        </section>

        <section class="subscribe-section">
            <div class="subscribe-box">
                <h2>Enlist for the Dispatch</h2>
                <p>No spam. No fluff. Just hard truths and dark humor delivered straight to your inbox when the ink is dry.</p>
                <div class="input-group">
                    <input type="email" placeholder="YOUR_EMAIL@HERE.COM">
                    <button type="submit">SIGN UP</button>
                </div>
                <p style="margin-top: 15px; font-size: 0.7rem; text-transform: uppercase;">By signing up, you acknowledge that feelings may be bruised.</p>
            </div>
        </section>

        <section style="text-align: center; border-bottom: none;">
            <p style="font-family: 'Special Elite'; font-size: 1.2rem; margin-bottom: 20px;">READY TO DIVE DEEPER INTO THE CHAOS?</p>
            <a href="#" class="btn-primary">Read the Dispatch</a>
        </section>

        <footer>
            <p>© 19XX-2024 VETERAN JESTER DISPATCH // <span class="strikethrough">TOP SECRET</span> // UNCLASSIFIED</p>
            <p style="margin-top: 10px; opacity: 0.6;">Built in the mud. Written in the dark. Shared for the free.</p>
        </footer>
    </div>
      ` }} />
    </main>
  );
}
import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<nav>
        <div class="container" style="display: flex; justify-content: space-between; align-items: center; width: 100%;">
            <div class="logo">FUNDING<span>PUNK</span></div>
            <a href="#apply" class="cta-btn" style="padding: 10px 20px; font-size: 0.9rem; box-shadow: 4px 4px 0px var(--white);">Apply Now</a>
        </div>
    </nav>

    <header class="hero">
        <div class="container">
            <div class="badge">SYSTEM READY v2.0</div>
            <h1>Start a Funding Agency <br>Without Building the <span class="accent-text">Whole Damn Machine</span> Yourself.</h1>
            <p>Plug into the tools, training, scripts, funding partners, and launch resources you need to help business owners access capital and earn high-ticket commissions.</p>
            <a href="#apply" class="cta-btn">Apply to Become a Partner</a>
        </div>
    </header>

    <section>
        <div class="container">
            <h2 class="section-title">Who This Is For</h2>
            <div class="grid-3">
                <div class="card">
                    <h3>The Builder</h3>
                    <p>You have the drive but don't want to waste 12 months building back-end infrastructure and vetting lenders.</p>
                </div>
                <div class="card" style="background: var(--acid);">
                    <h3>The Closer</h3>
                    <p>You’re great at talking to business owners but need a powerhouse machine to handle the funding fulfillment.</p>
                </div>
                <div class="card">
                    <h3>The Scaler</h3>
                    <p>You already have an audience or traffic source and want to plug in a high-margin financial backend.</p>
                </div>
            </div>
        </div>
    </section>

    <section style="background: #050505;">
        <div class="container">
            <h2 class="section-title">What Partners Get</h2>
            <div class="benefits-grid">
                <div class="benefit-item">
                    <span>01. LENDER NETWORK</span>
                    <p>Instant access to 50+ vetted business funding partners across all industries.</p>
                </div>
                <div class="benefit-item">
                    <span>02. SALES SCRIPTS</span>
                    <p>Tested, high-conversion scripts for cold outreach, follow-ups, and closing calls.</p>
                </div>
                <div class="benefit-item">
                    <span>03. CRM & TOOLS</span>
                    <p>Your own dashboard to track leads, applications, and your commission payouts.</p>
                </div>
                <div class="benefit-item">
                    <span>04. 1-ON-1 TRAINING</span>
                    <p>Direct access to our senior underwriters and agency growth mentors.</p>
                </div>
            </div>
        </div>
    </section>

    <section>
        <div class="container">
            <h2 class="section-title">The Model</h2>
            <div class="model-steps">
                <div class="step">
                    <div class="step-num">01</div>
                    <div>
                        <h3>Identify The Need</h3>
                        <p>Use our tools to find business owners who need capital for growth, inventory, or equipment.</p>
                    </div>
                </div>
                <div class="step">
                    <div class="step-num">02</div>
                    <div>
                        <h3>Plug Into The Machine</h3>
                        <p>Submit basic info through your partner portal. Our automated system routes the deal to the best lenders.</p>
                    </div>
                </div>
                <div class="step">
                    <div class="step-num">03</div>
                    <div>
                        <h3>Collect Your Cut</h3>
                        <p>Once the deal funds, you get paid a percentage of the total funding amount. No overhead, no chasing payments.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section>
        <div class="container">
            <div class="income-box">
                <div class="badge" style="background: black; color: var(--acid);">REVENUE POTENTIAL</div>
                <h2>\$10K - \$50K / MO</h2>
                <p style="font-weight: bold; text-transform: uppercase;">Based on 2-4 Funded Deals per Month. High-Ticket Commissions paid weekly.</p>
            </div>
        </div>
    </section>

    <section>
        <div class="container">
            <h2 class="section-title">Daily Action Plan</h2>
            <div style="background: var(--gray); padding: 40px; border-left: 5px solid var(--white);">
                <ul style="list-style: none; font-size: 1.2rem;">
                    <li style="margin-bottom: 20px;">⚡ <strong>09:00 AM:</strong> Run lead extraction tool (provided).</li>
                    <li style="margin-bottom: 20px;">⚡ <strong>10:30 AM:</strong> Deploy automated outreach sequence.</li>
                    <li style="margin-bottom: 20px;">⚡ <strong>01:00 PM:</strong> Review application status in your portal.</li>
                    <li>⚡ <strong>03:00 PM:</strong> Strategy call with your dedicated mentor.</li>
                </ul>
            </div>
        </div>
    </section>

    <section>
        <div class="container">
            <h2 class="section-title">Resource Library</h2>
            <div class="library-preview">
                <div class="lib-card"><span>Legal Contracts</span></div>
                <div class="lib-card" style="border-color: var(--acid);"><span>Email Templates</span></div>
                <div class="lib-card"><span>Lender Matrix</span></div>
                <div class="lib-card"><span>Ad Creatives</span></div>
            </div>
        </div>
    </section>

    <section>
        <div class="container" style="max-width: 800px;">
            <h2 class="section-title">FAQ</h2>
            <div class="faq-item">
                <h4>Do I need financial experience?</h4>
                <p>No. We provide the underwriter-vetted system. You provide the hustle.</p>
            </div>
            <div class="faq-item">
                <h4>How long until I'm live?</h4>
                <p>Most partners launch their first campaign within 48 hours of joining.</p>
            </div>
            <div class="faq-item">
                <h4>Are there territorial restrictions?</h4>
                <p>No. You can fund businesses across the entire US and Canada.</p>
            </div>
        </div>
    </section>

    <section class="final-cta" id="apply">
        <div class="container">
            <h2>READY TO PLUG IN?</h2>
            <p style="font-size: 1.5rem; margin-bottom: 50px;">We're looking for 10 new partners this month. No fluff. Just funding.</p>
            <a href="#" class="cta-btn" style="background: var(--bg); color: var(--acid); border-color: var(--acid); box-shadow: 10px 10px 0px var(--bg);">Apply to Become a Partner</a>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2024 FUNDINGPUNK AGENCY SYSTEM. ALL RIGHTS RESERVED. NOT A FRANCHISE. RESULTS NOT GUARANTEED.</p>
        </div>
    </footer>
      ` }} />
    </main>
  );
}
import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<nav class="container">
        <div class="logo">FUNDING<span>PUNK</span></div>
        <div class="nav-links">
            <a href="#apply" style="color: var(--primary); text-decoration: none; font-weight: 900; border: 2px solid var(--primary); padding: 8px 15px;">APPLY NOW</a>
        </div>
    </nav>

    <header class="hero container">
        <span class="badge">NOW RECRUITING FOR Q4</span>
        <h1>START A FUNDING AGENCY WITHOUT BUILDING THE WHOLE DAMN MACHINE YOURSELF.</h1>
        <p>Plug into the tools, training, scripts, funding partners, and launch resources you need to help business owners access capital.</p>
        <a href="#apply" class="cta-btn">Apply to Become a Partner</a>
    </header>

    <section class="container">
        <h2 class="section-title">Who This Is For</h2>
        <div class="grid">
            <div class="who-for-item">
                <h4>The Corporate Fugitive</h4>
                <p>You have the skills but hate the ceiling. You want a high-ticket business without the 2-year dev cycle.</p>
            </div>
            <div class="who-for-item">
                <h4> The Networker</h4>
                <p>You already know business owners. Stop giving away free advice and start getting paid to solve their #1 problem: Cash.</p>
            </div>
            <div class="who-for-item">
                <h4>The Scale-Up Hustler</h4>
                <p>You’re tired of low-margin affiliate offers. You want deep commissions and institutional backing.</p>
            </div>
        </div>
    </section>

    <section style="background: #fff; color: #000;">
        <div class="container">
            <h2 class="section-title" style="color: #000;">What Partners Get</h2>
            <div class="grid">
                <div class="card">
                    <h3>Proprietary CRM</h3>
                    <p>Custom-built pipeline management to track every lead, funding stage, and commission in real-time.</p>
                </div>
                <div class="card">
                    <h3>Lender Network</h3>
                    <p>Instant access to 50+ tier-1 funding partners. No need to spend years building relationships.</p>
                </div>
                <div class="card">
                    <h3>The Playbook</h3>
                    <p>Proven scripts, email sequences, and outreach templates that have cleared \$100M+ in funding.</p>
                </div>
                <div class="card" style="box-shadow: 8px 8px 0px #000;">
                    <h3>White-Label Support</h3>
                    <p>Our back-office handles the heavy underwriting paperwork while you focus on the relationship.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="container">
        <h2 class="section-title">How The Model Works</h2>
        <div style="display: flex; flex-direction: column; gap: 20px;">
            <div style="border: 2px solid #333; padding: 30px; display: flex; align-items: center; gap: 30px;">
                <div style="font-size: 3rem; font-weight: 900; color: var(--primary);">01</div>
                <div>
                    <h3 style="margin-bottom: 10px;">Find the Gap</h3>
                    <p>Use our tools to identify businesses that need capital for growth, equipment, or payroll.</p>
                </div>
            </div>
            <div style="border: 2px solid #333; padding: 30px; display: flex; align-items: center; gap: 30px;">
                <div style="font-size: 3rem; font-weight: 900; color: var(--primary);">02</div>
                <div>
                    <h3 style="margin-bottom: 10px;">Submit the Lead</h3>
                    <p>Plug their data into our portal. Our automated systems match them with the best funding source.</p>
                </div>
            </div>
            <div style="border: 2px solid #333; padding: 30px; display: flex; align-items: center; gap: 30px;">
                <div style="font-size: 3rem; font-weight: 900; color: var(--primary);">03</div>
                <div>
                    <h3 style="margin-bottom: 10px;">Get Paid</h3>
                    <p>When the deal closes, you get a percentage of the total funding amount. Simple, fast, lucrative.</p>
                </div>
            </div>
        </div>
    </section>

    <div class="income-potential">
        <div class="container">
            <h2>Income Potential</h2>
            <div class="income-value">\$15,000+</div>
            <p style="font-weight: 900; text-transform: uppercase;">Average monthly commission for active partners</p>
            <p style="margin-top: 20px; font-size: 0.9rem;">*Results vary based on effort and network size.</p>
        </div>
    </div>

    <section class="container">
        <h2 class="section-title">Daily Action Plan</h2>
        <div class="action-plan">
            <div class="action-row">
                <div class="action-time">09:00</div>
                <div class="action-desc">Review automated lead notifications in CRM.</div>
            </div>
            <div class="action-row">
                <div class="action-time">10:30</div>
                <div class="action-desc">Follow up with pending applications using the "Closer Script."</div>
            </div>
            <div class="action-row">
                <div class="action-time">13:00</div>
                <div class="action-desc">Outreach to new referral partners (CPAs, Lawyers).</div>
            </div>
            <div class="action-row">
                <div class="action-time">16:00</div>
                <div class="action-desc">Submit new files to the underwriting desk.</div>
            </div>
        </div>
    </section>

    <section class="container">
        <h2 class="section-title">Resource Library</h2>
        <div class="library-preview">
            <div class="asset-card">
                <span class="label">PDF Guide</span>
                <h3>The 72-Hour Launch Sequence</h3>
            </div>
            <div class="asset-card">
                <span class="label">Video Masterclass</span>
                <h3>High-Ticket Objection Handling</h3>
            </div>
            <div class="asset-card">
                <span class="label">Legal Docs</span>
                <h3>Referral Partner Agreements</h3>
            </div>
            <div class="asset-card">
                <span class="label">Marketing</span>
                <h3>Ad Creative Swipe File</h3>
            </div>
        </div>
    </section>

    <section class="container">
        <h2 class="section-title">Frequently Asked</h2>
        <div class="faq-item">
            <h4>Do I need a financial license?</h4>
            <p>In most jurisdictions, working as a commercial loan broker or referral partner does not require a specific license, but we provide all the compliance training you need.</p>
        </div>
        <div class="faq-item">
            <h4>How long until I see my first commission?</h4>
            <p>Successful partners typically close their first deal within 21-30 days of completing the initial training.</p>
        </div>
        <div class="faq-item">
            <h4>Is this multi-level marketing?</h4>
            <p>Absolutely not. This is a direct B2B service agency model. You get paid for the capital you help businesses secure.</p>
        </div>
    </section>

    <div class="final-cta" id="apply">
        <div class="container">
            <h2>READY TO STOP REINVENTING THE WHEEL?</h2>
            <p style="margin-bottom: 40px; font-weight: bold; font-size: 1.2rem;">Limited spots available for the Q4 intake group.</p>
            <a href="#" class="cta-btn">Apply to Become a Partner</a>
            <p style="margin-top: 40px; font-size: 1.5rem; font-weight: 900;">BUILD THE AGENCY. WE'LL PROVIDE THE MACHINE.</p>
        </div>
    </div>

    <footer class="footer-bottom">
        &copy; 2023 FUNDING PUNK AGENTS. ALL RIGHTS RESERVED. NO REINVENTION ALLOWED.
    </footer>
      ` }} />
    </main>
  );
}
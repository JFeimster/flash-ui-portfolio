import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<!-- HERO -->
    <header>
        <div class="container">
            <span class="kicker">NOW RECRUITING PARTNERS</span>
            <h1>Start a Funding Agency <br><span style="color: var(--accent);">Without Building</span> The Whole Damn Machine Yourself.</h1>
            <p class="hero-sub">Plug into the tools, training, scripts, funding partners, and launch resources you need to help business owners access capital. We built it. You scale it.</p>
            <a href="#apply" class="btn">Apply to Become a Partner</a>
        </div>
    </header>

    <!-- WHO THIS IS FOR -->
    <section class="section-padding who-is-it-for">
        <div class="container">
            <h2 class="section-title">Who is this for?</h2>
            <div class="grid">
                <div class="card">
                    <h3>The Hustler</h3>
                    <p>You have the drive but don't want to spend 2 years building a backend, vetting lenders, or coding a CRM.</p>
                </div>
                <div class="card">
                    <h3>The Consultant</h3>
                    <p>You already talk to business owners and want a high-ticket "plug and play" service to offer them instantly.</p>
                </div>
                <div class="card">
                    <h3>The Career-Changer</h3>
                    <p>You want to enter the fintech space with a proven model and institutional-grade support from day one.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- WHAT PARTNERS GET -->
    <section class="section-padding">
        <div class="container">
            <h2 class="section-title">What Partners Get</h2>
            <div class="grid">
                <div class="card">
                    <h3>Direct Lenders</h3>
                    <p>Instant access to our pre-vetted network of 50+ business funding sources.</p>
                </div>
                <div class="card">
                    <h3>The Tech Stack</h3>
                    <p>Your own white-labeled portal, CRM, and automated lead tracking system.</p>
                </div>
                <div class="card">
                    <h3>Battle-Tested Scripts</h3>
                    <p>The exact outreach and closing scripts we've used to move \$50M+ in capital.</p>
                </div>
                <div class="card">
                    <h3>Weekly Coaching</h3>
                    <p>Live sessions with agency owners who are currently in the trenches.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- INCOME POTENTIAL -->
    <section class="section-padding income-potential">
        <div class="container">
            <h2 class="section-title">Income Potential</h2>
            <p style="font-size: 1.5rem; margin-bottom: 40px; font-weight: 700;">WE DON'T DO "SMALL" COMMISSIONS.</p>
            <div class="grid">
                <div>
                    <span class="income-stat">\$5k - \$15k</span>
                    <p>Avg. Monthly Partner Revenue</p>
                </div>
                <div>
                    <span class="income-stat">10% - 15%</span>
                    <p>Success Fee Per Funded Deal</p>
                </div>
                <div>
                    <span class="income-stat">ZERO</span>
                    <p>Cap on Your Earnings</p>
                </div>
            </div>
        </div>
    </section>

    <!-- DAILY ACTION PLAN -->
    <section class="section-padding">
        <div class="container">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 60px; align-items: center;">
                <div>
                    <h2 class="section-title">Daily Action Plan</h2>
                    <p style="margin-bottom: 30px;">Stop guessing what to do. Our partners follow a rigorous, high-output daily schedule designed for maximum conversion.</p>
                    <div class="action-list">
                        <div class="action-item">
                            <div class="action-num">01</div>
                            <div><strong>Lead Pulse:</strong> Run our automated outreach to identify business owners looking for 50k-500k.</div>
                        </div>
                        <div class="action-item">
                            <div class="action-num">02</div>
                            <div><strong>The Filter:</strong> Use our 5-minute vetting tool to see which lenders fit the profile.</div>
                        </div>
                        <div class="action-item">
                            <div class="action-num">03</div>
                            <div><strong>Submission:</strong> One-click upload to the partner portal. Our backend team takes over the paperwork.</div>
                        </div>
                    </div>
                </div>
                <div class="card" style="background: #1a1a1a; border-color: var(--accent); color: #fff;">
                    <h3 style="color: var(--accent); border-color: #fff;">Resource Library Preview</h3>
                    <ul style="list-style: none; margin-top: 20px;">
                        <li style="margin-bottom: 15px;">📁 2024 Lending Guidelines PDF</li>
                        <li style="margin-bottom: 15px;">📁 Cold Email "Icebreaker" Templates</li>
                        <li style="margin-bottom: 15px;">📁 LinkedIn Prospecting SOPs</li>
                        <li style="margin-bottom: 15px;">📁 Client Pre-Qualification Form</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQ -->
    <section class="section-padding" style="background: #050505;">
        <div class="container">
            <h2 class="section-title">Common Questions</h2>
            <div class="faq-item">
                <h4>Do I need a financial license?</h4>
                <p>In most jurisdictions, no. You are acting as a referral partner/consultant. We provide the licensed backend.</p>
            </div>
            <div class="faq-item">
                <h4>How soon can I fund my first deal?</h4>
                <p>Our fastest partners have funded their first deal within 14 days of completing the onboarding.</p>
            </div>
            <div class="faq-item">
                <h4>Is there a cost to join?</h4>
                <p>We look for skin in the game. There is a setup fee to cover your tech stack and training, but we make our real money when you fund deals.</p>
            </div>
        </div>
    </section>

    <!-- FINAL CTA -->
    <section class="final-cta" id="apply">
        <div class="container">
            <h2 class="punchy-text">THE MACHINE IS READY.<br><span style="color: var(--accent);">ARE YOU?</span></h2>
            <p style="font-size: 1.5rem; color: #888; margin-bottom: 40px;">We are currently accepting 10 new partners this month to ensure quality support.</p>
            <a href="#" class="btn" style="font-size: 2rem; padding: 30px 60px;">Apply to Become a Partner</a>
            <p style="margin-top: 30px; font-weight: 900; text-transform: uppercase; letter-spacing: 2px;">Application takes 3 minutes.</p>
        </div>
    </section>
      ` }} />
    </main>
  );
}
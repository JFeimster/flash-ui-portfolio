import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<nav>
        <div class="container" style="display:flex; justify-content: space-between; width: 100%; align-items: center;">
            <div class="logo">DISTRICT<span>CAPITAL</span></div>
            <div style="font-size: 0.8rem; letter-spacing: 1px; color: var(--gold-accent);">NW • WASHINGTON DC</div>
        </div>
    </nav>

    <section class="hero">
        <div class="container">
            <span class="hero-tag">Capital for the District</span>
            <h1>Business Funding for Washington DC Operators Who Don’t Have Time for Bank Games.</h1>
            <p>Explore flexible funding options for DC-area businesses, from working capital and equipment financing to revenue-based funding and business credit strategies.</p>
            <a href="#apply" class="btn">Explore DC Funding Options</a>
        </div>
    </section>

    <section class="section-padding">
        <div class="container">
            <h2 class="section-title">The DC Struggle: <br>Beyond the Bureaucracy</h2>
            <div class="grid">
                <div class="pain-card">
                    <h3>Red Tape Fatigue</h3>
                    <p>Traditional banks in the District are bogged down by compliance that doesn't fit the speed of a K-Street consultant or a Navy Yard startup.</p>
                </div>
                <div class="pain-card">
                    <h3>High Op-Ex Reality</h3>
                    <p>DC commercial rents and labor costs are among the highest in the nation. Waiting 60 days for a loan isn't an option when payroll is due.</p>
                </div>
                <div class="pain-card">
                    <h3>Seasonal Volatility</h3>
                    <p>From tourism ebbs to congressional recesses, DC business revenue fluctuates. You need funding that scales with your reality, not a rigid schedule.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="section-padding" style="background: rgba(22, 34, 53, 0.4);">
        <div class="container">
            <h2 class="section-title">DC-Specific Funding Portfolio</h2>
            <div class="funding-grid">
                <div class="funding-card">
                    <h4>Working Capital</h4>
                    <p>Immediate cash flow for inventory, marketing, or gap coverage between government contracts.</p>
                </div>
                <div class="funding-card">
                    <h4>Equipment Financing</h4>
                    <p>From kitchen upgrades in Adams Morgan to high-end tech for a Capitol Hill agency.</p>
                </div>
                <div class="funding-card">
                    <h4>Revenue-Based Funding</h4>
                    <p>Repay based on your sales. Perfect for the hospitality and service sectors in the Metro area.</p>
                </div>
                <div class="funding-card">
                    <h4>Credit Strategy</h4>
                    <p>Proprietary methods to build business credit profile that doesn't rely on your personal SSN.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="section-padding">
        <div class="container">
            <div class="grid" style="grid-template-columns: 1fr 1.5fr; align-items: center;">
                <div>
                    <h2 class="section-title">Built for the <br>DC Economy</h2>
                    <p style="color: var(--text-gray); margin-bottom: 30px;">We specialize in industries that drive the District, Maryland, and Virginia corridors.</p>
                </div>
                <div class="industry-list">
                    <span class="industry-tag">Federal Contractors</span>
                    <span class="industry-tag">Hospitality & Fine Dining</span>
                    <span class="industry-tag">Professional Services</span>
                    <span class="industry-tag">Tech & SaaS Startups</span>
                    <span class="industry-tag">Construction & HVAC</span>
                    <span class="industry-tag">Medical Practices</span>
                    <span class="industry-tag">Retail Boutiques</span>
                    <span class="industry-tag">Logistics & Transport</span>
                </div>
            </div>
        </div>
    </section>

    <section class="section-padding trust-section">
        <div class="container">
            <h2 style="font-family: var(--font-serif); font-size: 2.5rem; margin-bottom: 20px;">Local Impact. Local Insight.</h2>
            <p style="color: var(--text-gray);">While national lenders see a zip code, we see the community. We've deployed capital from Georgetown to Anacostia.</p>
            <div class="stat-grid">
                <div class="stat-item">
                    <h2>\$45M+</h2>
                    <p>Capital Deployed in DC</p>
                </div>
                <div class="stat-item">
                    <h2>48hr</h2>
                    <p>Average Funding Time</p>
                </div>
                <div class="stat-item">
                    <h2>92%</h2>
                    <p>Approval Rate</p>
                </div>
            </div>
        </div>
    </section>

    <section class="section-padding">
        <div class="container">
            <h2 class="section-title">Three Steps to Capital</h2>
            <div class="process-row">
                <div class="step">
                    <div class="step-num">01</div>
                    <h4>Digital Submission</h4>
                    <p style="color: var(--text-gray);">A 5-minute application tailored for busy DC business owners. No mountains of paperwork.</p>
                </div>
                <div class="step">
                    <div class="step-num">02</div>
                    <h4>Strategic Review</h4>
                    <p style="color: var(--text-gray);">Our local underwriters review your cash flow and potential, not just your credit score.</p>
                </div>
                <div class="step">
                    <div class="step-num">03</div>
                    <h4>Same-Day Offer</h4>
                    <p style="color: var(--text-gray);">Receive multiple funding options. Once signed, funds are wired directly to your DC business account.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="section-padding">
        <div class="container" style="max-width: 800px;">
            <h2 class="section-title" style="text-align: center; border-left: none; padding: 0;">Frequently Asked Questions</h2>
            <div class="faq-item">
                <h4>What are the requirements?</h4>
                <p>Typically, we look for 6+ months in business and at least \$15k in monthly gross revenue.</p>
            </div>
            <div class="faq-item">
                <h4>How does this differ from an SBA loan?</h4>
                <p>Speed. While SBA loans can take months, our private funding options close in as little as 24-48 hours.</p>
            </div>
            <div class="faq-item">
                <h4>Is my personal credit at risk?</h4>
                <p>Most of our programs focus on the business’s revenue performance rather than just the owner's FICO score.</p>
            </div>
        </div>
    </section>

    <section class="final-cta" id="apply">
        <div class="container">
            <h2>Ready to Scale in the District?</h2>
            <p style="margin-bottom: 40px; font-size: 1.2rem; color: var(--soft-gray);">Stop playing games with big banks. Get the capital your DC business deserves.</p>
            <a href="#" class="btn" style="padding: 25px 60px; font-size: 1.1rem;">Explore DC Funding Options</a>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>© 2023 District Capital Solutions | 1200 G St NW, Washington, DC 20005</p>
            <p style="margin-top: 10px; opacity: 0.5;">Funding is subject to underwriting approval. Terms and rates vary by product.</p>
        </div>
    </footer>
      ` }} />
    </main>
  );
}
import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<nav class="container">
        <div class="logo">DISTRICT CAPITAL</div>
        <div class="nav-links">
            <a href="#funding">Funding</a>
            <a href="#how-it-works">Process</a>
            <a href="#faq">FAQ</a>
            <a href="#" class="cta-button" style="padding: 10px 20px; font-size: 0.8rem;">Get Funded</a>
        </div>
    </nav>

    <header class="hero">
        <div class="container">
            <span class="hero-badge">Built for the DC Metro Area</span>
            <h1>Business Funding for Washington DC Operators Who Don’t Have Time for Bank Games.</h1>
            <p>Explore flexible funding options for DC-area businesses, from working capital and equipment financing to revenue-based funding and business credit strategies.</p>
            <div class="hero-actions">
                <a href="#apply" class="cta-button">Explore DC Funding Options</a>
                <a href="#how-it-works" class="cta-button cta-secondary">How it Works</a>
            </div>
        </div>
    </header>

    <section class="section-padding">
        <div class="container">
            <div class="section-header">
                <h2>The District's Speed vs. The Bank's Wait</h2>
                <p>Traditional banks don't move at the speed of NoMa or the Navy Yard. We do.</p>
            </div>
            <div class="grid-3">
                <div class="pain-point-card">
                    <h3>Red Tape</h3>
                    <p>Stop filling out mountains of paperwork just to be told "no" after six weeks of silence.</p>
                </div>
                <div class="pain-point-card">
                    <h3>Strict Collateral</h3>
                    <p>Small businesses shouldn't have to leverage their lives just to upgrade their kitchen or hire staff.</p>
                </div>
                <div class="pain-point-card">
                    <h3>Local Blindness</h3>
                    <p>National lenders don't understand the seasonality of DC tourism or the nuances of the consulting corridor.</p>
                </div>
            </div>
        </div>
    </section>

    <section id="funding" class="section-padding funding-options">
        <div class="container">
            <div class="section-header">
                <h2>Capitol City Funding Solutions</h2>
            </div>
            <div class="grid-3">
                <div class="option-card">
                    <h3>Working Capital</h3>
                    <ul>
                        <li>Approval in 24 hours</li>
                        <li>Terms up to 24 months</li>
                        <li>No collateral required</li>
                    </ul>
                    <p>Perfect for handling payroll, inventory, or emergency repairs in the District.</p>
                </div>
                <div class="option-card">
                    <h3>Revenue-Based</h3>
                    <ul>
                        <li>Based on cash flow</li>
                        <li>Flexible repayments</li>
                        <li>No fixed monthly bills</li>
                    </ul>
                    <p>Ideal for restaurants and seasonal hospitality businesses across DC.</p>
                </div>
                <div class="option-card">
                    <h3>Equipment Finance</h3>
                    <ul>
                        <li>Up to \$500k</li>
                        <li>New or used gear</li>
                        <li>Tax advantages</li>
                    </ul>
                    <p>From kitchen appliances to tech stacks for K-Street startups.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="industries">
        <div class="container">
            <div class="section-header">
                <h2>Industries We Power in the District</h2>
            </div>
            <div class="industry-tags">
                <span class="tag">Government Contractors</span>
                <span class="tag">Michelin-Starred Restaurants</span>
                <span class="tag">Boutique Retail</span>
                <span class="tag">IT & Cyber Security</span>
                <span class="tag">Non-Profits & NGOs</span>
                <span class="tag">Health & Wellness</span>
                <span class="tag">Construction & Trade</span>
                <span class="tag">Professional Services</span>
            </div>
        </div>
    </section>

    <section id="how-it-works" class="section-padding">
        <div class="container">
            <div class="section-header">
                <h2>A Frictionless Path to Capital</h2>
            </div>
            <div class="process-grid">
                <div class="step">
                    <div class="step-number">01</div>
                    <h3>60-Second Form</h3>
                    <p>A quick digital application that doesn't hurt your credit score.</p>
                </div>
                <div class="step">
                    <div class="step-number">02</div>
                    <h3>Consultation</h3>
                    <p>Speak with a funding specialist who knows the DC market.</p>
                </div>
                <div class="step">
                    <div class="step-number">03</div>
                    <h3>Secure Offers</h3>
                    <p>Review multiple funding structures tailored to your ROI.</p>
                </div>
                <div class="step">
                    <div class="step-number">04</div>
                    <h3>Same-Day Wire</h3>
                    <p>Funds hit your account, sometimes in as little as 4 hours.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="section-padding trust-section">
        <div class="container">
            <p class="trust-quote">"They understood that a business in Adams Morgan has different needs than a firm in Bethesda. They moved at our pace."</p>
            <p><strong>— Marcus T., DC Hospitality Group</strong></p>
        </div>
    </section>

    <section id="faq" class="section-padding">
        <div class="container">
            <div class="section-header">
                <h2>District Funding FAQ</h2>
            </div>
            <div class="faq-section">
                <div class="faq-item">
                    <h4>Do you work with startups?</h4>
                    <p>Yes. If you have at least 6 months of revenue history, we have options available for growth capital.</p>
                </div>
                <div class="faq-item">
                    <h4>What is the maximum funding amount?</h4>
                    <p>We provide solutions from \$10,000 up to \$2,000,000 depending on your business performance.</p>
                </div>
                <div class="faq-item">
                    <h4>Is there a credit score requirement?</h4>
                    <p>We focus on the health of your business and cash flow rather than just a FICO score.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="section-padding" style="background: var(--navy-light); text-align: center;">
        <div class="container">
            <h2 style="font-size: 3rem; margin-bottom: 30px;">Ready to grow your District presence?</h2>
            <a href="#" class="cta-button">Explore DC Funding Options</a>
        </div>
    </section>

    <footer>
        <div class="container">
            <span class="footer-logo">DISTRICT CAPITAL</span>
            <div class="dc-accent"></div>
            <p style="color: var(--text-muted); font-size: 0.8rem; letter-spacing: 1px;">Serving Washington DC, Maryland, and Virginia</p>
            <p style="margin-top: 40px; font-size: 0.75rem; color: #445;">© 2024 District Capital Partners. All rights reserved.</p>
        </div>
    </footer>
      ` }} />
    </main>
  );
}
import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<div class="noise"></div>

    <nav>
        <a href="#" class="logo">THE RADICAL LIBERTARIAN</a>
        <div style="font-weight: bold; color: var(--cream);">VOL. 001 // ISSUE: FREEDOM</div>
    </nav>

    <header class="hero torn-bottom">
        <h1>FREEDOM IS NOT SUPPOSED TO BE COMFORTABLE.</h1>
        <p>Essays, podcasts, rants, and philosophical grenades for people who distrust both the boot and the person begging to polish it.</p>
        <br><br>
        <a href="#manifesto" class="btn">Read the Manifesto</a>
    </header>

    <div class="marquee">
        <span>DECENTRALIZE EVERYTHING // QUESTION AUTHORITY // TAXATION IS EXTORTION // SOVEREIGNTY OF THE INDIVIDUAL // NO NPC SCRIPTS // </span>
    </div>

    <h2 class="section-title">THE CORE TENETS</h2>
    
    <section id="manifesto" class="manifesto-container">
        <div class="card">
            <h3>01. Radical Sovereignty</h3>
            <p>You own your body. You own your mind. You own your time. Any entity claiming a percentage of these without consent is an aggressor.</p>
        </div>
        <div class="card">
            <h3>02. Digital Defiance</h3>
            <p>Cryptography is the ultimate weapon against tyranny. Code is speech, and privacy is a fundamental human right, not a privilege.</p>
        </div>
        <div class="card">
            <h3>03. Anti-Compliance</h3>
            <p>The "common good" is a linguistic trap used to justify the erosion of personal liberty. We reject the collective consensus.</p>
        </div>
        <div class="card">
            <h3>04. Market Anarchy</h3>
            <p>Unregulated exchange is the natural state of humanity. State interference is a distortion of value and human desire.</p>
        </div>
    </section>

    <section class="essays">
        <h2 style="font-size: 4rem; margin-bottom: 3rem;">LATEST RANTS</h2>
        <a href="#" class="essay-item">
            <h4>THE MYTH OF THE SOCIAL CONTRACT</h4>
            <span>OCT 24</span>
        </a>
        <a href="#" class="essay-item">
            <h4>WHY YOUR VOTE IS A PSY-OP</h4>
            <span>OCT 21</span>
        </a>
        <a href="#" class="essay-item">
            <h4>BITCOIN: THE EXIT RAMP FROM TYRANNY</h4>
            <span>OCT 15</span>
        </a>
        <a href="#" class="essay-item">
            <h4>CENSORSHIP-INDUSTRIAL COMPLEX</h4>
            <span>OCT 08</span>
        </a>
    </section>

    <section class="podcasts torn-top torn-bottom">
        <h2 style="font-size: 3.5rem; margin-bottom: 4rem; text-align: center;">THE AUDIO GRENADE</h2>
        <div class="podcast-grid">
            <div class="podcast-box">
                <p>EP. 142</p>
                <h3>Waging Peace, Preparing for War</h3>
                <p>A deep dive into agorism and counter-economics in a surveillance state.</p>
                <br>
                <a href="#" style="color: var(--red); font-weight: bold;">LISTEN NOW -></a>
            </div>
            <div class="podcast-box">
                <p>EP. 141</p>
                <h3>The Psychology of the Serf</h3>
                <p>Why do people beg for more chains? Discussion with Dr. X about institutional Stockholm syndrome.</p>
                <br>
                <a href="#" style="color: var(--red); font-weight: bold;">LISTEN NOW -></a>
            </div>
        </div>
    </section>

    <section class="enemies">
        <h2 style="font-size: 4rem;">ENEMIES OF THINKING</h2>
        <div class="enemy-list">
            <div class="enemy-tag" style="--r: -2;">PARTY LINES</div>
            <div class="enemy-tag" style="--r: 3;">SAFETYISM</div>
            <div class="enemy-tag" style="--r: -1;">CENTRAL BANKS</div>
            <div class="enemy-tag" style="--r: 4;">BUREAUCRACY</div>
            <div class="enemy-tag" style="--r: -3;">NPC DIALOGUE</div>
            <div class="enemy-tag" style="--r: 2;">COMPLIANCE</div>
        </div>
    </section>

    <section class="signup">
        <h2 style="font-size: 3rem; margin-bottom: 1rem;">JOIN THE UNDERGROUND</h2>
        <p style="margin-bottom: 2rem;">No spam. Just hard truths delivered to your inbox when the signal is clear.</p>
        <form onsubmit="return false;">
            <input type="email" placeholder="YOUR@EMAIL.COM" required>
            <br><br>
            <button class="btn">ENLIST NOW</button>
        </form>
    </section>

    <footer>
        <p style="font-size: 2rem; font-family: 'Archivo Black';">THE RADICAL LIBERTARIAN</p>
        <p>© NONE. REPLICATE. DISTRIBUTE. DESTROY.</p>
        <div style="margin-top: 2rem;">
            <a href="#" style="color: var(--cream); margin: 0 10px;">TWITTER / X</a>
            <a href="#" style="color: var(--cream); margin: 0 10px;">NOSTR</a>
            <a href="#" style="color: var(--cream); margin: 0 10px;">RSS</a>
        </div>
    </footer>
      ` }} />
    </main>
  );
}
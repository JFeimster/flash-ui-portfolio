import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<nav>
        <div class="container nav-content">
            <div class="logo">Darwin Hanneman <span>/ Partner Kit</span></div>
            <div style="font-size: 0.7rem; letter-spacing: 2px;">POWERED BY MOONSHINE CAPITAL</div>
        </div>
    </nav>

    <header class="hero">
        <div class="container hero-grid">
            <div class="hero-text">
                <div class="hero-badge">Direct Commercial Partner</div>
                <h1>Commercial Funding Support Built on Relationships.</h1>
                <p>Darwin helps business owners and referral partners explore practical funding options for equipment, working capital, trucking, and construction.</p>
                <a href="#contact" class="btn btn-gold">Work With Darwin</a>
            </div>
            <div class="hero-visual">
                <!-- Profile Image Placeholder -->
                <div style="width: 100%; height: 450px; background: rgba(255,255,255,0.1); border-radius: 8px; border: 1px solid var(--gold); display: flex; align-items: center; justify-content: center; position: relative;">
                    <div style="text-align: center; color: var(--gold);">
                        <div style="font-size: 4rem; margin-bottom: 1rem;">DH</div>
                        <div style="text-transform: uppercase; letter-spacing: 3px; font-size: 0.8rem;">Professional Profile</div>
                    </div>
                    <div style="position: absolute; bottom: -20px; right: -20px; background: var(--gold); color: var(--navy); padding: 1.5rem; font-weight: 700; border-radius: 4px; box-shadow: 0 10px 30px rgba(0,0,0,0.3);">
                        15+ Years Experience
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="trust-strip">
        <div class="container trust-flex">
            <div>EQUIPMENT FINANCING</div>
            <div>WORKING CAPITAL</div>
            <div>TRUCKING SPECIALIST</div>
            <div>CONSTRUCTION LOANS</div>
            <div>SBA INTERMEDIARY</div>
        </div>
    </div>

    <section id="lanes">
        <div class="container">
            <div class="section-header">
                <h2>Best-Fit Funding Lanes</h2>
                <div class="divider"></div>
            </div>
            <div class="card-grid">
                <div class="card">
                    <div class="card-icon">⛟</div>
                    <h3>Trucking & Logistics</h3>
                    <p>Specialized financing for owner-operators and fleets. New rigs, trailers, and heavy maintenance capital.</p>
                </div>
                <div class="card">
                    <div class="card-icon">🏗️</div>
                    <h3>Construction</h3>
                    <p>Yellow iron financing, project-based working capital, and specialized masonry/paving equipment.</p>
                </div>
                <div class="card">
                    <div class="card-icon">💼</div>
                    <h3>Growth Capital</h3>
                    <p>Unsecured working capital for expanding businesses, inventory buys, and operational scaling.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="referral-section">
        <div class="container">
            <div class="section-header">
                <h2>Strategic Referral Partners</h2>
                <p style="color: var(--slate);">Darwin acts as the technical funding arm for professionals in these sectors:</p>
                <div class="divider"></div>
            </div>
            <div class="tag-container">
                <div class="tag">Certified Public Accountants</div>
                <div class="tag">Business Attorneys</div>
                <div class="tag">Bank Managers</div>
                <div class="tag">Commercial Realtors</div>
                <div class="tag">Equipment Dealers</div>
                <div class="tag">Insurance Brokers</div>
            </div>
        </div>
    </section>

    <section>
        <div class="container">
            <div class="section-header">
                <h2>Partner Toolkit</h2>
                <div class="divider"></div>
            </div>
            <div class="toolkit-container">
                <div class="toolkit-sidebar">
                    <ul>
                        <li>Local Market Angles</li>
                        <li>Outreach Scripts Preview</li>
                        <li>30-Day Launch Plan</li>
                        <li>Resource Downloads</li>
                    </ul>
                </div>
                <div class="toolkit-content">
                    <h3>Direct Outreach Script</h3>
                    <p style="color: var(--slate); margin-bottom: 1rem;">Use this template when introducing Darwin to a client or bank contact:</p>
                    <div class="script-box">
                        "I'm working closely with Darwin Hanneman—he's a commercial funding specialist who focuses on the relationship first rather than just lead chasing. He specializes in the [Industry] space and can usually find creative paths for equipment or capital that traditional banks might overlook. Would you be open to a 10-minute intro?"
                    </div>
                    
                    <h3 style="margin-top: 3rem;">30-Day Launch Roadmap</h3>
                    <div class="launch-plan">
                        <div class="phase">
                            <span class="phase-number">WEEK 1</span>
                            <h4>Identify Top 10</h4>
                            <p style="font-size: 0.8rem; color: var(--slate);">Pinpoint existing high-trust clients needing equipment.</p>
                        </div>
                        <div class="phase">
                            <span class="phase-number">WEEK 2</span>
                            <h4>The "Soft" Intro</h4>
                            <p style="font-size: 0.8rem; color: var(--slate);">Socialize the partnership via LinkedIn and direct email.</p>
                        </div>
                        <div class="phase">
                            <span class="phase-number">WEEK 3+</span>
                            <h4>Joint Reviews</h4>
                            <p style="font-size: 0.8rem; color: var(--slate);">Scheduled discovery calls with Darwin for active deals.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="contact-cta" id="contact">
        <div class="container">
            <h2>Ready to Fund More Deals?</h2>
            <p style="font-size: 1.2rem; margin-bottom: 3rem; opacity: 0.9;">Secure Darwin's expertise for your client base today.</p>
            <a href="mailto:darwin@example.com" class="btn btn-gold">Work With Darwin</a>
            <div style="margin-top: 2rem; font-size: 0.9rem; color: var(--gold);">Official Partner: Moonshine Capital</div>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2023 Darwin Hanneman. All Rights Reserved. Commercial Finance Specialist.</p>
            <p style="margin-top: 1rem; opacity: 0.5;">Brokerage services provided by Moonshine Capital. Financing subject to credit approval.</p>
        </div>
    </footer>
      ` }} />
    </main>
  );
}
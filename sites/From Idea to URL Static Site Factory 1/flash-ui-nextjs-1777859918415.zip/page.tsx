import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<div class="grid-overlay"></div>
    <div class="scanline"></div>

    <nav>
        <div class="logo">
            <span class="bolt"><i class="fas fa-bolt"></i></span> FLASH-UI // STATIC FACTORY
        </div>
        <div class="nav-links">
            <a href="#">Templates</a>
            <a href="#">Showcase</a>
            <a href="#">Docs</a>
            <a href="#">Pricing</a>
        </div>
        <div class="mono" style="font-size: 0.7rem; color: var(--accent);">
            <i class="fas fa-circle" style="font-size: 0.5rem; animation: pulse 2s infinite;"></i> LIVE_NODE: ONLINE
        </div>
    </nav>

    <header class="hero">
        <span class="section-tag">FROM IDEA TO URL</span>
        <h1>Turn one prompt into <span>deployable site files.</span></h1>
        <p>Describe your vision. Our AI architect constructs multiple static versions with clean code. Download as ZIP. Deploy anywhere.</p>

        <div class="prompt-container">
            <div class="prompt-header">
                <span><i class="fas fa-terminal"></i> AI_INPUT_MODULE</span>
                <span>v4.0.2-stable</span>
            </div>
            <textarea class="prompt-textarea" placeholder="Describe your site (e.g. 'A brutalist portfolio for a creative developer with dark mode and a glitched terminal header...')">Design a high-conversion landing page for a boutique coffee roaster called 'Volt Beans'. Industrial aesthetic, neon accents, and a complex subscription dashboard mockup.</textarea>
            <div class="prompt-footer">
                <div class="mono" style="font-size: 0.7rem; color: var(--text-muted);">
                    Shift + Enter to submit
                </div>
                <button class="btn-generate">Generate My Site <i class="fas fa-arrow-right"></i></button>
            </div>
        </div>
    </header>

    <section class="results-section">
        <span class="section-tag">// GENERATED_OUTPUT</span>
        <div class="output-grid">
            <!-- Card 1 -->
            <div class="version-card">
                <div class="version-preview">
                    <div class="preview-mock">
                        <div class="mock-hero" style="background: var(--accent); opacity: 0.2;"></div>
                        <div class="mock-line" style="width: 60%"></div>
                        <div class="mock-line" style="width: 40%"></div>
                        <div class="mock-line" style="width: 90%; margin-top: 10px;"></div>
                        <div style="display: flex; gap: 5px; margin-top: 10px;">
                            <div style="width: 30%; height: 40px; background: #222;"></div>
                            <div style="width: 30%; height: 40px; background: #222;"></div>
                            <div style="width: 30%; height: 40px; background: #222;"></div>
                        </div>
                    </div>
                </div>
                <div class="version-details">
                    <div class="version-meta">
                        <span class="version-title">Main Landing Page</span>
                        <span class="version-tag-ui">HTML / Tailwind</span>
                    </div>
                    <p style="font-size: 0.8rem; color: var(--text-muted);">Industrial layout with heavy typography and acid-green accents.</p>
                    <div class="zip-badge">
                        <i class="far fa-file-archive"></i> volt_beans_main_v1.zip (1.2MB)
                    </div>
                </div>
            </div>

            <!-- Card 2 -->
            <div class="version-card">
                <div class="version-preview">
                    <div class="preview-mock">
                        <div style="display: flex; height: 100%;">
                            <div style="width: 25%; border-right: 1px solid #333; padding-top: 10px;">
                                <div class="mock-line" style="width: 70%; margin-bottom: 5px;"></div>
                                <div class="mock-line" style="width: 50%; margin-bottom: 5px;"></div>
                            </div>
                            <div style="flex: 1; padding: 10px;">
                                <div class="mock-hero" style="height: 20px;"></div>
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 5px;">
                                    <div style="height: 40px; background: #222;"></div>
                                    <div style="height: 40px; background: #222;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="version-details">
                    <div class="version-meta">
                        <span class="version-title">Member Dashboard</span>
                        <span class="version-tag-ui">React Mockup</span>
                    </div>
                    <p style="font-size: 0.8rem; color: var(--text-muted);">Complex data visualization for coffee subscription tracking.</p>
                    <div class="zip-badge">
                        <i class="far fa-file-archive"></i> subscription_ui_assets.zip (4.5MB)
                    </div>
                </div>
            </div>

            <!-- Card 3 -->
            <div class="version-card">
                <div class="version-preview">
                    <div class="preview-mock" style="text-align: center; justify-content: center;">
                        <div class="mock-line" style="width: 20%; margin: 0 auto 10px;"></div>
                        <div class="mock-hero" style="height: 60px; width: 60%; margin: 0 auto;"></div>
                        <div class="mock-line" style="width: 40%; margin: 10px auto;"></div>
                    </div>
                </div>
                <div class="version-details">
                    <div class="version-meta">
                        <span class="version-title">Waitlist Funnel</span>
                        <span class="version-tag-ui">Pure HTML/CSS</span>
                    </div>
                    <p style="font-size: 0.8rem; color: var(--text-muted);">Single-page high-intent conversion funnel for mobile users.</p>
                    <div class="zip-badge">
                        <i class="far fa-file-archive"></i> waitlist_mobile_v2.zip (0.8MB)
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="use-cases">
        <div style="max-width: 1200px; margin: 0 auto;">
            <span class="section-tag">// USE_CASES</span>
            <div class="examples-scroll">
                <div class="example-prompt">
                    <strong>SaaS Dashboard</strong>
                    "A dark, sleek analytics dashboard for a crypto trading platform with real-time charts."
                </div>
                <div class="example-prompt">
                    <strong>Creative Portfolio</strong>
                    "A horizontal scrolling portfolio for a 3D artist with large imagery and minimal UI."
                </div>
                <div class="example-prompt">
                    <strong>E-Commerce</strong>
                    "A brutalist streetwear store with high contrast grids and bold typography."
                </div>
                <div class="example-prompt">
                    <strong>Mobile App Site</strong>
                    "A vibrant, gradient-heavy landing page for a fitness app with app store badges."
                </div>
            </div>
        </div>
    </section>

    <section class="pricing">
        <span class="section-tag">// ALLOCATION_PLANS</span>
        <div class="pricing-grid">
            <div class="price-card">
                <h3>SINGLE GEN</h3>
                <div class="cost">\$9</div>
                <ul>
                    <li><i class="fas fa-check"></i> 1 Prompt Input</li>
                    <li><i class="fas fa-check"></i> 3 Site Versions</li>
                    <li><i class="fas fa-check"></i> Raw ZIP Files</li>
                    <li><i class="fas fa-times" style="color: #444;"></i> Custom Branding</li>
                </ul>
                <button class="btn-generate" style="width: 100%; background: #222; color: #fff;">Get Started</button>
            </div>
            <div class="price-card popular">
                <div style="position: absolute; top: -12px; left: 50%; transform: translateX(-50%); background: var(--accent); color: #000; font-size: 0.6rem; padding: 2px 10px; font-weight: 900;">RECOMMENDED</div>
                <h3>CREATOR</h3>
                <div class="cost">\$29</div>
                <ul>
                    <li><i class="fas fa-check"></i> 10 Prompts / Mo</li>
                    <li><i class="fas fa-check"></i> 10 Versions per prompt</li>
                    <li><i class="fas fa-check"></i> Landing + Dashboard + Funnel</li>
                    <li><i class="fas fa-check"></i> Figma Export Beta</li>
                </ul>
                <button class="btn-generate" style="width: 100%;">Power Up</button>
            </div>
            <div class="price-card">
                <h3>STUDIO</h3>
                <div class="cost">\$99</div>
                <ul>
                    <li><i class="fas fa-check"></i> Unlimited Prompts</li>
                    <li><i class="fas fa-check"></i> Custom UI Kits</li>
                    <li><i class="fas fa-check"></i> GitHub Sync</li>
                    <li><i class="fas fa-check"></i> 24/7 Priority Support</li>
                </ul>
                <button class="btn-generate" style="width: 100%; background: #222; color: #fff;">Contact Us</button>
            </div>
        </div>
    </section>

    <section class="faq">
        <span class="section-tag">// SYSTEM_RESOURCES_FAQ</span>
        <div class="faq-item">
            <div class="faq-question">What format are the files in?</div>
            <div class="faq-answer">Every generation produces a clean ZIP containing production-ready HTML, CSS (Tailwind or Vanilla), and JS. No proprietary "builder" code.</div>
        </div>
        <div class="faq-item">
            <div class="faq-question">Can I use these for commercial projects?</div>
            <div class="faq-answer">Yes. Once you generate the files, you own them. No royalties, no attribution required.</div>
        </div>
        <div class="faq-item">
            <div class="faq-question">Do I need to know how to code?</div>
            <div class="faq-answer">Not to generate them, but you'll need a place to host them (like Vercel, Netlify, or your own server).</div>
        </div>
    </section>

    <footer class="final-cta">
        <div class="footer-logo">FLASH-UI</div>
        <h2 style="font-size: 3rem; margin-bottom: 2rem;">Ready to build?</h2>
        <button class="btn-generate" style="padding: 20px 60px; font-size: 1.2rem;">Generate My Site Now</button>
        <div class="mono" style="margin-top: 4rem; color: #333; font-size: 0.7rem;">
            &copy; 2024 FLASH-UI // FROM IDEA TO URL // ALL RIGHTS RESERVED
        </div>
    </footer>

    <script>
        // Subtle animation for the generate button
        document.querySelector('.btn-generate').addEventListener('mousedown', function() {
            this.style.transform = 'scale(0.98)';
        });
        document.querySelector('.btn-generate').addEventListener('mouseup', function() {
            this.style.transform = 'translateY(-2px)';
        });
    </script>
      ` }} />
    </main>
  );
}